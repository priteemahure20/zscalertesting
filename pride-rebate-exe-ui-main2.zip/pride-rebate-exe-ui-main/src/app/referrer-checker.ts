import { environment } from 'src/environments/environment';
import { APP_INITIALIZER } from '@angular/core';
export function referrerCheckerFactory() {
    return () => {
      const allowedReferrer = environment.prideUrl;
      const currentReferrer = document.referrer;
      console.log('currentReferrer', currentReferrer);
      console.log('allowedReferrer', allowedReferrer);
      if(environment.baseUrl=='http://localhost:5000') return true // for local testing purpose
      if (!currentReferrer || currentReferrer !== allowedReferrer) {
        window.location.href = allowedReferrer
      }
    };
  }

  export const referrerCheckerProvider = {
    provide: APP_INITIALIZER,
    useFactory: referrerCheckerFactory,
    multi: true
  };