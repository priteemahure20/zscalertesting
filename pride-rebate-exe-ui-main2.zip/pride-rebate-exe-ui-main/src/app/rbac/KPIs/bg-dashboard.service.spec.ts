import { TestBed } from '@angular/core/testing';

import { BgDashboardService } from './bg-dashboard.service';

describe('BgDashboardService', () => {
  let service: BgDashboardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BgDashboardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
