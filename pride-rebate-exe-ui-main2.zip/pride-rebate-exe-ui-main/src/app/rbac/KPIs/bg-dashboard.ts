import { rbacConfig } from "./kpi-config";

const canShowDisputeResolution = () => {
    const found: any = rbacConfig.KPI.find(r => r.name == 'Dispute Resolution');
    const UserType: any = localStorage.getItem('userType');
    const role = localStorage.getItem('role');
    if(Object.keys(found).includes(UserType) && found[UserType].includes(role)) {
        return true;
    }
    return false;
}
const canShowRebateLibrary = () => {
    return true;
}
const canShowRebateGovernance = () => {
    return true;
}
const canShowFinancialHealth = () => {
    return true;
}
const canShowRebateOptimization = () => {
    return true;
}
const canShowWeeklyLoginReport = () => {
    return true;
}

export {
    canShowDisputeResolution,
    canShowRebateLibrary,
    canShowRebateGovernance,
    canShowFinancialHealth,
    canShowRebateOptimization,
    canShowWeeklyLoginReport
}