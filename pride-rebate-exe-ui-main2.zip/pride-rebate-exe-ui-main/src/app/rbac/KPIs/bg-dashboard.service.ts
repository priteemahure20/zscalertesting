import { Injectable } from '@angular/core';
import { DataService } from 'src/app/services/data.service';
import { KPINames } from './constants';

import { find as _find, get as _get } from 'lodash';
import { AuthService } from 'src/app/services/auth.service';
import { User } from 'src/app/models/user.model';

@Injectable({
  providedIn: 'root'
})
export class BgDashboardService {

  constructor(private dataService: DataService, private authService:AuthService) { }

  canShowDisputeResolution = () => {
    console.log('this.dataService.roleBasedAccessConfig: ', this.dataService.roleBasedAccessConfig);
    const found: any = this.dataService.roleBasedAccessConfig?.KPI.find((r: { name: string; }) => r.name == KPINames.DisputeResolution);
    // const UserType: any = localStorage.getItem('userType');
    // const UserType: any = this.authService.getUser()?.userType;
    // // const role = this.authService.getUser()?.role;
    // const role = this.authService.getUser()?.role;
    const {userType:UserType,role} = this.authService.getUser() as User;
    if(UserType && Object.keys(found).includes(UserType) && found[UserType].includes(role)) {
        return true;
    }
    return false;
  }
  canShowRebateLibrary = () => {
    const found: any = this.dataService.roleBasedAccessConfig?.KPI.find((r: { name: string; }) => r.name == KPINames.RebateLibrary);
    // const UserType: any = localStorage.getItem('userType');
    // const UserType: any = this.authService.getUser()?.userType;
    // const role = this.authService.getUser()?.role;
    const {userType:UserType,role} = this.authService.getUser() as User;
    if(UserType && Object.keys(found).includes(UserType) && found[UserType].includes(role)) {
        return true;
    }
    return false;
  }
  canShowRebateGovernance = () => {
    const found: any = this.dataService.roleBasedAccessConfig?.KPI.find((r: { name: string; }) => r.name == KPINames.RebateGovernance);
    // const UserType: any = localStorage.getItem('userType');
    // const UserType: any = this.authService.getUser()?.userType;
    // const role = this.authService.getUser()?.role;
    const {userType:UserType,role} = this.authService.getUser() as User;
    if(UserType && Object.keys(found).includes(UserType) && found[UserType].includes(role)) {
        return true;
    }
    return false;
  }
  canShowFinancialHealth = () => {
    const found: any = this.dataService.roleBasedAccessConfig?.KPI.find((r: { name: string; }) => r.name == KPINames.FinancialHealth);
    // const UserType: any = localStorage.getItem('userType');
    // const UserType: any = this.authService.getUser()?.userType;
    // const role = this.authService.getUser()?.role;
    const {userType:UserType,role} = this.authService.getUser() as User;
    if(UserType && Object.keys(found).includes(UserType) && found[UserType].includes(role)) {
        return true;
    }
    return false;
  }
  canShowRebateOptimization = () => {
    const found: any = this.dataService.roleBasedAccessConfig?.KPI.find((r: { name: string; }) => r.name == KPINames.RebateOptimization);
    // const UserType: any = localStorage.getItem('userType');
    // const UserType: any = this.authService.getUser()?.userType;
    // const role = this.authService.getUser()?.role;
    const {userType:UserType,role} = this.authService.getUser() as User;
    if(UserType && Object.keys(found).includes(UserType) && found[UserType].includes(role)) {
        return true;
    }
    return false;
  }
  canShowWeeklyLoginReport = () => {
    const found: any = this.dataService.roleBasedAccessConfig?.KPI.find((r: { name: string; }) => r.name == KPINames.WeeklyLoginReport);
    // const UserType: any = localStorage.getItem('userType');
    // const UserType: any = this.authService.getUser()?.userType;
    // const role = this.authService.getUser()?.role;
    const {userType:UserType,role} = this.authService.getUser() as User;
    if(UserType && Object.keys(found).includes(UserType) && found[UserType].includes(role)) {
        return true;
    }
    return false;
  }

  canShowViewAllRebateProgramDetail = () => {
    console.log(this.dataService.roleBasedAccessConfig, 'check data');
    const data = _find(_get(this.dataService, 'roleBasedAccessConfig' ,[]), { module: 'DASHBOARD', page: 'FINANCIAL_HEALTH'});
    console.log(data, 'working');
    if (data) {
      const found: any = data?.kpi?.data?.find((r: { name: string; }) => r.name == KPINames.viewAllRebateDetails);
      // const UserType: any = localStorage.getItem('userType');
      // const UserType: any = this.authService.getUser()?.userType;
      // const role = this.authService.getUser()?.role;
      const {userType:UserType,role} = this.authService.getUser() as User;
      if(UserType && Object.keys(found).includes(UserType) && found[UserType].includes(role)) {
          return true;
      }
      
    }
    return false;
    
  }

}
