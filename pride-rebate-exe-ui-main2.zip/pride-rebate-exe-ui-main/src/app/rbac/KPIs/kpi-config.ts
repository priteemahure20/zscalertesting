// clean it, not required

import { Role, UserType } from "src/app/helpers/constants";

const rbacConfig = {
    "tenantName": "ND",
    "module": "Rebate Management",
    "page": "overview",
    "KPI": [
        {
            "name": "Dispute Resolution",
            [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
            [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
            [UserType.Distributor]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
        },
        {
            "name": "Rebate Library",
            "show": false
        },
        {
            "name": "Rebate Governance",
            "show": true
        },
        {
            "name": "Financial Health",
            "show": false
        },
        {
            "name": "Rebate Optimization",
            "show": false
        },
        {
            "name": "Weekly login report",
            "show": true
        }
    ]
};

export {
    rbacConfig
}
