enum KPINames {
    DisputeResolution = 'Dispute Resolution',
    RebateLibrary = 'Rebate Library',
    RebateGovernance = 'Rebate Governance',
    FinancialHealth = 'Financial Health',
    RebateOptimization = 'Rebate Optimization',
    WeeklyLoginReport = 'Weekly Login Report',
    viewAllRebateDetails = 'VIEW_ALL_REBATE_DETAILS',
}

export {
    KPINames
}