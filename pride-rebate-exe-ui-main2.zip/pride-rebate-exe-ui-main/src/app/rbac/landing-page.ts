import { UserType, Role } from "../helpers/constants";

const navs = [
    {
        name: 'My Dashboard',
        url: 'my-dashboard',
        icon:'dashboard',
        info:"This section is a one-stop shop for all your analytics requirements.",
        //userTypes: [UserType.Corporate,UserType.Distributor, UserType.Supplier], -> Hiding Supplier for current release
        userTypes: [UserType.Corporate,UserType.Distributor,UserType.Supplier],
        roles: {
          [UserType.Corporate]: [ Role.Admin,  Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate],
          [UserType.Supplier]: [Role.Admin,Role.SuperuserRebate,Role.ReportingLayerRebate,Role.ReportingLayerNonrebate],
          [UserType.Distributor]: [ Role.Admin, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserRebate]
        }
    },
    {
      name: 'Associate Management',
      url: 'associate-library',
        icon:'associate',
        info:"This section allows you to onboard and manage business associates.",
        userTypes: [UserType.Corporate],
        roles: {
          [UserType.Corporate]: [Role.Admin,Role.SuperuserRebate,Role.SuperuserNonrebate],
        }
    },
    {
        name: 'User Library',
        url: 'associate-users',
        icon:'user',
        info:"This section allows you to view corporate users as well as business associate users",
        userTypes: [UserType.Corporate,UserType.Distributor, UserType.Supplier],
        roles: {
          [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
          [UserType.Supplier]: [Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
          [UserType.Distributor]: [Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
        }
    },
    // {
    //   name: 'Rebate Management',
    //   url: 'rebateManagement/bg-dashboard',
    //     icon:'rebate',
    //     info:"Everything you need to know about the Rebate Programs and people involved.",
    //     userTypes: [UserType.Corporate],
    //     roles: {
    //       [UserType.Corporate]: [Role.Admin, Role.SuperuserRebate, Role.DataLayerRebate],
    //     }

    // },
    // {
    //   name: 'Report Generator',
    //   url: 'report-generator',
    //     icon:'report-generator',
    //     info:"Everything you need to know about the Rebate Programs and people involved.",
    //     userTypes: [UserType.Corporate],
    //     roles: {
    //       [UserType.Corporate]: [Role.Admin, Role.SuperuserRebate, Role.DataLayerRebate],
    //     }

    // },
    {
      name: 'Rebate Management',
      url: 'rebateManagement/bg-view',
        icon:'rebate',
        info:"This section enables you to interact with vendors and create, view and edit rebate programs",
        userTypes: [UserType.Corporate],
        roles: {
          [UserType.Corporate]: [Role.Admin,Role.SuperuserRebate, Role.DataLayerRebate],
        }
    },
    {
      name: 'Payment Management',
      url: 'payment',
        icon:'rebate',
        info:"This section enables you to create and view payment events",
        userTypes: [UserType.Corporate],
        roles: {
          [UserType.Corporate]: [Role.Admin,Role.SuperuserRebate, Role.DataLayerRebate],
        }
    },
    {
      name: 'Rebate Library',
      url: 'rebateManagement/distributor-base-programs',
        icon: 'rebate',
        info:"Everything you need to know about the Rebate Programs and people involved.",
        userTypes: [UserType.Distributor],
        roles: {
          [UserType.Distributor]: [Role.Admin, Role.SuperuserRebate, Role.DataLayerRebate],
        }
    },
    {
      name: 'Data Management',
      url: 'file-management',
        icon:'database-management',
        info:"This section enables to upload the product catalog and view transaction pull details",
        userTypes: [UserType.Corporate],
        roles: {

          [UserType.Corporate]: [ Role.Admin,Role.SuperuserRebate,Role.SuperuserNonrebate,Role.DataLayerNonrebate,Role.DataLayerRebate ],

        }
    },
    {
      name: 'Payout Management',
      url: 'payoutManagement',
        icon:'payout-management',
        info:"This section enables you to create and view payout events",
        userTypes: [UserType.Corporate],
        roles: {
          [UserType.Corporate]: [Role.Admin, Role.SuperuserRebate, Role.DataLayerRebate],
        }
    },
  ]

  export {
      navs
  }
