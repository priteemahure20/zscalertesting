import { Role, UserType } from "src/app/helpers/constants";
import { get as _get } from "lodash";

const canShowFinancialHealth = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate, Role.DataLayerNonrebate, Role.DataLayerRebate ],
    // [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
    // [UserType.Distributor]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
}

const canShowRebateOptimization = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate ],
    // [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
    // [UserType.Distributor]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
}

const canShowWeeklyLoginReport = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate, Role.ReportingLayerRebate, Role.ReportingLayerNonrebate ],
    // [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
    // [UserType.Distributor]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
}

const canShowFinancialHealthService = (userType: any, role: any) => {
    const rolesCanAccess = _get(canShowFinancialHealth, `${userType}`);
    // console.log(rolesCanAccess, rolesCanAccess.includes(role), role, userType, '================service role access===========');
    if (rolesCanAccess.includes(role)) return true;
    return false;

};

const canShowRebateOptimizationService = (userType: any, role: any) => {
    const rolesCanAccess = _get(canShowRebateOptimization, `${userType}`);
    if (rolesCanAccess.includes(role)) return true;
    return false;

};

const canShowWeeklyLoginReportService = (userType: any, role: any) => {
    const rolesCanAccess = _get(canShowWeeklyLoginReport, `${userType}`);
    if (rolesCanAccess.includes(role)) return true;
    return false;

};


export {
   canShowFinancialHealth,
   canShowWeeklyLoginReport,
   canShowRebateOptimization,
   canShowFinancialHealthService,
   canShowWeeklyLoginReportService,
   canShowRebateOptimizationService
}
