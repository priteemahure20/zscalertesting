import { Role, UserType } from "src/app/helpers/constants";
import { get as _get } from "lodash";

const regionWiseTransaction = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate ],
    // [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
    // [UserType.Distributor]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
};
const dashboardTiles = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate ],
}

const trendChart = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate ],
}

const topRebate = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate ],
}

const supplierWithoutData = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate, Role.DataLayerNonrebate, Role.DataLayerRebate ],
}

// const canShowRebateOptimization = {
//     [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate ],
//     // [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
//     // [UserType.Distributor]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
// }

// const canShowWeeklyLoginReport = {
//     [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate, Role.ReportingLayerRebate, Role.ReportingLayerNonrebate ],
//     // [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
//     // [UserType.Distributor]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
// }

const canShowKPI = (accessRole: any, userType: any, role: any) => {
    const rolesCanAccess = _get(accessRole, `${userType}`);
    // console.log(rolesCanAccess, rolesCanAccess.includes(role), role, userType, '================service role access===========');
    if (rolesCanAccess.includes(role)) return true;
    return false;

};

// const canShowRebateOptimizationService = (userType: any, role: any) => {
//     const rolesCanAccess = _get(canShowRebateOptimization, `${userType}`);
//     if (rolesCanAccess.includes(role)) return true;
//     return false;

// };

// const canShowWeeklyLoginReportService = (userType: any, role: any) => {
//     const rolesCanAccess = _get(canShowWeeklyLoginReport, `${userType}`);
//     if (rolesCanAccess.includes(role)) return true;
//     return false;

// };


export {
    regionWiseTransaction,
    dashboardTiles,
    trendChart,
    topRebate,
    supplierWithoutData,
    canShowKPI
}
