class Roles {
    canEdit() {
        return true;
    }
    canDelete() {
        return true;
    }
}