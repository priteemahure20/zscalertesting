import { Role, UserType } from "src/app/helpers/constants"

const editAssignedTo = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
    [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
    [UserType.Distributor]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
}

const deleteAssingedTo = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
    [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
    [UserType.Distributor]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
}

const changeDropdown = {
    [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
    [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
    [UserType.Distributor]: [ Role.SuperuserRebate, Role.SuperuserNonrebate ],
}

export {
    editAssignedTo,
    deleteAssingedTo,
    changeDropdown
}