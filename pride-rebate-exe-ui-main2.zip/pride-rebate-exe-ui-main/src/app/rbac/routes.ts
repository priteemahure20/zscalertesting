import {Role, UserType} from '../helpers/constants';

// Object.freeze(obj): Forbids adding/removing/changing of properties. Sets configurable: false, writable: false for all existing properties.
const rbac = Object.freeze({
    AssociateUserManagement: {
        [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
        [UserType.Supplier]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
        [UserType.Distributor]: [Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
    },
    AssociateUserCreate: {
        [UserType.Corporate]: [Role.Admin,Role.SuperuserRebate,Role.SuperuserNonrebate],
        [UserType.Supplier]: [Role.Admin,Role.SuperuserRebate,Role.SuperuserNonrebate],
        [UserType.Distributor]: [Role.Admin,Role.SuperuserRebate,Role.SuperuserNonrebate],
    },
    AssociateLibrary: {
        [UserType.Corporate]: [Role.Admin,Role.SuperuserRebate,Role.SuperuserNonrebate],
    },
    ReportGenerator: {
        [UserType.Corporate]: [Role.Admin,Role.SuperuserRebate,Role.SuperuserNonrebate],
    },
    AssociateCreate: {
        [UserType.Corporate]: [Role.Admin,Role.SuperuserRebate,Role.SuperuserNonrebate],
    },
    AssociateEdit: {
        [UserType.Corporate]: [Role.Admin,Role.SuperuserRebate,Role.SuperuserNonrebate],
    },
    FileManagement: {
        [UserType.Corporate]: [ Role.Admin, Role.Dashboard, Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate ],
        [UserType.Supplier]: [ Role.Admin,Role.SuperuserRebate,Role.SuperuserNonrebate,Role.DataLayerNonrebate,Role.DataLayerRebate ],
        [UserType.Distributor]: [ Role.SuperUser, Role.Admin, Role.Dashboard, Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate ],
    },
    Home: {
        [UserType.Corporate]: [Role.SuperUser, Role.Admin, Role.Dashboard, Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate],
        [UserType.Supplier]: [Role.SuperUser, Role.Admin, Role.Dashboard, Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate],
        [UserType.Distributor]: [Role.SuperUser, Role.Admin, Role.Dashboard, Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate]
    },
    SupplierRebateMgmt: {
       // [UserType.Supplier]: [Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate],
        [UserType.Supplier]: [Role.Admin,Role.SuperuserRebate, Role.DataLayerRebate],

    },
    DistributorRebateMgmt: {
        [UserType.Distributor]: [Role.Admin, Role.SuperuserRebate, Role.DataLayerRebate],
    },
    CorporateRebateMgmt: {
        [UserType.Corporate]: [Role.Admin, Role.SuperuserRebate, Role.DataLayerRebate],
    },
    FinancialHealth: {
        // [UserType.Corporate]: [Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate],
        [UserType.Corporate]: [Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate, Role.DataLayerNonrebate, Role.DataLayerRebate]
    },

    SupplierWithoutData: {
       
        [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate, Role.DataLayerNonrebate, Role.DataLayerRebate ]
    },
   
    TopRebatePayingSuppliers: {
        [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate ]
    },
    RebateOptimization: {
        [UserType.Corporate]: [Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate],
    },
    RebateOptimizationDealr: {
        [UserType.Corporate]: [Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate],
        [UserType.Distributor]: [Role.SuperUser, Role.Admin, Role.Dashboard, Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate]
    },
    WeeklyLoginReport: {
        [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate, Role.ReportingLayerRebate, Role.ReportingLayerNonrebate ],
    },
    rebateLibrary: {
        [UserType.Corporate]: [ Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate ],
        [UserType.Supplier]: [ Role.SuperuserRebate, Role.SuperuserNonrebate, Role.Admin ],
        [UserType.Distributor]: [Role.SuperUser, Role.Admin, Role.Dashboard, Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate]

    },
    myDashboard:{
        // [UserType.Corporate]: [ Role.Admin, Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate],
        // [UserType.Supplier]: [Role.Admin,Role.SuperuserRebate,Role.ReportingLayerRebate,Role.ReportingLayerNonrebate],
        // [UserType.Distributor]: [Role.SuperUser, Role.Admin, Role.Dashboard, Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate]

        [UserType.Corporate]: [ Role.Admin,  Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate],
        [UserType.Supplier]: [Role.Admin,Role.SuperuserRebate,Role.ReportingLayerRebate,Role.ReportingLayerNonrebate],
        [UserType.Distributor]: [ Role.Admin, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserRebate]
    },
    supplierDashboard:{
        [UserType.Supplier]: [ Role.SuperUser, Role.Admin, Role.Dashboard, Role.DataLayerNonrebate, Role.DataLayerRebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate, Role.SuperuserNonrebate, Role.SuperuserRebate ],
    },

    DistributorFinancialHealth: {
        // [UserType.Corporate]: [Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate],
        [UserType.Distributor]: [Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate, Role.DataLayerNonrebate, Role.DataLayerRebate]
    },
    DistributorRebateOptimization: {
        // [UserType.Corporate]: [Role.Admin, Role.SuperuserRebate, Role.SuperuserNonrebate, Role.ReportingLayerNonrebate, Role.ReportingLayerRebate],
        [UserType.Distributor]: [Role.Admin, Role.SuperuserRebate, Role.ReportingLayerRebate, Role.DataLayerNonrebate, Role.DataLayerRebate]
    },
});

export {
    rbac
}
