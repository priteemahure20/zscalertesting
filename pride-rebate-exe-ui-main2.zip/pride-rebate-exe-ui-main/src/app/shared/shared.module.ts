import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../shared/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterModule } from '@angular/router';
import { ShortNumberPipe } from '../pipes/short-number.pipe';
import {NgMultiSelectDropDownModule} from 'ng-multiselect-dropdown';
import {MultiSelectDropdownComponent} from '../common/multi-select-dropdown/multi-select-dropdown.component';
import {
  ProgramCompareComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/add-to-compare/program-compare/program-compare.component';
import {TextModifyPipe} from '../pipes/text-modify.pipe';
import { OtherPipe } from '../pipes/other.pipe';

@NgModule({
  declarations: [
    ShortNumberPipe,
    MultiSelectDropdownComponent,
    TextModifyPipe,
    OtherPipe
  ],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    RouterModule,
    NgMultiSelectDropDownModule.forRoot()

  ],
  entryComponents: [
 ],
  exports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    ShortNumberPipe,
    MultiSelectDropdownComponent,
    TextModifyPipe,
    OtherPipe
  ]
})
export class SharedModule { }
