import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { ButtonComponent } from '../common/button/button.component';
import { NoDataComponent } from '../common/no-data/no-data.component';
import { ProgressBarComponent } from '../common/progress-bar/progress-bar.component';
import { SelectComponent } from '../common/table-hist/select/select.component';
import { TableHistComponent } from '../common/table-hist/table-hist.component';
import { SharedModule } from './shared.module';
import { InputFieldComponent } from '../common/input-field/input-field.component';
import { ToggleSwitchComponent } from '../common/toggle-switch/toggle-switch.component';
import { HierarchicalTableComponent } from '../common/hierarchical-table/hierarchical-table.component';
import { PaginatorDirective } from '../common/pagination/pagination.directive';
import { SubmitButtonComponent } from '../common/submit-button/submit-button.component';
import { Pagination } from '../common/pagination/pagination.component';
import { ModelInputFieldComponent } from '../common/model-input-field/model-input-field.component';
import { FileUploadComponent } from '../common/file-upload/file-upload.component';
import { LineChartComponent } from '../common/line-chart/line-chart.component';
import { ChartsModule } from 'ng2-charts';
import { D3PieComponent } from 'src/app/common/d3-pie/d3-pie.component';
import { LightTableComponent } from '../common/light-table/light-table.component';
import { YearSelectDropdownComponent } from '../common/year-select-dropdown/year-select-dropdown.component';
import {AutoSuggestionInputComponent} from '../common/auto-suggestion-input/auto-suggestion-input.component';
import { AggrementProgramsComponent } from '../common/aggrement-programs/aggrement-programs.component';
import { DynamicFormFieldComponent } from '../common/dynamic-form-field/dynamic-form-field.component';
import {
  ProgramCompareComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/add-to-compare/program-compare/program-compare.component';
import {
  BasicInformationDetailsComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/basic-information-details/basic-information-details.component';
import {
  CalculationDetailsComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/calculation-details/calculation-details.component';
import {
  CriteriaTierViewDetailsComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/calculation-details/criteria-tier-view-details/criteria-tier-view-details.component';
import {
  DistributorsListViewComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/distributors-list-view/distributors-list-view.component';
import {
  DistributorsCountViewComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/distributors-count-view/distributors-count-view.component';
import {
  SpecialConditionsDetailsComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/special-conditions-details/special-conditions-details.component';
import {
  CatalogSelectionViewComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/catalog-selection-view/catalog-selection-view.component';
import {
  SpecialConditionBaselineComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/special-condition-baseline/special-condition-baseline.component';
import {
  AddToCompareComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/add-to-compare/add-to-compare.component';
import {
  ProgramListComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/add-to-compare/program-list/program-list.component';
import {
  FilterProgramDetailsComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/add-to-compare/filter-program-details/filter-program-details.component';
import {
  ViewDataListModalComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/view-data-list-modal/view-data-list-modal.component';
import {ExportModalComponent} from '../views/rebate-management/financial-health/rebate-details-program/export-modal/export-modal.component';
import {
  ViewMoreDataModalComponent
} from '../views/rebate-management/financial-health/rebate-details-program/view-more-data-modal/view-more-data-modal.component';
import {CreateProgramComponent} from '../views/rebate-management/supplier-rebate-mgmt/create-program/create-program.component';
import {
  SaveAndContinueComponent
} from '../views/rebate-management/supplier-rebate-mgmt/create-program/save-and-continue/save-and-continue.component';
import {AddSegmentComponent} from '../views/rebate-management/supplier-rebate-mgmt/create-program/add-segment/add-segment.component';
import {
  SegmentDistributorsComponent
} from '../views/rebate-management/supplier-rebate-mgmt/create-program/segment-distributors/segment-distributors.component';
import {
  SupplierWarningModalComponent
} from '../views/rebate-management/supplier-rebate-mgmt/create-program/supplier-warning-modal/supplier-warning-modal.component';
import {
  AddDistributorComponent
} from '../views/rebate-management/supplier-rebate-mgmt/create-program/add-distributor/add-distributor.component';
import {
  DistributorFilterModalComponent
} from '../views/rebate-management/supplier-rebate-mgmt/create-program/distributor-filter-modal/distributor-filter-modal.component';
import {StepperComponentComponent} from '../views/rebate-management/supplier-rebate-mgmt/stepper-component/stepper-component.component';
import {ProgramCreationComponent} from '../views/rebate-management/supplier-rebate-mgmt/program-creation/program-creation.component';
import {CatalogSelectionComponent} from '../views/rebate-management/supplier-rebate-mgmt/catalog-selection/catalog-selection.component';
import {
  SelectionDataListsComponent
} from '../views/rebate-management/supplier-rebate-mgmt/selection-data-lists/selection-data-lists.component';
import {
  ParticipatingDistributorComponent
} from '../views/rebate-management/supplier-rebate-mgmt/create-program/participating-distributor/participating-distributor.component';
import {
  SupplierDynamicFormComponent
} from '../views/rebate-management/supplier-rebate-mgmt/supplier-dynamic-form/supplier-dynamic-form.component';
import {CalculationsComponent} from '../views/rebate-management/supplier-rebate-mgmt/calculations/calculations.component';
import {
  CriteriaTierCreationComponent
} from '../views/rebate-management/supplier-rebate-mgmt/calculations/criteria-tier-creation/criteria-tier-creation.component';
import {
  CriteriaModalComponent
} from '../views/rebate-management/supplier-rebate-mgmt/calculations/criteria-tier-creation/criteria-modal/criteria-modal.component';
import {
  RebateConfigurationComponent
} from '../views/rebate-management/supplier-rebate-mgmt/rebate-configuration/rebate-configuration.component';
import {SpecialConditionsComponent} from '../views/rebate-management/supplier-rebate-mgmt/special-conditions/special-conditions.component';
import {
  SelectCategoriesComponent
} from '../views/rebate-management/supplier-rebate-mgmt/supplier-dynamic-form/select-categories/select-categories.component';
import {
  CategoriesViewComponent
} from '../views/rebate-management/supplier-rebate-mgmt/special-conditions/categories-view/categories-view.component';
import { BaselineFileUploadComponent } from '../views/rebate-management/supplier-rebate-mgmt/special-conditions/manual-base-line/baseline-file-upload/baseline-file-upload.component';
import {
  DependencyComponent
} from '../views/rebate-management/supplier-rebate-mgmt/special-conditions/dependency/dependency.component';
import {
  ManualBaseLineComponent
} from '../views/rebate-management/supplier-rebate-mgmt/special-conditions/manual-base-line/manual-base-line.component';
import {
  BaseLineViewComponent
} from '../views/rebate-management/supplier-rebate-mgmt/special-conditions/manual-base-line/base-line-view/base-line-view.component';
import { CatalogAndVendorViewComponent } from '../views/rebate-management/rebate-library/rebate-library-program-details/special-conditions-details/catalog-and-vendor-view/catalog-and-vendor-view.component';
import {VerticalChordsComponent} from '../common/vertical-chords/vertical-chords.component';
import {FixedDecimalPipe} from '../pipes/fixed-decimal.pipe';
import {CurrencyPipe} from '../pipes/currency.pipe';
import { DatePipe } from '@angular/common';
import {
  CatalogVendorViewModalComponent
} from '../views/rebate-management/rebate-library/rebate-library-program-details/special-conditions-details/catalog-vendor-view-modal/catalog-vendor-view-modal.component';
import { MessageDialog } from '../common/message-dialog/message-dialog.component';
import { ColumnTextFilterComponent } from '../common/table-components/column-text-filter/column-text-filter.component';
import { TablePaginationComponent } from '../common/table-components/table-pagination/table-pagination.component';
import { CheckboxDirective } from '../common/directives/checkbox.directive';
import { FormFieldDirective } from '../common/directives/form-field.directive';
import { FormFieldAsButtonDirective } from '../common/directives/form-field-as-button.directive';
import { StatusDirective } from '../common/directives/status.directive';
import { PercentPipe } from '../pipes/percent.pipe';
import { LastUpdateDateComponent } from '../common/last-update-date/last-update-date.component';
//import {TabModalComponent} from '../views/rebate-management/supplier-rebate-mgmt/calculations/tab-modal/tab-modal.component';
@NgModule({
  declarations: [
    TableHistComponent,
    ButtonComponent,
    ProgressBarComponent,
    SelectComponent,
    NoDataComponent,
    InputFieldComponent,
    ToggleSwitchComponent,
    FileUploadComponent,
    LineChartComponent,
    D3PieComponent,
    Pagination,
    PaginatorDirective,
    ModelInputFieldComponent,
    HierarchicalTableComponent,
    SubmitButtonComponent,
    LightTableComponent,
    YearSelectDropdownComponent,
    AutoSuggestionInputComponent,
    AggrementProgramsComponent,
    DynamicFormFieldComponent,
    ProgramCompareComponent,
    BasicInformationDetailsComponent,
    CalculationDetailsComponent,
    CriteriaTierViewDetailsComponent,
    DistributorsListViewComponent,
    DistributorsCountViewComponent,
    SpecialConditionsDetailsComponent,
    CatalogSelectionViewComponent,
    CatalogAndVendorViewComponent,
    SpecialConditionBaselineComponent,
    AddToCompareComponent,
    ProgramListComponent,
    FilterProgramDetailsComponent,
    ViewDataListModalComponent,
    ExportModalComponent,
    ViewMoreDataModalComponent,
    CreateProgramComponent,
    SaveAndContinueComponent,
    AddSegmentComponent,
    SegmentDistributorsComponent,
    SupplierWarningModalComponent,

    AddDistributorComponent,
    DistributorFilterModalComponent,
    StepperComponentComponent,
    ProgramCreationComponent,
    CatalogSelectionComponent,
    SelectionDataListsComponent,
    CatalogSelectionComponent,
    ParticipatingDistributorComponent,
    SupplierDynamicFormComponent,
    CalculationsComponent,
    CriteriaTierCreationComponent,
    CriteriaModalComponent,
    RebateConfigurationComponent,
    SpecialConditionsComponent,
    SelectCategoriesComponent,
    CategoriesViewComponent,
    ManualBaseLineComponent,
    BaselineFileUploadComponent,
    DependencyComponent,
    BaseLineViewComponent,
    VerticalChordsComponent,
    // TabModalComponent,
    FixedDecimalPipe,
    CurrencyPipe,
    CatalogVendorViewModalComponent,
    MessageDialog,
    ColumnTextFilterComponent,
    TablePaginationComponent,
    CheckboxDirective,
    FormFieldDirective,
    FormFieldAsButtonDirective,
    StatusDirective,
    PercentPipe,
    LastUpdateDateComponent
  ],
  imports: [
    SharedModule,
    ChartsModule,
    NgSelectModule,

  ],
  entryComponents: [
 ],
  exports: [
    TableHistComponent,
    ButtonComponent,
    ProgressBarComponent,
    SelectComponent,
    NoDataComponent,
    InputFieldComponent,
    ToggleSwitchComponent,
    FileUploadComponent,
    LineChartComponent,
    D3PieComponent,
    ChartsModule,
    Pagination,
    PaginatorDirective,
    ModelInputFieldComponent,
    HierarchicalTableComponent,
    SubmitButtonComponent,
    LightTableComponent,
    YearSelectDropdownComponent,
    AutoSuggestionInputComponent,
    AggrementProgramsComponent,
    DynamicFormFieldComponent,
    ProgramCompareComponent,
    BasicInformationDetailsComponent,
    CalculationDetailsComponent,
    CriteriaTierViewDetailsComponent,
    DistributorsListViewComponent,
    DistributorsCountViewComponent,
    SpecialConditionsDetailsComponent,
    CatalogSelectionViewComponent,
    CatalogAndVendorViewComponent,
    SpecialConditionBaselineComponent,
    AddToCompareComponent,
    ProgramListComponent,
    FilterProgramDetailsComponent,
    ViewDataListModalComponent,
    ExportModalComponent,
    ViewMoreDataModalComponent,
    CreateProgramComponent,
    SaveAndContinueComponent,
    AddSegmentComponent,
    SegmentDistributorsComponent,
    SupplierWarningModalComponent,

    AddDistributorComponent,
    DistributorFilterModalComponent,
    StepperComponentComponent,
    ProgramCreationComponent,
    CatalogSelectionComponent,
    SelectionDataListsComponent,
    CatalogSelectionComponent,
    ParticipatingDistributorComponent,
    SupplierDynamicFormComponent,
    CalculationsComponent,
    CriteriaTierCreationComponent,
    CriteriaModalComponent,
    RebateConfigurationComponent,
    SpecialConditionsComponent,
    SelectCategoriesComponent,
    CategoriesViewComponent,
    ManualBaseLineComponent,
    BaselineFileUploadComponent,
    DependencyComponent,
    BaseLineViewComponent,
    VerticalChordsComponent,
    // TabModalComponent,
    FixedDecimalPipe,
    CurrencyPipe,
    CatalogVendorViewModalComponent,
    MessageDialog,
    ColumnTextFilterComponent,
    TablePaginationComponent,
    CheckboxDirective,
    FormFieldDirective,
    FormFieldAsButtonDirective,
    StatusDirective,
    PercentPipe,
    LastUpdateDateComponent

  ],

  providers:[DatePipe]

})
export class CommonCompsModule { }
