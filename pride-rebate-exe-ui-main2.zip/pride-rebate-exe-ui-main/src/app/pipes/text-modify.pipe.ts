import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'underscore'
})
export class TextModifyPipe implements PipeTransform {
    transform(value:string): any {
        if(value){
            return value.replace(/_+/g, ' ');;
        }else{
            return value
        }
    }
}
