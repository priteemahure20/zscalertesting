import { Pipe, PipeTransform } from '@angular/core';

/**
 * Use currencyPipe to format value to currency.
 */
@Pipe({
    name: 'currencyPipe'
})
export class CurrencyPipe implements PipeTransform {

    /**
     * Currency value transformer function.
     * @param value Percent Value.
     * @param currency 
     * @param maximumFractionDigits Maximum number of decimal places to show, defaults to 0. 
     * @param minimumFractionDigits Minimum number of decimal places to show, defaults to 0.
     * @param countryCode Country for Regional formatting, defaults to US.
     * @returns Formatted string as currency with regional digit grouping.
     */
    transform(value: any, currency: string = 'USD', maximumFractionDigits: number = 0, minimumFractionDigits: number = 0, countryCode: string = 'US'): string {
        if (value || value === 0) {
            return new Intl.NumberFormat(`en-${countryCode}`, { style: "currency", currency, maximumFractionDigits, minimumFractionDigits }).format(value);
        }
        return '';
    }

}
