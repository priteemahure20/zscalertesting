import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'fixedDecimal'
})
export class FixedDecimalPipe implements PipeTransform {
    transform(data:any): any {
        if(data || data==0){
            if(!Number.isInteger(data)){
                return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed();
            }else{
                return data
            }
        }
    }
}
