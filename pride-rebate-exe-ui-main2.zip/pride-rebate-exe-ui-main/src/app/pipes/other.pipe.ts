import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'other'
})
export class OtherPipe implements PipeTransform {
  transform(value:string): any {
    if(value.toLowerCase() === 'all'){
      return 'All';
    }else{
      return value;
    }
  }
}
