import { Pipe, PipeTransform } from '@angular/core';

/**
 * Use percentPipe to format value to percentage.
 */
@Pipe({
  name: 'percentPipe'
})
export class PercentPipe implements PipeTransform {

  /**
   * Percent value transformer function.
   * @param value Percent Value.
   * @param maximumFractionDigits Maximum number of decimal places to show, defaults to 2. 
   * @param minimumFractionDigits Minimum number of decimal places to show, defaults to 0.
   * @param countryCode Country for Regional formatting, defaults to US.
   * @returns Formatted string as percentage with regional digit grouping.  
   */
  transform(value: number, maximumFractionDigits: number = 2, minimumFractionDigits: number = 0, countryCode: string = 'US'): string {
    if (value || value === 0) {
      return new Intl.NumberFormat(`en-${countryCode}`, { style: 'percent', maximumFractionDigits, minimumFractionDigits }).format(value / 100);
    }
    return new Intl.NumberFormat(`en-${countryCode}`, { style: 'percent', maximumFractionDigits, minimumFractionDigits }).format(0);
  }

}
