import { OtherPipe } from './other.pipe';

describe('OtherPipe', () => {
  it('create an instance', () => {
    const pipe = new OtherPipe();
    expect(pipe).toBeTruthy();
  });
});
