import { SelectionModel } from '@angular/cdk/collections';
import { AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, EventEmitter, HostListener, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatIconRegistry } from '@angular/material/icon';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { DomSanitizer } from '@angular/platform-browser';
import { Subject,of } from 'rxjs';
import * as d3 from 'd3';
import { HttpService } from 'src/app/services/http.service';
import { get as _get, reduce as _reduce, isEqual as _isEqual } from 'lodash';
import { ThrowStmt } from '@angular/compiler';
import * as moment from 'moment';
import { CONSTANTS } from 'src/app/helpers/constants';
import { MatMenuTrigger } from '@angular/material/menu';
import { debounceTime, delay, distinctUntilChanged, map, mergeMap } from 'rxjs/operators';
import { MatDatepicker } from '@angular/material/datepicker';
import { DatePipe } from '@angular/common';
import {MatTableDataSource} from '@angular/material/table';
@Component({
  selector: 'app-table-hist',
  templateUrl: './table-hist.component.html',
  styleUrls: ['./table-hist.component.scss']
})
export class TableHistComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator | undefined;
  // @ViewChild(MatSort) sort: MatSort | undefined;
  @ViewChild(MatSort, {static: false}) sort: MatSort | undefined;
  // @ViewChild('picker') datePicker: MatDatepicker<Date> | undefined;
  // onChange(value:any) {
  //   if (value === 'someValue') {
  //     this.datePicker.open();
  //   }
  // }
  @ViewChild(MatMenuTrigger,{ read: MatMenuTrigger })
  contextMenu: MatMenuTrigger | undefined;
  public keyUp = new Subject<KeyboardEvent>();
  @Input() tableName: string | undefined;
  @Input() name: string | undefined;
  @Input() searchPlaceholder: string | undefined;
  data: any;
  editList: any = [];
  date:any;
  newSupplierValue: any;
  newClassificationFlag: any = 1;
  dropdownSelectedValue: any;
  tableLength: number = 0;
  @Input() removeExcessTierToggle = false;
  newSupplierName: any;
  tableRowsCount: any;
  extraDataOriginal: any;
  supplierDropdownOriginal: any;
  filterValue: any;
  options: any = []
  showCloseIcon:boolean = false;
  datePlaceholder: any ='Search by date';
  searchIconProduct: string = 'search-icon-product';
  searchIconPivot: string = 'search-icon-pivot';
  // @ViewChild("tierToggleElement") ref: ElementRef;

  @Input() set dataSource(value: any) {
    this.data = value;
    this.data?.sort ? this.data.sort = this.sort:
    // console.log('selection: ', this.selection.selected);
    this.selection.clear();
    // console.log('selection: ', this.selection.selected);
    if (this.dataType != 'invoice' &&
      this.dataType != 'purchaseOrder' &&
      this.dataType != 'product' &&
      this.dataType != 'supplier-classification' &&
      this.dataType != 'missedOppurtunity' && this.dataType != 'inGroup' && 
      this.dataType != 'inGroupSummary' && this.dataType !='rebateProductCategory' && 
      this.dataType != 'rebateSummary' && this.dataType != 'userManagement' && this.dataType != 'historyTable'
    ) {
      //  this.data.paginator = this.paginator;
      this.data?.paginator ? this.data.paginator = this.paginator:'';
      // this.data?.paginator ? this.data.paginator = this.paginator:,
    }
    // in search cases (e.g., member product categorization), paginator reset required
    // for paginator reset, 
    // this.data.paginator = this.paginator;
    // this.tableCount should also be updated

  }
  
  @Input() columnsToDisplay: any;
  @Input() columnsProps: any;
  @Input() showTools: any;
  @Input() showButton: any;
  @Input() buttonLabel: string = 'Save';
  @Input() showSearch: any;
  @Input() dataType: any;
  @Input() extraData: any;
  @Input() searchValue: any;
  @Input() isSortApplied: Subject<any> | undefined;
  @Input() set tableCount(value: any) {
    this.tableRowsCount = value;
  }
  @Input() statusData: any;
  @Output() addClick = new EventEmitter<any>();
  @Output() removeExcessTierEvent = new EventEmitter<any>();
  @Output() deleteClick = new EventEmitter<any>();
  @Output() saveClick = new EventEmitter<any>();
  @Output() selectedRowData = new EventEmitter<any>();
  @Output() download = new EventEmitter<any>();
  @Output() selectedIngroup = new EventEmitter<any>();
  @Output() supplierClassificationUpdate = new EventEmitter<any>();
  @Output() getNextPage = new EventEmitter<any>();
  @Output() filterColumnValue = new EventEmitter();
  @Output() filteredValues = new EventEmitter<any>();
  @Output() filterStatus = new EventEmitter<any>()
  @Output() sortDataEvent = new EventEmitter();
  stateDisabled = true;
  public isDisabledDate: boolean = true;
  iconText: string = '';
  searchForm: FormGroup;
  selection = new SelectionModel<any>(true, []);
  showDropdown = false;
  displayDropDown =false
  showFilter = false;
  columnName: string = ''
  showDropdownTop: any = 307;
  showDropdownLeft: any;
  innerWidth: any;
  showDropdownRight: any = window.innerWidth / 32;
  filterForm: any;
  categories: any;
  seletedIndex: any;
  selectedElement: any;
  updateCategoryObj: any;
  successMessage = '';
  selectedDropdownValue: any;
  oldData: any = [];
  searchStatusValue:any;
  searchBoxPad:string = 'beforeSearch';
  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.innerWidth = window.innerWidth;
  }
  contextMenuPosition = { x: '0px', y: '0px' };

  filterKeyUp = new Subject<any>();
  selectedSortData:any ={active:'',direction:''}
  constructor(private matIconRegistry: MatIconRegistry, private fb: FormBuilder,
    private domSanitizer: DomSanitizer, private httpService: HttpService,public datepipe:DatePipe,
    public changeDetector: ChangeDetectorRef) {
    this.searchForm = new FormGroup({
      searchText: new FormControl(''),
      searchDate:new FormControl('')
    });

    this.matIconRegistry.addSvgIcon("rebate", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/rebate_icon.svg"))
      .addSvgIcon("ra-delete", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/delete.svg"))
      .addSvgIcon("ra-edit", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/ra-edit.svg"))
      .addSvgIcon("ra-add", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/ra-add.svg"))
      .addSvgIcon("filter", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/filter_icon.svg"))
      .addSvgIcon("missed", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/missed_icon.svg"))

  }

  ngOnInit(): void {
    this.extraDataCopy();
    this.innerWidth = window.innerWidth;
    if (this.dataType == 'supplier-classification') {
      console.log('supplier classification categoris')
    }
    if (this.dataType == 'historyTable' ) {
    this.filterForm = this.fb.group({});
    for (let i = 0; i < this.columnsProps.length; i++) {
      this.filterForm.addControl(this.columnsProps[i], new FormControl(null))
    }
    if (this.data) {
      this.filterForm.valueChanges.subscribe((value: any) => {
        this.filterKeyUp.next(value);
      });
    }
  }
    this.filterKeyUp.pipe(
      map(event => event),
      debounceTime(1000),
      distinctUntilChanged(),
      mergeMap(search => of(search).pipe(
        delay(50),
      )),
    ).subscribe((res:any)=>{
      console.log(this.showSearch,"in show search");
      if(this.searchStatusValue=='searchinputhistory'){
        this.filterColumnValue.emit(res);
      }
     else{
      this.filterStatus.emit(res);
     }
     
    })

    // if (this.dataType == 'historyTable') {
    //   this.filterKeyUp.pipe(
    //     map(event => event),
    //     debounceTime(1000),
    //     distinctUntilChanged(),
    //     mergeMap(search => of(search).pipe(
    //       delay(50),
    //     )),
    //   ).subscribe((res:any)=>{
    //     this.filterStatus.emit(res);
    //   })
    // }



    if (this.dataType == 'inGroup') {
      this.filterForm = this.fb.group({});
      for (let i = 0; i < this.columnsProps.length; i++) {
        this.filterForm.addControl(this.columnsProps[i], new FormControl(''))
      }

      if (this.data) {
        this.filterForm.valueChanges.subscribe((value: any) => {
          // this.data.filterPredicate = this.createFilter();
          // this.data.filter = JSON.stringify(value);
          this.filterKeyUp.next(value);
        });
      }
      // if(this.dataType == 'product'){
      //   this.filterForm.addControl('search', new FormControl(''))
      //   if (this.data) {
      //     this.filterForm.valueChanges.subscribe((value: any) => {
      //       this.data.filter = JSON.stringify(value);
      //     });
      //   }
      // }
    }

    if (this.dataType == 'inGroupSummary') {
      this.filterForm = this.fb.group({});
      for (let i = 0; i < this.columnsProps.length; i++) {
        this.filterForm.addControl(this.columnsProps[i], new FormControl(''))
      }


      if (this.data) {
        this.filterForm.valueChanges.subscribe((value: any) => {
          //this.data.filterPredicate = this.createFilter2();
         // this.data.filter = JSON.stringify(value);
          this.filterKeyUp.next(value);
        });
      }

    }

    if (this.dataType == 'rebate-program') {
      this.filterForm = this.fb.group({});
      for (let i = 0; i < this.columnsProps.length; i++) {
        this.filterForm.addControl(this.columnsProps[i], new FormControl(''))
      }

      if (this.data) {
        this.filterForm.valueChanges.subscribe((value: any) => {
          this.data.filterPredicate = this.createRebateFilter();
          this.data.filter = JSON.stringify(value);
        });
      }

    }



    if (this.tableName === 'Upload History' && this.data) {
      this.data.filterPredicate = function (data: { filename: string; }, filter: string): boolean {
        return data.filename.toLowerCase().includes(filter.toLowerCase());
      };
    }

    if (this.name === 'Upload History') {
      this.data.filterPredicate = function (data: any, filter: string): boolean {
        return data.emailId.toLowerCase().includes(filter.toLowerCase());
      };
    }
    if (this.dataType === 'searchValue') {
      this.data.filterPredicate = function (data: any, filter: string): boolean {
        return data.productDescription.toLowerCase().includes(filter.toLowerCase());
      };
    }
    // this.getHistorypivot();
    // console.log("pivotdata",this.getHistorypivot());
    
  }
  extraDataCopy() {
    if(this.extraData && this.extraData.supplierDropdown){
      this.supplierDropdownOriginal = [...this.extraData.supplierDropdown];
      // console.log('supplierDropdownOriginal: ', this.supplierDropdownOriginal);
    }
   
  }

  onHoverSearchIcon() {
    this.iconText = 'clear';
  }

  onLeaveSearchIcon() {
    this.iconText = 'search';
  }

  clearSearch() {
    this.searchForm.patchValue({
      projectName: '',
    });
  }

  ngAfterViewInit() {
    if (this.dataType == 'invoice' || this.dataType == 'purchaseOrder' ||
      this.dataType == 'missedOppurtunity' || this.dataType == 'inGroup' || this.dataType == 'inGroupSummary' ||
      this.dataType == 'product' || this.dataType == 'supplier-classification' || this.dataType == 'rebateProductCategory' || this.dataType=="rebateSummary" ||
      this.dataType == 'userManagement' || this.dataType == 'historyTable'
    ) {
      this.data?.sort ? this.data.sort = this.sort:'';
    } else {
      // this.data.paginator = this.paginator;
      this.data?.paginator ? this.data.paginator = this.paginator:'';
      this.data.sort = this.sort;
      
    }

    //   this.data.sortingDataAccessor = (object: any, columnDef: any) => {
    //     switch(columnDef) {
    //        case 'select':
    //           return object.yourValue ? 1 : 0;
    //        default:
    //           return;
    //     }
    //  }
  }

  onFocusEvent(event: any){
    console.log(event);
  }
  applyFilterdate(event: any) {
    this.datePlaceholder = "Search by date";
    this.showCloseIcon = false;
    this.searchBoxPad = 'beforeSearch';
    this.date = null;
    console.log("search data",this.searchForm.value);
    this.searchStatusValue='searchinputhistory'
    let filterValue: string = event?.target.value;
    // filterValue = filterValue.trim(); // Remove whitespace
    // filterValue = filterValue.toLowerCase(); // MatTabledata defaults to lowercase matches
    this.filterKeyUp.next(filterValue);
    
    //this.data.filter = filterValue;
  }
  applyFilter(event: any) {
    this.date = null;
    console.log("search data",this.searchForm.value);
    this.searchStatusValue='searchinputhistory'
    let filterValue: string = event?.target.value;
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTabledata defaults to lowercase matches
    this.filterKeyUp.next(filterValue);
   
    //this.data.filter = filterValue;
  }
  searchPivotDate = (event: any) => {
    this.searchStatusValue='searchinputhistory';
    this.showCloseIcon = false;
    let filterValue =this.datepipe.transform(event?.target.value,'yyyy-MM-dd') ;
    console.log('filterValue', filterValue);
    this.searchBoxPad = 'beforeSearch';
    if(filterValue){
      this.showCloseIcon = true;
      this.searchBoxPad = 'afterSearch';
    }
 // MatTabledata defaults to lowercase matches
    this.filterKeyUp.next(filterValue);
    //console.log("pivot date",filterValue );
    if (this.datePlaceholder) {
      this.datePlaceholder = null
      return;
    } else {
      this.datePlaceholder = 'Search by date'
      return
    }
  }
  isAllSelected() {
    // console.log('selection: ', this.selection.selected);
    const numSelected = this.selection.selected.length;
    const numRows = this.data.data.length;
    //console.log('selection.selected.length: ',numSelected, ' & data.length: ', numRows);
    return numSelected === numRows;
  }

  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
    } else {
      // console.log('mastertoggle else case table data: ', this.data.data);
      this.data.data.forEach((row: any) => this.selection.select(row));
    }
    this.selectedRowData.emit(this.selection.selected);

    // console.log(this.data.data);
    // console.log(this.selection.selected);
  }

  addClicked() {
    this.addClick.emit();
  }

  deleteClicked() {
    this.deleteClick.emit();
  }

  closeMatMenu = () =>{
    this.contextMenu?.closeMenu();
    this.showDropdown = false;
  }

  selectedEventPosition = (event:any) =>{
    event.preventDefault();
    this.contextMenuPosition.x = event.clientX + 'px';
    this.contextMenuPosition.y = event.clientY + 'px';
    
  }

  openDropdown(event: any, index: any, element: any) {
    event.preventDefault();
    this.contextMenuPosition.x = event.clientX + 'px';
    this.contextMenuPosition.y = event.clientY + 'px';
    this.contextMenu?.openMenu();
    this.showDropdown = true;
    this.showDropdownTop = event.pageY;
    this.showDropdownLeft = event.pageX;
    // console.log('x and y: ', event.pageX, ' ,', event.pageY, ' this.innerWidth: ,', this.innerWidth)
    this.showDropdownRight = this.innerWidth - event.pageX;
    this.seletedIndex = index;
    this.selectedElement = element;
    console.log('index: ', index)
    console.log('and element: ', element);
    if (this.dataType == 'supplier-classification') {
      console.log('element.supplierValueInDB: ', element.supplierValueInDB);
      // restore this.extraData.supplierDropdown from original
      this.extraData.supplierDropdown = [...this.supplierDropdownOriginal];
      console.log('after restore extradata: ', this.extraData.supplierDropdown);
      // remove the object from this.extraData.supplierDropdown
      // where value is this.selectedElement.supplierValueInDB
      this.extraData.supplierDropdown = this.extraData.supplierDropdown.filter((e: any) => e.value !== this.selectedElement.supplierValueInDB);
      this.newSupplierValue = this.extraData.supplierDropdown[0].value;
      this.newSupplierName = this.extraData.supplierDropdown[0].displayText;
      console.log('after remove extradata: ', this.extraData.supplierDropdown);

      this.updateCategoryObj = {
        newSupplierValue: this.extraData.supplierDropdown[0].value,
        element: this.selectedElement
      }
    } else if (this.dataType == 'product') {
      console.log('element is: ', this.selectedElement);
      // restore this.extraData.supplierDropdown from original
      // remove the object from this.extraData.supplierDropdown 
      // where displaytext is this.selectedElement.predictedCategory
      this.extraData.supplierDropdown = [...this.supplierDropdownOriginal];
      // console.log('checklength: ', this.extraData.supplierDropdown.length)
      this.extraData.supplierDropdown = this.extraData.supplierDropdown.filter((e: any) => e.displayText !== this.selectedElement.predictedCategory && e.displayText !== this.selectedElement.updatedCategory );
      // console.log('checklength: ', this.extraData.supplierDropdown.length)
      if (this.selectedElement.updatedCategory !== CONSTANTS.mpcNone) {
        this.extraData.supplierDropdown = [{ displayText: CONSTANTS.mpcNone, value: CONSTANTS.mpcNone }, ...this.extraData.supplierDropdown];
      }
      this.updateCategoryObj = {
        id: [this.selectedElement['memberId']],
        updatedCategory: this.extraData.supplierDropdown[0].value,
      }
      this.selectedDropdownValue = this.extraData.supplierDropdown[0];
    }
  }

  selectedRow = (value: any) => {
    if (value) {
      // this.selectedRowData.emit(value);
      console.log('selected value: ', value);
      // console.log(this.selection)
      this.selectedRowData.emit(this.selection.selected);

    }
  }

  downloadFile = (value: any) => {
    if (value) {
      console.log('download row: ', value);
      this.download.emit(value);
      this.selectedRow(value)
    }
  }

  singleSelection(element: any) {
    //  console.log(this.selection);
    this.selection.toggle(element);
    //  console.log(this.selection);
    this.selectedRowData.emit(this.selection.selected);
  }

  enableEdit() {
    this.stateDisabled = false;
  }

  disableEdit() {
    this.stateDisabled = true;
  }

  stateChange(event: any, element: any) {
    console.log('slide state: ', event);
    console.log('element: ', element);
    element.state = event.checked;
    let index = this.editList.findIndex((f: any) => f.userId === element.userId);
    if (index !== -1) {
      this.editList[index].state = event.checked;
      console.log(this.editList);
      return;
    }
    this.editList.push(element);
    console.log(this.editList);
  }

  accessTypeEdit(value: any, element: any) {
    console.log('accessType new: ', value);
    console.log('element: ', element);
    element.accessType = value;
    let index = this.editList.findIndex((f: any) => f.userId === element.userId);
    if (index !== -1) {
      this.editList[index].accessType = value;
      console.log(this.editList);
      return;
    }
    this.editList.push(element);
    console.log(this.editList);
  }

  classificationFlagChange(value: any, element: any) {
    console.log('value: ', value, ' and element: ', element);
    this.selectedElement = element;
    this.updateCategoryObj = {
      newSupplierValue: this.extraData.supplierDropdown[0].value,
      element: this.selectedElement
    }

    if (_isEqual(value, 1)) { // out to in
      this.contextMenu?.openMenu();
      this.showDropdown = true;
      this.newClassificationFlag = value;
      this.newSupplierValue = this.extraData.supplierDropdown[0].value;
      this.newSupplierName = this.extraData.supplierDropdown[0].displayText;
    } else { // in to out
      this.supplierClassificationUpdate.emit({
        supplier_classification_id: _get(element, 'supplierClassificationID'),
        classification_id: value,
        supplier_id: null
      });
    }
  }

  supplierNameChange(value: any) {
    if (this.dataType == 'supplier-classification') {
      this.newSupplierValue = value;
      const newSupplier = this.extraData['supplierDropdown'].find((element: any) => element.value === value);
      this.newSupplierName = newSupplier.displayText;

      this.updateCategoryObj = {
        newSupplierValue: this.newSupplierValue,
        element: this.selectedElement
      }
    }

    if (this.dataType == 'product') {
      this.updateCategoryObj = {
        id: [this.selectedElement['memberId']],
        updatedCategory: parseInt(value)
      }
      this.selectedDropdownValue = this.extraData['supplierDropdown'].find((obj: any) => {
        if (value == obj['value']) {
          return obj;
        }
      });
    }
  }

  save() {
    console.log('save this: ', this.editList);
    if (this.editList.length == 0) {
      return;
    }
    this.saveClick.emit(this.editList);
    this.disableEdit();
  }

  openFilter = (event: any, seletedColumn: string, col: any) => {
    setTimeout(() => {
      event.stopPropagation();
      this.showFilter = !this.showFilter
      this.columnName = seletedColumn
      col.displayFilter = !col.displayFilter
    })


  }

  removeFilter(event: any, column: any,form:any) {
    setTimeout(() => {
      event.stopPropagation();
      column.displayFilter = false;
      this.filterForm['controls'][column['field']].setValue('')
      if((this.dataType!='inGroupSummary' && this.dataType != 'inGroup')||(this.dataType!='historyTable')){
      this.filterForm['controls'][column['field']].valueChanges.subscribe((value: any) => {
        this.data.filter = JSON.stringify('');
      });
      }
      
    })
  }

  stopEventProp(event:any){
    setTimeout(() => {
      event.stopPropagation();
    })
  }

  createFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data: any, filter: any): boolean {
      let searchTerms = JSON.parse(filter);
      if(searchTerms){
        return (
          data.supplierName.toLowerCase().indexOf(searchTerms.supplierName.toLowerCase()) !== -1 &&
          data.totalPurchase
            .toString()
            .toLowerCase()
            .indexOf(searchTerms.totalPurchase.toLowerCase()) !== -1 &&
          data.totalRebateEarned
            .toString()
            .toLowerCase()
            .indexOf(searchTerms.totalRebateEarned.toLowerCase()) !== -1 &&
          data.yoyChangeInPurchase
            .toString()
            .toLowerCase()
            .indexOf(searchTerms.yoyChangeInPurchase.toLowerCase()) !== -1
        );
      }else{
        return false
      }
   
    };
    return filterFunction;
  }
  createRebateFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function (data: any, filter: any): boolean {
      let searchTerms = JSON.parse(filter);
      return (

        data.year
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.year.toLowerCase()) !== -1 &&
        data.supplierName
          .toString()
          .toLowerCase()
          .indexOf(searchTerms.supplierName.toLowerCase()) !== -1

      );
    };
    return filterFunction;
  }
  createFilter2(): (data: any, filter: string) => boolean {

    let filterFunction = function (data: any, filter: any): boolean {

      let searchTerms = JSON.parse(filter);
      if(searchTerms){
        return (

          data.totalPurchase
            .toString()
            .toLowerCase()
            .indexOf(searchTerms.totalPurchase.toLowerCase()) !== -1 &&
          data.totalRebateEarned
            .toString()
            .toLowerCase()
            .indexOf(searchTerms.totalRebateEarned.toLowerCase()) !== -1 &&
          data.yoyChangeInPurchase
            .toString()
            .toLowerCase()
            .indexOf(searchTerms.yoyChangeInPurchase.toLowerCase()) !== -1 &&
          data.supplierName.toLowerCase().indexOf(searchTerms.supplierName.toLowerCase()) !== -1 &&
  
          data.category
            .toString()
            .toLowerCase()
            .indexOf(searchTerms.category.toLowerCase()) !== -1
        );
      }else{
        return false;
      }
   
    };
    return filterFunction;
  }

  viewIngroup = (col: any) => {
    this.selectedIngroup.emit(col)
  }

  selectedCatergory = (data: any, type: any) => {
    if (data != 'none') {
      this.updateCategoryObj = [
        {
          id: this.selectedElement['memberId'],
          updatedCategory: parseInt(data.value)
        }
      ]

    }

  }
  submitCategory = () => {
    this.showDropdown = false;
    this.contextMenu?.closeMenu();
    if (this.dataType === 'supplier-classification') {

      this.supplierClassificationUpdate.emit({
        supplier_classification_id: _get(this.selectedElement, 'supplierClassificationID'),
        classification_id: this.newClassificationFlag,
        supplier_id: this.newSupplierValue,
        supplier_name: this.newSupplierName
      });

      this.updateCategoryObj = undefined;
    } else {
      if (this.updateCategoryObj && Object.keys(this.updateCategoryObj).length > 0) {
        this.httpService.updateProductCategory(this.updateCategoryObj).subscribe((response: any) => {
          if (response && response['data'] && response['data']['message']) {
            this.successMessage = response['data']['message'];
            if (this.successMessage) {
              let objIndex = this.data['data'].findIndex((obj: any) => {
                return obj.memberId == this.updateCategoryObj['id'][0]
              });
              let currentUTCDate = this.updateWithCurrentUTCDate();
              let userId  = localStorage.getItem("userId"); 
             // let userName  = localStorage.getItem("username"); 
              let desc = this.data['data'][objIndex]['productDescription']
              this.data['data'][objIndex].lastUpdated = currentUTCDate?currentUTCDate:'NA'
              this.data['data'][objIndex].updatedBy = userId?userId:'NA'
              this.data['data'][objIndex].updatedCategory = this.selectedDropdownValue['displayText']
              if(desc){
                this.data['data'].map((res:any)=>{
                  if(res['productDescription']==desc){
                    res['lastUpdated'] = currentUTCDate?currentUTCDate:'NA'
                    res['updatedBy'] = userId?userId:'NA'
                    res['updatedCategory'] = this.selectedDropdownValue['displayText']
                  }
                })
              }
           
            }
          }
        })
      }
    }

  }

  updateWithCurrentUTCDate = () =>{
    const format1 = "YYYY-MM-DD HH:mm:ss"
    return moment.utc(new Date()).subtract(8, 'hours').format(format1);
  }
  removeExcessTier = (event: any) => {
    console.log(event);

    this.removeExcessTierToggle = event.checked;
    console.log('removeExcessTierToggle', this.removeExcessTierToggle)
    this.removeExcessTierEvent.emit(event.checked);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.searchValue) {
      let filterValue: string = changes.searchValue.currentValue;
      filterValue = filterValue.trim(); // Remove whitespace
      filterValue = filterValue.toLowerCase(); // MatTabledata defaults to lowercase matches
      this.data.filter = filterValue;
    }

    this.isSortApplied?.asObservable().subscribe((result)=>{
      if(result){
        this.data = []
        setTimeout(()=>{
          this.data = new MatTableDataSource(result)
        },100)
      }
    })
    
    


  }
  checkNameLength = (name: any) => {
    return name
  }

  pageChanged(event: any) {
    setTimeout(() => {
      this.data.filter = '';
    })
    let pageIndex = event.pageIndex;
    let pageSize = event.pageSize;
    let previousIndex = event.previousPageIndex;

    let previousSize = pageSize * pageIndex;
    this.getNextPage.emit({ "previousSize": previousSize, "pageIndex": (pageIndex).toString(), "pageSize": pageSize.toString() });
  }

  fixedDecimalValue = (data:any) =>{
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(data);
    }

    abbreviateNumber = (value:any) => {
      return new Intl.NumberFormat(undefined, {
        //@ts-ignore
        
        notation: "compact",
        compactDisplay: "short",
        style: "currency",currency: "USD",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(value);
  }

  menuClose() {
    this.showDropdown = false;
    console.log('menu closed. revert now');
    if (this.dataType === 'supplier-classification') {
      this.data['data'].map((res:any) => {
        if (res['supplierClassificationID'] === this.selectedElement.supplierClassificationID && res['classificationID'] === 2) {
          res['classificationID'] = undefined;
          setTimeout(() => {
            res['classificationID'] = 2;
          }, 1);
          console.log('menu close found')
        }
      })
    }
  }

  filterClicked = (value: any) => {
    if (this.dataType == 'historyTable' ) {
          
      if (value == 'Status') {
        //  this.options = [{ displayText: "Processing", value: 'Processing' }, { displayText: "Processed", value: 'Processed' },  { displayText: "Rejected", value: 'Rejected' }]
        this.options = this.statusData
      }
 
    }
  }

  selectedFilterOption = (value: any, columnName: any) => {
    this.searchStatusValue='searchinputhistorystatus'
    this.filteredValues.emit(this.filterForm.value)
  }

  // selectedFilterOption = (value: any, columnName: any) => {
  //   this.filteredValues.emit(this.filterForm.value.status)
  //   console.log("in iption",this.filterForm.value.status);
    
  //   this.filterStatus.emit(this.filterForm.value.status)
  //   this.isEffectiveDateToggled = false;
  // }
  removeFilterstatus(event: any, column: any, form: any) {
    setTimeout(() => {
      event.stopPropagation();
      column.displayFilter = !column.displayFilter;

      if (this.dataType == 'historyTable' ) {
        console.log("remove status");
        
        if (column['field'] == 'status') {
          console.log("remove status1");
          if (this.filterForm.value.status) {
            delete this.filterForm.value.status
            console.log("remove status2",this.filterForm.value.status);
          }

        }

      }
      this.filteredValues.emit(this.filterForm.value)

    })
  }
  removeSearchdate(event: any, column: any, form: any) {
    setTimeout(() => {
      event.stopPropagation();
      column.displayFilter = !column.displayFilter;

      if (this.dataType == 'historyTable' ) {
        if (column['field'] == 'status') {
          if (this.filterForm.value && this.filterForm.value['status']) {
            delete this.filterForm.value['status']
          }

        }

      }
      this.filteredValues.emit(this.filterForm.value)

    })
  }
  clearDate(event:any) {
    event.stopPropagation();
    this.date = null;
    this.searchStatusValue='searchinputhistory'
    let filterValue: string = event?.target.value;
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTabledata defaults to lowercase matches
    this.filterKeyUp.next(filterValue);
    
}
  sortColumnData = (sort: Sort) =>{
    console.log("======>",sort);
    
    this.selectedSortData = sort
    this.sortDataEvent.emit(sort)
  }


 
}
