import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss']
})
export class SelectComponent implements OnInit,OnChanges {
  form!: FormGroup;
  @Input() selectedValue: any;
  @Input() options: any;
  @Input() displayField: any;
  @Input() valueField: any;
  @Input() placeholder: any;
  @Input() name: any;
  @Input() disabled: any;
  @Input() isReset:any;
  @Output() selectionChange = new EventEmitter<any>();

  get selectFormControl() { return this.form.get('select'); }

  constructor(private fb: FormBuilder) { 
    this.form = this.fb.group({
			select: [null, Validators.required]
		});
  }
  ngOnChanges(changes: SimpleChanges): void {
    if(this.isReset){
      this.resetForm();
      console.log('resettting select')
    }
    console.log('after reset, selectedvalue: ', this.selectedValue);
    const selectedValue =  this.selectedValue;
    this.selectedValue =  undefined;
    setTimeout(() => {
      this.selectedValue = selectedValue;
      this.form.get('select')!.setValue(this.selectedValue);
    }, 1);
  }
  ngOnDestroy() {
    console.log('ngOnDestroy called in select');
  }

  ngOnInit(): void {
    
    console.log('selectedValue: ', this.selectedValue)
    this.form.get('select')!.setValue(this.selectedValue);
    if(this.isReset){
      this.resetForm();
    }
  }

  selectedOption(value: any) {
    console.log('selection: ', value);
    this.selectedValue = value;
    this.form.get('select')!.setValue(this.selectedValue);
    this.selectionChange.emit(this.selectedValue);
  }

  resetForm = () =>{
    this.form.reset();
  }

  

}
