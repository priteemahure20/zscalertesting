import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TableHistComponent } from './table-hist.component';

describe('TableHistComponent', () => {
  let component: TableHistComponent;
  let fixture: ComponentFixture<TableHistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TableHistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TableHistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
