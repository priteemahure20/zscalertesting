import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

interface JsonFormValidators {
  min?: number;
  max?: number;
  required?: boolean;
  requiredTrue?: boolean;
  email?: boolean;
  minLength?: boolean;
  maxLength?: boolean;
  pattern?: string;
  nullValidator?: boolean;
}
interface JsonFormControlOptions {
  min?: string;
  max?: string;
  step?: string;
  icon?: string;
}
interface JsonFormControls {
  name: string;
  label: string;
  value: string;
  type: string;
  options?: JsonFormControlOptions;
  required: boolean;
  validators: JsonFormValidators;
}
export interface JsonFormData {
  controls: JsonFormControls[];
}
@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss'],
})
export class DynamicFormComponent  implements OnChanges,OnInit {

  @Input() jsonFormData: any=[];
  @Input() headers:any;
  @Input() isDisabled:any;
  @Input() isDisabledRefresh:any;
  @Input() previousFields:any;
  inputForm: FormGroup = this.fb.group({});
  valuesList =[];
  allValuesList = []
  selectedValues:any = [];
  sampleForm:any;
  displayedColumns: string[] = ['Column Name', 'Map to Field'];
  dataSource:any = [];
  isReset:boolean = false;
  @Output() 
  mappedData = new EventEmitter();
  @Output() refreshMapping = new EventEmitter();
  constructor(private fb: FormBuilder) { }
  ngOnInit(): void {    
    this.valuesList = this.headers;
    this.allValuesList =  this.headers;
  }
  ngOnChanges(changes: SimpleChanges) {
    this.valuesList = this.headers;
    this.allValuesList =  this.headers;
    this.isDisabled = this.isDisabled
    this.isDisabledRefresh = this.isDisabledRefresh
    if(this.jsonFormData.controls){
      this.inputForm =  this.fb.group({});
        this.createForm(this.jsonFormData.controls);
        this.mapTableHeadersWithData(this.jsonFormData.controls);
    }
    
  }
  createForm(controls: JsonFormControls[]) {
    for (const control of controls) {
      const validatorsToAdd = [];
      for (const [key, value] of Object.entries(control.validators)) {
        switch (key) {
          case 'min':
            validatorsToAdd.push(Validators.min(value));
            break;
          case 'max':
            validatorsToAdd.push(Validators.max(value));
            break;
          case 'required':
            if (value) {
              validatorsToAdd.push(Validators.required);
            }
            break;
          case 'requiredTrue':
            if (value) {
              validatorsToAdd.push(Validators.requiredTrue);
            }
            break;
          case 'email':
            if (value) {
              validatorsToAdd.push(Validators.email);
            }
            break;
          case 'minLength':
            validatorsToAdd.push(Validators.minLength(value));
            break;
          case 'maxLength':
            validatorsToAdd.push(Validators.maxLength(value));
            break;
          case 'pattern':
            validatorsToAdd.push(Validators.pattern(value));
            break;
          case 'nullValidator':
            if (value) {
              validatorsToAdd.push(Validators.nullValidator);
            }
            break;
          default:
            break;
        }
      }
      this.inputForm.addControl(control.name,new FormControl(null, validatorsToAdd));
    }
  }

  onSubmit() {
    if(this.inputForm.valid){
     let buySellRepValues:any =  this.createFormValues(this.inputForm.value);
     this.mappedData.emit(buySellRepValues)
    }
  }
  reset(){
    setTimeout(()=>{
      this.valuesList.map((eachValue:any)=>{
        eachValue['selected'] = true;
      })
    this.selectedValues = []
    this.inputForm.reset()  
    })
    this.refreshMapping.emit()
  }




  selectedValue = (event:any,formValue:any)=>{
   
      if(this.selectedValues.length>0){
        this.selectedValues.map((each:any)=>{
          if(each[formValue] && each[formValue]['selected']==false){
            this.valuesList.map((eachValue:any)=>{
              if(eachValue['value']==each[formValue]['value']){
                eachValue['selected'] = true
              }
            })
          }
         })
      }
        let object:any = {};
         object[formValue]= event
         this.selectedValues.push(object);
         event.selected = false;
    
       
  }

  public createFormValues = (form:any) =>{
    let allData = []
    for(const value in form){
      if(value!=''){
        let object = {
          'column_master_id':value,
          'USER_GROUP_COLUMN_NAME':form?form[value]?form[value]['value']:'':''
        }
        allData.push(object)   
      }
    }
    return allData

  }

  public mapTableHeadersWithData = (formData:any) =>{
    let data=[]
    for(let form of formData){
     let obj={
      'Column Name':form.label,
      'Map to Field': form  
      }
      data.push(obj)
    }
    this.dataSource = data;
  }

  getMappedFields = (matchValue:any) =>{
    for(let i=0;i<this.previousFields.length;i++){
      if(this.previousFields[i]['COLUMN_MASTER_NAME']==matchValue){
        return this.previousFields[i]['USER_GROUP_COLUMN_NAME']
      }
    }
  }

}
