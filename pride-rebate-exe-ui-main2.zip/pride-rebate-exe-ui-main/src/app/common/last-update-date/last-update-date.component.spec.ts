import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LastUpdateDateComponent } from './last-update-date.component';

describe('LastUpdateDateComponent', () => {
  let component: LastUpdateDateComponent;
  let fixture: ComponentFixture<LastUpdateDateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LastUpdateDateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LastUpdateDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
