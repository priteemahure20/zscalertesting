import { Component, OnInit, Input } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-last-update-date',
  template: 'Last Updated : {{lastUpdateDate | date:"MM/dd/yyyy"}}',
  host: { 'class': 'text-muted' }
})
export class LastUpdateDateComponent implements OnInit {

  lastUpdateDate: any = 'NA';
  //lastUpdateDate:any;


  ngOnInit(): void {
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    //console.log('lastUpdateDate',this.lastUpdateDate);
    // const updatedDate: any = localStorage.getItem('lastUpdatedDate');
    // if (updatedDate) {
    //   const dateString = [];
    //   dateString.push(new Intl.DateTimeFormat('en-US', {
    //     year: "numeric",
    //     month: "numeric",
    //     day: "numeric"
    //   }).format(new Date(updatedDate)));
    //   dateString.push(new Intl.DateTimeFormat('en-US', {
    //     hour: "numeric",
    //     minute: "numeric",
    //     second: "numeric",
    //     hour12: true,
    //     timeZone: "America/Denver",
    //     timeZoneName: "shortOffset"
    //   }).format(new Date(updatedDate)));
    //   this.lastUpdateDate = dateString.join(' | ');
    // }
  }
}
