import { Component, Input, OnInit, Output,EventEmitter } from '@angular/core';
import * as d3 from 'd3';
import {DecimalPipe} from '@angular/common'
@Component({
  selector: 'app-d3-bubble-chart',
  templateUrl: './d3-bubble-chart.component.html',
  styleUrls: ['./d3-bubble-chart.component.scss']
})
export class D3BubbleChartComponent implements OnInit {

  @Input("dataSet") public dataSet:any;
  @Input()
  width:any;
  @Input()
  height:any;
  @Input()
  chartId:any;
  @Output()
  selectedInSideBubble = new EventEmitter()
  constructor() { }
  ngOnInit(): void {
    this.createBubbleChart();
  }
  createBubbleChart = () =>{
    let diameter = 600;
    let height = this.height;
    let width = this.width;
    let width2 = 300;
    let color = d3.scaleOrdinal(d3.schemeCategory10);
    let  margin = { top:10, right:10, bottom: 0, left:10}
    let bubble = d3.pack()
      .size([width, height])
      .padding(5);

    let svg = d3.select('#'+this.chartId)
      .append("svg")
      .attr('width', '100%')
      .attr('height', '100%')
      .attr('viewBox', '-' + (margin.left + margin.right) + ' ' + (margin.bottom) + ' ' + this.width + ' ' + this.height)
      .attr("class", "bubble");
    let nodes = d3.hierarchy(this.dataSet)
      .sum(function (d: any) {
        return d.Count;
      });

    let node = svg.selectAll(".node")
      .data(bubble(nodes).descendants())
      .enter()
      .filter(function (d) {
        return !d.children
      })
      .append("g")
      .attr("class", "node")
      .attr("transform", function (d) {
        return "translate(" + d.x + "," + d.y + ")";
      }).style("fill", function (d, i: any) {
        return color(i);
      });

    node.append("title")
      .text(function (d: any) {
        return  d.data.fullName + '\n' + 'Sum - ' + getFormatNumber(parseInt(d.data['Count']));
      })
      
    node.append("circle")
      .attr("x", function (d) { return d.x; })
      .attr("y", function (d) { return d.y })
      .attr("r", function (d) {
        return d.r;
      })
      .style("fill", function (d, i: any) {
          return "#FBA504";
       
      })
      .style("opacity",function (d, i: any) {
          return "0.9";
      })
      .style("cursor","pointer")
      .on('click', (e:any, d:any) => {
        this.selectedInSideBubble.emit(d.data)
      })
    node.append("text")
      .attr("dy", ".1em")
      .style("text-anchor", "middle")
      .text(function (d: any,i) {
      if(d.r>20){
        return d.data.Name;
      }
        
       // return d.data.Name;
      })
      .attr("font-family", "IBM Plex Sans")
      .attr("font-size", function (d) {
        return d.r / 6;
      })
      .attr("fill", "white")
      // .on("mouseover", function(d) {
      //   d3.selectAll('.node')
      //     .raise()
      //     .transition()
      //     .style("stroke-width", 1.5);
      // })
      // .on("mouseout", function(d) {
      //    d3.selectAll('.node')
      //     .lower()
      //     .transition()
      //     .style("stroke-width", 0.75);
      // })
    // node.append('text')
    //   .attr("dy", "1.3em")
    //   .style("text-anchor", "middle")
    //   .text(function (d: any) {
    //     return d.data.Count;
    //   })
    //   .attr("font-family", "Gill Sans")
    //   .attr("font-size", function (d) {
    //     return d.r / 2;
    //   })
    //   .attr("fill", "white");
  }

 
}

function fixedDecimalValue (data:any) {
  if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      }else{
        return data
      }
      
     }
  }
function getFormatNumber(number: number) {
  return new Intl.NumberFormat(undefined, {
    //@ts-ignore
    
    notation: "compact",
    compactDisplay: "short",
    style: "currency",currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(number);
  
 
}



