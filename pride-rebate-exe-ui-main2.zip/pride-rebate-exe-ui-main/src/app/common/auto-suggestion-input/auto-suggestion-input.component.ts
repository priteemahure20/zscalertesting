import {Component, forwardRef, Input, OnInit} from '@angular/core';
import {ControlContainer, NG_VALUE_ACCESSOR} from '@angular/forms';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
@Component({
  selector: 'app-auto-suggestion-input',
  templateUrl: './auto-suggestion-input.component.html',
  styleUrls: ['./auto-suggestion-input.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting:forwardRef(() => AutoSuggestionInputComponent),
    multi: true
  }],
})
export class AutoSuggestionInputComponent implements OnInit {
  @Input()
  inputForm:any;
  @Input()
  labelName:any;
  @Input()
  fieldName:any;
  @Input()
  type:any;
  @Input()
  placeHolder:any;

  control: any;
  @Input()
  options: any[] = [];
  filteredOptions: Observable<any[]> | undefined;
  constructor(public controlContainer: ControlContainer) { }

  ngOnInit(): void {
    if (this.controlContainer && this.fieldName) {
      this.control = this.controlContainer.control?.get(this.fieldName)
    }
    this.filteredOptions = this.control.valueChanges.pipe(
        startWith(''),
        map((value:any) => this._filter(value)),
    );
  }
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option['displayText'].toLowerCase().includes(filterValue));
  }
}
