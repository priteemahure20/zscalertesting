import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoSuggestionInputComponent } from './auto-suggestion-input.component';

describe('AutoSuggestionInputComponent', () => {
  let component: AutoSuggestionInputComponent;
  let fixture: ComponentFixture<AutoSuggestionInputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutoSuggestionInputComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoSuggestionInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
