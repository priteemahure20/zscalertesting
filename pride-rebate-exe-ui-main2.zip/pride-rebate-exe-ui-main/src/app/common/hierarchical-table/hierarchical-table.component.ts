import {Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild} from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatSort, Sort } from '@angular/material/sort';
import { MatMenuTrigger } from '@angular/material/menu';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { FormBuilder, FormControl } from '@angular/forms';
import { Subject, of } from 'rxjs';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import { checkNameLength } from 'src/app/helpers/commonUtils';
import * as moment from 'moment';
import { debounceTime, delay, distinctUntilChanged, map, mergeMap } from 'rxjs/operators';
import { element } from 'protractor';
import {ReusableService} from '../../services/reusable.service';
import {MatTableDataSource} from '@angular/material/table';
import {MatSelectChange} from '@angular/material/select';
import {AuthService} from '../../services/auth.service';
import {UserType} from '../../helpers/constants';
import { HttpService } from 'src/app/services/http.service';
@Component({
  selector: 'app-hierarchical-table',
  templateUrl: './hierarchical-table.component.html',
  styleUrls: ['./hierarchical-table.component.scss']
})
export class HierarchicalTableComponent implements OnInit {
  @ViewChild(MatSort, {static: false}) sort: MatSort | any;
  @ViewChild(MatMenuTrigger, { read: MatMenuTrigger })
  contextMenu: MatMenuTrigger | undefined;

  @Input() set dataSource(value: any) {
    this.data = value;
    // this.data.sort = this.sort;
    this.selection.clear();
  }
  @Input() columnsToDisplay: any;
  @Input() columnsProps: any;
  @Input() viewType: any;
  @Input() contentType: any
  @Input() filterAssociateId: any;
  @Input() filterEmailId: any;
  @Input() permissionOptions: any = [];
  @Input() checkboxSelectDefault: any;
  @Input() isSortApplied: Subject<any> | undefined;
  @Input() selectedValue:any;
  @Input() new:any;

  @Output() selectedRowData = new EventEmitter<any>();
  @Output() selectedHierarchical = new EventEmitter<any>();
  @Output() selectedOrgName = new EventEmitter<any>();
  @Output() filteredValues = new EventEmitter<any>();
  @Output() effectiveDateChanges = new EventEmitter<any>()
  @Output() filterColumnValue = new EventEmitter();
  @Output() redirectForEdit = new EventEmitter<any>();
  @Output() editedSelectedRow = new EventEmitter();
  @Output() toggleActivateDeActivate = new EventEmitter()
  @Output() selectedPermission = new EventEmitter();
  @Output() sendEmailEmitter = new EventEmitter();
  @Output() distributorData = new EventEmitter();
  @Output() navigateToProgramDetail = new EventEmitter();
  @Output() navigateToRebateGovReqDetail = new EventEmitter();
  @Output() switchToUser = new EventEmitter();
  @Output() sortDataEvent = new EventEmitter();
  @Output() exportEach = new EventEmitter<any>();

  selection = new SelectionModel<any>(true, []);
  data: any;
  editList: any = [];
  showFilter = false;
  columnName: string = '';
  filterForm: any;
  filterKeyUp = new Subject<any>();
  selectedRowDate: any;
  options: any = []
  isEffectiveDateToggled: boolean = true;
  minDate = new Date();
  // selectedSortData:any ={active:'',direction:''}
  selectedSortData:any ={limit:10,pageNo:1,orderBy:'',orderType:''}
  userType:any;
  associateObj:any={};
  totalCount:any;
  pagination={
    limit:10,
    pageNo:1,
  };

  distributorUser = UserType.Distributor
  constructor(private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer, private fb: FormBuilder, private _liveAnnouncer: LiveAnnouncer,private reusable: ReusableService,private authService:AuthService,) {
    this.matIconRegistry.addSvgIcon("ra-edit", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/ra-edit.svg"))
      .addSvgIcon("filter", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/filter_icon.svg"))
      .addSvgIcon("dropdown", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/dropdown.svg"))
      .addSvgIcon("dropdown-up", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/dropdown-up.svg"))
      .addSvgIcon("dashboard-view", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/dashboard-view-icon.svg"))
      .addSvgIcon("email-view", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/email-icon.svg"))
      .addSvgIcon("view-rebate", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/view-rebate.svg"))

  }
  ngOnChanges(changes: SimpleChanges): void {
    // console.log(this.sort);

    this.data?.data?.forEach((row: any) => {
      if(row['selected']){
        this.selection.select(row)
      }
    });
    if(this.reusable.getUnselectedList().length>0){
      let unselectedList = this.reusable.getUnselectedList()
      let tableList = this.data?.data|| []
      for(let i=0;i<unselectedList.length;i++){
        for(let j=0;j<tableList.length;j++){
          if(unselectedList[i]['product_id']==tableList[j]['product_id']){
            this.selection.deselect(tableList[j])
          }
        }
      }
    }
    if(this.reusable.getSelectedList().length>0){
      let selectedList = this.reusable.getSelectedList()
      let tableList = this.data?.data || []
      for(let i=0;i<selectedList.length;i++){
        for(let j=0;j<tableList.length;j++){
          if(selectedList[i]['product_id']==tableList[j]['product_id']){
            this.selection.select(tableList[j])
          }
        }
      }
    }
    this.isSortApplied?.asObservable().subscribe((result)=>{
      if(result){
        this.data = []
        setTimeout(()=>{
          this.data = new MatTableDataSource(result)
        },100)
      }
    })
    // if (this.checkboxSelectDefault) {
    //   this.data?.data?.forEach((row: any) => {
    //     this.selection.select(row)
    //   });
    // } else {
    //   this.data?.data?.forEach((row: any) => {
    //     if (row['selected']) {
    //       this.selection.select(row)
    //     }
    //   });
    // }
  }
  ngOnInit(): void {
    const {userType} = this.authService.getUser() as any;
    this.userType = userType;
    console.log("Column Props",this.columnsProps);
      this.data?.data?.forEach((row: any) => {
        if(row['selected']){
          this.selection.select(row)
        }
      });
    if(this.reusable.getUnselectedList().length>0){
      let unselectedList = this.reusable.getUnselectedList()
      let tableList = this.data?.data|| []
      for(let i=0;i<unselectedList.length;i++){
        for(let j=0;j<tableList.length;j++){
          if(unselectedList[i]['product_id']==tableList[j]['product_id']){
            this.selection.deselect(tableList[j])
          }
        }
      }
    }
    if(this.reusable.getSelectedList().length>0){
      let selectedList = this.reusable.getSelectedList()
      let tableList = this.data?.data|| []
      for(let i=0;i<selectedList.length;i++){
        for(let j=0;j<tableList.length;j++){
          if(selectedList[i]['product_id']==tableList[j]['product_id']){
            this.selection.select(tableList[j])
          }
        }
      }
    }


    if (this.contentType == 'supplierAssociateLibrary' || this.contentType == 'distributerAssociateLibrary' ||
      this.contentType == 'supplierAssociateUser' || this.contentType == 'financialHealthDistributor' ||
      this.contentType == 'financialHealthSupplier' || this.contentType == 'supplierWithoutData' ||
      this.contentType == 'rebateTopOpportunities' || this.contentType == 'weeklyLogin' || this.contentType == 'distributorOptimization' ||
      this.contentType == 'rebateGovernance' || this.contentType == 'rebateGovernanc2' || this.contentType == 'catalogSelectionProducts' ||
      this.contentType == 'catalogSelectionProductsView' ||this.contentType == 'reportGenerator' || this.contentType == 'payoutAssessment') {
      this.filterForm = this.fb.group({});
      for (let i = 0; i < this.columnsProps.length; i++) {
        this.filterForm.addControl(this.columnsProps[i], new FormControl(null))
      }
      // if (this.data) {
        this.filterForm.valueChanges.subscribe((value: any) => {
          this.filterKeyUp.next(value);
        });
      // }
    }

    this.filterKeyUp.pipe(
      map(event => event),
      debounceTime(1000),
      distinctUntilChanged(),
      mergeMap(search => of(search).pipe(
        delay(50),
      )),
    ).subscribe((res: any) => {
      this.filterColumnValue.emit(res);
    })
  }

  ngAfterViewInit() {
    this.data.sort = this.sort;
  }


  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.data.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
    } else {
      this.data.data.forEach((row: any) => this.selection.select(row));
    }
    this.selectedRowData.emit(this.selection.selected);
  }

  singleSelection(element: any) {
    this.selection.toggle(element);
    if(this.contentType=='catalogSelectionProducts'){
      let selectedProduct ={
        selectedValue:element,
        isValueSelected:this.selection.isSelected(element)
      }
      this.selectedRowData.emit(selectedProduct);
    }else{
      this.selectedRowData.emit(this.selection.selected);
    }
  }

  stateChange(event: any, element: any) {
    element.status = event.checked;
    if (this.contentType == 'supplierAssociateLibrary' || this.contentType == 'distributerAssociateLibrary') {
      let index = this.editList.findIndex((f: any) => f.group_id === element.group_id);
      console.log("in statechange");
      if (index !== -1) {
        this.editList[index].status = event.checked;
        return;
      }
      this.editList.push(element);
    }
    if (this.contentType == 'supplierAssociateUser') {
      let index = this.editList.findIndex((f: any) => f.group_id === element.group_id);
      console.log("in statechange");
      if (index !== -1) {
        this.editList[index].status = event.checked;
        return;
      }
      this.editList.push(element);
    }

  }


  openFilter = (event: any, seletedColumn: string, col: any) => {
    setTimeout(() => {
      event.stopPropagation();
      this.showFilter = !this.showFilter
      this.columnName = seletedColumn
      col.displayFilter = !col.displayFilter

    })
  }

  removeFilter(event: any, column: any, form: any) {
    setTimeout(() => {
      event.stopPropagation();
      column.displayFilter = !column.displayFilter;
      if (column['field'] != 'effectiveDate' && column['field'] != 'editedDate' && column['field'] != 'editedDate') {
        this.filterForm['controls'][column['field']].setValue(null)
      }

      if (this.contentType == 'supplierAssociateLibrary' || this.contentType == 'distributerAssociateLibrary' || this.contentType == 'rebateGovernance' ||
        this.contentType == 'rebateGovernanc2') {
        if (column['field'] == 'effectiveDate') {
          if (this.filterForm.value && this.filterForm.value['active_from']) {
            delete this.filterForm.value['active_from']

          }
          if (this.filterForm.value && this.filterForm.value['active_to']) {
            delete this.filterForm.value['active_to']
          }
        }

      }
      if (this.contentType == 'supplierAssociateLibrary' || this.contentType == 'distributerAssociateLibrary' ||
        this.contentType == 'supplierAssociateUser' || this.contentType == 'rebateGovernance' || this.contentType == 'rebateGovernanc2') {
        if (column['field'] == 'editedDate' || column['field'] == 'lastUploadDate') {
          if (this.filterForm.value && this.filterForm.value['updated_date_from']) {
            delete this.filterForm.value['updated_date_from']
          }
          if (this.filterForm.value && this.filterForm.value['updated_date_to']) {
            delete this.filterForm.value['updated_date_to']
          }
        }
      }
      if (this.contentType == 'supplierWithoutData') {
        if (this.filterForm.value && this.filterForm.value['last_uploaded_from']) {
          delete this.filterForm.value['last_uploaded_from']
        }
        if (this.filterForm.value && this.filterForm.value['last_uploaded_to']) {
          delete this.filterForm.value['last_uploaded_to']
        }
      }
      if (this.contentType == 'weeklyLogin') {
        if (this.filterForm.value && this.filterForm.value['last_login_from']) {
          delete this.filterForm.value['last_login_from']
        }
        if (this.filterForm.value && this.filterForm.value['last_login_from']) {
          delete this.filterForm.value['last_login_from']
        }
      }
      if (this.contentType == 'rebateGovernance' || this.contentType == 'rebateGovernanc2' && column['field'] == 'created') {
        if (this.filterForm.value && this.filterForm.value['created_from']) {
          delete this.filterForm.value['created_from']
        }
        if (this.filterForm.value && this.filterForm.value['created_to']) {
          delete this.filterForm.value['created_to']
        }
      }
      if(this.contentType=='financialHealthDistributor' || this.contentType =='financialHealthSupplier'){
        if (this.filterForm.value && this.filterForm.value['last_transaction_from']) {
          delete this.filterForm.value['last_transaction_from']
        }
        if (this.filterForm.value && this.filterForm.value['last_transaction_to']) {
          delete this.filterForm.value['last_transaction_to']
        }
      }
      if(this.contentType=='payoutAssessment'){
        if (this.filterForm.value && this.filterForm.value['effectiveDateFrom']) {
          delete this.filterForm.value['effectiveDateFrom']
        }
        if (this.filterForm.value && this.filterForm.value['effectiveDateTo']) {
          delete this.filterForm.value['effectiveDateTo']
        }
      }
      this.filteredValues.emit(this.filterForm.value)

    })
  }

  removeInputFilter(event: any, column: any, form: any) {
    setTimeout(() => {
      event.stopPropagation();
      column.displayFilter = false;
      this.filterForm['controls'][column['field']].setValue('')
      this.filterForm.valueChanges.subscribe((value: any) => {
        this.filterKeyUp.next(value);
      });
      if (this.contentType != 'inGroupSummary') {
        // this.filterForm['controls'][column['field']].valueChanges.subscribe((value: any) => {
        //   this.data.filter = JSON.stringify('');
        // });
      }

    })
  }

  stopEventProp(event: any) {
    setTimeout(() => {
      event.stopPropagation();
    })
  }

  selectedHierarchiRow = (rowData: any) => {
    if (this.viewType) {
      this.selectedHierarchical.emit(rowData)
    }
  }

  selectDate = (event: any, row: any) => {
    this.selectedRowDate = event.value
    let selectedObj = {
      selectedRow: row,
      selectedDate: this.selectedRowDate
    }
    this.effectiveDateChanges.emit(selectedObj)
    this.isEffectiveDateToggled = false;
  }

  onClose = (event: any, row: any) => {
    //event.open()
    if (this.isEffectiveDateToggled) {
      let objIndex = this.data['data'].findIndex((obj: any) => {
       return obj.group_id == row['group_id']
      });
      this.data['data'][objIndex]['status'] = !row['status']
      this.isEffectiveDateToggled = true;
    } else {
      this.isEffectiveDateToggled = true;
    }
  }

  showTestEmit = (event: any) => {
    console.log('>>>>', event)
  }

  selectedFilterOption = (value: any, columnName: any) => {
    this.filteredValues.emit(this.filterForm.value)
  }

  filterClicked = (value: any) => {
    if (this.contentType == 'supplierAssociateLibrary' || this.contentType == 'distributerAssociateLibrary' || this.contentType == 'weeklyLogin') {
      if (value == 'Asso ID') {
        this.options = this.filterAssociateId
      }
      if (value == 'Activate / Deactivate') {
        this.options = [{ displayText: "Active", value: 1 }, { displayText: "In Active", value: 0 }]
      }
      if (value == 'Permission') {
        this.options = [{ displayText: "Associate", value: "associate" }, { displayText: "Manager", value: "manager" }]
      }
      if (value == 'Edited By') {
        this.options = this.filterEmailId;
      }
    }
    if (this.contentType == 'supplierAssociateUser') {
      if (value == 'Active/Inactive') {
        this.options = [{ displayText: "Active", value: "Active" }, { displayText: "In Active", value: "InActive" }]
      }
      if (value == 'Active') {
        this.options = [{ displayText: "TRUE", value: 1 }, { displayText: "FALSE", value: 0 }]
      }
      if (value == 'Permission') {
        this.options = this.permissionOptions
      }
    }
  }

  startChange = (event: any, columnName: any) => {
    if (event.value) {
      let startUTC = moment.utc(event.value).local().format('YYYY-MM-DD')
      this.addFromDateToFilterObject(startUTC, columnName)
    }
  }
  endChange = (event: any, columnName: any) => {
    if (event.value) {
      let startUTC = moment.utc(event.value).local().format('YYYY-MM-DD')
      this.addToDateToFilterObject(startUTC, columnName)
    }

  }

  viewOrgDetails = (value: any) => {
    this.selectedOrgName.emit(value)
  }

  redirectToEdit = (rowData: any) => {
    // console.log(rowData);
    this.redirectForEdit.emit(rowData);
  }

  selectedPermissionOption = (value: any, rowData: any) => {
    if (value) {
      let details = { value: value, selectedRow: rowData }
      this.selectedPermission.emit(details)
    }
  }

  checkNameLength = (value: any,length?:number) => {
    return value
  }

  addFromDateToFilterObject = (date: any, columnName: any) => {
    if (this.contentType == 'supplierAssociateLibrary' || this.contentType == 'distributerAssociateLibrary' ||
      this.contentType == 'supplierAssociateUser') {
      if (columnName['header'] == 'Effective Date') {
        this.filterForm.value['active_from'] = date
      }
      if (columnName['header'] == 'Edited Date') {
        this.filterForm.value['updated_date_from'] = date
      }
    }
    if (this.contentType == 'supplierWithoutData') {
      if (columnName['header'] == 'Last Upload Date') {
        this.filterForm.value['last_uploaded_from'] = date
      }
    }
    if (this.contentType == 'weeklyLogin') {
      if (columnName['header'] == 'Last Login') {
        this.filterForm.value['last_login_from'] = date
      }
    }
    if(this.contentType == 'rebateTopOpportunities'){
      if(columnName['header'] =='File date'){
        this.filterForm.value['file_date_from'] = date
      }
    }
    if(this.contentType == 'reportGenerator'){
      if(columnName['header'] =='File date'){
        this.filterForm.value['file_date_from'] = date
      }
    }
    if (this.contentType == 'rebateGovernance' || this.contentType == 'rebateGovernanc2') {
      if (columnName['header'] == 'Created') {
        this.filterForm.value['created_from'] = date
      }
    }
    if(this.contentType == 'financialHealthDistributor' || this.contentType =='financialHealthSupplier'){
      if (columnName['header'] == 'Last Transaction Date') {
        this.filterForm.value['last_transaction_from'] = date
      }
    }
    if(this.contentType == 'payoutAssessment'){
      if(columnName['header'] =='Effective Date'){
        this.filterForm.value['effectiveDateFrom'] = date
      }
    }
    this.filteredValues.emit(this.filterForm.value)
  }

  addToDateToFilterObject = (date: any, columnName: any) => {
    if (this.contentType == 'supplierAssociateLibrary' || this.contentType == 'distributerAssociateLibrary' || this.contentType == 'supplierAssociateUser') {
      if (columnName['header'] == 'Effective Date') {
        this.filterForm.value['active_to'] = date
      }
      if (columnName['header'] == 'Edited Date') {
        this.filterForm.value['updated_date_to'] = date
      }
    }
    if (this.contentType == 'supplierWithoutData') {
      if (columnName['header'] == 'Last Upload Date') {
        this.filterForm.value['last_uploaded_to'] = date
      }
    }
    if (this.contentType == 'weeklyLogin') {
      if (columnName['header'] == 'Last Login') {
        this.filterForm.value['last_login_to'] = date
      }
    }
    if(this.contentType == 'rebateTopOpportunities'){
      if(columnName['header'] =='File date'){
        this.filterForm.value['file_date_to'] = date
      }
    }
    if(this.contentType == 'reportGenerator'){
      if(columnName['header'] =='File date'){
        this.filterForm.value['file_date_to'] = date
      }
    }
    if (this.contentType == 'rebateGovernance' || this.contentType == 'rebateGovernanc2') {
      if (columnName['header'] == 'Created') {
        this.filterForm.value['created_to'] = date
      }
    }
    if(this.contentType == 'financialHealthDistributor' || this.contentType =='financialHealthSupplier'){
      if (columnName['header'] == 'Last Transaction Date' || this.contentType =='financialHealthSupplier') {
        this.filterForm.value['last_transaction_to'] = date
      }
    }
    if(this.contentType == 'payoutAssessment'){
      if(columnName['header'] =='Effective Date'){
        this.filterForm.value['effectiveDateTo'] = date
      }
    }
    this.filteredValues.emit(this.filterForm.value)
  }

  // editRecord = (value:any)=>{
  //   if(value){
  //     this.editedSelectedRow.emit(value)
  //   }
  // }

  redirectToDashboard = (element: any) => {
    this.switchToUser.emit(element);
  }

  TriggerEmail = (element: any) => {
    this.sendEmailEmitter.emit(element)
  }

  openDistributorData = (element: any) => {
    if (element) {
      this.distributorData.emit(element)
    }
  }
  redirectToProgramDetails = (element: any) => {
    this.navigateToProgramDetail.emit(element);
  }

  selectedTicketRow = (data: any) => {
    if (data) {
      if (this.contentType != 'rebateGovernance') {
        this.selectedRowData.emit(data)
      }
    }
    this.navigateToRebateGovReqDetail.emit(data);
  }

  viewMore(data:any){
      if(this.selection.selected.length >0){
        this.selection.clear();
      }
      this.selection.toggle(data);
      this.selectedOrgName.emit(data);
  }

  sortColumnData = (sort: Sort) =>{
    console.log("======>",sort);

    this.selectedSortData = sort
    this.sortDataEvent.emit(sort)
  }

  selectedRadioValue = (value:any)=>{
    console.log("value--->",value)
    setTimeout(()=>{
      this.selectedValue = value
      this.selectedRowData.emit(value)
    })

  }

  exportEachDealer = (value: any) => {
    if (value) {
      console.log('download row: ', value);
      this.exportEach.emit(value);
      // this.selectedRow(value)
    }
  }


}
