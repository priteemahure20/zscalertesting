import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HierarchicalTableComponent } from './hierarchical-table.component';

describe('HierarchicalTableComponent', () => {
  let component: HierarchicalTableComponent;
  let fixture: ComponentFixture<HierarchicalTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HierarchicalTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HierarchicalTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
