import { ComponentFixture, TestBed } from '@angular/core/testing';

import { YearSelectDropdownComponent } from './year-select-dropdown.component';

describe('YearSelectDropdownComponent', () => {
  let component: YearSelectDropdownComponent;
  let fixture: ComponentFixture<YearSelectDropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ YearSelectDropdownComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(YearSelectDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
