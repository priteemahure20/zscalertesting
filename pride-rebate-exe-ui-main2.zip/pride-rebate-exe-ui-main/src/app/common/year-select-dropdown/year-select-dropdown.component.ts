import { Component, EventEmitter, forwardRef, Input, OnInit, Output } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-year-select-dropdown',
  templateUrl: './year-select-dropdown.component.html',
  styleUrls: ['./year-select-dropdown.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => YearSelectDropdownComponent),
  }],
})
export class YearSelectDropdownComponent implements OnInit {

  @Input() years: any;
  @Input() selectedYear:any;
  @Output() selectedYearOption = new EventEmitter<string>();

  constructor(private dataService: DataService) { 
    console.log("====",this.years);
    
  }

  selectYear(value: string) {
    this.selectedYearOption.emit(value);
    // console.log('selecgted year: ', value);
    this.dataService.yearSubject.next(value);
  }

  ngOnInit(): void {

  }

}
