import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerticalChordsComponent } from './vertical-chords.component';

describe('VerticalChordsComponent', () => {
  let component: VerticalChordsComponent;
  let fixture: ComponentFixture<VerticalChordsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VerticalChordsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VerticalChordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
