import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-vertical-chords',
  templateUrl: './vertical-chords.component.html',
  styleUrls: ['./vertical-chords.component.scss']
})
export class VerticalChordsComponent implements OnInit {

  @Input()
  type:any

  @Input()
  data:any;
  @Output() navigateToProgramDetail = new EventEmitter();
  @Output() hidePagination = new EventEmitter();
  dash: string = ' - ';
  constructor() { }

  ngOnInit(): void {
    console.log("test of data--->",this.data)
  }

  checkNameLength = (name: any,size:number) => {
    if (name && name.length > 1) {
      let values = Array.isArray(name)?name.join(', '):name
      return values.length>size?values.substring(0, size) + "...":values;
    } else {
      return name
    }
  }

  naviagteToProgramDetail = (data:any) =>{
    this.navigateToProgramDetail.emit(data);
  }

}
