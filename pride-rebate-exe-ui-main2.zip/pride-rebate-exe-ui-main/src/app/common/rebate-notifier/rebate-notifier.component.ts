import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rebate-notifier',
  templateUrl: './rebate-notifier.component.html',
  styleUrls: ['./rebate-notifier.component.scss']
})
export class RebateNotifierComponent implements OnInit {
  public notification: any = {
    // message: "hello"
  };
  public readonly config: any;

  constructor() { }

  ngOnInit(): void {
    
  }

  /**
   * Handle click on dismiss button
   */
   public onClickDismiss(): void {
    // this.dismiss.emit(this.notification.id);
  }  

}
