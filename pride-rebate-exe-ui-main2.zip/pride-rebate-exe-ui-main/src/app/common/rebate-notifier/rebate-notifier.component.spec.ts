import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RebateNotifierComponent } from './rebate-notifier.component';

describe('RebateNotifierComponent', () => {
  let component: RebateNotifierComponent;
  let fixture: ComponentFixture<RebateNotifierComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RebateNotifierComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RebateNotifierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
