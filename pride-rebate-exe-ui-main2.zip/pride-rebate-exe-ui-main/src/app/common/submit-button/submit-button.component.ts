//Useage of btn in html
// <app-submit-button [color]="'#FFFFFF'" [background]="'#F48120'" [name]="'Submit'" (submit)="submitBtn()"></app-submit-button>

//Useage of btn in ts file
// submitBtn = () =>{
//   do requried functionality
// }

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-submit-button',
  templateUrl: './submit-button.component.html',
  styleUrls: ['./submit-button.component.scss']
})
export class SubmitButtonComponent implements OnInit {

  @Input()
  background:any;
  @Input()
  color:any;
  @Input()
  name:any

  @Output()
  submit = new EventEmitter()

  constructor() { }

  ngOnInit(): void {
  }

  submitBtn = () =>{
    this.submit.emit();
  }

}
