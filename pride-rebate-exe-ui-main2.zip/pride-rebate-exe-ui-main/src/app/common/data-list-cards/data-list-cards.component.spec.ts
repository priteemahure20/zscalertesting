import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataListCardsComponent } from './data-list-cards.component';

describe('DataListCardsComponent', () => {
  let component: DataListCardsComponent;
  let fixture: ComponentFixture<DataListCardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DataListCardsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DataListCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
