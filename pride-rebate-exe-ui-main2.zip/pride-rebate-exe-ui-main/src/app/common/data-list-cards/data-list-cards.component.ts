import {ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation} from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material/icon';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-data-list-cards',
  templateUrl: './data-list-cards.component.html',
  styleUrls: ['./data-list-cards.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,

})
export class DataListCardsComponent implements OnInit {

  @Input()
  data:any
  @Input()
  type:any;
  @Output()
  selectedDataEmitter = new EventEmitter();
  @Output()
  switchUserEmitter = new EventEmitter();
  @Input()
  label:any
  userType:any;
  constructor(private domSanitizer: DomSanitizer,private matIconRegistry: MatIconRegistry, private authService:AuthService) {
    this.matIconRegistry.addSvgIcon("expand", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/pop-out.svg"))

  }

  ngOnInit(): void {
    const {userType} = this.authService.getUser() as any;
    this.userType = userType;
  }
  fixedDecimalValue = (data:any) =>{
    if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      }else{
        return data
      }

    } else{
      return 0
    }
  }

  abbreviateNumber = (value:any) => {
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore

      notation: "compact",
      compactDisplay: "short",
      style: "currency",currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  }

  selectedData = (data:any) =>{
    this.selectedDataEmitter.emit(data)
  }

  checkNameLength = (name: any,size:number) => {
    if (name && name.length > 1) {
      let values = Array.isArray(name)?name.join(', '):name
      return values.length>size?values.substring(0, size) + "...":values;
    } else {
      return name
    }
  }

  getDataBySupplier = (value:any) =>{
    if(value){
      this.switchUserEmitter.emit(value)
    }
  }



}
