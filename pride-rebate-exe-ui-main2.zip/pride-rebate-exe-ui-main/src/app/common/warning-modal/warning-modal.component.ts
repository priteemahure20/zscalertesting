import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {MatIconRegistry} from '@angular/material/icon';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'app-warning-modal',
  templateUrl: './warning-modal.component.html',
  styleUrls: ['./warning-modal.component.scss']
})
export class WarningModalComponent implements OnInit {
  message: any;
  type:any;
  constructor(
      public dialogRef: MatDialogRef<WarningModalComponent>, @Inject(MAT_DIALOG_DATA) public data: { type: string, message: string },
      private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer) {
    this.matIconRegistry.addSvgIcon("close", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/close.svg"))
    this.matIconRegistry.addSvgIcon("warning", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/warning.svg"))
    this.matIconRegistry.addSvgIcon("approve-warning", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/approve-warning.svg"))
    this.matIconRegistry.addSvgIcon("success-svg", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/success-svg.svg"))
  }

  ngOnInit(): void {
    this.message = this.data['message']
    this.type = this.data['type']
  }

  close = () => {
    this.dialogRef.close('close');
  }

  reject = () =>{
    if(this.type == 'agreementDetailsReject' ) {
      this.dialogRef.close('reject');
    } else if(this.type == 'unlockRequest'){
      this.dialogRef.close('unlock');
    } else if(this.type == 'agreementDetailsApprove'){
      this.dialogRef.close('Approve');
    }else if(this.type == 'agreementDetailsRecall'){
      this.dialogRef.close('Approve');
    }
  }
  confirm = () =>{
    this.dialogRef.close('confirm');

  }

  getButtonText = () =>{
    if(this.type == 'agreementDetailsReject'){
      return 'Reject'
    } else if(this.type=='unlockRequest'){
      return 'Yes'
    }else if(this.type == 'agreementDetailsRecall'){
      return "Recall"
    }else{
      return 'Approve'
    }
  }
}
