import { Component, Input, OnInit, Output,EventEmitter } from '@angular/core';
import * as d3 from "d3";

@Component({
  selector: 'app-d3-pie',
  templateUrl: './d3-pie.component.html',
  styleUrls: ['./d3-pie.component.scss']
})
export class D3PieComponent implements OnInit {
  @Input("pieData") public pieData: SimpleDataModel[] = [];
  @Input("textColor") public textColor: string = "#ffffff";
  @Input("isPercentage") public isPercentage: boolean = false;
  @Input("enablePolylines") public enablePolylines: boolean = false;
  @Input()public  type:any
  @Output()
  selectedValue = new EventEmitter()
  public d3 = d3;

  public chartId:any;
  public svg:any;
  public margin = 0;
  public width = 750;
  public height = 450;

  // The radius of the pie chart is half the smallest side
  public radius = Math.min(this.width, this.height) / 2 - this.margin;

  public colors:any;
  constructor() {
  }

  ngOnInit() {
    this.createSvg();
    this.createColors();
    this.drawChart();
  }

  public createSvg(): void {
    if(this.type=='supplier-dashboard'){

      this.svg = this.d3
          .select("figure#pie")
          .append("svg")
          .attr("viewBox", `20 0 600 500`)
          // .attr('width', this.width)
          //.attr('height', this.height)
          .append("g")
          .attr(
              "transform",
              "translate(" + this.width / 2 + "," + this.height / 2 + ")"
          );
    }else {
      this.svg = this.d3
          .select("figure#pie")
          .append("svg")
          .attr("viewBox", `-40 0 640 470`)
          // .attr('width', this.width)
          //.attr('height', this.height)
          .append("g")
          .attr(
              "transform",
              "translate(" + this.width / 2 + "," + this.height / 2 + ")"
          );
    }

  }

  public createColors(data = this.pieData): void {
    this.colors = this.d3
      .scaleOrdinal()
      .domain(data.map(d => d.value.toString()))
      .range([
        "#6773f1",
        "#32325d",
        "#6162b5",
        "#6586f6",
        "#8b6ced",
        "#1b1b1b",
        "#212121"
      ]);
  }
  public drawChart(data = this.pieData): void {
    // Compute the position of each group on the pie
    const pie = this.d3.pie<any>().value((d: any) => Number(d.value));
    const data_ready = pie(data);

    // The radius of the pieplot is half the width or half the height (smallest one). I subtract a bit of margin.
    let radius = Math.min(this.width, this.height) / 2 - this.margin;
    let outerArc = this.d3
      .arc()
      .innerRadius(radius * 0.9)
      .outerRadius(radius * 0.9);
    // The arc generator
    let arc = this.d3
      .arc()
      .innerRadius(radius * 0.5) // This is the size of the donut hole
      .outerRadius(radius * 0.8);
      let tooltip = d3.select("#tooltip")

    // append the svg object to the div called 'my_dataviz'

    // Build the pie chart: Basically, each part of the pie is a path that we build using the arc function.
    this.svg
      .selectAll("pieces")
      .data(data_ready)
      .enter()
      .append("path")
      .attr(
        "d",
        this.d3.arc()
          .innerRadius(0)
          .outerRadius(this.radius)
      )
      .attr("fill", (d:any, i:any) => (d.data.color ? d.data.color : this.colors(i)))
      .style("stroke-width", "1px")
      .style("cursor","pointer")
      .on("click",(event:any,d:any)=>{
        this.selectedValue.emit(d['data'])
      })
      // .on("mouseover", function (event:any,d:any){
      //   console.log('----->',d)
      //   tooltip.style("opacity", 0.6);
      //   tooltip
      //     .html(
      //       "<span>" +
      //         'Name' +
      //         " : <span style='color:red'>" + d.data.name +"</span>"+
      //         "</span><br>"+
      //         "<span> Value" +
      //         " : "+d.data.value +
      //         "</span><br>" 
      //     )
      //     .style("left", event.pageX +8 + "px")
      //     .style("top", event.pageY + 100 + "px");
      // })
      // .on("mouseout", function(d:any) {
      //   tooltip.style("opacity", 0);
      // })

    // Now add the annotation. Use the centroid method to get the best coordinates
    
    const labelLocation = this.d3
      .arc()
      .innerRadius(50)
      .outerRadius(this.radius);
    let dy = 0;
    let index = 0;
    this.svg
      .selectAll("pieces")
      .data(pie(data))
      .enter()
      .append("text")
      .style("font-size", "11px")
      .text((d:any):any => {
        if (
          ((d.endAngle - d.startAngle) / (2 * Math.PI)) * 100 > 5 ||
          !this.enablePolylines
        ) {
          if(this.type !='bgDashboard' && this.type !='supplier-dashboard'){
            return (
                d.data.name +
                " (" +
                d.data.value +
                (this.isPercentage ? "%" : "") +
                ")"
            );
          }

        }
      })
      .attr("transform", (d:any) => "translate(" + labelLocation.centroid(d,60) + ")")
      .style("text-anchor", "middle")
      .style("font-size", 18)
      .style("font-family","Fira Sans")
      .attr("fill", this.textColor)
   
    if (this.enablePolylines && this.type !='bgDashboard') {
      this.svg
        .selectAll("allLabels")
        .data(data_ready)
        .enter()
        .append("text")
        .text((d:any) => {
          if (((d.endAngle - d.startAngle) / (2 * Math.PI)) * 100 > 5) {
            return null;
          } else {
            return (
              d.data.name +
              " (" +
              d.data.value +
              (this.isPercentage ? "%" : "") +
              ")"
            );
          }
        })
        .style("font-size", "28px")
        .attr("dy",(d:any) => {
          if (((d.endAngle - d.startAngle) / (2 * Math.PI)) * 100 > 5) {
            return null;
          } else {
            let value = 0.35;
            if (index != 0) dy = dy + 1;
            index++;
            value = value + dy;
            return value.toString() + "em";
          }
        })
        .attr("transform", (d:any) => {
          if (((d.endAngle - d.startAngle) / (2 * Math.PI)) * 100 > 5) {
            return null;
          } else {
            let pos = outerArc.centroid(d);
            let midangle = d.startAngle + (d.endAngle - d.startAngle) / 2;
            pos[0] = radius * 0.99 * (midangle < Math.PI ? 1 : -1);
            return "translate(" + pos + ")";
          }
        })
        .style("text-anchor", (d:any) => {
          let midangle = d.startAngle + (d.endAngle - d.startAngle) / 2;
          return midangle < Math.PI ? "start" : "end";
        })
      .style("font-size", 18)
      .style("font-family","Fira Sans")
      .attr("fill",  (d:any, i:any) => (d.data.color ? d.data.color : this.colors(i)))
      index = 0;
      let addTo = 5;
      this.svg
        .selectAll("allPolylines")
        .data(data_ready)
        .enter()
        .append("polyline")
        .attr("stroke", (d:any, i:any) => (d.data.color ? d.data.color : this.colors(i)))
        .style("fill", "none")
        .attr("stroke-width", 1)
        .attr("points", (d:any) => {
          if (((d.endAngle - d.startAngle) / (2 * Math.PI)) * 100 > 5) {
            return null;
          } else {
            let posA = arc.centroid(d); // line insertion in the slice
            let posB = outerArc.centroid(d); // line break: we use the other arc generator that has been built only for that
            let posC = outerArc.centroid(d); // Label position = almost the same as posB
            let midangle = d.startAngle + (d.endAngle - d.startAngle) / 2; // we need the angle to see if the X position will be at the extreme right or extreme left
            posC[0] = radius * (midangle < Math.PI ? 1 : -1); // multiply by 1 or -1 to put it on the right or on the left
            posC[0] = posC[0] + addTo;
            posC[1] = posC[1] + addTo;
            addTo = addTo + 10;
            return [posA, posB, posC];
          }
        });
    }
  }

}
export interface SimpleDataModel {
  name: string;
  value: string;
  color?: string;
}
