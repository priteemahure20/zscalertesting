import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {SelectionModel} from '@angular/cdk/collections';
import { AuthService } from 'src/app/services/auth.service';
import { UserType } from '../../helpers/constants';
import * as moment from 'moment';
import { ReusableService } from 'src/app/services/reusable.service';

@Component({
  selector: 'app-aggrement-programs',
  templateUrl: './aggrement-programs.component.html',
  styleUrls: ['./aggrement-programs.component.scss']
})
export class AggrementProgramsComponent implements OnInit {

  @Input()
  agreementsList:any;
  @Input()
  type:any;
  @Input()
  programFor:any;
  userType: any;
  @Input()
  requestType:any;
  @Output()
  selectedAggrements = new EventEmitter()
  @Output()
  programAgreements = new EventEmitter()

  selection = new SelectionModel<any>(true, []);

  constructor(private authService: AuthService, private reusableService:ReusableService){}

  ngOnInit(): void {
    this.userType = this.authService.getUser()?.userType as UserType;
    console.log('user type', this.userType);
  }
  singleSelection(element: any) {
    this.selection.toggle(element);
    this.selectedAggrements.emit({status:this.selection.isSelected(element),masterId:element['masterId']})
  }

  selectedProgramAggrement = (data:any)=>{
    this.programAgreements.emit(data)
  }
  
  checkNameLength = (name: any) => {
    if (name && name.length > 1) {
      let values = Array.isArray(name)?name.join(', '):name
      return values.length>30?values.substring(0,30) + "...":values;
    } else {
      return name
    }
  }

  formatDate = (date:any) => {
    if(date){
      let dateValue =  moment(date,'YYYY-MM-DD')
      return  dateValue.toISOString(true).split("T")[0]
      
    }
  }

  checkDate = (startDate:any) => {
    let currentDate = new Date();
    return new Date(startDate) > currentDate;
  };

  checkName =(name:any)=>{
    if (name && name.length >1){
     let Name =name.toLowerCase().split('_');
     let TitleName = Name.map(function(Name:any){
      return Name.charAt(0).toUpperCase() + Name.slice(1);
     })
     let rebatetype =TitleName.join(' ');
     if(rebatetype == 'Pride Incentive'){
      rebatetype = 'PRIDE Incentive';
     }
     if(rebatetype=='Management Fee' || rebatetype=='Passthrough' || rebatetype=='Training Rebate' || rebatetype=='Marketing' || rebatetype=='Future Qualification' || rebatetype=='Pride Incentive' || rebatetype=='PRIDE Incentive' || rebatetype == 'Training Base' || rebatetype=='Training Incentive')
     {
      return rebatetype.substring(0,rebatetype.length)
     }
     else
     {
      return rebatetype.substring(0,rebatetype.length-1)
     }
    }
  }

  formatEffectiveDate(date:any){
    let effectiveDate = date;
    let effectiveDateStart = effectiveDate.substring(0, 10)
    let effectiveDateEnd = effectiveDate.substr(13, 10);
    return this.getEffectiveDate(effectiveDateStart,effectiveDateEnd);
  }

  getEffectiveDate = (start:any,end:any) =>{
    return `${this.convertDateToMMDDYYYY(start)} - ${this.convertDateToMMDDYYYY(end)}`
  }

  convertDateToMMDDYYYY = (value:any) =>{
    return moment(value).format('MM/DD/YYYY');
  }
}
