import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AggrementProgramsComponent } from './aggrement-programs.component';

describe('AggrementProgramsComponent', () => {
  let component: AggrementProgramsComponent;
  let fixture: ComponentFixture<AggrementProgramsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AggrementProgramsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AggrementProgramsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
