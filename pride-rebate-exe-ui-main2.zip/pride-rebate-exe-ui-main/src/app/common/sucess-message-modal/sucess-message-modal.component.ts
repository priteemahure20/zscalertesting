import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {MatIconRegistry} from '@angular/material/icon';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'app-sucess-message-modal',
  templateUrl: './sucess-message-modal.component.html',
  styleUrls: ['./sucess-message-modal.component.scss']
})
export class SucessMessageModalComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<SucessMessageModalComponent>, @Inject(MAT_DIALOG_DATA) public data: { type: string, actionStatus: string },
              private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer,) {
    this.matIconRegistry.addSvgIcon("close", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/close.svg"))
    this.matIconRegistry.addSvgIcon("reject-icon", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/reject-icon.svg"))
    this.matIconRegistry.addSvgIcon("success-icon", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/success-svg.svg"))

  }
  message: any;
  actionStatus:any;

  ngOnInit(): void {
    this.message = this.data['type'];
    this.actionStatus = this.data['actionStatus'];
  }

  close = () =>{
    this.dialogRef.close()
  }

}
