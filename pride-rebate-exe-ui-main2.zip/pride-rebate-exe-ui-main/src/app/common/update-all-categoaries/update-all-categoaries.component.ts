import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-update-all-categoaries',
  templateUrl: './update-all-categoaries.component.html',
  styleUrls: ['./update-all-categoaries.component.scss']
})
export class UpdateAllCategoariesComponent implements OnInit {
  form: FormGroup;
  submitted = false;
  successMessage = '';
  errorMessage = '';
  selectedValue:any ='';
  options:any=[]
  constructor(private fb: FormBuilder,private httpService: HttpService,
    public dialogRef: MatDialogRef<UpdateAllCategoariesComponent>,
    @Inject(MAT_DIALOG_DATA) public extraData: {options:any},) { 
    this.form = this.fb.group({
			select: [null, Validators.required]
		});
    this.options = this.extraData
  }
  get selectFormControl() { return this.form.get('select'); }

  ngOnInit(): void {
    this.options = this.extraData['options']
  }



  close(): void {
    this.dialogRef.close();
  }

  submit(){
    console.log('selected value in mpc update all: ', this.selectedValue);
    this.dialogRef.close(this.selectedValue);
  }

  onChange = (value:any) =>{
    this.selectedValue = value['value']
  }
}
