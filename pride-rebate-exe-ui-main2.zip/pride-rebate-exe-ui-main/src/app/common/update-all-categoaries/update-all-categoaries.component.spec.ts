import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateAllCategoariesComponent } from './update-all-categoaries.component';

describe('UpdateAllCategoariesComponent', () => {
  let component: UpdateAllCategoariesComponent;
  let fixture: ComponentFixture<UpdateAllCategoariesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateAllCategoariesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateAllCategoariesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
