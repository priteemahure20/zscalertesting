import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

export enum MessageDialogType {
  ALERT = 'ALERT',
  CONFIRM = 'CONFIRM'
}

export interface MessageDialogData {
  title: string;
  message: string;
  type?: MessageDialogType;
}

@Component({
  selector: 'app-message-dialog',
  templateUrl: './message-dialog.component.html'
})
export class MessageDialog {

  alertDialog: MessageDialogType = MessageDialogType.ALERT;
  confirmDialog: MessageDialogType = MessageDialogType.CONFIRM;

  dialogType: MessageDialogType = MessageDialogType.ALERT;

  constructor(public dialogRef: MatDialogRef<MessageDialog>, @Inject(MAT_DIALOG_DATA) public data: MessageDialogData) {
    if (data.type) {
      this.dialogType = data.type;
    }
  }

}
