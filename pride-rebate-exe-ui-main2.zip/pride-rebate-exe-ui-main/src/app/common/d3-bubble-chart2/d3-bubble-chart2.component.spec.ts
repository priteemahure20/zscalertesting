import { ComponentFixture, TestBed } from '@angular/core/testing';

import { D3BubbleChart2Component } from './d3-bubble-chart2.component';

describe('D3BubbleChart2Component', () => {
  let component: D3BubbleChart2Component;
  let fixture: ComponentFixture<D3BubbleChart2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ D3BubbleChart2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(D3BubbleChart2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
