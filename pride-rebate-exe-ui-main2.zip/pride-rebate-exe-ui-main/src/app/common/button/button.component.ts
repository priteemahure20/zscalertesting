import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent implements OnInit {

  @Input() buttonLabel: string | undefined;
  @Input() size: string | undefined;
  @Input() disabled: boolean = true;
  @Input() minWidth:any;
  @Input() width:any
  @Input() height:any

  @Output()
  submit = new EventEmitter()
  constructor() { }

  ngOnInit(): void {
  }

  submitValues = () =>{
    this.submit.emit();
  }

}
