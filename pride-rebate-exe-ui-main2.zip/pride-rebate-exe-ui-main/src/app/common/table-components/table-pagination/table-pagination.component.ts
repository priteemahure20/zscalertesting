import { Component, EventEmitter, Input, Output } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { PaginationOptions } from 'src/app/models/pagination-options.model';

@Component({
  selector: 'app-table-pagination',
  templateUrl: './table-pagination.component.html',
  styleUrls: ['./table-pagination.component.scss']
})
export class TablePaginationComponent {

  @Input() pageOptions: PaginationOptions = { limit: 10, pageNo: 1, length: 0 };
  @Input() pageLimits: number[] = [10, 15, 30, 100];
  @Output() pageOptionsChange: EventEmitter<PaginationOptions> = new EventEmitter<PaginationOptions>();

  getNextPage(event: PageEvent) {
    console.log('getNextPage', event);
    this.pageOptionsChange.emit({ ...this.pageOptions, pageNo: event.pageIndex + 1, limit: event.pageSize });
  }

  selectedViewPageLimit(event: number) {
    console.log('selectedViewPageLimit', event);
    this.pageOptionsChange.emit({ ...this.pageOptions, limit: Number(event) });
  }

  goToPageNumber(event: number) {
    console.log('goToPageNumber', event);
    this.pageOptionsChange.emit({ ...this.pageOptions, pageNo: event });
  }
}
