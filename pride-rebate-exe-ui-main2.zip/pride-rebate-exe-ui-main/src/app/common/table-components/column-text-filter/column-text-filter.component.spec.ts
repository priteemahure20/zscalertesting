import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ColumnTextFilterComponent } from './column-text-filter.component';

describe('ColumnTextFilterComponent', () => {
  let component: ColumnTextFilterComponent;
  let fixture: ComponentFixture<ColumnTextFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ColumnTextFilterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ColumnTextFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
