import { Component, Input, Output, EventEmitter } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-column-text-filter',
  templateUrl: './column-text-filter.component.html',
  styleUrls: ['./column-text-filter.component.scss']
})
export class ColumnTextFilterComponent {

  @Input() title: string = '';
  @Input() column: string = '';

  @Output() aplyFilter: EventEmitter<any> = new EventEmitter<any>();

  filterOpened: boolean = false;
  inputControl = new FormControl('');
  timer?: any;

  constructor(private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer) {
    this.matIconRegistry.addSvgIcon("filter", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/filter_icon.svg"));
    this.inputControl.valueChanges.subscribe((value: any) => {
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        console.log('change value', value);
        this.aplyFilter.emit({ column: this.column, value });
      }, 1000);
    });
  }

  toggleFilter(event: any) {
    event.stopPropagation();
    this.filterOpened = true;
  }

  clearFilter() {
    if (this.inputControl.value) {
      this.inputControl.reset('');
    }
    this.filterOpened = false;
  }
}
