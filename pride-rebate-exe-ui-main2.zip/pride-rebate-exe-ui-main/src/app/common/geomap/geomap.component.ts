import { style } from '@angular/animations';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import * as d3 from 'd3';
import { select } from 'd3-selection';
import * as topojson from 'topojson-client';
import { GeometryObject, GeometryCollection, Topology, Objects } from 'topojson-specification';
@Component({
  selector: 'app-geomap',
  templateUrl: './geomap.component.html',
  styleUrls: ['./geomap.component.scss']
})
export class GeomapComponent implements OnInit {
  @Input()
  locationsData:any;

  @Output()
  selectedHospital = new EventEmitter();

  @Output()
  resetMapValues = new EventEmitter();

  margin = { top: 20, right: 20, bottom: 30, left: 50 };
  width = 600;
  height = 350;


  lookup:any = {
    "01" : "AL",
    "02" : "AK",
    "60" : "AS",
    "04":"AZ",
    "05":"AR",
    "81":"BI",
    "06":"CA",
    "08":"CO",
    "09":"CT",
    "10":"DE",
    "11":"DC",
    "12":"FL",
    "64":"FM",
    "13":"GA",
    "14":"",
    "66":"GU",
    "15":"HI",
    "84":"HI",
    "16":"ID",
    "17":"IL",
    "18":"IN",
    "19":"IA",
    "86":"JI",
    "67":"JA",
    "20":"KS",
    "21":"KY",
    "89":"KR",
    "22":"LE",
    "23":"ME",
    "68":"MH",
    "24":"MD",
    "25":"MA",
    "26":"MI",
    "71":"MI",
    "27":"MN",
    "28":"MS",
    "29":"MO",
    "30":"MT",
    "76":"NI",
    "31":"NE",
    "32":"NV",
    "33":"NH",
    "34":"NJ",
    "35":"NM",
    "36":"NY",
    "37":"NC",
    "38":"ND",
    "69":"MP",
    "39":"OH",
    "40":"OK",
    "41":"OR",
    "70":"PW",
    "95":"PA",
    "42":"PA",
    "72":"PR",
    "44":"RI",
    "45":"SC",
    "46":"SD",
    "47":"TN",
    "48":"TX",
    "74":"UM",
    "49":"UT",
    "50":"VT",
    "51":"VA",
    "78":"VI",
    "79":"WI",
    "53":"WA",
    "54":"WV",
    "55":"WI",
    "56":"WY"



}
  constructor() { }

  ngOnInit(): void {


    const svg = d3.select('#map').append('svg')
    .attr('viewBox', '-20 250 1000 100')
      .attr('width', this.width)
      .attr('height', this.height);
    const g:any = svg.append('g');
    g.attr('class', 'map');

    const tooltip = d3.select('#tooltip')
      .style('opacity', 0);

    d3.json('https://d3js.org/us-10m.v1.json')

      .then((topology: any) => {
        if(topology && topology.objects.counties){
          const featureCollection:any = topojson.feature(topology, topology.objects.states as GeometryCollection)["features"];
          const path:any = d3.geoPath();
           g.selectAll('path')
            //.data(topojson.feature(topology, topology.objects.states as GeometryCollection)["features"])
            .data(this.locationsData)
            .enter().append('path')
            .attr('d', path)
            .attr('class', (d:any)=>{
              return 'Feature'
            })
            .attr('d', (datum:any) => {
              const feature = topojson.merge(
                topology,
                topology.objects.states.geometries.filter((state:any) => {
                  return datum.contains.indexOf(this.lookup[state.id]) > -1;
                })
              );
              return path(feature);
            })
           
            .attr('fill', (d:any) => {
              return d.color;
            })
       
            .on("mouseover", (event:any,i:any,d:any) =>{
              d3.selectAll(".Feature")
              .transition()
              .duration(200)
              .style("opacity", 0.5)
              d3.select(event.currentTarget)
              .transition()
              .duration(200)
              .style("opacity", 1)
              .style("stroke", "white")
              .attr('stroke-width', 3)

              d3.selectAll("#content")
              .classed("selected", (e:any, j:any)=> { 
                if(e.name !=i.name){
                 let val = document.getElementsByClassName('content-'+j)[0]
                 val.setAttribute("opacity","0.4")
                }
                return j == i; 
              })
              
           })
           .on("mouseout", (event:any,i:any,d:any) => {
            d3.selectAll(".Feature")
              .transition()
              .duration(200)
              .style("opacity",1)
              d3.select(event.currentTarget)
              .transition()
              .duration(200)
              .style("opacity", 1)
              .style("stroke", "white")
              .attr('stroke-width', 3)
              d3.selectAll("#content")
              .classed("selected", (e:any, j:any)=> { 
                if(e.name !=i.name){
                 let val = document.getElementsByClassName('content-'+j)[0]
                 val.setAttribute("opacity","1")
                }
                return j == i; 
              })
           })
            .attr('stroke', 'white')
            .attr('stroke-width', 3)
        
           let zoom = d3.zoom()
            .on('zoom', function(event) {
              g.attr('transform', event.transform);
            })
            let rect =g.selectAll("rect")
            .data(this.locationsData)
            .enter();
          rect.append("rect")
          .attr('class',(d:any,i:any)=>{
            return 'content-'+i
           })
          .attr('id',(d:any,i:any)=>{
           return 'content'
          })
          .attr("x", (datum:any) =>{
            
            const feature = topojson.merge(
              topology,
              topology.objects.states.geometries.filter((state:any) => {
               
                return datum.contains[0] == this.lookup[state.id] ?true:false;
              })
            );
              return path.centroid(feature)[0]-50;
          })
          .attr("y", (datum:any) => {
            const feature = topojson.merge(
              topology,
              topology.objects.states.geometries.filter((state:any) => {
                return datum.contains[0] == this.lookup[state.id] ?true:false;
              })
            );
              return  path.centroid(feature)[1]-20;
          })
          .attr("width", 100)
        .attr("height", 60)
        .attr( "rx", "5")
        .attr( "ry", "5")
        .style("fill", "white");
        rect.append("text")
        .style("fill", "black")
        .style("font-size", "14px")
        .attr("dy", ".35em")
        .attr("x", (datum:any) =>{
          const feature = topojson.merge(
            topology,
            topology.objects.states.geometries.filter((state:any) => {
              return datum.contains[0] == this.lookup[state.id] ?true:false;
            })
          );
            return path.centroid(feature)[0];
        })
        .attr("y", (datum:any) => {
          const feature = topojson.merge(
            topology,
            topology.objects.states.geometries.filter((state:any) => {
              return datum.contains[0] == this.lookup[state.id] ?true:false;
            })
          );
            return  path.centroid(feature)[1];
        })
        .text(function(d:any) { return d.name; })
        .style("text-anchor", "middle")
  
          // const zoomed = (event:any) => {
          //   g.attr('transform', event.transform);
          // };
  
          // g.call(d3.zoom().on('zoom', zoomed))
          //   .on('click', (event:any) => {
          //     g.selectAll('mark')
          //       .attr('d', path.projection(path));
          //     g.selectAll('path')
          //       .attr('d', path.projection(path));
          //   });
  
          //   d3.select('#zoom_in').on('click', function() {
          //     zoom.scaleBy(g.transition().duration(750), 1.3);
          //   });
            
          //   d3.select('#zoom_out').on('click', function() {
          //     zoom.scaleBy(g, 1 / 1.3);
          //   });
        }
      

      });
      svg.on('click', (event) => {
        if ((event.target.className.baseVal != "feature" && event.target.className.baseVal != "circleClass")) {
          this.resetMapValues.emit(true);
        }
      })

      

  }

}
