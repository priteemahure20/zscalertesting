import {
  Component, ViewChild, EventEmitter,
  Input, Output, OnInit, ViewEncapsulation
} from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-chat-ui',
  templateUrl: './chat-ui.component.html',
  styleUrls: ['./chat-ui.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ChatUiComponent implements OnInit {
  text = '';
  newMessage = '';
  msgList: any;
  public flag: boolean = false;
  public htmlCode: any;
  public htmlDoc: any;
  selection: any;
  selectedUserName:any;

  @Input() messageList: any;
  @Input() userList: any;
  @Input() isScroll: any;
  @Input() status:any;
  @Output() selectedMessage = new EventEmitter<any>();
  @Output() scrollUp = new EventEmitter<string>();
  @Output() scrollBottom = new EventEmitter<string>();
  @ViewChild('refEl', { static: false }) refEl: any;
  @ViewChild('scrollMe') private myScrollContainer: any;

  constructor(private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer) {
    this.matIconRegistry
      .addSvgIcon("sent-button-arrow", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/sent-button-arrow.svg"))
  }

  ngOnInit(): void {
    this.scrollToBottom();
  }

  scrolledToBottom = false;

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  sendMessage = () => {
    let txt = document.getElementById('input-content')?.innerHTML;
    this.selectedMessage.emit({text:txt,selectedUser:this.selectedUserName});
    let element = document.getElementById('input-content') as HTMLInputElement;
    element.innerHTML = '';
  }

  format(e: any) {
    return '@' + e.displayText + '@';
  }

  itemSelected(event: any) {
    setTimeout(() => {
      this.selectedUserName = event;
      this.htmlDoc = document.getElementById('input-content');
      this.htmlDoc.innerHTML = this.htmlDoc.innerHTML.replace(
        '@' + event.displayText + '@',
        '<b class="user-list-item">' + '@' + event.displayText + '</b>&nbsp;'
      );
      this.selectEnd();
    }, 10);
  }

  selectEnd() {
    let range;
    range = document.createRange();
    range.selectNodeContents(this.htmlDoc);
    range.collapse(false);
    this.selection = window.getSelection();
    this.selection.removeAllRanges();
    this.selection.addRange(range);
  }

  scrollToBottom(): void {
    try {
      if (!this.scrolledToBottom) {
        this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
      }
    } catch (err) { }
  }

  onScroll() {
    this.scrolledToBottom = true;
  }

  scrollTowardUp = () => {
    this.scrollUp.emit();
  }

}
