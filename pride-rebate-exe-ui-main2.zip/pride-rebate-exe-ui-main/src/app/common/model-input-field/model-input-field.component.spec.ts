import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelInputFieldComponent } from './model-input-field.component';

describe('ModelInputFieldComponent', () => {
  let component: ModelInputFieldComponent;
  let fixture: ComponentFixture<ModelInputFieldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModelInputFieldComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelInputFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
