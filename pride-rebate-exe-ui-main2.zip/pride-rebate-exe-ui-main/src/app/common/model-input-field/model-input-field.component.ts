import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { Subject,of } from 'rxjs';
import { debounceTime, delay, distinctUntilChanged, map, mergeMap } from 'rxjs/operators';

@Component({
  selector: 'app-model-input-field',
  templateUrl: './model-input-field.component.html',
  styleUrls: ['./model-input-field.component.scss']
})
export class ModelInputFieldComponent implements OnInit {
  @Input()
  inputForm:any;
  @Input()
  labelName:any;
  @Input()
  fieldName:any;
  @Input()
  type:any;
  @Input()
  placeHolder:any;
  @Input()
  isClear=false;
  @Input()
  isDisabled:boolean = false

  @Output()
  inputValueChange = new EventEmitter();

  filterKeyUp = new Subject<any>();
  constructor() { }

  ngOnInit(): void {
    if(this.isClear){
      this.fieldName =""
    }
    this.filterKeyUp.pipe(
      map(event => event),
      debounceTime(1000),
      distinctUntilChanged(),
      mergeMap(search => of(search).pipe(
        delay(50),
      )),
    ).subscribe((res:any)=>{
      this.inputValueChange.emit(res)
    })
  }
  valueChange = (value:any) =>{
    this.filterKeyUp.next(value)
  }
  ngOnChanges(changes: SimpleChanges) {
    if(this.isClear){
      this.fieldName =""
    }
  }
  stopEventProp(event:any){
    setTimeout(() => {
      event.stopPropagation();
    })
  }
}
