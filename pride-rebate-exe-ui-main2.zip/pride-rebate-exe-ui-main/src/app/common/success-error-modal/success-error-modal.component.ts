import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-success-error-modal',
  templateUrl: './success-error-modal.component.html',
  styleUrls: ['./success-error-modal.component.scss']
})
export class SuccessErrorModalComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<SuccessErrorModalComponent>, @Inject(MAT_DIALOG_DATA) public data: { type: string, actionStatus: string, start_date:any, end_date:any,year:any },
    private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer,) {
    this.matIconRegistry.addSvgIcon("close", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/close.svg"))
    this.matIconRegistry.addSvgIcon("reject-icon", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/reject-icon.svg"))

  } 
  message: any;
  actionStatus:any;
  selectedYear:any;
  startDate:any;
  endDate:any;

  ngOnInit(): void {
    this.message = this.data['type'];
    this.actionStatus = this.data['actionStatus'];
    this.startDate = this.data['start_date'];
    this.endDate = this.data['end_date'];
    this.selectedYear = this.data['year'];
  }
  close = () => {
    this.dialogRef.close();
  }
  cancel = () => {
    this.dialogRef.close('cancel');
  }

  ok(){
    this.dialogRef.close('ok');
  }
}
