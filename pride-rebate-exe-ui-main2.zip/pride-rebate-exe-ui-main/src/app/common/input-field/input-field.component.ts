//Usage of Form in Parent Component in TS


// constructor(private fb:FormBuilder){}
// formName = this.fb.group({
//   loginemail: new FormControl('', [Validators.required, Validators.pattern('^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$')]),
//   password: new FormControl('', [Validators.required]),
// })


//Usage of Form in Parent Component in HTML


// <form [formGroup]="loginFormGroup">
// <app-input-field   [labelName]="'Email'" [fieldName]="'loginemail'" [type]="'email'" [placeHolder]="'Please Enter First Name'"></app-input-field>
//     <div
//     *ngIf="loginFormGroup.controls['loginemail'].hasError('required') && loginFormGroup.controls['loginemail']?.touched">
//     <span class="error">Email is required</span>
// </div>
// <div
//     *ngIf="loginFormGroup.controls['loginemail']?.hasError('pattern')  && loginFormGroup.controls['loginemail']?.touched">
//     <span class="error">Please enter a valid email address</span>
// </div> 
// <app-input-field   [labelName]="'Password'" [fieldName]="'password'" [type]="'password'" [placeHolder]="'Please Enter First Name'"></app-input-field>
  
// </form>
// <button (click)="saveForm()">Save</button>

import { Component, OnInit, Input, ViewEncapsulation, forwardRef, Output, EventEmitter } from '@angular/core';
import { ControlContainer, FormControl, ControlValueAccessor, AbstractControl, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-input-field',
  templateUrl: './input-field.component.html',
  styleUrls: ['./input-field.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting:forwardRef(() => InputFieldComponent),
    multi: true
  }],
})
export class InputFieldComponent implements OnInit {


  @Input()
  inputForm:any;
  @Input()
  labelName:any;
  @Input()
  fieldName:any;
  @Input()
  type:any;
  @Input()
  placeHolder:any;

  control: any;

  constructor(public controlContainer: ControlContainer) { }

    ngOnInit(): void {
      if( this.controlContainer && this.fieldName){
          this.control = this.controlContainer.control?.get(this.fieldName)
    }
  }
  
 
  



  
  

}


