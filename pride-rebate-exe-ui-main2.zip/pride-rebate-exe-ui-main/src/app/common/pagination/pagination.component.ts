import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MessageDialog } from '../message-dialog/message-dialog.component';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class Pagination implements OnInit {

  @Input()
  totalCount:any;
  @Input()
  pageLimits = [10,12]//[5,10,15,20,25] 
  //[15,30,45,60,75,90,105,120,135,150]
  @Input()
  selectedPageLimit:any = 10;
  @Input()
  addToCompare:any;
  @Output() 
  getNextPage = new EventEmitter();
  @Output()
  pageLimit = new EventEmitter();
  @Output()
  goTo = new EventEmitter();


  goToPage:any='';
  goToPageNumber:any;
  pageIndex='0'
  isClear = false

  @ViewChild(MatPaginator) matPaginator!: MatPaginator;

  constructor(private dialog: MatDialog) { }

  ngOnInit(): void {
    this.isClear = true;
    // if(this.selectedPageLimit){
    //   this.selectedPageLimit =this.selectedPageLimit;
    //   console.log("SelectedLimit",this.selectedPageLimit);
    // }else{
    //   this.selectedPageLimit=10;
    // }
    // this.selectedPageLimit=5;
    // this.selectedPageLimit ? this.selectedPageLimit : this.selectedPageLimit=10;
  }

  changePage = (pageEvent:any) =>{
    this.isClear = true
    this.getNextPage.emit(pageEvent)
    
  }

  selectedPageCount = (value:any) =>{
    this.isClear = true
    this.selectedPageLimit = value;
    this.pageLimit.emit(this.selectedPageLimit);   
  }

  getPageNumber = (value:number) =>{
    // if(value>0){
      this.goToPageNumber = value
    // }
  }
  submitPageNo(): void {
    if (this.goToPageNumber > 0 && this.goToPageNumber <= this.matPaginator.getNumberOfPages()) {
      this.pageIndex = ''
      setTimeout(() => {
        this.pageIndex = (parseInt(this.goToPageNumber) - 1).toString()
        this.goTo.emit(this.goToPageNumber)
      }, 100)
    } else {
      this.dialog.open(MessageDialog, { width: '400px', position: { top: '100px' }, data: { message: `Page number must be between 1 and ${this.matPaginator.getNumberOfPages()}.` } });
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if(this.isClear){
      this.goToPage =""
    }
  }

}
