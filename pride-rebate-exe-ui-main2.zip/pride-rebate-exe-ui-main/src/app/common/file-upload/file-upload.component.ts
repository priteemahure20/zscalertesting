import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { isCSVFile,isValidSize ,isValidSizePayout} from 'src/app/helpers/commonUtils';
import * as XLSX from 'xlsx';
import readXlsxFile from 'read-excel-file'

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit {

  @Input()
  resetFile:boolean=false

  @Input()
  type:any

  @Input()
  disabled:boolean=false;

  @Output()
  csvFileEmitter = new EventEmitter()
  @Output()
  validFileCheck = new EventEmitter();

  public fileName:any="No file chosen";
  public file:any;
  public isValidFile:boolean = false;
  public validFileSize:boolean = false;


  constructor() { }

  ngOnInit(): void {
    if(this.resetFile){
      this.file = '';
      this.fileName = '';
    }
  }

  csvInputChange = ($event:any) =>{
    const targetElement: any = $event.srcElement.files[0];
    if(targetElement){
      this.file='';
      setTimeout(() => {
        this.file = targetElement;
        this.fileName = this.file.name;
        let jsonData = null;
        const reader = new FileReader();
        reader.onload = (event) => {
          const data = reader.result;
          let workBook = XLSX.read(data, { type: 'binary' });
          let headers:any = [];
          jsonData = workBook.SheetNames.reduce((initial: any, name: any) => {
            const sheet = workBook.Sheets[name];
            initial[name] = XLSX.utils.sheet_to_json(sheet);
            for (const cell in sheet) {
              const cellDetails = XLSX.utils.decode_cell(cell);
              if (cellDetails.r === 0) {
                headers.push(sheet[cell].v);
              }
            }
            return initial;
          }, {})
          jsonData.Sheet1 = jsonData[workBook.SheetNames[0]]
          if(jsonData.Sheet1.length){
            if(this.type && this.type == 'associate'){
              let tempDataString = headers.toString();
              // const tempData = reader.result;
              // let tempDataString = tempData?.toString();
              let PIVOT_TYPE = 'PARENT PIVOT ID'
              if(tempDataString?.includes('PARENT PIVOT_ID')){
                PIVOT_TYPE = 'PARENT PIVOT_ID'
                tempDataString = tempDataString?.replace("PARENT PIVOT_ID", "TEMP");
              }
              if(tempDataString?.includes('ASSOCIATE NAME') && tempDataString?.includes('PIVOT ID')
              && tempDataString?.includes('GP ID') && tempDataString?.includes('HIERARCHY LEVEL')
              && (tempDataString?.includes('PARENT PIVOT ID') || tempDataString?.includes('TEMP') || tempDataString?.includes('PARENT PIVOT_ID'))){
                let flag:any;
                for (let row = 0; row < jsonData.Sheet1.length; row++) {
                  if(jsonData.Sheet1[row].hasOwnProperty('ASSOCIATE NAME') && jsonData.Sheet1[row].hasOwnProperty('PIVOT ID') && 
                  jsonData.Sheet1[row].hasOwnProperty('GP ID') && jsonData.Sheet1[row].hasOwnProperty('HIERARCHY LEVEL')){ 
                    if(!jsonData.Sheet1[row]['HIERARCHY LEVEL'].includes("CONGLOMERATE") && !jsonData.Sheet1[row].hasOwnProperty(PIVOT_TYPE)) {
                      flag = false;
                      this.csvFileEmitter.emit({isMandetoryColumns : 1})
                      break;
                    }
                    flag = true;
                    continue;
                  } else {
                    flag = false;
                    this.csvFileEmitter.emit({isMandetoryColumns : 1})
                    break;
                  }
                }
                if(flag){
                  this.checkFile(this.file)
                }
              } else {
                this.csvFileEmitter.emit({isMandetoryColumns : 2})
              }
            }else {
                this.checkFile(this.file)
            }
          } else {
            this.csvFileEmitter.emit(false)
          }
        }
        reader.readAsBinaryString(this.file);
      }, 500);
      // setTimeout(()=>{
      //   this.file = targetElement;
      //   this.fileName = this.file.name
      //   this.checkFile(this.file)
      // },500)
    }
  }

  checkFile = (file:any) => {
   
    if (isCSVFile(file)) {
      this.isValidFile = false
      let isValid:boolean;
      if(this.type=='payout' ||this.type=='payment'){
        isValid=isValidSizePayout(file)
        this.validFileCheck.emit(true)
      }else{
        isValid=isValidSize(file)
      }
      if(isValid && this.isValidFile ==false){
        this.validFileSize = false;
        this.csvFileEmitter.emit(file)
        this.validFileCheck.emit(true)
      }else{
        this.validFileSize = true
        this.validFileCheck.emit(false)
      }
    }else{
      this.isValidFile = true
      this.validFileCheck.emit(false)
    }
  } 

  ngOnChanges(changes: SimpleChanges) {
    if(this.resetFile){
      this.file = '';
      this.fileName = '';
    }
  }
}
