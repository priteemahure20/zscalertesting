import { Component, Input, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { AuthService } from 'src/app/services/auth.service';
import {TitleCasePipe} from '@angular/common';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.scss']
})
export class LineChartComponent implements OnInit {
  firstYLabel: any = 'Sales';
  secondYLabel: any = 'Rebate';
  @Input() singleYAxis = false;
  @Input() name: any;
  @Input() lineChartLabels: Label[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  @Input() set data(value: any) {
    this.updateEventLineData(value);
  };
  lineChartTypeLabel:any='';
  ticksColor: any = '#59595A';
  eventLineData = [
  {
    data: [], 
      pointRadius: 5, 
      lineTension: 0,
      borderColor: '#F48120', backgroundColor: '#F48120', pointBackgroundColor: '#F48120', pointBorderColor: '#F48120',
      fill: false, yAxisID: 'y-axis-0'
  },
  {
    data: [], 
      pointRadius: 5, 
      lineTension: 0, 
      borderColor: '#0097A6', backgroundColor: '#0097A6', pointBackgroundColor: '#0097A6', pointBorderColor: '#0097A6', 
      fill: false, yAxisID: 'y-axis-1'
    }
  ];
  maxValue:any;
  minValue:any;
  // public lineChartLabels: Label[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  public lineChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    legend: {
      display: false
    },
    tooltips: {
      callbacks: {
        label: function(context:any) {
          let label =  '';
          if (context.value !== null) {
            label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0,
              maximumFractionDigits: 0,}).format(parseInt(context.value));
          }
          return label;
        }
      }
    },
    // legend: {
    //   display: true,
    //   position: 'bottom',
    //   labels: {
    //     usePointStyle: true,
    //     fontColor: this.ticksColor
    //   }
    // },
    scales: {
      xAxes: [{
        // type: 'linear',
        gridLines: {
          display: false
        },
        scaleLabel: {
          display: true,
          labelString: this.lineChartTypeLabel,
          fontSize: 12,
          fontStyle: "bold",
          fontFamily: '"Montserrat", sans-serif',
          fontColor: this.ticksColor
        },
        ticks: {
          fontSize: 10,
          fontFamily: '"Poppins", sans-serif',
          fontColor: this.ticksColor
        }
      }],
      yAxes: [{
        id: 'y-axis-0',
        position: 'left',
        gridLines: {
          display: true,
        },
        scaleLabel: {
          display: true,
          labelString: this.firstYLabel,
          fontSize: 12,
          fontStyle: "bold",
          fontFamily: '"Poppins", sans-serif',
          fontColor: this.ticksColor
        },
        ticks: {
          beginAtZero: false,
          maxTicksLimit: 5,
          stepSize: 10,
          suggestedMin:0,
          suggestedMax:0,
          fontSize: 10,
          fontColor: this.ticksColor,
          fontFamily: '"Poppins", sans-serif',
          callback: function(value:any) {
            let label =  '';
            if (value !== null) {
              label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0,
                maximumFractionDigits: 0,}).format(parseInt(value));
            }
            return label;
            },
        }
      },
      {
        id: 'y-axis-1',
        position: 'right',
        gridLines: {
          display: true
        },
        scaleLabel: {
          display: true,
          labelString: this.secondYLabel,
          fontSize: 10,
          fontStyle: "bold",
          fontFamily: '"Poppins", sans-serif',
          fontColor: this.ticksColor
        },
        ticks: {
          beginAtZero: false,
          maxTicksLimit: 5,
          stepSize: 10,
          suggestedMin:0,
          suggestedMax:0,
          fontSize: 10,
          fontColor: this.ticksColor,
          fontFamily: '"Poppins", sans-serif',
          // callback: function(value:any) {
          //   let label =  '';
          //   if (value !== null) {
          //     label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0,
          //       maximumFractionDigits: 0,}).format(parseInt(value));
          //   }
          //   return label;
          //   },
        }
      }
      ]
    }
  };
  userType:any;
  public lineChartColors: Color[] = [
    {
      // borderColor: ['black', "#f48120"],
      // backgroundColor: ["#f48120", 'rgba(255,0,0,0.3)'],
    },
  ];
  public lineChartLegend = true;
  public lineChartType: ChartType = 'line';
  public lineChartPlugins = [];
  
  constructor(private authService:AuthService,private titlecasePipe:TitleCasePipe) { }

  ngOnInit(): void {
    const {userType} = this.authService.getUser() as any;
    this.userType = userType;
  }

  updateEventLineData(value: any) {
    this.eventLineData[0].data = value[0]?.data;
    this.firstYLabel = value[0]?.label;
    this.lineChartTypeLabel = (value &&value[0]?.xAxisLabel)? this.titlecasePipe.transform(value[0]?.xAxisLabel):'';

    this.eventLineData[1].data = value[1]?.data;
    this.secondYLabel = value[1]?.label;
    const Ydata1 = value[0].data.map((item:any) => item.y);
    const Ydata2 = value[1].data.map((item:any) => item.y);
    let  maxDataValue1 = Math.max(...Ydata1)
    let  maxDataValue2 = Math.max(...Ydata2)
    this.maxValue= Math.max(...Ydata1,...Ydata2)
    this.minValue= Math.min(...Ydata1,...Ydata2)

    
    console.log("data",maxDataValue1,maxDataValue2,Ydata1,Ydata2,this.maxValue,this.minValue);

    this.updateLineChartOptions();
  }
  
  updateLineChartOptions() {
    this.lineChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      legend: {
        display: false
      },
      tooltips: {
        callbacks: {
          label: function(context) {
            let label = '';
            if (context.value !== null) {
              label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0,
                maximumFractionDigits: 0,}).format(parseInt(context.value));            }
            return label;
          }
        }
      },
      // legend: {
      //   display: true,
      //   position: 'bottom',
      //   labels: {
      //     usePointStyle: true,
      //     fontColor: this.ticksColor
      //   }
      // },
      scales: {
        xAxes: [{
          // type: 'linear',
          gridLines: {
            display: false
          },
          scaleLabel: {
            display: true,
            labelString: this.lineChartTypeLabel,
            fontSize: 12,
            fontStyle: "bold",
            fontFamily: '"Montserrat", sans-serif',
            fontColor: this.ticksColor
          },
          ticks: {
            fontSize: 12,
            fontFamily: '"Poppins", sans-serif',
            fontColor: this.ticksColor
          }
        }],
        yAxes: [{
          id: 'y-axis-0',
          position: 'left',
          gridLines: {
            display: true,
          },
          scaleLabel: {
            display: true,
            labelString: this.firstYLabel,
            fontSize: 12,
            fontStyle: "bold",
            fontFamily: '"Poppins", sans-serif',
            fontColor: this.ticksColor
          },
          ticks: {
            beginAtZero: false,
            maxTicksLimit: 5,
            stepSize: 10,
            suggestedMin:this.minValue,
            suggestedMax:this.maxValue,
            fontSize: 10,
            fontColor: this.ticksColor,
            fontFamily: '"Poppins", sans-serif',
            callback: function(value) {
              let label =  '';
              if (value !== null) {
                label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0,
                  maximumFractionDigits: 0,}).format(parseInt(value));
              }
              return label;
            },
          }
        },
        {
          id: 'y-axis-1',
          position: 'right',
          gridLines: {
            display: true
          },
          scaleLabel: {
            display: true,
            labelString: this.secondYLabel,
            fontSize: 10,
            fontStyle: "bold",
            fontFamily: '"Poppins", sans-serif',
            fontColor: this.ticksColor
          },
          ticks: {
            beginAtZero: false,
            maxTicksLimit: 5,
            stepSize: 10,
            suggestedMin:this.minValue,
            suggestedMax:this.maxValue,
            fontSize: 10,
            fontColor: this.ticksColor,
            fontFamily: '"Poppins", sans-serif',
            callback: function(value) {
              let label =  '';
              if (value !== null) {
                label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0,
                  maximumFractionDigits: 0,}).format(parseInt(value));
              }
              return label;
            },
          }
        }
        ]
      }
    };

    if(this.singleYAxis) {
      this.lineChartOptions.scales.yAxes.pop();
    }
  }
  fixedDecimalValue = (data:any) =>{
    if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      }else{
        return data
      }

    } else{
      return 0
    }
  }
}
