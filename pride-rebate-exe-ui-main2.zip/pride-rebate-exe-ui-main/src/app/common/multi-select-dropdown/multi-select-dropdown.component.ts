import { Component, EventEmitter, forwardRef, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { ControlContainer, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-multi-select-dropdown',
  templateUrl: './multi-select-dropdown.component.html',
  styleUrls: ['./multi-select-dropdown.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting:forwardRef(() => MultiSelectDropdownComponent),
  }],
})
export class MultiSelectDropdownComponent implements OnInit {

  @Input()
  isSingleSelection:any;
  @Input()
  labelName:any;
  @Input()
  fieldName:any;
  @Input()
  type:any;
  @Input()
  placeHolder:any;
  @Input()
  dropDownValues:any;

  @Input()
  selRebateTypes: any;

  @Input()
  isReset:boolean = false;
  @Input()
  allowSearchFilter:boolean = true

  @Output()
  selectedEachItem = new EventEmitter();

  @Output()
  selectedAllItem = new EventEmitter();

  @Output()
  deSelectItem = new EventEmitter();

  @Input()
  disable:boolean = true;

  disabled = false;
  ShowFilter = false;
  limitSelection = false;
  selectedItems: any = [];
  dropdownSettings: any = {};
  dropdownSettingsVendor: any = {};
  control:any

  constructor(public controlContainer: ControlContainer) { }

  ngOnInit(): void {
    this.dropdownSettings = {
      "singleSelection": this.isSingleSelection,
      "defaultOpen": false,
      "idField": "value",
      "textField": "displayText",
      "selectAllText": "Select All",
      "unSelectAllText": "UnSelect All",
      "enableCheckAll": true,
      "itemsShowLimit": 1,
      "allowSearchFilter": this.allowSearchFilter
  };

  this.dropdownSettingsVendor = {
    "singleSelection": this.isSingleSelection,
    "defaultOpen": false,
    "idField": "user_group_id",
    "textField": "displayText",
    "enableCheckAll": true,
    "itemsShowLimit": 1,
    "allowSearchFilter": this.allowSearchFilter
};

  if( this.controlContainer && this.fieldName){
    this.control = this.controlContainer.control?.get(this.fieldName)
    }
  }

  onItemSelect(item: any) {
    console.log(item,'onItemSelect')
    this.selectedEachItem.emit(item)
}
  onSelectAll(items: any) {
     this.selectedAllItem.emit(items)
  }
   onDeSelectAll(items: any) {
    this.selectedAllItem.emit(items)
  }

  onDeSelectItem(item: any) {
    console.log(item,'onDeSelectItem')
    this.deSelectItem.emit(item);
  }

  ngOnChanges(changes: SimpleChanges) {
    if(this.isReset){
      this.selRebateTypes =[]
    }
  }

}
