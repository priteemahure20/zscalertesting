import {Component, ElementRef, Inject, OnInit, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {MatIconRegistry} from '@angular/material/icon';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'app-reason-dialog',
  templateUrl: './reason-dialog.component.html',
  styleUrls: ['./reason-dialog.component.scss']
})
export class ReasonDialogComponent implements OnInit {
  @ViewChild('el') theDiv: ElementRef | undefined;
  isDataPresent:any='';
  isButtonDisabled:boolean = true
  header: any;
  type:any;
  constructor(
      public dialogRef: MatDialogRef<ReasonDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: { type: string, header: string },
      private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer) {
    this.matIconRegistry.addSvgIcon("close", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/close.svg"))
    this.matIconRegistry.addSvgIcon("reject-icon", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/reject-icon.svg"))
  }

  ngOnInit(): void {
    this.type = this.data.type
  }
  close(): void {
    this.dialogRef.close({type:'close',message:''});
  }
  ngDoCheck() {
    this.isDataPresent = this.theDiv?.nativeElement.innerHTML
    if(this.isDataPresent && this.isDataPresent.length>1){
      this.isButtonDisabled = false
    }else{
      this.isButtonDisabled = true
    }
  }

  sendMessage = () => {
    let txt = document.getElementById('input-content')?.innerText;
    this.isDataPresent =txt
    if(this.isDataPresent){
      this.dialogRef.close({type:'message',message:txt});
      let element = document.getElementById('input-content') as HTMLInputElement;
      element.innerHTML = '';
    }

  }

  dataChange = (data:any)=>{
    console.log('>>>',data)
  }

}
