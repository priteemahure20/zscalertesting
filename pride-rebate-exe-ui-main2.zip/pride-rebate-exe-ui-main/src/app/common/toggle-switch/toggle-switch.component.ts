import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-toggle-switch',
  templateUrl: './toggle-switch.component.html',
  styleUrls: ['./toggle-switch.component.scss']
})
export class ToggleSwitchComponent implements OnInit {

  @Input() toggleChecked: boolean = false;
  @Input() stateDisabled: boolean = false;
  @Input() element: any = null;
  @Output() toggleChange = new EventEmitter();
  
  constructor() { }

  ngOnInit(): void {
  }

  toggleStateChange = (event: any, element: any) => {
    this.toggleChange.emit({ event, element});
  }

}
