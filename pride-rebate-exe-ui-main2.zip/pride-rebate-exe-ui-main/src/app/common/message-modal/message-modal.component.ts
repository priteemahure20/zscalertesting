import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { AuthService } from 'src/app/services/auth.service';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-message-modal',
  templateUrl: './message-modal.component.html',
  styleUrls: ['./message-modal.component.scss']
})
export class MessageModalComponent implements OnInit {
  fg: any;
  type:any=''
  processOptions:any
  typeOfSelection:any=''
  receiptDate: any;
  deActivatetDate:any;
  maxReceiptDate: any;
  mode:any;
  basicInfoForm!: FormGroup;
  minEffectiveDate: any = '2022-01-01';
  userType:any;
  minDate = new Date();
  endDate:any;
  program_id:any = ""
  programName:any = "";
  activateDate: Date = new Date();
  deactiveDate : any;
  constructor(public dialogRef: MatDialogRef<MessageModalComponent>,@Inject(MAT_DIALOG_DATA) public data: {type: string,selectedRows:any,mode:any, deactiveDate: any},
  private httpService: HttpService,public activatedRoute: ActivatedRoute,public router: Router,private fb: FormBuilder,private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer,private authService:AuthService) {
    this.maxReceiptDate = new Date(3000, 12, 31);
    this.receiptDate = new FormControl("",[Validators.required]);
    this.matIconRegistry.addSvgIcon("close", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/close.svg"))

  }

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe((value: any) => {
      if (value) {
        console.log("value",value)
        this.program_id= value['program_id']
        if (this.program_id) {
          let obj = {
            program_id: parseInt(this.program_id),
          }

          this.httpService.getProgramDetailsOverview(obj).subscribe((response: any) => {
            if (response && response['data']) {
              this.programName = response['data']['programName'];
              this.endDate = new Date(response['data']['end_date']);
              console.log("response program message model", this.programName)
            }
          })
        }
      }

    })
    const {userType} = this.authService.getUser() as any;
    this.userType = userType;
    this.type= this.data['type']
    this.mode = this.data['mode']
    this.deactiveDate = this.data['deactiveDate'];
    if(this.mode=='clone'){
      this.basicInfoForm = this.fb.group({
        startDate: new FormControl('', [Validators.required]),
        endDate: new FormControl('', [Validators.required]),
      },{ validator: this.checkDates })
    }
    if(this.mode=='deActivatePDP' ||this.mode=='ActivatePDP'){
      this.basicInfoForm = this.fb.group({
        deActivatetDate: new FormControl('', [Validators.required]),
      })
    }
  }

  radioChange = (event:any)=>{
    if(event['value']==1){
      this.type = 'message2'
    } else if(event['value']==2){
      this.type = 'message3'
    }
  }

  close = () =>{
    this.dialogRef.close({event:'Cancel'});
  }

  submit = (type:any) =>{
    console.log("type", type);
    if(type=='message2' && this.mode=='associoManagement'){
      this.typeOfSelection = type
      this.type=''
    }else if(this.mode=='userManagement'){
      if(type=='message2'){
        this.dialogRef.close({type:'deactivate',value:''});
      }else{
        this.dialogRef.close({type:'delete',value:''});
      }
    }else if(type=='deleteprogramMsg'){
      this.dialogRef.close({type:'delete',value:''});
    } else {
      this.dialogRef.close({type:'delete',value:''});
    }
  }

  submitDate = () =>{
    if(this.mode=='clone'){
      if(this.basicInfoForm.valid){
        let obj={
          startDate:this.changeDateFormat(this.basicInfoForm.value['startDate']),
          endDate:this.changeDateFormat(this.basicInfoForm.value['endDate'])
        }
        this.dialogRef.close(obj);
      }
    }
    if(this.mode=='deActivatePDP' || this.mode=='ActivatePDP'){
      if(this.basicInfoForm.valid){
        let obj={
          deActivatetDate:this.changeDateFormat(this.basicInfoForm.value['deActivatetDate']),
        }
        console.log("deactivate date",this.basicInfoForm.value['deActivatetDate'])
        this.activateDate = this.basicInfoForm.value['deActivatetDate']
        console.log("deactivate date 1",this.activateDate)
        this.programName = this.programName
        this.dialogRef.close(obj);
      }
    }
    else if(this.type=='deactivatemessage'){
      this.dialogRef.close();
    }
    else if(this.type=='programmessage'){
      this.dialogRef.close();
    }
 
    if(this.receiptDate.value){
      this.dialogRef.close({type:'deactivate',value:this.changeDateFormat(this.receiptDate.value)});
    }  
    else if(this.type=='activateMessage'){
      
      this.dialogRef.close();
    }
  }

  selectDate = (event:any)=>{

  }

  getErrors(ctrl:any) {
    return Object.keys(ctrl.errors);
  }

  changeDateFormat = (value:any) =>{
    if(value){
      let dateValue =  moment(value,'YYYY-MM-DD')
      return  dateValue.toISOString(true).split("T")[0]
  }
  }

  checkDates(group: FormGroup) {
    if (group.controls.endDate.value && group.controls.startDate.value
        && new Date(group.controls.endDate.value) < new Date(group.controls.startDate.value)) {
      return { notValid: true }
    }
    return null;
  }
}
