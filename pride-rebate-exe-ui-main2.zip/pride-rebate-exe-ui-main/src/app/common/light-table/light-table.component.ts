import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-light-table',
  templateUrl: './light-table.component.html',
  styleUrls: ['./light-table.component.scss']
})
export class LightTableComponent implements OnInit {
  @Input() columnsToDisplay: any;
  @Input() dataSource: any;
  @Input() columnsProps: any;
  @Output() switchToUser = new EventEmitter();

  constructor(private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer) { 
    this.matIconRegistry.addSvgIcon("ra-edit", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/ra-edit.svg"))   
    .addSvgIcon("dashboard-view", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/dashboard-view-icon.svg"))
  }

  ngOnInit(): void {
  }

  navigate(element:any) {
    this.switchToUser.emit(element);
  }
  checkNameLength = (name: any) => {
    return name
  }

}
