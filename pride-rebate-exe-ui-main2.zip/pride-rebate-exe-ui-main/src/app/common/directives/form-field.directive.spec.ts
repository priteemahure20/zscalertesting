import { FormFieldDirective } from './form-field.directive';

describe('FormFieldDirective', () => {
  it('should create an instance', () => {
    const directive = new FormFieldDirective();
    expect(directive).toBeTruthy();
  });
});
