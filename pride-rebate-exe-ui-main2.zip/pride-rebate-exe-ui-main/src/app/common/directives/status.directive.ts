import { Directive, OnInit, Input, ElementRef, Renderer2 } from '@angular/core';

/**
 * Directive to format status.
 */
@Directive({
  selector: '[rapStatus]'
})
export class StatusDirective implements OnInit {

  /**
   * Input status / current status.
   */
  @Input() status: string = '';

  /**
   * List of success status to be displayed in green color.
   */
  @Input() success: string[] = [];

  /**
   * List of error / danger status to be displayed in red color.
   */
  @Input() danger: string[] = [];

  /**
   * Classes which will be added to html element based on status.
   */
  classList: string[] = ['text-success', 'text-danger', 'text-primary'];

  successIndex: number = 0;
  dangerIndex: number = 1;
  warningIndex: number = 2;

  /**
   * Adding required references
   * @param element Element reference.
   * @param renderer Renderer to render html content inside referenced element.
   */
  constructor(private element: ElementRef, private renderer: Renderer2) { }

  /**
   * After Initialization, add color class and status as text inside element.
   */
  ngOnInit() {
    this.renderer.addClass(this.element.nativeElement, this.getClassName());
    this.renderer.appendChild(this.element.nativeElement, this.renderer.createText(this.status))
  }

  /**
   * Decides color class based on status / active status.
   * @returns color class name.
   */
  getClassName() {
    if (this.success.includes(this.status)) {
      return this.classList[this.successIndex];
    } else if (this.danger.includes(this.status)) {
      return this.classList[this.dangerIndex];
    }
    return this.classList[this.warningIndex];
  }
}
