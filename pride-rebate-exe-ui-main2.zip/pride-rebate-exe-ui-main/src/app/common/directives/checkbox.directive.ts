import { Directive } from '@angular/core';

@Directive({
  selector: '[rapCheckbox]',
  host: {
    'class': 'rap-checkbox'
  }
})
export class CheckboxDirective { }
