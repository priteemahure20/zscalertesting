import { FormFieldAsButtonDirective } from './form-field-as-button.directive';

describe('FormFieldAsButtonDirective', () => {
  it('should create an instance', () => {
    const directive = new FormFieldAsButtonDirective();
    expect(directive).toBeTruthy();
  });
});
