import { CheckboxDirective } from './checkbox.directive';

describe('CheckboxDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckboxDirective();
    expect(directive).toBeTruthy();
  });
});
