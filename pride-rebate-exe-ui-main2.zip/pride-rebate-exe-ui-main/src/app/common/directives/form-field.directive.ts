import { Directive } from '@angular/core';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';

@Directive({
  selector: '[rapFormField]',
  host: { 'class': 'rap-form-field' },
  providers: [
    { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: { appearance: 'outline', floatLabel: 'never' } }
  ]
})
export class FormFieldDirective { }
