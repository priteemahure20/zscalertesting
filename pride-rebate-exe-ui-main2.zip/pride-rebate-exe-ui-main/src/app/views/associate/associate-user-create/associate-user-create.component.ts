import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import { AuthService } from 'src/app/services/auth.service';
import { DataService } from 'src/app/services/data.service';
import { HttpService } from 'src/app/services/http.service';
import {UserType} from '../../../helpers/constants';

@Component({
  selector: 'app-associate-user-create',
  templateUrl: './associate-user-create.component.html',
  styleUrls: ['./associate-user-create.component.scss']
})
export class AssociateUserCreateComponent implements OnInit {
  typeOfAssociate:any=''
  associateUserCreate!:FormGroup;
  permissionOptions:any = []
  associateOptions:any=[]
  tenantType:any;
  mode:any;
  selectedUserId:any;
  buttonName:any;
  constructor(public router: Router, public activatedRoute: ActivatedRoute,private fb:FormBuilder,private httpService: HttpService,public dialog: MatDialog,
    private dataService: DataService,private authService:AuthService) { }
  isButtonDisabled:boolean = false;
  resetFile:boolean = false;
  public formData = new FormData();
  rbacBgUserLogged: boolean = false;
  loggedInUserName:any;
  loggedInUserId:any;
  userType:any;
  header :string = "Associate User Create";
  ngOnInit(): void {
   
    this.activatedRoute.paramMap.subscribe((params:any) => {
      // this.userType = localStorage.getItem('userType') as UserType;
      this.userType = this.authService.getUser()?.userType;
      this.applyRBAC();
      if(params && params['params'] && params['params']['associateType']){
        this.mode = params['params']['mode']
        this.typeOfAssociate = params['params']['associateType']
        this.httpService.userPermissionPrerequisite(this.typeOfAssociate).subscribe((response:any)=>{
          if(response && response['data']){
            this.permissionOptions = response['data']['permissions'];
            this.associateOptions = response['data']['associates'];

          }
        })
        if(this.mode == 'edit'){
          this.selectedUserId= params['params']['userId']
          this.buttonName = 'UPDATE USER'
          this.header = "Associate User Edit";
          if(this.selectedUserId){
            this.httpService.getManagementUserDetails(parseInt(this.selectedUserId)).subscribe((response)=>{
              if(response && response['data']){
                this.populateEditObject(response['data'])
              }
            })
          }
        }else{
          this.buttonName = 'ADD USER';
          this.header = "Associate User Create";
        }
      }
    });

    this.tenantType = localStorage.getItem('tenant')
    this.associateUserCreate = this.fb.group({
      permission: new FormControl(null, [Validators.required]),
      associateName: new FormControl(null, [Validators.required]),
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required, Validators.pattern('^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$')]),
      title: new FormControl('')
    })
    if(!this.rbacBgUserLogged){
      this.loggedInUserName = localStorage.getItem('username');
      this.loggedInUserId = localStorage.getItem('userGroupId');
      this.associateUserCreate.controls['associateName'].setValue(parseInt(this.loggedInUserId))
      this.associateUserCreate.controls['associateName'].disable();
    }


  }
  applyRBAC() {
    this.rbacBgUserLogged = this.userType === UserType.Corporate;
  }
  saveAssociateUser = ()=>{
    if(this.associateUserCreate.valid){
      let requestObj:any = this.prepareSaveObject(this.associateUserCreate.getRawValue())
    
      if(this.mode !='edit'){
      
        this.httpService.createManagementUser(requestObj).subscribe((response:any)=>{
          if(response && response['data']){
            if(response['data']['message']=='success'){
              this.associateUserCreate.reset();
              this.showSuccessOrError("User added successful")
              setTimeout(()=>{
                this.dialog.closeAll();
                this.router.navigate([`/${this.tenantType}/associate-users`,{associateType:this.typeOfAssociate}])
              },5000)
            }else if(response['data']['message']=='Email id already exists'){
              this.showSuccessOrError("Email id already exists")
              setTimeout(()=>{
                this.dialog.closeAll();
                
              },5000)
            }
          }
        },error=>{
          this.showSuccessOrError("Error occured while adding the user")
          setTimeout(()=>{
            this.dialog.closeAll();
          },2000)
        })
      }else{
        this.associateUserCreate.reset();
        requestObj['user_id']=[parseInt(this.selectedUserId)]
        this.httpService.saveEditUserManagementDetails(requestObj).subscribe((response:any)=>{
          if(response && response['data']){
            if(response['data']['code']==1){  
              this.showSuccessOrError("Updated user successful")
              setTimeout(()=>{
                this.dialog.closeAll();
                this.router.navigate([`/${this.tenantType}/associate-users`,{associateType:this.typeOfAssociate}])
              },5000)
            }
          }
        },error=>{
          this.showSuccessOrError("Error occured while adding the user")
          setTimeout(()=>{
            this.dialog.closeAll();
          },2000)
        })
      }
     
    }else{
      this.associateUserCreate.markAllAsTouched();
    }
   
  }

  prepareSaveObject = (value:any)=>{
    console.log('>>>>',value)
    return  {
     'roleId':value['permission'],
      'userGroupId':value['associateName'],
     'userType':this.typeOfAssociate,
     'groupName':this.rbacBgUserLogged?this.getNameBYId(value['associateName']):this.loggedInUserName,
     'firstName':value['firstName'],
     'lastName':value['lastName'],
     'email':value['email'],
     'title':value['title']
    }
    
    
  }

  getNameBYId = (id:number)=>{
    let name = this.associateOptions.find((data:any) => {
      if(data['value']==id){
        return data['name']
      }
    })
    return name['name']
  }

  showSuccessOrError = (message:any) =>{
    if(message){
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: {"type":message},
        disableClose: true,
      });
      dialogRef.afterClosed().subscribe(result => {
        if(message!='Email id already exits'){
          this.router.navigate([`/${this.tenantType}/associate-users`,{associateType:this.typeOfAssociate}])
        }
      })
    }
   
  }

  populateEditObject = (data:any)=>{
    this.associateUserCreate.patchValue({
      permission: data['roleId'] ||data['roleId'] ==0 ?data['roleId']:'',
      associateName: data['userGroupId']?data['userGroupId']:'',
      firstName: data['firstName']?data['firstName']:'',
      lastName: data['lastName']?data['lastName']:'',
      email: data['email']?data['email']:'',
      title: data['title']?data['title']:''
    })
    this.associateUserCreate.controls['email'].disable();
  }

  downloadSample() {
    // console.log('typeOfAssociate: ', this.typeOfAssociate);
    // supplier, distributor, bgAdmin
    let type;
    switch (this.typeOfAssociate) {
      case 'supplier':
        type = "associate_user_supplier";
        break;
      case 'distributor':
        type = "associate_user_distributor";
        break;
      case 'bgAdmin':
        type = "associate_user_bguser";
        break;
      default:
        break;
    }
    this.dataService.download(type, `${type + '.csv'}`);
  }
  uploadedFile = (file:any) =>{
    if(file){
      this.formData.append("file",file)
     }
  }

  isDisabled = (event:any)=>{
    this.isButtonDisabled = event
  }

  uploadFile = () =>{
    this.resetFile = true;
    if(this.formData.has('file')){
      if(this.typeOfAssociate == 'corporate' || this.typeOfAssociate == 'bgAdmin'){
        this.typeOfAssociate = "bguser"
      }
      this.httpService.uploadUserManagementFile(this.formData,this.typeOfAssociate).subscribe((response)=>{
        if(response && response['message']){
          if(response['message']=='Success'){
            this.showSuccessOrError("File Upload Successful")
          }
        }
      },error=>{
        this.showSuccessOrError("Error occured while uploading file")
      })
    }
  }
  navigateToAssociateModule = () =>{
    if(this.associateUserCreate.dirty){
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '382px',
        height: '180',
        data: {"type":"Are you sure discard your changes ?"},
        disableClose: true,
      });
      dialogRef.afterClosed().subscribe(result => {
        if(result !='cancel'){
          this.router.navigate([`/${this.tenantType}/associate-users`])
        }
      })
    }else{
      this.router.navigate([`/${this.tenantType}/associate-users`])
    }
    
  }

  navigateToAssociateHome = () =>{
    if(this.associateUserCreate.dirty){
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '382px',
        height: '180',
        data: {"type":"Are you sure discard your changes ?"},
        disableClose: true,
      });
      dialogRef.afterClosed().subscribe(result => {
        if(result !='cancel'){
          this.router.navigate([`/${this.tenantType}/home`])
        }
      })
    }else{
      this.router.navigate([`/${this.tenantType}/home`])
    }

  }

}
