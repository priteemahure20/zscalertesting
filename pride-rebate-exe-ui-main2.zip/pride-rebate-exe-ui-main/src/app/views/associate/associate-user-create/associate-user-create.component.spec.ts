import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociateUserCreateComponent } from './associate-user-create.component';

describe('AssociateUserCreateComponent', () => {
  let component: AssociateUserCreateComponent;
  let fixture: ComponentFixture<AssociateUserCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssociateUserCreateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociateUserCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
