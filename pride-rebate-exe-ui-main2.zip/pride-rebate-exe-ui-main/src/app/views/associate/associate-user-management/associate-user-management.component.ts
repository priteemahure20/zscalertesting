import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { MessageModalComponent } from 'src/app/common/message-modal/message-modal.component';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import { AuthService } from 'src/app/services/auth.service';
import { HttpService } from 'src/app/services/http.service';
import {UserType} from '../../../helpers/constants';
import {TitleCasePipe} from '@angular/common';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-associate-user-management',
  templateUrl: './associate-user-management.component.html',
  styleUrls: ['./associate-user-management.component.scss']
})
export class AssociateUserManagementComponent implements OnInit {

  searchName:any=''
  columnsToDisplay :any= [];
  columnsProps:any;
  columnsToDisplayForBG :any= [];
  columnsPropsForBG:any;
  dataSource: any;
  tenantType:any;
  pagination={
    limit:10,
    pageNo:1,
  }
  userType:any;
  associateUserObj:any={};
  isRowsSelected:boolean = false
  selectedTab:any;
  permissionOption:any=[]
  totalCount:any;
  tabIndex=0;
  selectedRowsData:any;
  rbacBgUserLogged: boolean = false;
  userGroupId:any;
  userGroupName:string;
  sort:any;
  constructor(private domSanitizer: DomSanitizer,private matIconRegistry: MatIconRegistry,public dialog: MatDialog,
    public router: Router, public activatedRoute: ActivatedRoute,private httpService: HttpService,private snackBar: MatSnackBar,private authService:AuthService,private titlecasePipe:TitleCasePipe, private dataService:DataService) {
      this.matIconRegistry.addSvgIcon("ra-add", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/ra-add.svg"))
    .addSvgIcon("ra-delete", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/delete.svg"))
    const currentState = this.router.getCurrentNavigation()?.extras.state;
    this.userGroupName=currentState ? currentState['associateName'] : undefined;
    this.dataService.wndowSrollYEmitter.emit(100);
    }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe((params:any) => {
      this.tenantType = localStorage.getItem('tenant');
      // this.userType = localStorage.getItem('userType') as UserType;
      this.userType = this.authService.getUser()?.userType;
      this.applyRBAC();
      if(!this.rbacBgUserLogged){
        this.userGroupId = localStorage.getItem('userGroupId')
        if(this.userGroupId){
          this.associateUserObj['userGroupId'] = parseInt(this.userGroupId);
        }
      }
      if(this.userGroupName){
        this.associateUserObj={...this.associateUserObj,userGroupName:this.userGroupName}
      }
      if(params && params['params'] && params['params']['associateType']){
        this.associateUserObj['limit']=this.pagination['limit'];
        this.associateUserObj['pageNo']=this.pagination['pageNo'];
        
        if(params['params']['associateType']=='dealer'){
          this.onTabChanged({index:0})
          this.tabIndex =0;
        }else{
          this.onTabChanged({index:1})
          this.tabIndex =1;
        }
        // this.populateAssociateUserData(this.tableContent)
        this.tenantType = localStorage.getItem('tenant')
      }else{
        this.associateUserObj['limit']=this.pagination['limit'];
        this.associateUserObj['pageNo']=this.pagination['pageNo'];
        this.tabIndex =0
        this.onTabChanged({index:0})


      }
    });
    
  }

  applyRBAC() {
    this.rbacBgUserLogged = this.userType === UserType.Corporate;
  }
  populateAssociateUserData = (content:any) =>{
    console.log('content',content)
    const tableData:any = [];
    for(let i=0;i<content.length;i++){
      console.log('content[i]',content[i])
      let obj:any={}
      obj['firstName']=content && content[i]['first_name']?this.titlecasePipe.transform(content[i]['first_name']):'NA'
      obj['lastName']=content && content[i]['last_name']?this.titlecasePipe.transform(content[i]['last_name']):'NA'
      obj['status']=content && content[i]['active_flag']?content[i]['active_flag']:'NA'
      obj['associate']=content && content[i]['user_group_name']?content[i]['user_group_name']:'NA'
      obj['pivot_id']=content && content[i]['group_id']?content[i]['group_id']:'NA'
      obj['gp_id']=content && content[i]['gp_id']?content[i]['gp_id']:'NA'
      obj['email']=content && content[i]['email']?content[i]['email']:'NA'
      tableData.push(obj)
    }
    this.dataSource = new MatTableDataSource(tableData);
  }

  onTabChanged = (event:any)=>{
    if(event && event.hasOwnProperty('tab')){
      this.associateUserObj = {}
      this.associateUserObj['limit']=this.pagination['limit'];
      this.associateUserObj['pageNo']=this.pagination['pageNo'];
      this.isRowsSelected = false;
    }
    this.searchName ='';
   
      if(event && event['index']==0){
        this.selectedTab =  'dealer'
      }else{
        this.selectedTab =  'corporate'
      }
      this.associateUserObj['type'] = this.selectedTab
      this.getPrerequesties(this.selectedTab);
      this.getUserManagementData();
      //this.getAllFilterData()
  }

  openUserCreation = (type:string)=>{
    this.router.navigate([`/${this.tenantType}/associate-createUser`,{associateType:type,mode:'create'}])
  } 

  getPrerequesties = (type:any) =>{
    this.httpService.userPermissionPrerequisite(type).subscribe((response:any)=>{
      if(response && response['data']){
        this.permissionOption = response['data']['permissions']
      }
    })
  }

  getUserManagementData = () =>{
    console.log('test1')
    // if(this.dataSource && this.dataSource['data'].length>0 && this.pagination['pageNo']==1){
      console.log('test2')
      this.dataSource = new MatTableDataSource([])
    //}
    this.populateHeaders();
    this.populateHeadersForBG();
    console.log('test3')

    this.httpService.getUserManagementData(this.associateUserObj).subscribe((response:any)=>{
      if(response && response['data']['usersCount']>0){
        this.totalCount = response['data']['usersCount']
        if(response['data']['users']){
          console.log(response['data']['users'],'users')
          this.populateAssociateUserData(response['data']['users'])
          // this.populateAssociateUserData([])
        } else{
          // this.snackBar.open('Please enter valid page number', 'Ok', {
          //   duration: 2000,
          // });
        }
      }else{
        this.populateAssociateUserData([])
      }
    })
  }

  populateHeaders = () =>{
    this.columnsToDisplay=[
    {header: 'First Name', field: 'firstName',displayFilter: false,cell: (element: any) => `${element.name}`,ellipseLength:15}, 
    {header: 'Last Name', field: 'lastName',displayFilter: false,cell: (element: any) => `${element.name}`,ellipseLength:15}, 
    // {header: 'Active/Inactive', field: 'status', width:'140px', displayFilter: false,cell: (element: any) => `${element.name}` ,placeHolder:'Active'}, 
    {header: 'Associate Name', field: 'associate',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Pivot Id', field: 'pivot_id',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Gp Id', field: 'gp_id',displayFilter: false,cell: (element: any) => `${element.name}`},
    {header: 'Email', field: 'email'}];
      this.columnsProps= this.columnsToDisplay.map((column:any) => {return column.field});
  }

  populateHeadersForBG = () =>{
    this.columnsToDisplayForBG=[
    {header: 'First Name', field: 'firstName',displayFilter: false,cell: (element: any) => `${element.name}`,ellipseLength:15}, 
    {header: 'Last Name', field: 'lastName', displayFilter: false,cell: (element: any) => `${element.name}`,ellipseLength:15}, 
    // {header: 'Active/Inactive', field: 'status', width:'140px', displayFilter: false,cell: (element: any) => `${element.name}` ,placeHolder:'Active'}, 
    {header: 'Associate Name', field: 'associate', displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Email', field: 'email'}];
      this.columnsPropsForBG= this.columnsToDisplayForBG.map((column:any) => {return column.field});
  }

  public getDate = (date:any) =>{
    if(date){
      let modifedDate = moment(date,"YYYYMMDD")
      return modifedDate.format('MM/DD/YYYY')
    }else{
      return 'NA'
    }
  }

  getNextPage = (event:any) =>{
    console.log(event,'event');
    this.pagination['pageNo']=parseInt(event['pageIndex'])+1
    console.log(this.pagination['pageNo'],'this.pagination');
    this.associateUserObj['limit']=this.pagination['limit']
    this.associateUserObj['pageNo']=this.pagination['pageNo']
    this.getUserManagementData();
  }

  selectedPageLimit = (limitValue:any) => {    
    this.pagination['limit']=parseInt(limitValue)
    this.pagination['pageNo']=1;
    this.associateUserObj['limit']=this.pagination['limit']
    this.associateUserObj['pageNo']=this.pagination['pageNo']
    this.getUserManagementData();
  }

  goToPageNumber = (event:any) =>{
    let value = Math.ceil(this.totalCount/this.pagination['limit'])
    if(event <=value){
      this.pagination['pageNo']=parseInt(event);
      this.associateUserObj['limit']=this.pagination['limit']
      this.associateUserObj['pageNo']=this.pagination['pageNo']
      this.getUserManagementData();
    }else{
        const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
          width: '370px',
          height: '180',
          data: {"type":"PageNo entered out of range."},
          disableClose: true,
        });
        setTimeout(()=>{
          dialogRef.close()
        },2000)
  
        dialogRef.afterClosed().subscribe((result:any) => {
          if(this.dataSource && this.dataSource['data'] && this.dataSource['data'].length>0){
            this.dataSource['data'] = []
          }
          this.pagination['pageNo']=1;
          this.associateUserObj['limit']=this.pagination['limit']
          this.associateUserObj['pageNo']=this.pagination['pageNo']
          // this.getUserManagementData();
          this.selectedPageLimit(this.pagination.limit);
        })
    }
    
  }

  sortByColumnName = (data:any) =>{
    console.log("DataSource",this.dataSource);
    this.sort = this.dataSource.sort;
    // this.dataSource = new MatTableDataSource([])
    if(data['direction']){
      if(this.associateUserObj['sorting'] && this.associateUserObj['sorting'].length > 0){
        const isFound = this.associateUserObj['sorting'].find((row:any) => row['orderBy'] === data['active']);
        if(isFound){
          this.associateUserObj['sorting'] = this.associateUserObj['sorting'].map((row:any)=>{
            if(row['orderBy'] === data['active']){
              row['orderType'] = data['direction']
            }
            return row;
          })
        }
        else{
          this.associateUserObj['sorting'] = [{orderBy:data['active'],orderType:data['direction']}]
        } 
      }else{
        this.associateUserObj['sorting'] = [{orderBy:data['active'],orderType:data['direction']}]
        
      }
    }else{
      if(this.associateUserObj.hasOwnProperty('sorting')){
        delete this.associateUserObj['sorting']
      }
    }
    this.getUserManagementData();
  }

  filterColumnwiseData = (values:any)=>{
    let isValueExists=0
    if(values && values['firstName']){
      this.associateUserObj['firstName']= values['firstName']
      isValueExists=1
    } else if((values['firstName']=='' || values['firstName']=="" || values['firstName']==null)  && this.associateUserObj.hasOwnProperty('firstName')){
      delete this.associateUserObj.firstName
      isValueExists=1
    }

    if(values && values['lastName']){
      this.associateUserObj['lastName']= values['lastName']
      isValueExists=1
    } else if((values['lastName']=='' || values['lastName']=="" || values['lastName']==null)  && this.associateUserObj.hasOwnProperty('lastName')){
      delete this.associateUserObj.lastName
      isValueExists=1
    }

    if(values && values['pivot_id']){
      this.associateUserObj['pivot_id']= values['pivot_id']
      isValueExists=1
    } else if((values['pivot_id']=='' || values['pivot_id']=="" || values['pivot_id']==null)  && this.associateUserObj.hasOwnProperty('pivot_id')){
      delete this.associateUserObj.pivot_id
      isValueExists=1
    }

    if(values && values['gp_id']){
      this.associateUserObj['gp_id']= values['gp_id']
      isValueExists=1
    } else if((values['gp_id']=='' || values['gp_id']=="" || values['gp_id']==null)  && this.associateUserObj.hasOwnProperty('gp_id')){
      delete this.associateUserObj.gp_id
      isValueExists=1
    }

    if(values && values['associate']){
      this.associateUserObj['userGroupName']= values['associate']
      isValueExists=1
    } else if((values['associate']=='' || values['associate']=="" || values['associate']==null)  && this.associateUserObj.hasOwnProperty('userGroupName')){
      delete this.associateUserObj.userGroupName
      isValueExists=1
    }
    
    // if(values && (values['permission']|| values['permission']===0)){
    //   this.associateUserObj['roleId']= values['permission']
    //   isValueExists=1
    // } else if((values['permission']=='' || values['permission']=="" || values['permission']==null)  && this.associateUserObj.hasOwnProperty('roleId')){
    //   delete this.associateUserObj.roleId
    //   isValueExists=1
    // }
    // if(values && values['editedBy']){
    //   this.associateUserObj['updated_by']= values['editedBy']
    //   isValueExists=1
    // } else if((values['editedBy']=='' || values['editedBy']=="" || values['editedBy']==null) && this.associateUserObj.hasOwnProperty('updated_by')){
    //   delete this.associateUserObj.updated_by
    //   isValueExists=1
    // }

    // if(values.hasOwnProperty('updated_date_from')){
    //   this.associateUserObj['updated_date_from'] = values['updated_date_from']
    //   isValueExists=1
    // }else if(!values.hasOwnProperty('updated_date_from')){
    //   if(this.associateUserObj.hasOwnProperty('updated_date_from')){
    //     delete this.associateUserObj.updated_date_from
    //     isValueExists=1
    //   }
    // }
    // if(values.hasOwnProperty('updated_date_to')){
    //   this.associateUserObj['updated_date_to'] = values['updated_date_to']
    //   isValueExists=1
    // }else if(!values.hasOwnProperty('updated_date_to')){
    //   if(this.associateUserObj.hasOwnProperty('updated_date_to')){
    //     delete this.associateUserObj.updated_date_to
    //     isValueExists=1
    //   }
    // }
    if(isValueExists==1){
      this.selectedPageLimit(this.pagination.limit)

    }
  }

  searchByEmail = (value:any)=>{
    if(value){
      this.associateUserObj['email'] = value
    }else{
      if(this.associateUserObj.hasOwnProperty('email'))
      delete this.associateUserObj.email
    }
    this.selectedPageLimit("15")
  }

  applyFilter = (values:any) => {

    let isValueExists=0
    if(values['status']!=null){
      this.associateUserObj['activeFlag']=values['status']=="Active"?1:0
      isValueExists=1
    }else if(values['status']==null){
      if(values['status']==null && this.associateUserObj.hasOwnProperty('activeFlag')){
        delete this.associateUserObj.activeFlag
        isValueExists=1
      }
    }
    // if(values.hasOwnProperty('updated_date_from')){
    //   this.associateUserObj['updated_date_from'] = values['updated_date_from']+this.appendTimeStamp()
    //   isValueExists=1
    // }else if(!values.hasOwnProperty('updated_date_from')){
    //   if(this.associateUserObj.hasOwnProperty('updated_date_from')){
    //     delete this.associateUserObj.updated_date_from
    //     isValueExists=1
    //   }
    // }
    // if(values.hasOwnProperty('updated_date_to')){
    //   this.associateUserObj['updated_date_to'] = values['updated_date_to']+this.appendEndTimeStamp()
    //   isValueExists=1
    // }else if(!values.hasOwnProperty('updated_date_to')){
    //   if(this.associateUserObj.hasOwnProperty('updated_date_to')){
    //     delete this.associateUserObj.updated_date_to
    //     isValueExists=1
    //   }
    // }
    if(isValueExists==1){
      this.selectedPageLimit(this.pagination.limit)
    }
    
  }
  editRow = (editRow:any)=>{
    if(editRow && (editRow['userId'] ||editRow['userId'] === 0)){
      this.router.navigate([`/${this.tenantType}/associate-createUser`,{associateType:this.selectedTab,mode:'edit',userId:editRow['userId']}])
    }
  }

  prepareDeletionData = (event:any)=>{
    if(event && event.length>0){
      this.isRowsSelected = true
      this.selectedRowsData = event
    }else{
      this.isRowsSelected = false
      this.selectedRowsData = []
    }
  }

  deleteAssociates = () => {
    const dialogRef2 = this.dialog.open(MessageModalComponent, {
      width: '500px',
      height: '249px',
      data: {"type":"message1","selectedRows":this.selectedRowsData,"mode":'userManagement'},
      disableClose: false,
    });
    dialogRef2.afterClosed().subscribe(result => {
      if(result){
        let list = this.selectedRowsData.map((a:any) => {return parseInt(a.userId)});
        let message="";
        if(list.length>0){
          let deleteOrDeactivateObj:any ={}
          if(result && result['type']=='deactivate'){
            deleteOrDeactivateObj['activeFlag']=0;
            deleteOrDeactivateObj['user_id']=list
            message = "Successfully Deactivated"
          }else{
            deleteOrDeactivateObj['delete']=1;
            deleteOrDeactivateObj['user_id']=list
            message = "Successfully Deleted"
          }
          this.httpService.deleteActivateUserManagement(deleteOrDeactivateObj).subscribe((response:any)=>{
            if(response && response['data']){
              if(response['data']['code']==1){
                this.selectedPageLimit(this.pagination.limit);
                this.showSuccessOrError(message)
              }
            }
          },error=>{
            if(error && error['error']['message']){
              let message = error['error']['message']
              this.showSuccessOrError(message)
            }
            this.selectedPageLimit(this.pagination.limit)
          })
        }
      }
     
  
    })
  }

  showSuccessOrError = (message:any) =>{
    if(message){
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: {"type":message},
        disableClose: true,
      });
    }
   
  }

  toggleActivate = (value:any)=>{
    let deleteOrDeactivateObj:any ={}
    if(value){
      deleteOrDeactivateObj['activeFlag']=value['status']==true?1:0;
      deleteOrDeactivateObj['user_id']=[value['userId']]
      this.httpService.deleteActivateUserManagement(deleteOrDeactivateObj).subscribe((response:any)=>{
      },error=>{
        this.showSuccessOrError("Error occured while changing activating/deactivating")
      })
    }
 
  }

  navigateToAssociateModule = () =>{
    this.router.navigate([`/${this.tenantType}/home`])
  }

  updatePermission = (value:any) =>{
    if(value && value['value']){
      let permissionObject:any = {}
      permissionObject['roleId']=value['value']['value'];
      permissionObject['user_id']=[value['selectedRow']['userId']]
      this.httpService.deleteActivateUserManagement(permissionObject).subscribe((response:any)=>{
      },error=>{
        this.showSuccessOrError("Error occured while updating the permission")
      })
    }
  }

  appendTimeStamp =()=>{
    return 'T00:00:00.000Z'
  }

  appendEndTimeStamp = () =>{
    return 'T23:59:59.999Z'
  }


}
