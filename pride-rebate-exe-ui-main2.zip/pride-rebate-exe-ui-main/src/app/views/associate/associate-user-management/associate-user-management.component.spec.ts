import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociateUserManagementComponent } from './associate-user-management.component';

describe('AssociateUserManagementComponent', () => {
  let component: AssociateUserManagementComponent;
  let fixture: ComponentFixture<AssociateUserManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssociateUserManagementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociateUserManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
