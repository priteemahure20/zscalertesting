import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpService } from 'src/app/services/http.service';
import { get as _get, map as _map } from 'lodash';
import { mapAssociateCreateData, mapDistributorAssociateCreateData } from '../../../mapper/outbound/associate';
import { ThisReceiver } from '@angular/compiler';
import { DataService } from 'src/app/services/data.service';
import { MatDialog } from '@angular/material/dialog';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import { DynamicFormFieldModel } from '../../../models/dynamic-form-field.model';
import { Subject } from 'rxjs';
import {cleanEntityData, titlecase} from "../../../helpers/commonUtils";
import readXlsxFile from 'read-excel-file'
import * as XLSX from 'xlsx';
import { settings } from 'cluster';

@Component({
  selector: 'app-associate-create',
  templateUrl: './associate-create.component.html',
  styleUrls: ['./associate-create.component.scss']
})
export class AssociateCreateComponent implements OnInit {
  @Input() associateId:any;
  dynamicForm!: FormGroup;
  dynamicFormFields!: any[];

  associateCreateGroup!: FormGroup;
  sementGroup!:FormGroup;
  isDisplaySegment:boolean = false;
  // isDisplaySegmentAsync$ = new Subject<boolean>();
  parentOptions= [{displayText:"TRUE",value:1},{displayText:"FALSE",value:0}]
  associateParent: any = [];
  hierarchyOptions: any = [];
  selectedHierarchy: any = null;
  selectedParent: any = null;
  is_hq: boolean = false;
  parentLinkRequired: boolean = true;
  tenantType: any;
  userEmail:any;
  associateDetail: any;
  selectRebateTypes: any;
  // parentOptons: any = [];
  rebateTypeOptions: any = [];
  selectedParentLinkList:any=[];
  selectedRebateTypes:any=[];
  configureRebate: number = 0;
  configurePayment: number = 0;
  isButtonDisabled:boolean = false;
  resetFile:boolean = false;
  isSupplierDisable:boolean = false;
  isDistributorDisable:boolean = false;
  public formData = new FormData();
  editedUserId:any;
  isItemsReset:boolean = false;
  header="Create Associate";
  pivotId:any;
  constructor(private fb:FormBuilder, private domSanitizer: DomSanitizer, private matIconRegistry: MatIconRegistry, private httpService: HttpService, public router: Router, private activatedRoute: ActivatedRoute,
    public dialog: MatDialog, private dataService: DataService) {
    this.matIconRegistry.addSvgIcon("add-segment", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/add-icon.svg"))
    if(window.innerHeight == 923){
      this.dataService.wndowSrollYEmitter.emit(60);
    }else {
      this.dataService.wndowSrollYEmitter.emit(0);
    }
    
    // this.associateCreateGroup = this.fb.group({

    //   associateName: new FormControl('', [Validators.required]),
    //   associateId: new FormControl('', [Validators.required]),
    //   hierarchyLevel: new FormControl('', [Validators.required]),
    //   parentLink: new FormControl('', [Validators.required]),
    //   emailId: new FormControl('', [Validators.required, Validators.pattern('^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$')]),
    //   title: new FormControl('' ),
    //   firstName: new FormControl('', [Validators.required]),
    //   lastName: new FormControl('', [Validators.required]),
    //   address: new FormControl('', [Validators.required]),
    //   state: new FormControl('', [Validators.required]),
    //   city: new FormControl('', [Validators.required]),
    //   zip: new FormControl('', [Validators.required]),
    //   rebateType: new FormControl(''),

    // });
    // this.sementGroup = this.fb.group({
    //   industry: new FormControl(''),
    //   annualRevenue: new FormControl(''),
    //   location: new FormControl(''),
    //   tier: new FormControl(''),
    // })
   }
  public canConfigureRebateAttr: boolean = false;
  public canConfigureRebateAttrYes: boolean = false;
  public canConfigureRebateAttrNo: boolean = false;
  public canConfigurePaymentAttrYes: boolean = false;
  public canConfigurePaymentAttrNo: boolean = false;
  public selectedTab: string = 'vendor';
  public editSupplier: boolean = false;
  public editBody: any = {};
  public editForm: boolean = false;
  public typeTabIndex: number = 0;
  public isEditMode:boolean = false
  public editUserGroupId:any;
  public associateTypeValue:any;
  // buildEditForm(){
  //   this.associateCreateGroup = this.fb.group({

  //     associateName: new FormControl('', [Validators.required]),
  //     associateId: new FormControl('', [Validators.required]),
  //     hierarchyLevel: new FormControl('', [Validators.required]),
  //     parentLink: new FormControl(''),
  //     emailId: new FormControl('', [Validators.required, Validators.pattern('^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$')]),
  //     title: new FormControl('' ),
  //     firstName: new FormControl('', [Validators.required]),
  //     lastName: new FormControl('', [Validators.required]),
  //     address: new FormControl('', [Validators.required]),
  //     state: new FormControl('', [Validators.required]),
  //     city: new FormControl('', [Validators.required]),
  //     zip: new FormControl('', [Validators.required]),
  //     rebateType: new FormControl(''),

  //   });
  //   this.sementGroup = this.fb.group({
  //     industry: new FormControl(''),
  //     annualRevenue: new FormControl(''),
  //     location: new FormControl(''),
  //     tier: new FormControl(''),
  //   })
  // }

  buildCreateForm () {
    this.associateCreateGroup = this.fb.group({

      associateName: new FormControl('', Validators.required),
      associateId: new FormControl('', [Validators.required]),
      associatePId: new FormControl('', [Validators.required]),
      hierarchyLevel: new FormControl('', [Validators.required]),
      parentLink: new FormControl('', [Validators.required]),
      // emailId: new FormControl('', [Validators.required, Validators.pattern('^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$')]),
      //title: new FormControl(''),
      //firstName: new FormControl(''),
      //lastName: new FormControl(''),
      address: new FormControl(''),
      state: new FormControl(''),
      city: new FormControl(''),
      zip: new FormControl(''),
      rebateType: new FormControl([]),
      // editUserGroupId: new FormControl(''),

    });
    this.sementGroup = this.fb.group({
      industry: new FormControl(''),
      annualRevenue: new FormControl(''),
      location: new FormControl(''),
      tier: new FormControl(''),
    })
  };

  // buildCreateFormDistributor = () => {
  //   this.associateCreateGroup = this.fb.group({

  //     associateName: new FormControl('', [Validators.required]),
  //     associateId: new FormControl('', [Validators.required]),
  //     hierarchyLevel: new FormControl('', [Validators.required]),

  //     emailId: new FormControl('', [Validators.required, Validators.pattern('^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$')]),
  //     title: new FormControl('' ),
  //     firstName: new FormControl('', [Validators.required]),
  //     lastName: new FormControl('', [Validators.required]),
  //     address: new FormControl('', [Validators.required]),
  //     state: new FormControl('', [Validators.required]),
  //     city: new FormControl('', [Validators.required]),
  //     zip: new FormControl('', [Validators.required]),
  //     rebateType: new FormControl(''),

  //   });
  //   this.sementGroup = this.fb.group({
  //     industry: new FormControl(''),
  //     annualRevenue: new FormControl(''),
  //     location: new FormControl(''),
  //     tier: new FormControl(''),
  //   })
  // }

  ngOnInit(): void {
    this.tenantType = localStorage.getItem('tenant');
    this.userEmail = localStorage.getItem('userId');
    console.log("payload username",this.tenantType)
    console.log("payload email",this.userEmail)
    const editId = this.activatedRoute.snapshot.paramMap.get('associateId');
    const associateType = this.activatedRoute.snapshot.queryParamMap.get('type');
    this.associateTypeValue = associateType
    this.dynamicForm = this.fb.group({});
    //this.getSegmentData();
    this.dynamicFormFields = [];
    // console.log('associate type', associateType);
    if(associateType == 'dealer'){

      this.typeTabIndex = 2;
      this.selectedTab = 'dealer';
    }

    if ( editId ) {
      this.header="Edit Associate";
      this.editUserGroupId = editId
      if(associateType == 'dealer'){
        this.isSupplierDisable = true;
        this.isDistributorDisable = false;
      }else{
        this.isSupplierDisable = false;
        this.isDistributorDisable = true;
      }
      this.isEditMode = true
      this.buildCreateForm();
      this.getAssociateDetail(editId);


    } else {
      this.header="Create Associate";
      // if(associateType == 'distributor'){
      //   this.buildCreateFormDistributor();
      // } else {
      //   this.buildCreateForm();
      // }
      this.isEditMode = false
      this.buildCreateForm();

    }

    this.tenantType = localStorage.getItem('tenant')
    this.getFormPrerequisite()
    this.checkRequiredFields(this.associateId);
  }

  ngOnChanges(changes:any) {
    this.checkRequiredFields(this.associateId);
 }

  checkRequiredFields(input: any) {
    if(input === null) {
      let selectedDialog:any = this.showSuccessOrError("associateId required")
      setTimeout(()=>{
        selectedDialog.close()
        //this.router.navigate([`/${this.tenantType}/associate-library`,{associateType:this.associateTypeValue}])
      },5000)
    }
 }
  // getSegmentData() {
  //   this.httpService.fetchTenantSegmentData({group_type:this.associateTypeValue}).subscribe((response: any) => {
  //     const segments = response?.data?.segments;
  //     if(Array.isArray(segments)) {
  //       // this.isDisplaySegmentAsync$.next(true);
  //       this.isDisplaySegment = false;
  //       this.prepareSegments(segments);
  //     }
  //   },error=>{

  //   })
  // }
  prepareSegments(segments: any[]) {
    this.dynamicFormFields = segments.map(s => {
      return {
        id: s.segment_name,
        label: titlecase(`${s.segment_name}`), // title case
        type: 'select',
        items: s.segment_options
      }
    });
    this.dynamicFormFields.forEach(formItem => {
      this.dynamicForm.addControl(formItem.id, this.fb.control(null, Validators.required))
    })
  }

  formChanges(form: any): void{
    // this.associateCreateGroup.valueChanges.subscribe(x => {
    //   console.log('form value changed')
    //   console.log(x)
    // });
    form.get('associateName').valueChanges.subscribe((val: any)=>{
      this.editBody['associateName'] = val;
    });
    form.get('associateId').valueChanges.subscribe((val: any)=>{
      this.editBody['associateId'] = val;
    });
    form.get('associatePId').valueChanges.subscribe((val: any)=>{
      this.editBody['associatePId'] = val;
    });
    form.get('hierarchyLevel').valueChanges.subscribe((val: any)=>{
      this.editBody['hierarchyLevel'] = val;
    });
    form.get('parentLink').valueChanges.subscribe((val: any)=>{
      this.editBody['parentLink'] = val;
    });
    // form.get('title').valueChanges.subscribe((val: any)=>{
    //   this.editBody['title'] = val;
    // });
    // form.get('firstName').valueChanges.subscribe((val: any)=>{
    //   this.editBody['firstName'] = val;
    // });
    // form.get('lastName').valueChanges.subscribe((val: any)=>{
    //   this.editBody['lastName'] = val;
    // });
    form.get('address').valueChanges.subscribe((val: any)=>{
      this.editBody['address'] = val;
    });
    form.get('state').valueChanges.subscribe((val: any)=>{
      this.editBody['state'] = val;
    });
    form.get('zip').valueChanges.subscribe((val: any)=>{
      this.editBody['zip'] = val;
    });
    // form.get('rebateType').valueChanges.subscribe((val: any)=>{
    //   this.editBody['rebateType'] = val;
    // });
  }
  // this.testForm.addControl('new', new FormControl('', Validators.required));
  getAssociateDetail(associateId: string) {
    console.log("in  getAssociateDetail");

    this.httpService.fetchAssociateDetail(associateId).subscribe((response: any) => {
      if (_get(response, 'data.res.code') === 1) {
        console.log("in fetchAssociateDetail",response);
          this.editSupplier = true;
          this.editForm = true;
          this.associateDetail = _get(response, 'data.res.associates');
          this.pivotId = this.associateDetail.group_id;
           let obj = {displayText:_get(this.associateDetail, 'associate_level'),value: _get(this.associateDetail, 'associate_level')}
          this.selectedHierarchy = _get(this.associateDetail, 'associate_level');
          this.hierarchyChange(obj)
          if (_get(response, 'data.hierarchyDisable') == true) {
            console.log("in ierarchyDisable");

            this.associateCreateGroup.controls['hierarchyLevel'].disable();
            this.associateCreateGroup.controls['parentLink'].disable();
          }
          // console.log("first userid ",this.associateDetail,"second userid",this.associateDetail['userEmailData']);

          // if(this.associateDetail && this.associateDetail['userEmailData']){
          //   if(this.associateDetail['userEmailData'].hasOwnProperty('user_id') && this.associateDetail['userEmailData']['user_id']){
          //     this.editedUserId = this.associateDetail['userEmailData']['user_id']
          //   }
          // }

          if(this.associateDetail || this.associateDetail['userEmailData']){
            console.log("first userid ",this.associateDetail);
            if(this.associateDetail.hasOwnProperty('user_group_id') && this.associateDetail['user_group_id']){
              this.editedUserId = this.associateDetail['user_group_id']
              console.log("second userid ",this.associateDetail);
            }

          }
        // this.httpService.fetchTenantSegmentData({group_type:this.associateTypeValue}).subscribe((response: any) => {
        //   const segments = response?.data?.segments;
        //   if(Array.isArray(segments)) {
        //     // this.isDisplaySegmentAsync$.next(true);
        //     this.isDisplaySegment = true;
        //     this.prepareSegments(segments);
        //     this.dynamicFormFields.forEach(formItem => {
        //       const idInUpperCase = formItem.id.toUpperCase();
        //       this.dynamicForm.patchValue({
        //         [formItem.id]: _get(this.associateDetail?.segments, idInUpperCase) && _get(this.associateDetail?.segments, idInUpperCase).toUpperCase()
        //       })
        //     })
        //   }
        // },error=>{

        // })
          this.associateCreateGroup.patchValue({
            associateName:_get(this.associateDetail, 'group_name'),
            associateId:_get(this.associateDetail, 'gp_id'),
            associatePId:_get(this.associateDetail, 'group_id'),
            hierarchyLevel:_get(this.associateDetail, 'associate_level'),
            // emailId:_get(this.associateDetail, 'associate_poc_email'),
            address:_get(this.associateDetail, 'address'),
            city:_get(this.associateDetail, 'city'),
            state:_get(this.associateDetail, 'state'),
            zip:_get(this.associateDetail, 'zip'),
            title:_get(this.associateDetail, 'userEmailData.title'),
            firstName:_get(this.associateDetail, 'userEmailData.first_name'),
            lastName:_get(this.associateDetail, 'userEmailData.last_name'),
            parent_link:_get(this.associateDetail, 'group_parent_name'),

          });
          // this.associateCreateGroup.controls['hierarchyLevel'].disable();

          if(this.associateDetail && this.associateDetail.hasOwnProperty('industry') ||
          this.associateDetail.hasOwnProperty('tier') || this.associateDetail.hasOwnProperty('location') ||
          this.associateDetail.hasOwnProperty('annualRevenue')){
            this.isDisplaySegment = true
            this.sementGroup.patchValue({
              industry: this.associateDetail['industry'],
              annualRevenue: this.associateDetail['annualRevenue'],
              location: this.associateDetail['location'],
              tier: this.associateDetail['tier'],
            })
          }else{
            this.isDisplaySegment = false
          }
          // this.associateCreateGroup.controls['associateName'].setValue(_get(this.associateDetail, 'group_name'));
          // this.associateCreateGroup.controls['associateId'].setValue(_get(this.associateDetail, 'group_id'));
          // this.associateCreateGroup.controls['hierarchyLevel'].setValue(_get(this.associateDetail, 'associate_level'));
           // this.associateCreateGroup.controls['parentLink'].setValue(_get(this.associateDetail, 'group_parent_id'));
          // this.associateCreateGroup.controls['emailId'].setValue(_get(this.associateDetail, 'associate_poc_email'));
          // this.associateCreateGroup.controls['address'].setValue(_get(this.associateDetail, 'address'));
          // this.associateCreateGroup.controls['city'].setValue(_get(this.associateDetail, 'city'));
          // this.associateCreateGroup.controls['state'].setValue(_get(this.associateDetail, 'state'));
          // this.associateCreateGroup.controls['zip'].setValue(_get(this.associateDetail, 'zip'));
          // this.associateCreateGroup.controls['title'].setValue(_get(this.associateDetail, 'userEmailData.title'));
          // this.associateCreateGroup.controls['firstName'].setValue(_get(this.associateDetail, 'userEmailData.first_name'));
          // this.associateCreateGroup.controls['lastName'].setValue(_get(this.associateDetail, 'userEmailData.last_name'));
          this.is_hq = _get(this.associateDetail, 'is_hq') == 1 ? true : false;
          // this.associateCreateGroup.controls['is_hq'].setValue(this.is_hq);
          // console.log(this.selectedRebateTypes, 'working', _get(this.associateDetail, 'rebatetypes'));
         this.selectedRebateTypes = _get(this.associateDetail, 'rebatetypes') ? JSON.parse(_get(this.associateDetail, 'rebatetypes')) : [];
          // console.log('checking', this.selectedRebateTypes);
          this.associateCreateGroup.controls['rebateType'].setValue(this.selectedRebateTypes);
          // console.log(this.selectedRebateTypes.length, 'checking', this.selectedRebateTypes);
          this.selectRebateTypes = this.selectedRebateTypes.length !== 0 ?   this.selectedRebateTypes.map((d: any) => ({value: _get(d, 'value'), displayText: _get(d, 'displayText')})): [];

          this.canConfigureRebateAttrYes = _get(this.associateDetail, 'segment_allowed_flag') === 1 ? true : false;
          this.canConfigureRebateAttrNo = _get(this.associateDetail, 'segment_allowed_flag') === 1 ? false : true;

          this.canConfigurePaymentAttrYes = _get(this.associateDetail, 'member_based_payment_flag') === 1 ? true : false;
          this.canConfigurePaymentAttrNo = _get(this.associateDetail, 'member_based_payment_flag') === 1 ? false : true;
          let body;
          if(this.editForm){
            body = {
              group_id:this.pivotId,
            }
          }else {
            body = {};
          }
          this.httpService.fetchAssociateParent(this.selectedHierarchy, this.selectedTab, body).subscribe((response: any) => {
            if(_get(response, 'data.code', -1) === 1) {

              this.associateParent = _get(response, 'data.parentAssociate');
              // let parentId = _get(this.associateDetail, 'group_parent_name');
              let parentId = _get(this.associateDetail, 'user_group_parent_id');
              let associate_level = _get(this.associateDetail, 'associate_level');
              console.log("first parent", this.associateParent);
              console.log("third parent", this.associateDetail);
              console.log("second parent",parentId);

              // this.selectedParent = parentId;
              if(associate_level!='CONGLOMERATE'){
                  this.associateCreateGroup.controls['parentLink'].setValue(parentId)
              }

            }
          })


          // form changes tracking
          this.formChanges(this.associateCreateGroup);
      }
      // this.associateCreateGroup.controls['emailId'].disable();
      this.associateCreateGroup.controls['associatePId'].disable();
    })
  }
  getFormPrerequisite(){
    this.httpService.associateFormPrerequisite(this.selectedTab).subscribe((response:any)=>{
      if(response && response['data']['code'] === 1){
        this.hierarchyOptions = _get(response, 'data.hierarchy');
        this.hierarchyOptions.forEach((item: any) => {
          item.displayText = item.displayText.charAt(0).toUpperCase() + item.displayText.slice(1).toLowerCase();
        });
        this.rebateTypeOptions = _get(response, 'data.rebateType');
      }
    })
  }

  hierarchyChange(event: any) {
    this.associateCreateGroup.controls['parentLink'].setValue(null)
    if (this.editSupplier) {
      this.editBody['hierarchyLevel'] = this.selectedHierarchy;
    }

    if(this.selectedHierarchy=='BRAND' || this.selectedHierarchy=='LOCATION'){
      this.associateCreateGroup.controls['parentLink'].setValidators([Validators.required])
      this.associateCreateGroup.controls['parentLink'].updateValueAndValidity();
      this.associateCreateGroup.controls['parentLink'].enable()
    }else{
      this.associateCreateGroup.controls['parentLink'].disable()
     this.associateCreateGroup.controls['parentLink'].clearValidators();
      this.associateCreateGroup.controls['parentLink'].updateValueAndValidity();
      this.associateParent = [];
    }
    if (this.selectedHierarchy !== 'CONGLOMERATE') {
      this.fetchParent(this.selectedHierarchy, this.selectedTab);
    }


  }

  parentChange(event: any) {
    console.log("event check",event);
    console.log("parent selected",this.selectedParent);
    if(this.editSupplier) {
      this.editBody['parentLink']= this.selectedParent;

    }
  }

  fetchParent(hierarchy: string, type: string) {
    let body;
    if(this.editForm){
      body = {
        group_id:this.pivotId,
      }
    }else {
      body = {};
    }
    this.httpService.fetchAssociateParent(hierarchy, type, body).subscribe((response: any) => {
      if(_get(response, 'data.code', -1) === 1) {
        this.associateParent = _get(response, 'data.parentAssociate');
        console.log("parent fetch", this.associateParent);

      }
    })
  }
  canConfigureRebate(event: boolean) {
    // console.log( 'configure rebate', event);
    if (this.editSupplier) {
      this.editBody['configureRebate'] = 1
    } else {
      this.configureRebate = 1;
    }

      this.canConfigureRebateAttrYes = true;
      this.canConfigureRebateAttrNo = false;


  };
  cannotConfigureRebate(event: boolean) {
    // console.log( 'configure rebate  not', event);
    if (this.editSupplier) {
      this.editBody['configureRebate'] = 0
    } else {
      this.configureRebate = 0;

    }

    this.canConfigureRebateAttrYes = false;
    this.canConfigureRebateAttrNo = true;

  };

  canConfigurePayment(event: boolean) {
    // console.log( 'configure payment', event);
    if(this.editSupplier ) {
      this.editBody['configurePayment'] = 1
    } else {
      this.configurePayment = 1;
    }
    this.canConfigurePaymentAttrYes = true;
    this.canConfigurePaymentAttrNo = false;

  };
  cannotConfigurePayment(event: boolean) {
    // console.log( 'configure payment  not', event);
    if(this.editSupplier) {
      this.editBody['configurePayment'] = 0;
    } else {
      this.configurePayment = 0;
    }
    this.canConfigurePaymentAttrYes = false;
    this.canConfigurePaymentAttrNo = true;
  };

  hqSwitch(event: any) {
    if(this.editSupplier) {
      this.editBody['is_hq'] = event.event.checked
    } else {
      this.is_hq = event.event.checked;
    }
  }
  saveAssociateCall(data: any) {
    this.deSelectAllItems({})
    console.log('data...',data);
    this.httpService.createAssociateData(data).subscribe((response: any) => {
      //console.log(data);
      if(_get(response, 'data.code') === 1) {
        // this.associateCreateGroup.reset();
        // this.sementGroup.reset();
        let selectedDialog:any = this.showSuccessOrError("Associate created successfully")
        setTimeout(()=>{
          selectedDialog.close()
          //this.router.navigate([`/${this.tenantType}/associate-library`,{associateType:this.associateTypeValue}])
        },5000)
      }else if(response['data']['message']=='Email id already exists'){
        let selectedDialog:any = this.showSuccessOrError("Email id already exits")
        setTimeout(()=>{
           selectedDialog.close()
        },5000)
      }else if(response['data']['message']=='Group id already exists'){
        let selectedDialog:any = this.showSuccessOrError("Pivot Id already exists")
        setTimeout(()=>{
           selectedDialog.close()
        },5000)
      }
    },error=>{
      let selectedDialog:any = this.showSuccessOrError("Error occured while saving the associate")
      setTimeout(()=>{
         selectedDialog.close()
      },5000)
    })
  }

  editAssociateCall(data:any){

    this.associateCreateGroup.reset();
    this.sementGroup.reset();
    this.httpService.editAssociateData(data).subscribe((response: any) => {
      if(_get(response, 'message') === "success") {
        let selectedDialog:any = this.showSuccessOrError("Associate updated successfully");
        setTimeout(()=>{
           selectedDialog.close()
          //this.router.navigate([`/${this.tenantType}/associate-library`,{associateType:this.associateTypeValue}])
        },5000)
      }
    },error=>{
      let selectedDialog:any = this.showSuccessOrError("Error occured while saving the associate")
      setTimeout(()=>{
         selectedDialog.close()
      },5000)
    })
  }

  saveAssociate(type:any) {
    if(this.associateCreateGroup.valid) {

      if(type=='vendor'){
        let finalObject  = {
          ...this.associateCreateGroup.value
        }
        // if(this.isDisplaySegment){
        //   finalObject  = {
        //     ...finalObject,
        //     segments: this.dynamicForm.value
        //   }
        // }
       console.log(finalObject);
        const data = mapAssociateCreateData(finalObject, this.is_hq , this.configurePayment, this.configureRebate, this.selectedTab);
        this.saveAssociateCall(data);
      }else{
        console.log("under final object");
        let finalObject  = {}
        if(this.isDisplaySegment){
          finalObject  = {
            ...this.associateCreateGroup.value,
            segments: this.dynamicForm.value
          }
        }else{
          finalObject  = {
            ...this.associateCreateGroup.value
          }

        }
        const data = mapDistributorAssociateCreateData(finalObject, this.is_hq , this.selectedTab);
        this.saveAssociateCall(data);
      }

    }else{
      console.log("under associate save");
      this.associateCreateGroup.markAllAsTouched();
      // alert("enter required");
      // this.dynamicForm.markAllAsTouched();
    }
  }

  editAssociate(type: any) {
    let finalObject  = {};
    // finalObject  = cleanEntityData({
    //   ...this.associateCreateGroup.value,
    //   segments: this.dynamicForm.value
    // });
    this.associateCreateGroup.controls['parentLink'].enable();
    finalObject  = {
      ...this.associateCreateGroup.value
    };
    this.associateCreateGroup.controls['parentLink'].disable();
    if ( this.associateCreateGroup.valid || this.dynamicForm.valid) {
      if(type === 'vendor') {
        let data:any = mapAssociateCreateData(finalObject, this.editBody?.is_hq , this.editBody?.configurePayment, this.editBody?.configureRebate, this.selectedTab);
        console.log("this.editedUserId",this.editedUserId)
        if(this.editedUserId){
          //  data['user_id']=this.editedUserId;
          data['user_group_id']=this.editUserGroupId
        }
        console.log("group id",+this.editUserGroupId);
        //console.log("user group id",+data)
        this.editAssociateCall({...data, title:this.editBody['title']})
        this.deSelectAllItems({})
      }else{

        // if(this.isDisplaySegment){
        //   finalObject  = {
        //     ...this.associateCreateGroup.value,
        //     ...this.sementGroup.value,

        //   }
        // }else{
        // }

        let data:any = mapDistributorAssociateCreateData(finalObject, this.editBody?.is_hq , this.selectedTab);
        if(this.editedUserId){
          //  data['user_id']=this.editedUserId;
          data['user_group_id']=this.editUserGroupId
        }
        this.editAssociateCall(data)
        this.deSelectAllItems({})
      }
    }
  }

  // addSegment = () =>{
  //   this.isDisplaySegment = !this.isDisplaySegment
  // }

  selectedParentItem = (value:any)=>{
    if(value){
      this.selectedParentLinkList.push(value)
    }
    if(this.selectedParentLinkList.length==0){
      this.associateCreateGroup.controls['parentLink'].setErrors({'required': true});
    }
    this.associateCreateGroup.controls['parentLink'].setValue(this.selectedParentLinkList)


  }
  selectedAllParentItem = (values:any)=>{
    this.selectedParentLinkList = values
    if(this.selectedParentLinkList.length==0){
      this.associateCreateGroup.controls['parentLink'].setErrors({'required': true});
    }
    this.associateCreateGroup.controls['parentLink'].setValue(this.selectedParentLinkList)
    console.log("parent list",this.selectedParentLinkList);

  }
  selectedRebateItem = (values:any)=>{


    if(values){
      // this.selectedRebateTypes.push(_get(values, 'value'))
      this.selectedRebateTypes.push(values)

      this.associateCreateGroup.controls['rebateType'].setValue(this.selectedRebateTypes)
      if (this.editSupplier) {
        this.editBody['rebateType'] = this.selectedRebateTypes;
        this.associateCreateGroup.controls['rebateType'].setValue(this.selectedRebateTypes)
      }

    }
  }
  selectedAllRebateItems = (values:any)=>{
    // this.selectedRebateTypes = _map(values, v => _get(v, 'value'))
    this.selectedRebateTypes = values;
    // console.log(this.selectedRebateTypes);
    if(values.length>0){
      this.associateCreateGroup.controls['rebateType'].setValue(this.selectedRebateTypes)
      if(this.editSupplier) {
        this.editBody['rebateType'] = this.selectedRebateTypes;
        this.associateCreateGroup.controls['rebateType'].setValue(this.selectedRebateTypes)
      }
    }else{
      this.associateCreateGroup.controls['rebateType'].setValue([])
      if(this.editSupplier){
        this.editBody['rebateType'] = [];
        this.associateCreateGroup.controls['rebateType'].setValue([])
      }

    }



  }

  deSelectedItem = (event: any) => {
    const ind = this.selectedRebateTypes.findIndex((v: any) => v === event.value);
    this.selectedRebateTypes.splice(ind, 1);

    if(this.editSupplier) {
      this.editBody['rebateType'] = this.selectedRebateTypes;
      this.associateCreateGroup.controls['rebateType'].setValue(this.selectedRebateTypes)
    }

  }

  onTabChanged = (event:any) =>{
    if(event && event['index']==0){
      this.selectedTab =  'vendor'
    }else{
      this.selectedTab =  'dealer'
    }
    this.associateCreateGroup.reset();
    this.sementGroup.reset();
    this.dynamicForm.reset();
    this.deSelectAllItems({});
    this.associateTypeValue = this.selectedTab;
    this.dynamicFormFields = [];
    this.dynamicForm = this.fb.group({});
    //this.getSegmentData();
  }



  uploadedFile = (file:any) =>{
    if(file){
      if(file.hasOwnProperty('isMandetoryColumns') && file['isMandetoryColumns']==2){
        this.showSuccessOrError("Mandatory column(s) are missing");
      } else if(file.hasOwnProperty('isMandetoryColumns') && file['isMandetoryColumns']==1){
        this.showSuccessOrError("Data for mandatory column(s) is missing");
      }
      else {
        this.formData.append("file",file)
      }
    } else {
      this.showSuccessOrError("Please Upload File With Data");
    }
  }

  isDisabled = (event:any)=>{
    this.isButtonDisabled = event
  }

  uploadFile = () =>{
    this.resetFile = true;
    if(this.formData.has('file')){
      this.formData.append('email', this.userEmail);
      this.formData.append('userName', this.tenantType);
      console.log('formData..', this.formData);
      this.httpService.uploadAssociatedFile(this.formData,this.selectedTab).subscribe((response)=>{
        if(response && response['message']){
          if(response['message']=='Success'){
            this.showSuccessOrError("File Upload Successful")
          }

        }
      },error=>{
        this.showSuccessOrError("Error occured while uploading file")
      })
    }

  }

  showSuccessOrError = (message:any) =>{
    if(message){
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: {"type":message},
        disableClose: true,
      });
      dialogRef.afterClosed().subscribe(result => {
        if(message!='Email id already exits'){
          this.router.navigate([`/${this.tenantType}/associate-library`,{associateType:this.associateTypeValue}])

        }
      })
      return dialogRef
    }

  }

  downloadSample(type: string) {
    switch (type) {
      case 'vendor':
        type = "associate_vendor_sample";
        break;
      case 'dealer':
        type = "associate_dealer_sample";
        break;
      default:
        break;
    }
    this.dataService.download(type, `${type + '.csv'}`);
  }

  deSelectAllItems = (event:any) =>{
    this.isItemsReset = true
    this.associateCreateGroup.controls['rebateType'].setValue([])
    this.selectedRebateTypes = []
  }

  navigateToAssociateModule = () =>{
    if(this.associateCreateGroup.dirty || this.sementGroup.dirty){
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '382px',
        height: '180',
        data: {"type":"Are you sure discard your changes ?"},
        disableClose: true,
      });
      dialogRef.afterClosed().subscribe(result => {
        if(result !='cancel'){
          this.router.navigate([`/${this.tenantType}/associate-library`])
        }
      })
    }else{
      this.router.navigate([`/${this.tenantType}/associate-library`])
    }

  }

  navigateToHome = () =>{
    if(this.associateCreateGroup.dirty || this.sementGroup.dirty){
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '382px',
        height: '180',
        data: {"type":"Are you sure discard your changes ?"},
        disableClose: true,
      });
      dialogRef.afterClosed().subscribe(result => {
        if(result !='cancel'){
          this.router.navigate([`/${this.tenantType}/home`])
        }
      })
    }else{
      this.router.navigate([`/${this.tenantType}/home`])
    }
  }


}
