import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociateSupplierComponent } from './associate-supplier.component';

describe('AssociateSupplierComponent', () => {
  let component: AssociateSupplierComponent;
  let fixture: ComponentFixture<AssociateSupplierComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssociateSupplierComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociateSupplierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
