import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-associate-supplier',
  templateUrl: './associate-supplier.component.html',
  styleUrls: ['./associate-supplier.component.scss']
})
export class AssociateSupplierComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
