import { Component, Inject, OnInit} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/services/http.service';
import { checkNameLength } from 'src/app/helpers/commonUtils';
import { TitleCasePipe } from '@angular/common';

@Component({
  selector: 'app-associate-org-view',
  templateUrl: './associate-org-view.component.html',
  styleUrls: ['./associate-org-view.component.scss']
})
export class AssociateOrgViewComponent implements OnInit {

  orgData:any=[];
  associateDetails:any;
  columnsToDisplay = [
    {header: 'User Name', field: 'userName'},
    // {header: 'Access Level', field: 'accessLevel'},
    {header: 'Email', field: 'email'},
  ];
  columnsProps = this.columnsToDisplay.map(column => column.field);
  dataSource: any;
  selectionType:any;
  selectedIdValue:any;
  isOrgViewDisplay:boolean = false;
  tenantType: any;
  associateTypeValue:any;
  constructor(public dialogRef: MatDialogRef<AssociateOrgViewComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {data: any,selectedAssoType:any,selectedId:any},private domSanitizer: DomSanitizer,private matIconRegistry: MatIconRegistry,private httpService: HttpService, public router:Router,private titlecasePipe:TitleCasePipe) {
      this.matIconRegistry.addSvgIcon("ra-close", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/close-icon.svg"))
      this.matIconRegistry.addSvgIcon("ra-back", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/back-icon.svg"))
     }


  ngOnInit(): void {
    if(this.data){
      this.selectedIdValue = this.data['selectedId']
      this.selectionType = this.data['selectedAssoType']
      const keys = Object.keys(this.data['data']);
      keys.forEach((key, index) => {
        if(key == 'name'){
          this.data['data'][key] = this.titlecasePipe.transform(this.data['data'][key]);
        }
      });
      this.populateAssociateDetails(this.data['data'],this.selectedIdValue);
      this.tenantType = localStorage.getItem('tenant')
      console.log("org view data",this.data);
    }

  }

  checkNameLength = (value: any,length?:number) => {
    return value
  }
  selectNode = (value:any)=>{
    console.log('>>>',value)
    let payloadObj = {
      "user_type_id": this.selectionType=='supplier'?2:3,
      "user_group_id": value['id']
    }
    this.httpService.getOrgViewData(payloadObj).subscribe((responseObj:any)=>{
      if(responseObj && responseObj['data']){
        this.isOrgViewDisplay = false
        this.populateAssociateDetails(responseObj['data'],value['id']);
      }
    })
    this.orgData.forEach(
      function iter(a:any) {
          if (value['id']==(a.id)) {
              a.cssClass = "selected-org";
          }else{
            a.cssClass = "non-selected-org";
          }
          Array.isArray(a.childs) && a.childs.forEach(iter);
      });
  }

  close = () =>{
    console.log("calling Dialog")
    this.dialogRef.close();
  }

  populateDetails = (details:any)=>{
    const tableData:any = [];
    for(let i=0;i<details.length;i++){
      let obj:any={}
      obj['userName']=details[i]['userName']
      obj['accessLevel']=details[i]['accessLevel']
      obj['email']=details[i]['email']
      tableData.push(obj)
    }
    this.dataSource = new MatTableDataSource(tableData);

  }
  populateAssociateDetails = (associate:any,selectedGroupId:any)=>{
    this.associateDetails = associate;
    if(this.associateDetails && this.associateDetails['userDetails']){
      this.populateDetails(this.associateDetails['userDetails'])
    }

    if( this.associateDetails &&  this.associateDetails.hasOwnProperty('orgDetails')){
      let data =  this.associateDetails['orgDetails']
        data.forEach(
          function iter(a:any): void {
              if (selectedGroupId==(a.id)) {
                  a.cssClass = "selected-org";
              }else{
                a.cssClass = "non-selected-org";
              }
              Array.isArray(a.childs) && a.childs.forEach(iter);
        });
        this.orgData=data;
        let modifyOrgData = (array: any) => {
          for (let index = 0; index < array.length; index++) {
            //array[index].name = this.titlecasePipe.transform(array[index].name)
            if(array[index].childs && Array.isArray(array[index].childs) && array[index].childs.length > 0){
              modifyOrgData(array[index].childs);
            }
          }
        }
        modifyOrgData(this.orgData);
        console.log('>>>',this.orgData)
      }
    }


  getModifiedValue = (value:any)=>{
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore

      notation: "compact",
      compactDisplay: "short",
      style: "currency",currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  }

  displayOrgMap = () =>{
    this.isOrgViewDisplay = true
  }

  closeOrgView = () =>{
    this.isOrgViewDisplay = false
  }

  navigateToUserManagement = ()=>{
    console.log("calling navigateToUserManagement")

    this.close();
    console.log(this.associateDetails['name']);
    this.router.navigate([`/${this.tenantType}/associate-users`,{associateType:this.selectionType}],{
      state: { associateName: this.associateDetails['name'] }
    })
  }

  redirectEdit = () => {
    console.log("calling redirectEdit")

    this.close();
    this.router.navigate([`/${this.tenantType}/associate/edit/${this.selectedIdValue}`],  { queryParams: { type: this.selectionType=='distributor'?'distributor':this.selectionType}})
  }
}
