import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociateOrgViewComponent } from './associate-org-view.component';

describe('AssociateOrgViewComponent', () => {
  let component: AssociateOrgViewComponent;
  let fixture: ComponentFixture<AssociateOrgViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssociateOrgViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociateOrgViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
