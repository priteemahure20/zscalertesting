import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociateLibraryComponent } from './associate-library.component';

describe('AssociateLibraryComponent', () => {
  let component: AssociateLibraryComponent;
  let fixture: ComponentFixture<AssociateLibraryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssociateLibraryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociateLibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
