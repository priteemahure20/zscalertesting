import { TitleCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpService } from 'src/app/services/http.service';
import { AssociateOrgViewComponent } from '../associate-org-view/associate-org-view.component';
import * as moment from 'moment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MessageModalComponent } from 'src/app/common/message-modal/message-modal.component';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import { Subject } from 'rxjs/internal/Subject';
import { ReusableService } from 'src/app/services/reusable.service';

@Component({
  selector: 'app-associate-library',
  templateUrl: './associate-library.component.html',
  styleUrls: ['./associate-library.component.scss']
})
export class AssociateLibraryComponent implements OnInit {
  columnsToDisplay :any= [];
  columnsProps:any;
  dataSource: any;
  sort:any;
  searchName:any=''
  isListView:boolean = false;
  tenantType:any;
  selectedTab:any;
  associateObj:any={};
  filterAssociateIds=[];
  filterAssociateEmailIds=[];
  totalCount:any;
  pagination={
    limit:10,
    pageNo:1,
  }
  isRowsSelected:boolean = false
  selectedRowsData:any=[]
  tableCompanyContent = []
  tableBranchContent = []
  updatedHierarchiTable:any =[]
  isToogledSupplier:boolean= false;
  isToogledDistributor:boolean = false;
  tabIndex:number=0;
  selectedPageLimit = this.pagination.limit;
  isSortApplied: Subject<any> = new Subject();
  constructor( private domSanitizer: DomSanitizer,private matIconRegistry: MatIconRegistry,public dialog: MatDialog,
    public router: Router, public activatedRoute: ActivatedRoute,private httpService: HttpService,private titlecasePipe:TitleCasePipe,
    private snackBar: MatSnackBar, private reusableService:ReusableService) { 
    this.matIconRegistry.addSvgIcon("ra-add", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/ra-add.svg"))
    .addSvgIcon("ra-delete", this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/delete.svg"))
  }

  ngOnInit(): void {
    this.tenantType = localStorage.getItem('tenant')
    this.activatedRoute.paramMap.subscribe((params:any) => {
      if(params && params['params'] && params['params']['associateType']){
        this.associateObj['limit']=this.pagination['limit'];
        this.associateObj['pageNo']=this.pagination['pageNo'];
       
        if(params['params']['associateType']=='vendor'){
          this.onTabChanged({index:0})
          this.tabIndex =0;
        }else if(params['params']['associateType']=='dealer'){
          console.log('>>>',params['params']['associateType'])
          this.onTabChanged({index:1})
          this.tabIndex =1;
        }
      }else{
        this.tenantType = localStorage.getItem('tenant')
        this.associateObj['limit']=this.pagination['limit'];
        this.associateObj['pageNo']=this.pagination['pageNo'];
        this.onTabChanged({index:0})
      }
    })
   
  }
  changeView = (event:any) =>{
    this.isListView = event.checked;
    this.dataSource && this.dataSource['data']?this.dataSource['data'] = []:[]
    this.associateObj = {}
    this.associateObj['limit']=this.pagination['limit']=10;
    this.associateObj['pageNo']=this.pagination['pageNo']=1;
    this.isRowsSelected = false;
    this.isToogledSupplier = false;
    this.isToogledDistributor = false;
    if(!this.isListView){
      if(this.selectedTab && this.selectedTab=='vendor'){
        this.onTabChanged({index:0})
      }else{
        this.onTabChanged({index:1});
      }
    }else{
       if(this.selectedTab && this.selectedTab=='vendor'){
        this.onTabChanged({index:0});
        this.isToogledSupplier = true;
      }else{
        this.onTabChanged({index:1});
        this.isToogledDistributor = true;
      }
    }
  }

  populateAssociateData = (content:any) =>{
  
    const tableData:any = [];
    for(let i=0;i<content.length;i++){
      let obj:any={}
      obj['userGroupId']=content && content[i]['user_group_id']?content[i]['user_group_id']:'NA'
      obj['group_id']=content && content[i]['group_id']?content[i]['group_id']:'NA'
      obj['gp_id']=content && content[i]['gp_id']?content[i]['gp_id']:'NA'
      obj['name']=content && content[i]['group_name']?content[i]['group_name']:'NA'
      obj['associateLevel']=content && content[i]['associate_level']?this.titlecasePipe.transform(content[i]['associate_level']):'NA'
      obj['status']= content[i]['active_flag']==1?true:false;
      obj['effectiveDate']=content && content[i]['effective_date']?this.formatDate(content[i]['effective_date']):"--/--/----"
      obj['editedBy']=content && content[i]['updated_by']?content[i]['updated_by']:'NA'
      obj['editedDate']=content && content[i]['updated_at']?this.formatDate(content[i]['updated_at']):"NA"
      if(this.isListView){
        obj['isOpened'] = false
      }
      tableData.push(obj)
    }
  //   setTimeout(()=>{
  //     this.dataSource = new MatTableDataSource(tableData);
  //   },500)
  this.dataSource = new MatTableDataSource(tableData);
   }

 

  selectedHierarchical = (hierarchyData:any) =>{
    let data= this.dataSource['data']
    let index = data.findIndex((f: any) => f.userGroupId === hierarchyData['userGroupId']);
    let userGroupId = hierarchyData['userGroupId'];
    if( data[index]['isOpened']==false){
      this.httpService.getHierarchicalView(userGroupId).subscribe((response:any)=>{
        if(response && response['data'] &&  response['data']['associates'] && response['data']['associates'].length>0){
          this.tableCompanyContent = response['data']['associates']
          this.populateOrganisationHirarchy(data,index,hierarchyData)
          if(!hierarchyData['isOpened']){
            data[index]['isOpened'] = true
          } 
          this.dataSource = new MatTableDataSource(data);
        }else{
          const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
            width: '370px',
            height: '180',
            data: {"type":"No matching hierarchical data found"},
            disableClose: true,
          });
          setTimeout(()=>{
            dialogRef.close();
          },2000)
        }
      },error=>{
        const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
          width: '370px',
          height: '180',
          data: {"type":"Error occured while retriving the data"},
          disableClose: true,
        });
        setTimeout(()=>{
          dialogRef.close();
        },2000)
      })
    }else{
      data=this.updatedHierarchiTable
      let matchedOrgList=[]
      let matchedCompanyList=[]
      if(hierarchyData['isOpened'] && hierarchyData['associateLevel']=='Conglomerate' ){
        for(let i=0;i<data.length;i++){
          if(data[i].hasOwnProperty('primaryHierarchiId') && data[i]['primaryHierarchiId']==hierarchyData['userGroupId']){
            matchedOrgList.push(data[i]['primaryHierarchiId'])
          }
        }
        matchedOrgList.forEach(function(id){
          var itemIndex = data.findIndex((i:any) => i['primaryHierarchiId'] == id);
          data.splice(itemIndex,1);
       });
        hierarchyData['isOpened']=false
      } 
       if(hierarchyData['isOpened'] && hierarchyData['associateLevel']=='Brand'){
        for(let i=0;i<data.length;i++){
          if(data[i].hasOwnProperty('secondaryHierarchiId') && data[i]['secondaryHierarchiId']==hierarchyData['userGroupId']){
            matchedCompanyList.push(data[i]['secondaryHierarchiId'])
          }
        }
        matchedCompanyList.forEach(function(id){
          var itemIndex = data.findIndex((i:any) => i['secondaryHierarchiId'] == id);
          data.splice(itemIndex,1);
       });
        hierarchyData['isOpened']=false 
        
      }
      this.dataSource = new MatTableDataSource(data);
    }

   
   
  
  }
  populateHierarchicalResponse = (content:any,tableData:any,index:any,isAdd:any) =>{
    if(index>=0  && tableData.length>0){
      if(!isAdd){
        tableData.splice(index+1, 0 , content);
      }
      else{
        tableData.splice(index+1, 1);
      }
      this.dataSource = new MatTableDataSource(tableData);
    }
  }

  populateOrganisationHirarchy = (data:any,index:any,hierarchyData:any)=>{
    let hierarchicalResponse = this.tableCompanyContent
    for(let i=0;i<hierarchicalResponse.length;i++){
      let obj:any={}
      obj['userGroupId']=hierarchicalResponse && hierarchicalResponse[i]['user_group_id']?hierarchicalResponse[i]['user_group_id']:'NA'
      obj['group_id']=hierarchicalResponse && hierarchicalResponse[i]['group_id']?hierarchicalResponse[i]['group_id']:'NA'
      obj['gp_id']=hierarchicalResponse && hierarchicalResponse[i]['gp_id']?hierarchicalResponse[i]['gp_id']:'NA'
      obj['name']=hierarchicalResponse && hierarchicalResponse[i]['group_name']?this.titlecasePipe.transform(hierarchicalResponse[i]['group_name']):'NA'
      obj['associateLevel']=hierarchicalResponse && hierarchicalResponse[i]['associate_level']?this.titlecasePipe.transform(hierarchicalResponse[i]['associate_level']):'NA'
      obj['status']= hierarchicalResponse[i]['active_flag']==1?true:false;
      obj['effectiveDate']=hierarchicalResponse && hierarchicalResponse[i]['effective_date']?this.formatDate(hierarchicalResponse[i]['effective_date']):"--/--/----"
      obj['editedBy']=hierarchicalResponse && hierarchicalResponse[i]['updated_by']?hierarchicalResponse[i]['updated_by']:'NA'
      obj['editedDate']=hierarchicalResponse && hierarchicalResponse[i]['updated_at']?this.formatDate(hierarchicalResponse[i]['updated_at']):"NA"
      obj['isOpened'] = false
      if(hierarchyData['associateLevel']=='Conglomerate' ){
        obj['primaryHierarchiId']=hierarchyData['userGroupId']
      } else if(hierarchyData['associateLevel']=='Brand'){
        obj['secondaryHierarchiId']=hierarchyData['userGroupId']
        obj['primaryHierarchiId']=hierarchyData['primaryHierarchiId']
      }
      this.populateHierarchicalResponse(obj,data,index,hierarchyData['isOpened'])
    }
    this.updatedHierarchiTable =this.dataSource['data']
  }


  // closeSelectedHierarchical = (hierarchyData:any) =>{
  //   let data= this.dataSource['data']
  //   let index = data.findIndex((f: any) => f.group_id === hierarchyData['group_id']);
  //   if(hierarchyData['isOpened']){
  //     data[index]['isOpened'] = false
  //   }
  //   this.dataSource = new MatTableDataSource(data);
  // }

  showTestEmit = (event:any)=>{
    console.log('>>>>',event)
  }

  onTabChanged = (event:any)=>{
    // On Tab changing reset all the filters and reload the data of selected tab
   
    if(event && event.hasOwnProperty('tab')){
      this.associateObj = {}
      this.associateObj['limit']=this.pagination['limit']=10;
      this.associateObj['pageNo']=this.pagination['pageNo']=1;
      this.isRowsSelected = false;
      this.isListView = false
      this.isToogledSupplier = false;
      this.isToogledDistributor = false;
    }
    this.searchName ='';
    if(event && event['index']==0){
      this.selectedTab =  'vendor'
    }else{
      this.selectedTab =  'dealer'
    }
    this.associateObj['type'] = this.selectedTab
    if(!this.isListView){
      if(this.associateObj && this.associateObj.hasOwnProperty('hierarchy')){
        delete this.associateObj.hierarchy
      }
      this.getAssociateData();
      this.getAllFilterData()
    }else{
      this.associateObj['hierarchy']=true
      this.getAssociateData();
      //this.populateAssociateData(this.tableOrganizationContent)
    }
  }

  getAssociateData = () =>{
    if(this.dataSource && this.dataSource['data'].length>0 && this.pagination['pageNo']==1){
     
      this.dataSource = new MatTableDataSource([])
    }
    this.populateHeaders();
    this.httpService.getAssociateLibraryData(this.associateObj).subscribe((response:any)=>{
      if(response && response['data']['associateCount']>0){
        this.totalCount = response['data']['associateCount']
        if(response['data']['associates']){
          this.populateAssociateData(response['data']['associates'])
          // this.populateAssociateData([])
          console.log("get associate count",this.totalCount);
          
        } else{
          this.snackBar.open('Please enter valid page number', 'Ok', {
            duration: 2000,
          });
        }
      }
    })
  }


  viewOrg = (details:any)=>{
    let payloadObj = {
      "user_type_id": this.selectedTab=='vendor'?2:3, 
      "user_group_id": details['userGroupId']
    }
    this.httpService.getOrgViewData(payloadObj).subscribe((responseObj:any)=>{
      if(responseObj && responseObj['data']){
        const dialogref= this.dialog.open(AssociateOrgViewComponent, {
          //width: '400px',
          //width: '30%'
          width: '100%',
          height: '460px',
          disableClose: true,
          panelClass: 'dialog-container-custom',
          data: {"data":responseObj['data'],selectedAssoType:this.selectedTab,selectedId:details['userGroupId']}, 
        })
        dialogref.afterClosed().subscribe((response:any)=>{
         
        })
      }
    })
 

  }

  navigateToAssociateUserLibrary = () =>{
    this.router.navigate([`/${this.tenantType}/associate-users`])
  }

  openAssociateCreation = () =>{
    this.router.navigate([`/${this.tenantType}/associate/create`], { queryParams: { type: this.selectedTab=='dealer'?'dealer':this.selectedTab}})
  }

  public getDate = (date:any) =>{
    if(date){
      let modifedDate = moment(date,"YYYYMMDD")
      return modifedDate.format('MM/DD/YYYY')
    }else{
      return 'NA'
    }
  }
  formatDate = (date:any) => {
    if(date){
      return this.reusableService.formatDateToMTZ(date)
    }
  }

  getAllFilterData = () =>{
    this.httpService.getFilterAssociateIds(this.selectedTab).subscribe((response:any)=>{
      if(response && response['data']){
        this.filterAssociateIds = response['data']
      }
    })
    this.httpService.getFilterEmailIds(this.selectedTab).subscribe((emailResponse:any)=>{
      if(emailResponse && emailResponse['data']){
        this.filterAssociateEmailIds = emailResponse['data']
      }
    })
  }

  applyFilter = (values:any) => {
    if(values['group_id']!=null){
      this.associateObj['user_group_id'] = values['group_id']
    }else if(values['group_id']==null){
      if(values['group_id']==null && this.associateObj.hasOwnProperty('user_group_id')){
        delete this.associateObj.user_group_id
      }
    }
    if(values['gp_id']!=null){
      this.associateObj['gp_id'] = values['gp_id']
    }else if(values['gp_id']==null){
      if(values['gp_id']==null && this.associateObj.hasOwnProperty('gp_id')){
        delete this.associateObj.gp_id
      }
    }
    if(values['status']!=null){
      this.associateObj['active_flag']=values['status']==true?1:0
    }else if(values['status']==null){
      if(values['status']==null && this.associateObj.hasOwnProperty('active_flag')){
        delete this.associateObj.active_flag
      }
    }
    if(values.hasOwnProperty('active_from')){
      this.associateObj['effective_date_from'] = values['active_from']+this.appendTimeStamp()
    }else if(!values.hasOwnProperty('active_from')){
      if(this.associateObj.hasOwnProperty('effective_date_from')){
        delete this.associateObj.effective_date_from
      }
    }
    if(values.hasOwnProperty('active_to')){
      this.associateObj['effective_date_to'] = values['active_to']+this.appendEndTimeStamp()
    }else if(!values.hasOwnProperty('active_to')){
      if(this.associateObj.hasOwnProperty('effective_date_to')){
        delete this.associateObj.effective_date_to
      }
    }
    if(values.hasOwnProperty('updated_date_from')){
      this.associateObj['updated_date_from'] = values['updated_date_from']+this.appendTimeStamp()
    }else if(!values.hasOwnProperty('updated_date_from')){
      if(this.associateObj.hasOwnProperty('updated_date_from')){
        delete this.associateObj.updated_date_from
      }
    }
    if(values.hasOwnProperty('updated_date_to')){
      this.associateObj['updated_date_to'] = values['updated_date_to']+this.appendEndTimeStamp()
    }else if(!values.hasOwnProperty('updated_date_to')){
      if(this.associateObj.hasOwnProperty('updated_date_to')){
        delete this.associateObj.updated_date_to
      }
    }
    if(values['editedBy']!=null){
      this.associateObj['updated_by'] = values['editedBy']
    }else if(values['editedBy']==null){
      if(values['editedBy']==null && this.associateObj.hasOwnProperty('updated_by')){
        delete this.associateObj.updated_by
      }
    }
    this.selectedViewPageLimit(this.pagination.limit)
  }

  getNextPage = (event:any) =>{
    this.pagination['pageNo']=parseInt(event['pageIndex'])+1
    this.associateObj['limit']=this.pagination['limit']
    this.associateObj['pageNo']=this.pagination['pageNo']
    this.getAssociateData();
  }

  goToPageNumber = (event:any) =>{
    let value = Math.ceil(this.totalCount/this.pagination['limit'])
    if(event<=value){
      this.pagination['pageNo']=parseInt(event);
      this.associateObj['limit']=this.pagination['limit']
      this.associateObj['pageNo']=this.pagination['pageNo']
      this.getAssociateData();
    }else{
        const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
          width: '370px',
          height: '180',
          data: {"type":"PageNo entered out of range."},
          disableClose: true,
        });
        setTimeout(()=>{
          dialogRef.close()
        },2000)
  
        dialogRef.afterClosed().subscribe((result:any) => {
          if(this.dataSource && this.dataSource['data'] && this.dataSource['data'].length>0){
            this.dataSource['data'] = []
          }
          this.pagination['pageNo']=1;
          this.associateObj['limit']=this.pagination['limit']
          this.associateObj['pageNo']=this.pagination['pageNo']
          this.getAssociateData();
        })
      }
  }

  selectedViewPageLimit = (limitValue:any) => {
    this.pagination['limit']=parseInt(limitValue);
    this.selectedPageLimit=this.pagination.limit;
    this.pagination['pageNo']=1;
    this.associateObj['limit']=this.pagination['limit']
    this.associateObj['pageNo']=this.pagination['pageNo']
    this.getAssociateData();
  }

  populateHeaders = () => {
    this.columnsToDisplay=[
    {header: 'Select', field: 'select'},
    {header: 'Pivot ID', field: 'group_id',displayFilter: false,cell: (element: any) => `${element.name}`,placeHolder:'Group Id'}, 
    {header: 'GP ID', field: 'gp_id',displayFilter: false,cell: (element: any) => `${element.name}`,placeHolder:'GP Id'},
    {header: 'Name', field: 'name',ellipseLength:15}, 
    {header: 'Hierarchy', field: 'associateLevel'}, 
    {header: 'Activate / Deactivate', field: 'status', width:'140px',displayFilter: false,cell: (element: any) => `${element.name}` ,placeHolder:'Active'}, 
    {header: 'Effective Date', field: 'effectiveDate',displayFilter: false,cell: (element: any) => `${element.name}`,placeHolder:'Effective Date'}, 
    {header: 'Edited By', field: 'editedBy',displayFilter: false,cell: (element: any) => `${element.name}`,placeHolder:'Edited By'}, 
    {header: 'Edited Date', field: 'editedDate',displayFilter: false,cell: (element: any) => `${element.name}`,placeHolder:'Edited Date'},
    {header: 'Edit', field: 'edit'},
  
    ];
    this.columnsProps= this.columnsToDisplay.map((column:any) => {return column.field});
  }

  searchByName = (value:any)=>{
    if(value){
      this.associateObj['name'] = value
    }else{
      if(this.associateObj.hasOwnProperty('name'))
      delete this.associateObj.name
    }
    this.selectedViewPageLimit(this.pagination.limit)
  }

  effectiveDateChanges = (event:any) =>{
    if(event && event['selectedDate']){
      let effectiveObj = {
        "user_group_id": [event['selectedRow']['userGroupId']],
        "active_flag":event['selectedRow']['status']==true?1:0,
        "effective_date": moment.utc(event['selectedDate']).local().format('YYYY-MM-DD'),
        "associateLevel": event['selectedRow']['associateLevel']
      }
      this.httpService.effectiveDateChanges(effectiveObj).subscribe((response:any)=>{
        if(response && response['data']){
          if(response['data']['code']==1){
            this.selectedViewPageLimit(this.pagination.limit)
          }
        }
      },error=>{
        console.log("parent date",error)
        console.log("parent date",[error.message])
        if(error.message === 'Success'){
          console.log("parent")
        }
        else{
          console.log("parent")
          this.showSuccessOrError("Activate the Parent first")
          setTimeout(()=>{
          this.dialog.closeAll();
         },5000)
        }
        this.selectedViewPageLimit(this.pagination.limit)
      })
    }
  }

  redirectEdit = (event: any) => {
    console.log('redirect event', event);
    this.router.navigate([`/${this.tenantType}/associate/edit/${event.userGroupId}`],  { queryParams: { type: this.selectedTab=='dealer'?'dealer':this.selectedTab}})
  }

  prepareDeletionData = (event:any)=>{
    if(event && event.length>0){
      this.isRowsSelected = true
      this.selectedRowsData = event
    }else{
      this.isRowsSelected = false
      this.selectedRowsData = []
    }
  }

  deleteAssociates = () => {
    const dialogRef2 = this.dialog.open(MessageModalComponent, {
      width: '500px',
      height: '215px',
      data: {"type":"message3","selectedRows":this.selectedRowsData,"mode":'associoManagement'},
      disableClose: false,
    });
    dialogRef2.afterClosed().subscribe(result => {
      if(result && result.event !== "Cancel"){
        let list = this.selectedRowsData.map((a:any) => {return parseInt(a.userGroupId)});
        let message="";
        if(list.length>0){
          let deleteOrDeactivateObj:any ={} 
          if(result && result['type']=='deactivate'){
            deleteOrDeactivateObj['effective_date']= result['value'];
            deleteOrDeactivateObj['active_flag']=0;
            deleteOrDeactivateObj['user_group_id']=list
            message = "Successfully Deactivated"
          }else{
            deleteOrDeactivateObj['delete_flag']=1;
            deleteOrDeactivateObj['user_group_id']=list
            message = "Successfully Deleted"
          }
          this.httpService.effectiveDateChanges(deleteOrDeactivateObj).subscribe((response:any)=>{
            if(response && response['data']){
              if(response['data']['code']==1){
                this.selectedViewPageLimit(this.pagination.limit);
                this.showSuccessOrError(message)
              }
            }
          },error=>{
            if(error && error['error']['message']){
              let message = error['error']['message']
              this.showSuccessOrError(message)
            }
            this.selectedViewPageLimit(this.pagination.limit)
          })
        }
      }
     
  
    })
  }

  showSuccessOrError = (message:any) =>{
    if(message){
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: {"type":message},
        disableClose: true,
      });
    }
   
  }


  filterColumnwiseData = (values:any)=>{
    let isValueExists=0
    if(values 
      && values['group_id']){
      this.associateObj['group_id']= values['group_id']
      isValueExists=1
    } else if((values['group_id']=='' || values['group_id']=="" || values['group_id']==null)  && this.associateObj.hasOwnProperty('group_id')){
      delete this.associateObj.group_id
      isValueExists=1
    }

    if(values && values['gp_id']){
      this.associateObj['gp_id']= values['gp_id']
      isValueExists=1
    } else if((values['gp_id']=='' || values['gp_id']=="" || values['gp_id']==null)  && this.associateObj.hasOwnProperty('gp_id')){
      delete this.associateObj.gp_id
      isValueExists=1
    }
  
    if(values && values['editedBy']){
      this.associateObj['updated_by']= values['editedBy']
      isValueExists=1
    } else if((values['editedBy']=='' || values['editedBy']=="" || values['editedBy']==null) && this.associateObj.hasOwnProperty('updated_by')){
      delete this.associateObj.updated_by
      isValueExists=1
    }
    if(isValueExists==1){
      this.selectedViewPageLimit(this.pagination.limit)

    }
  }

  appendTimeStamp =()=>{
    return 'T00:00:00.000Z'
  }

  appendEndTimeStamp = () =>{
    return 'T23:59:59.999Z'
  }
  navigateToHome = () =>{
    this.router.navigate([`/${this.tenantType}/home`])

  }
  sortByColumnName = (data:any) =>{
    console.log("DataSource",this.dataSource);
    this.sort = this.dataSource.sort;
    // this.dataSource = new MatTableDataSource([])
    if(data['direction']){
      if(this.associateObj['sorting'] && this.associateObj['sorting'].length > 0){
        const isFound = this.associateObj['sorting'].find((row:any) => row['orderBy'] === data['active']);
        if(isFound){
          this.associateObj['sorting'] = this.associateObj['sorting'].map((row:any)=>{
            if(row['orderBy'] === data['active']){
              row['orderType'] = data['direction']
            }
            return row;
          })
        }
        else{
          this.associateObj['sorting'] = [{orderBy:data['active'],orderType:data['direction']}]
        } 
      }else{
        this.associateObj['sorting'] = [{orderBy:data['active'],orderType:data['direction']}]
        
      }
    }else{
      if(this.associateObj.hasOwnProperty('sorting')){
        delete this.associateObj['sorting']
      }
    }
    this.getAssociateData();
  }
}




