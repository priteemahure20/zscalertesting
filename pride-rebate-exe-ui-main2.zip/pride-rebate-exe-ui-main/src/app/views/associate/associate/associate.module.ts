import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssociateLibraryComponent } from '../associate-library/associate-library.component';
import { AssociateCreateComponent } from '../associate-create/associate-create.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CommonCompsModule } from 'src/app/shared/common-comps.module';
import { ModelInputFieldComponent } from 'src/app/common/model-input-field/model-input-field.component';
import {AssociateSupplierComponent} from '../associate-supplier/associate-supplier.component';
import { AssociateDistributorComponent } from '../associate-distributor/associate-distributor.component';
import { HierarchicalTableComponent } from 'src/app/common/hierarchical-table/hierarchical-table.component';
import { PaginatorDirective } from 'src/app/common/pagination/pagination.directive';
import { SubmitButtonComponent } from 'src/app/common/submit-button/submit-button.component';
import { Pagination } from 'src/app/common/pagination/pagination.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { AssociateOrgViewComponent } from '../associate-org-view/associate-org-view.component';
import { NgxOrgChartModule } from 'flairstech-org-chart';
import { AssociateUserManagementComponent } from '../associate-user-management/associate-user-management.component';
import { AssociateUserCreateComponent } from '../associate-user-create/associate-user-create.component';





@NgModule({
  declarations: [
    AssociateOrgViewComponent,
    AssociateUserManagementComponent,
    AssociateUserCreateComponent,
    AssociateCreateComponent,
    AssociateSupplierComponent,
    AssociateDistributorComponent,
    AssociateLibraryComponent,

  ],
  imports: [
    CommonModule,
    SharedModule,
    CommonCompsModule,
    NgSelectModule,
    MatDatepickerModule,
    NgxOrgChartModule,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class AssociateModule { }
