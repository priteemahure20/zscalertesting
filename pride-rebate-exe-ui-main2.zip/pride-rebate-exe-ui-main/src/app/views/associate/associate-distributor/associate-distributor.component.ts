import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-associate-distributor',
  templateUrl: './associate-distributor.component.html',
  styleUrls: ['./associate-distributor.component.scss']
})
export class AssociateDistributorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
