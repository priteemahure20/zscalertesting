import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { HttpService } from 'src/app/services/http.service';
import { getLastUpdatedDate } from 'src/app/helpers/commonUtils';
import { TitleCasePipe } from '@angular/common';

@Component({
  selector: 'app-missed-opportunity',
  templateUrl: './missed-opportunity.component.html',
  styleUrls: ['./missed-opportunity.component.scss']
})
export class MissedOpportunityComponent implements OnInit {
  missedObject:any={}
  transactionTypes:any=[
    {displayText:"BG Admin Transaction",value:'bgTransaction'},
    {displayText:"Supplier Transaction Data",value:'supplierTransaction'},
    {displayText:"Member Transaction Data",value:'memberTransaction'}
  ]
  basicData:any=[];
  qtrData:any=[];
  mthData:any=[];
  allMissedOppurtunity:any;
  missedTableData:any =[]
  columnsToDisplay :any= [] 
  columnsProps:any;
  supplierDropdown: any = [];
  selectedModeValue:any = 'ytd';
  dataSource: any;
  pageNo:any=1;
  limit:any=15;
  tableTotal:number=0;
  inputYear:any;
  inputMonth:any;
  lastUpdatedDate:any=''
  constructor(private httpService: HttpService,private titlecasePipe:TitleCasePipe) { }

  ngOnInit(): void {
    this.lastUpdatedDate = getLastUpdatedDate()
    let todayDate = new Date();
    this.missedObject = {
      "year": todayDate.getFullYear(),
      "month": todayDate.getMonth()
    }
    // this.missedObject = {
    //   "year": 2020,
    //   "month": 6
    // }
    let selectedMode = localStorage.getItem("mode")
    if(!selectedMode){
      localStorage.setItem("mode",this.selectedModeValue)
    }else{
      this.selectedModeValue = selectedMode
    }
    let month = localStorage.getItem("month")
    if(!month){
      localStorage.setItem("month",todayDate.getMonth().toString())
      this.inputMonth = todayDate.getMonth()
    }else{
      this.inputMonth = parseInt(month)
      this.missedObject['month'] = parseInt(month)
    }
    let year = localStorage.getItem("year")
    if(!year){
      localStorage.setItem("year",todayDate.getFullYear().toString())
      this.inputYear = todayDate.getFullYear()
    }else{
      this.inputYear = parseInt(year)
      this.missedObject['year'] = parseInt(year)
    }
    if(this.missedObject && this.missedObject['month']==0){
      this.missedObject['month'] = 1
      localStorage.setItem("month","1")
    }
    this.getMissedData()
   // this.fillData();
    // this.supplierDropdown = {
    //   supplierDropdown:  [
    //     {displayText:'Coils - Residential',value:'coils'},
    //     {displayText:'Flexible gas connectors',value:'gasConnectors'},
    //     {displayText:'Thermostats',value:'thermostats'}
    //   ]
    // } 
  }
  getMissedData = () =>{
    this.httpService.getMissedOppurtunityDetails(this.missedObject['year'],this.missedObject['month'],this.pageNo,this.limit)
    .subscribe((response:any)=>{
      if(response && response['data']){
        this.allMissedOppurtunity = response['data'];
        this.missedTableData = this.allMissedOppurtunity['unapprovedSupplierVolume']
        this.tableTotal = this.allMissedOppurtunity['unapprovedSupplierVolumeCount']

        this.populateMissedOppurtinities(this.selectedModeValue)
      }
    })
  }
  selectedYear = (value:any)=>{
    if(value){
      this.missedObject['year']=parseInt(value);
      localStorage.setItem("year",value.toString())

    }
    if(Object.values(this.missedObject).length>1){
      this.columnsToDisplay=[]
      this.columnsProps =[]
      this.basicData= [];
      this.pageNo=1
      this.limit=15
      this.dataSource && this.dataSource['data']?this.dataSource['data']=[]:''
      this.getMissedData()
    }
  }
  selectedMonth = (value:any)=>{
    if(value){
      this.missedObject['month']=parseInt(value);
      localStorage.setItem("month",value.toString())

    }
    if(Object.values(this.missedObject).length>1){
      this.columnsToDisplay=[]
      this.columnsProps =[];
      this.basicData= [];
      this.pageNo=1
      this.limit=15
      this.dataSource && this.dataSource['data']?this.dataSource['data']=[]:''
      this.getMissedData()
    }
  }
  selectedMode = (value:any)=>{
    this.selectedModeValue = value
    localStorage.setItem("mode",this.selectedModeValue)
    this.populateMissedOppurtinities(this.selectedModeValue)
  }
  populateMissedOppurtinities = (mode:any) =>{
   
    let obj:any={} 
    if(this.pageNo==1){
      this.columnsToDisplay=[]
      this.columnsProps =[]
    }
    this.basicData =[]
    switch(mode){
      case 'ytd':
        const tableData = [];
        if(this.allMissedOppurtunity){
          obj={
            "totalPurchase":this.allMissedOppurtunity['totalPurchase']['ytdTotalPurchase'],
            "potentialRebate":this.allMissedOppurtunity['potentialRebate']['ytdPotentialRebate'],
            "alternateRebate":this.allMissedOppurtunity['potentialAvailableAlternates']['ytdPotentialAvailableAlternates'],
          }
          this.basicData.push(obj)
          this.populateHeaders();
          for(let i=0;i<this.missedTableData.length;i++){
            let tblObj = {
              category: this.missedTableData[i]['categoryName']?
              this.missedTableData[i]['categoryName']:'NA',
              volume: this.missedTableData[i]['ytdVolume'] && this.missedTableData[i]['ytdVolume']!=0?this.missedTableData[i]['ytdVolume']:0,
              rebateOppurtunity:this.missedTableData[i]['ytdRebateOpportunity'] && this.missedTableData[i]['ytdRebateOpportunity']!=0?
              this.missedTableData[i]['ytdRebateOpportunity']:0,
              vendorPartner1:this.missedTableData[i]['ytdVendorPartner'] && this.missedTableData[i]['ytdVendorPartner'].length>0 ? 
              this.missedTableData[i]['ytdVendorPartner'][0]:'NA',
              vendorPartner2:this.missedTableData[i]['ytdVendorPartner'] && this.missedTableData[i]['ytdVendorPartner'].length>1 ?
              this.missedTableData[i]['ytdVendorPartner'][1]:'NA',
              vendorPartner3:this.missedTableData[i]['ytdVendorPartner'] && this.missedTableData[i]['ytdVendorPartner'].length>2 ?
              this.missedTableData[i]['ytdVendorPartner'][2]:'NA',
              vendorPartner4:this.missedTableData[i]['ytdVendorPartner'] && this.missedTableData[i]['ytdVendorPartner'].length>3 ?
              this.missedTableData[i]['ytdVendorPartner'][3]:'NA',
            }
            tableData.push(tblObj)
            tableData.sort((a:any, b:any) => (a.rebateOppurtunity > b.rebateOppurtunity) ? 1 : (a.rebateOppurtunity === b.rebateOppurtunity) ? ((a.rebateOppurtunity > b.rebateOppurtunity) ? 1 : -1) : -1 )

          }

          this.dataSource = new MatTableDataSource(tableData);
        }
        

        break;
      case 'qtr':
        const tableData2 = [];
        if(this.allMissedOppurtunity){
          obj={
            "totalPurchase":this.allMissedOppurtunity['totalPurchase']['qtrTotalPurchase'],
            "potentialRebate":this.allMissedOppurtunity['potentialRebate']['qtrPotentialRebate'],
            "alternateRebate":this.allMissedOppurtunity['potentialAvailableAlternates']['qtrPotentialAvailableAlternates'],
          }
          this.basicData.push(obj)
          this.populateHeaders();
          for(let i=0;i<this.missedTableData.length;i++){
            let tblObj = {
              category: this.missedTableData[i]['categoryName']?
              this.missedTableData[i]['categoryName']:'NA',
              volume: this.missedTableData[i]['qtrVolume'] && this.missedTableData[i]['qtrVolume']!=0?this.missedTableData[i]['qtrVolume']:0,
              rebateOppurtunity:this.missedTableData[i]['qtrRebateOpportunity'] && this.missedTableData[i]['qtrRebateOpportunity']!=0
              ?this.missedTableData[i]['qtrRebateOpportunity']:0,
              vendorPartner1:this.missedTableData[i]['qtrVendorPartner'] &&
              this.missedTableData[i]['qtrVendorPartner'].length>0?
              this.missedTableData[i]['qtrVendorPartner'][0]:'NA',
              vendorPartner2:this.missedTableData[i]['qtrVendorPartner'] &&
              this.missedTableData[i]['qtrVendorPartner'].length>1?
              this.missedTableData[i]['qtrVendorPartner'][1]:'NA',
              vendorPartner3:this.missedTableData[i]['qtrVendorPartner'] &&
              this.missedTableData[i]['qtrVendorPartner'].length>2?
              this.missedTableData[i]['qtrVendorPartner'][2]:'NA',
              vendorPartner4:this.missedTableData[i]['qtrVendorPartner'] &&
              this.missedTableData[i]['qtrVendorPartner'].length>3?
              this.missedTableData[i]['qtrVendorPartner'][3]:'NA',
            }
            tableData2.push(tblObj)
            tableData2.sort((a:any, b:any) => (a.rebateOppurtunity > b.rebateOppurtunity) ? 1 : (a.rebateOppurtunity === b.rebateOppurtunity) ? ((a.rebateOppurtunity > b.rebateOppurtunity) ? 1 : -1) : -1 )

          }
          this.dataSource = new MatTableDataSource(tableData2);
        }
         
        break;
      case 'mth':
        const tableData3:any = [];

        if(this.allMissedOppurtunity){
          obj={
            "totalPurchase":this.allMissedOppurtunity['totalPurchase']['mthTotalPurchase'],
            "potentialRebate":this.allMissedOppurtunity['potentialRebate']['mthPotentialRebate'],
            "alternateRebate":this.allMissedOppurtunity['potentialAvailableAlternates']['ytdPotentialAvailableAlternates'],
          }
          this.basicData.push(obj);
          this.populateHeaders();

          for(let i=0;i<this.missedTableData.length;i++){
            let tblObj = {
              category: this.missedTableData[i]['categoryName']?
              this.missedTableData[i]['categoryName']:'NA',
              volume: this.missedTableData[i]['mthVolume'] && this.missedTableData[i]['mthVolume'] !=0?this.missedTableData[i]['mthVolume']:0,
              rebateOppurtunity:this.missedTableData[i]['mthRebateOpportunity'] && this.missedTableData[i]['mthRebateOpportunity']!=0
              ?this.missedTableData[i]['mthRebateOpportunity']:0,
              vendorPartner1:this.missedTableData[i]['mthVendorPartner'] &&
              this.missedTableData[i]['mthVendorPartner'].length>0?
              this.missedTableData[i]['mthVendorPartner'][0]:'NA',
              vendorPartner2:this.missedTableData[i]['mthVendorPartner'] &&
              this.missedTableData[i]['mthVendorPartner'].length>1?
              this.missedTableData[i]['mthVendorPartner'][1]:'NA',
              vendorPartner3:this.missedTableData[i]['mthVendorPartner'] &&
              this.missedTableData[i]['mthVendorPartner'].length>2?
              this.missedTableData[i]['mthVendorPartner'][2]:'NA',
              vendorPartner4:this.missedTableData[i]['mthVendorPartner'] &&
              this.missedTableData[i]['mthVendorPartner'].length>3?
              this.missedTableData[i]['mthVendorPartner'][3]:'NA',
            }
            tableData3.push(tblObj)
            tableData3.sort((a:any, b:any) => (a.rebateOppurtunity > b.rebateOppurtunity) ? 1 : (a.rebateOppurtunity === b.rebateOppurtunity) ? ((a.rebateOppurtunity > b.rebateOppurtunity) ? 1 : -1) : -1 )

          }
          this.dataSource = new MatTableDataSource(tableData3);
        }

        break;
    }

  }

  populateHeaders = ()=>{
    this.columnsToDisplay=[
      {header: 'CATEGORY', field: 'category', displayFilter: false,cell: (element: any) => `${element.name}`}, 
      {header: 'VOLUME', field: 'volume',displayFilter: false,cell: (element: any) => `${element.name}`}, 
      {header: 'REBATE OPPORTUNITY', field: 'rebateOppurtunity',displayFilter: false,cell: (element: any) => `${element.name}`}, 
      {header: 'VENDOR PARTNER 1', field: 'vendorPartner1',displayFilter: false,cell: (element: any) => `${element.name}`}, 
      {header: 'VENDOR PARTNER 2', field: 'vendorPartner2',displayFilter: false,cell: (element: any) => `${element.name}`}, 
      {header: 'VENDOR PARTNER 3', field: 'vendorPartner3',displayFilter: false,cell: (element: any) => `${element.name}`}, 
      {header: 'VENDOR PARTNER 4', field: 'vendorPartner4',displayFilter: false,cell: (element: any) => `${element.name}`}, 
  
    ];
    this.columnsProps= this.columnsToDisplay.map((column:any) => {return column.field});
  }
  getNextPage = (data:any) =>{
    this.pageNo=parseInt(data['pageIndex'])+1
    this.limit= data['pageSize']
    this.getMissedData()
  }

  fixedDecimalValue = (data:any) =>{
    if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      }else{
        return data
      }
      
    }
  }

}
