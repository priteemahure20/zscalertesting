import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { AuthGuardService as AuthGuard } from '../../services/auth-guard.service';
import { SummaryComponent } from './summary/summary.component';
import { IngroupPurchaseComponent } from './ingroup-purchase/ingroup-purchase.component';
import { IngroupSummaryComponent } from './ingroup-summary/ingroup-summary.component';
import { RebateSummaryComponent } from './rebate-summary/rebate-summary.component';
import { DetailsComponent } from './details/details.component';
import { MissedOpportunityComponent } from './missed-opportunity/missed-opportunity.component';
import { FeedbackComponent } from './feedback/feedback.component';

const routes: Routes = [
  { path: '', component: DashboardComponent,canActivate: [AuthGuard],
  children:[
    {path: '', pathMatch: 'full', redirectTo: ':type/dashboard'},
    {path: 'summary', component: SummaryComponent,canActivate: [AuthGuard] },
    {path: 'ingroup', component: IngroupPurchaseComponent,canActivate: [AuthGuard] },
    {path: 'category', component: IngroupSummaryComponent,canActivate: [AuthGuard] },
    {path: 'rebate-summary', component: RebateSummaryComponent,canActivate: [AuthGuard] },
    {path: 'details', component: DetailsComponent,canActivate: [AuthGuard] },
    {path: 'missed-oppurtunity', component: MissedOpportunityComponent,canActivate: [AuthGuard] },
    {path: 'feedback', component: FeedbackComponent,canActivate: [AuthGuard] },

  ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
