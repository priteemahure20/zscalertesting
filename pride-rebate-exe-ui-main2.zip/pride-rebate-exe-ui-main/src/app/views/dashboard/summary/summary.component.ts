import { Component, OnInit } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { values } from 'lodash';
import { HttpService } from 'src/app/services/http.service';
import { INDICATION } from 'src/app/helpers/constants';
import { Router } from '@angular/router';
import { getLastUpdatedDate } from 'src/app/helpers/commonUtils';
import * as  moment from 'moment';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {
  year:any;
  month:any;
  mode:any;
  transaction:any;
  summaryObject:any={};
  memberTransData:any = []
  bgAdminTransData:any = [];
  supplierTransData:any = [];
  populatePieChart:any = [];
  populateBubbleChart1:any = [];
  populateBubbleChart2:any = [];
  bubbleChartObj1:any={};
  bubbleChartObj2:any={}
  selectedTransactionValue:any ='memberTransaction';
  selectedModeValue:any = 'ytd';
  memberPerformData:any = [];
  supplierPerformData:any = [];
  bgAdminPerformData:any = [];
  performanceData:any = []
  transactionTypes:any=[
    {displayText:"BG Admin Transaction",value:'bgTransaction'},
    {displayText:"Supplier Transaction Data",value:'supplierTransaction'},
    {displayText:"Member Transaction Data",value:'memberTransaction'}
  ]
  inputMonth:any;
  inputYear:any;
  tenantType:any;
  lastUpdatedDate:any='';
  isFilterDataLoaded = false
  constructor(private httpService: HttpService,private matIconRegistry: MatIconRegistry,private domSanitizer: DomSanitizer,
    private router: Router) {
    this.matIconRegistry.addSvgIcon("up-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/up_arrow_icon.svg"))
    this.matIconRegistry.addSvgIcon("down-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/down_icon.svg"))

   }

  ngOnInit(): void {
  
    this.tenantType =localStorage.getItem('tenant')

    let todayDate = new Date();
    // this.summaryObject = {
    //   "year": todayDate.getFullYear(),
    //   "month": todayDate.getMonth()+1
    // }
    let transactionValue = localStorage.getItem("transaction")
    if(!transactionValue){
      localStorage.setItem("transaction",this.selectedTransactionValue)
    }else{
      this.selectedTransactionValue = transactionValue
    }
    let selectedMode = localStorage.getItem("mode")
    if(!selectedMode){
      localStorage.setItem("mode",this.selectedModeValue)
    }else{
      this.selectedModeValue = selectedMode
    }
    let month = localStorage.getItem("month")
    if(month){
      this.inputMonth = parseInt(month)
      this.summaryObject['month'] = parseInt(month)
    }
    let year = localStorage.getItem("year")
    if(year){
      this.inputYear = parseInt(year)
      this.summaryObject['year'] = parseInt(year)
    }
    if(this.summaryObject && this.summaryObject['month']==0){
      this.summaryObject['month'] = 1
      localStorage.setItem("month","1")
    }
    
      this.httpService.getLastUpdatedDate().subscribe((response:any)=>{
        if(response && response['data']){
          let lastUpdate = moment(response['data'],"YYYYMMDD");
          this.lastUpdatedDate =  lastUpdate.format('MM/DD/YYYY')
        }else{
          this.lastUpdatedDate = 'NA'
        }
      })
    
    if(!localStorage.getItem("year")){
      this.httpService.getYearsData().subscribe((response:any)=>{
        if(response && response['data']){
          this.summaryObject['year'] =response['data']['defaultYear'];
          this.inputYear = response['data']['defaultYear']
          this.summaryObject['month'] = response['data']['defaultMonth'];
          this.inputMonth =  response['data']['defaultMonth']
          localStorage.setItem("year",response['data']['defaultYear'].toString())
          localStorage.setItem("month",response['data']['defaultMonth'].toString())
          localStorage.setItem("minYear",response['data']['minYear'].toString())
          this.isFilterDataLoaded = true;
          this.httpService.getDashboardSummary(this.summaryObject).subscribe((response:any)=>{
            if(response && response['data'] && Object.keys(response['data']).length>0){
              let isSummaryDatapopulated = this.populateRebateSummary(response['data']['rebateSummary']);
              let isPerformanceData = this.populateRebatePerformance(response['data']['rebatePerformance'])  
              if(isSummaryDatapopulated && isPerformanceData){
                
                this.poplateChartSummary(this.selectedTransactionValue,this.selectedModeValue);
                this.populatePerformance(this.selectedTransactionValue,this.selectedModeValue)
              }
      
            }
          })
        }
      })
    }else{
      this.isFilterDataLoaded = true;
      this.httpService.getDashboardSummary(this.summaryObject).subscribe((response:any)=>{
        if(response && response['data'] && Object.keys(response['data']).length>0){
          let isSummaryDatapopulated = this.populateRebateSummary(response['data']['rebateSummary']);
          let isPerformanceData = this.populateRebatePerformance(response['data']['rebatePerformance'])  
          this.inputYear = localStorage.getItem("year")
          this.inputMonth = localStorage.getItem("month")
          if(isSummaryDatapopulated && isPerformanceData){
            
            this.poplateChartSummary(this.selectedTransactionValue,this.selectedModeValue);
            this.populatePerformance(this.selectedTransactionValue,this.selectedModeValue)
          }
  
        }
      })
    }
  
   
  }
  selectedYear = (value:any) =>{
    if(value){
      this.summaryObject['year']=value;
      localStorage.setItem("year",value.toString())
    }
    if(Object.values(this.summaryObject).length>1){
      this.performanceData = []
      this.memberTransData = []
      this.bgAdminTransData = [];
      this.supplierTransData = [];
      this.populatePieChart= [];
      this.populateBubbleChart1= [];
      this.populateBubbleChart2 = [];
      this.bubbleChartObj1={};
      this.bubbleChartObj2={};
      this.supplierPerformData =[];
      this.memberPerformData = [];
      this.bgAdminPerformData =[]
      this.httpService.getDashboardSummary(this.summaryObject).subscribe((response:any)=>{
        if(response && response['data'] && Object.keys(response['data']).length>0){
          let isDatapopulated = this.populateRebateSummary(response['data']['rebateSummary']);
          let isPerformanceData = this.populateRebatePerformance(response['data']['rebatePerformance'])  
          if(isDatapopulated && isPerformanceData){ 
             this.poplateChartSummary(this.selectedTransactionValue,this.selectedModeValue);
            this.populatePerformance(this.selectedTransactionValue,this.selectedModeValue)
          }
        }
      })
    }
  }
  selectedMonth = (value:any) =>{
    if(value){
      this.summaryObject['month']=value
      localStorage.setItem("month",value.toString())
    }
    if(Object.values(this.summaryObject).length>1){
      this.memberTransData = []
      this.bgAdminTransData = [];
      this.supplierTransData = [];
      this.populatePieChart= [];
      this.populateBubbleChart1= [];
      this.populateBubbleChart2 = [];
      this.bubbleChartObj1={};
      this.bubbleChartObj2={};
      this.performanceData = []
      this.supplierPerformData =[];
      this.memberPerformData = [];
      this.bgAdminPerformData =[]
    
      this.httpService.getDashboardSummary(this.summaryObject).subscribe((response:any)=>{
        if(response && response['data'] && Object.keys(response['data']).length>0){
          let isDatapopulated = this.populateRebateSummary(response['data']['rebateSummary']);
          let isPerformanceData = this.populateRebatePerformance(response['data']['rebatePerformance'])  

          if(isDatapopulated && isPerformanceData){
            this.poplateChartSummary(this.selectedTransactionValue,this.selectedModeValue);
            this.populatePerformance(this.selectedTransactionValue,this.selectedModeValue)
          }
        }
      })
    }
  }
  selectedMode = (value:any) =>{
    this.selectedModeValue = value
    localStorage.setItem("mode",this.selectedModeValue)
    this.poplateChartSummary(this.selectedTransactionValue,this.selectedModeValue);
    this.populatePerformance(this.selectedTransactionValue,this.selectedModeValue);
  }
  selectedTransaction = (value:any) =>{
    this.selectedTransactionValue = value
    localStorage.setItem("transaction",this.selectedTransactionValue)
    this.poplateChartSummary(this.selectedTransactionValue,this.selectedModeValue);
    this.populatePerformance(this.selectedTransactionValue,this.selectedModeValue);

  }

  populateRebateSummary = (data:any) =>{
    for(let i=0;i<data.length;i++){
      if(data[i]['data_provider']==2){
        this.memberTransData.push(data[i])
      }else if(data[i]['data_provider']==1){
        this.supplierTransData.push(data[i])
      }else{
        this.bgAdminTransData.push(data[i])
      }
    }
    return true;
  }

  populateRebatePerformance = (data:any) =>{
    this.performanceData = []
    for(let i=0;i<data.length;i++){
      if(data[i]['data_provider']==2){
        this.memberPerformData.push(data[i])
      }else if(data[i]['data_provider']==1){
        this.supplierPerformData.push(data[i])
      }else{
        this.bgAdminPerformData.push(data[i])
      }
    }
    return true;
  }

  poplateChartSummary = (drpValue:string,mode:string) =>{
    switch(drpValue) {
      case 'bgTransaction':
        this.populatePieChart =[];
        this.bubbleChartObj1={};
        this.bubbleChartObj2={}
        if(mode=='ytd' && this.bgAdminTransData.length>0){
          

          setTimeout(()=>{
            this.bubbleChartObj1={};
            this.bubbleChartObj2={}
            for(let i=0;i<this.bgAdminTransData.length;i++){
              let pieObject:any= {} 
              if(this.bgAdminTransData[i]['in_out_supplier']==0){
                this.populatePieChart =[];
                pieObject['name'] = 'Inside Group';
                pieObject['value'] = 100;
                pieObject['color'] = '#FBA504';
                this.populatePieChart.push(pieObject)
                this.bubbleChartObj1['children'] =  this.bgAdminTransData[i]['ytd_top_categories'] && 
                this.bgAdminTransData[i]['ytd_top_categories']['data']?
                this.populateCategories(this.bgAdminTransData[i]['ytd_top_categories']['data']):[];
              }
            }
          })
        } else if(mode=='mth' && this.bgAdminTransData.length>0){
          this.populatePieChart =[];
          setTimeout(()=>{
            for(let i=0;i<this.bgAdminTransData.length;i++){
              let pieObject:any= {} 
              if(this.bgAdminTransData[i]['in_out_supplier']==0){
                this.populatePieChart =[];
                pieObject['name'] = 'Inside Group';
                pieObject['value'] = 100;
                pieObject['color'] = '#FBA504';
                this.populatePieChart.push(pieObject)
                this.bubbleChartObj1['children'] = this.bgAdminTransData[i]['mtd_top_categories'] && 
                this.bgAdminTransData[i]['mtd_top_categories']['data']?
                this.populateCategories(this.bgAdminTransData[i]['mtd_top_categories']['data']):[];
              }
            }
          })
        } else if(mode=='qtr' && this.bgAdminTransData.length>0){
          this.populatePieChart =[];
          setTimeout(()=>{
            for(let i=0;i<this.bgAdminTransData.length;i++){
              let pieObject:any= {} 
              if(this.bgAdminTransData[i]['in_out_supplier']==0){
                this.populatePieChart =[];
                pieObject['name'] = 'Inside Group';
                pieObject['value'] = 100;
                pieObject['color'] = '#FBA504';
                this.populatePieChart.push(pieObject)
                this.bubbleChartObj1['children'] = this.bgAdminTransData[i]['qtd_top_categories'] && 
                this.bgAdminTransData[i]['qtd_top_categories']['data']
                ?this.populateCategories(this.bgAdminTransData[i]['qtd_top_categories']['data']):[];
              }
            }
          })
        }
        break;
      case 'supplierTransaction':
        this.populatePieChart =[];
        this.bubbleChartObj1={};
        this.bubbleChartObj2={}
        this.populatePieChart.length=0

        if(mode=='ytd' && this.supplierTransData.length>0){

          setTimeout(()=>{

            for(let i=0;i<this.supplierTransData.length;i++){
              let pieObject:any= {} 
              if(this.supplierTransData[i]['in_out_supplier']==0){
                this.populatePieChart =[];
                pieObject['name'] = 'Inside Group';
                pieObject['value'] = 100;
                pieObject['color'] = '#FBA504';
                this.populatePieChart.push(pieObject)
                this.bubbleChartObj1['children'] = 
                this.supplierTransData[i]['ytd_top_categories'] && this.supplierTransData[i]['ytd_top_categories']['data']?
                this.populateCategories(this.supplierTransData[i]['ytd_top_categories']['data']):[];
              }
            }
            console.log('pie--->',this.populatePieChart)

          },10)
        } else if(mode=='mth' && this.supplierTransData.length>0){
          this.populatePieChart =[];

          setTimeout(()=>{
            for(let i=0;i<this.supplierTransData.length;i++){
              let pieObject:any= {} 
              if(this.supplierTransData[i]['in_out_supplier']==0){
                this.populatePieChart =[]
                pieObject['name'] = 'Inside Group';
                pieObject['value'] = 100;
                pieObject['color'] = '#FBA504';
                this.populatePieChart.push(pieObject)
                this.bubbleChartObj1['children'] = this.supplierTransData[i]['mtd_top_categories'] && 
                this.supplierTransData[i]['mtd_top_categories']['data']?this.populateCategories(this.supplierTransData[i]['mtd_top_categories']['data']):[];
              }
            }
            

          },10)
        } else if(mode=='qtr' && this.supplierTransData.length>0){

          setTimeout(()=>{
            for(let i=0;i<this.supplierTransData.length;i++){
              let pieObject:any= {} 
              if(this.supplierTransData[i]['in_out_supplier']==0){
                this.populatePieChart =[];
                pieObject['name'] = 'Inside Group';
                pieObject['value'] = 100;
                pieObject['color'] = '#FBA504';
                this.populatePieChart.push(pieObject)
                this.bubbleChartObj1['children'] = this.supplierTransData[i]['qtd_top_categories']['data']?
                this.populateCategories(this.supplierTransData[i]['qtd_top_categories']['data']):[];
              }
            }

          },10)
        }
        break;
      case 'memberTransaction':
        let outPercent:any =0;
        this.bubbleChartObj1={};
        this.bubbleChartObj2={}
        if(mode=='ytd' && this.memberTransData.length>0){
          this.populatePieChart =[];
          setTimeout(()=>{

            for(let i=0;i<this.memberTransData.length;i++){
              let pieObject:any= {} 
              let inPercent = i<this.memberTransData.length-1?
              this.calculatePercet(this.memberTransData[i]['ytd_total_purchase'],this.memberTransData[i+1]['ytd_total_purchase']):0
              if(this.memberTransData[i]['in_out_supplier']==0){
                this.populatePieChart =[];
                pieObject['name'] = 'Inside Group';
                pieObject['value'] = inPercent['inside'];
                pieObject['color'] = '#FBA504';
                outPercent = inPercent;
                if(inPercent['inside']>0){
                  this.populatePieChart.push(pieObject)
                }
                this.bubbleChartObj1['children'] = 
                this.memberTransData[i]['ytd_top_categories']['data']?this.populateCategories(this.memberTransData[i]['ytd_top_categories']['data']):[];
              }else if(this.memberTransData[i]['in_out_supplier']==1){
                pieObject['name'] = 'Outside Group';
                pieObject['value'] = outPercent['outside']
                pieObject['color'] = '#0159FE';
                this.populatePieChart.push(pieObject)
                this.bubbleChartObj2['children'] = 
                this.memberTransData[i]['ytd_top_categories']['data']?
                this.populateCategories(this.memberTransData[i]['ytd_top_categories']['data']):[];
              }
            }
          },10)
         
        }else  if(mode=='mth' && this.memberTransData.length>0){

          let outPercent:any =0;
          this.populatePieChart =[];
          setTimeout(() => {

            for(let i=0;i<this.memberTransData.length;i++){
              let pieObject:any= {} 
              let inPercent = i<this.memberTransData.length-1?
              this.calculatePercet(this.memberTransData[i]['mtd_total_purchase'],this.memberTransData[i+1]['mtd_total_purchase']):0
              if(this.memberTransData[i]['in_out_supplier']==0){
                this.populatePieChart =[];
                pieObject['name'] = 'Inside Group';
                pieObject['value'] = inPercent['inside']
                pieObject['color'] = '#FBA504';
                outPercent = inPercent;
                if(inPercent['inside']>0){
                  this.populatePieChart.push(pieObject)
                }
                this.bubbleChartObj1['children'] = this.memberTransData[i]['mtd_top_categories'] && 
                this.memberTransData[i]['mtd_top_categories']['data']?
                this.populateCategories(this.memberTransData[i]['mtd_top_categories']['data']):[];
              }else if(this.memberTransData[i]['in_out_supplier']==1){
                pieObject['name'] = 'Outside Group';
                pieObject['value'] =outPercent['outside']
                pieObject['color'] = '#0159FE';
                this.populatePieChart.push(pieObject)
                this.bubbleChartObj2['children'] =  this.memberTransData[i]['mtd_top_categories'] &&
                this.memberTransData[i]['mtd_top_categories']['data']?
                this.populateCategories(this.memberTransData[i]['mtd_top_categories']['data']):[];
              }
            }

          },10);
        
        } else if(mode=='qtr' && this.memberTransData.length>0){

          let outPercent:any =0
          this.populatePieChart =[];

         setTimeout(() => {

          for(let i=0;i<this.memberTransData.length;i++){
            let pieObject:any= {} 
            let inPercent = i<this.memberTransData.length-1?
            this.calculatePercet(this.memberTransData[i]['qtd_total_purchase'],this.memberTransData[i+1]['qtd_total_purchase']):0
            if(this.memberTransData[i]['in_out_supplier']==0){
              this.populatePieChart =[];
              pieObject['name'] = 'Inside Group';
              pieObject['value'] = inPercent['inside']
              pieObject['color'] = '#FBA504';
              outPercent = inPercent;
              if(inPercent['inside']>0){
                this.populatePieChart.push(pieObject)
              }
              this.bubbleChartObj1['children'] = this.memberTransData[i]['qtd_top_categories'] &&
              this.memberTransData[i]['qtd_top_categories']['data']?
              this.populateCategories(this.memberTransData[i]['qtd_top_categories']['data']):[];
            }else if(this.memberTransData[i]['in_out_supplier']==1){
              pieObject['name'] = 'Outside Group';
              pieObject['value'] = outPercent['outside']
              pieObject['color'] = '#0159FE';
              this.populatePieChart.push(pieObject)
              this.bubbleChartObj2['children'] = this.memberTransData[i]['qtd_top_categories'] &&
              this.memberTransData[i]['qtd_top_categories']['data']?this.populateCategories(this.memberTransData[i]['qtd_top_categories']['data']):[];
            }
          }

         },10);
        }
        break
    }

  }


  populatePerformance =(drpValue:string,mode:string) =>{

    this.performanceData = []
    switch(drpValue) {
      case 'bgTransaction':
    
        if(mode=='ytd' && this.bgAdminPerformData.length>0){
          setTimeout(()=>{

            for(let i=0;i<this.bgAdminPerformData.length;i++){
              if(this.bgAdminPerformData[i]['in_out_supplier']==0){
                this.performanceData = []

                let missedObject:any ={
                  "title":"Performance across Rebate Programs",
                  "data":this.bgAdminPerformData[i]['ytd_rebate_program_performance']?this.populatePerormanceData(this.bgAdminPerformData[i]['ytd_rebate_program_performance']['data']):[]
                };
                this.performanceData.push(missedObject)
              }
            }
          })
         
        }else if(mode=='mth' && this.bgAdminPerformData.length>0){
          setTimeout(()=>{

            for(let i=0;i<this.bgAdminPerformData.length;i++){

              if(this.bgAdminPerformData[i]['in_out_supplier']==0){
                this.performanceData = []

                let missedObject:any ={
                  "title":"Performance across Rebate Programs",
                  "data": this.bgAdminPerformData[i]['mtd_rebate_program_performance']?this.populatePerormanceData(this.bgAdminPerformData[i]['mtd_rebate_program_performance']['data']):[]
                };
                this.performanceData.push(missedObject)
              }
            }
          })
        }else if(mode=='qtr' && this.bgAdminPerformData.length>0){
          setTimeout(()=>{

            for(let i=0;i<this.bgAdminPerformData.length;i++){
              if(this.bgAdminPerformData[i]['in_out_supplier']==0){
                this.performanceData = []

                let missedObject:any ={
                  "title":"Performance across Rebate Programs",
                  "data": this.bgAdminPerformData[i]['qtd_rebate_program_performance']?this.populatePerormanceData(this.bgAdminPerformData[i]['qtd_rebate_program_performance']['data']):[]
                };
                this.performanceData.push(missedObject)
              }
            }
          })
        }
      break;
      case 'supplierTransaction':
        this.performanceData = []
        if(mode=='ytd' && this.supplierPerformData.length>0){
          setTimeout(()=>{

            for(let i=0;i<this.supplierPerformData.length;i++){
              if(this.supplierPerformData[i]['in_out_supplier']==0){
               

                let missedObject:any ={
                  "title":"Performance across Rebate Programs",
                  "data": this.supplierPerformData[i]['ytd_rebate_program_performance']?this.populatePerormanceData(this.supplierPerformData[i]['ytd_rebate_program_performance']['data']):[]
                };
                this.performanceData.push(missedObject)
              }
            }
          })
         
        }else if(mode=='mth' && this.supplierPerformData.length>0){
          setTimeout(()=>{

            for(let i=0;i<this.supplierPerformData.length;i++){
              if(this.supplierPerformData[i]['in_out_supplier']==0){
                this.performanceData = []

                let missedObject:any ={
                  "title":"Performance across Rebate Programs",
                  "data": this.supplierPerformData[i]['mtd_rebate_program_performance']?this.populatePerormanceData(this.supplierPerformData[i]['mtd_rebate_program_performance']['data']):[]
                };
                this.performanceData.push(missedObject)
              }
            }
          })
        }else if(mode=='qtr' && this.supplierPerformData.length>0){
          setTimeout(()=>{
            for(let i=0;i<this.supplierPerformData.length;i++){
              if(this.supplierPerformData[i]['in_out_supplier']==0){
                this.performanceData = []

                let missedObject:any ={
                  "title":"Performance across Rebate Programs",
                  "data": this.supplierPerformData[i]['qtd_rebate_program_performance']?this.populatePerormanceData(this.supplierPerformData[i]['qtd_rebate_program_performance']['data']):[]
                };
                this.performanceData.push(missedObject)
              }
            }
          })
        }
      break;
      case 'memberTransaction':
        if(mode=='ytd' && this.memberPerformData.length>0){
          setTimeout(()=>{
            for(let i=0;i<this.memberPerformData.length;i++){
              if(this.memberPerformData[i]['in_out_supplier']==1){
                this.performanceData = []

                let missedObject:any ={
                  "title":"Categories with Max. Missed Opportunity",
                  "data":this.memberPerformData[i]['ytd_max_missed_oppotunity'] && this.memberPerformData[i]['ytd_max_missed_oppotunity']['data']?this.missedPopulatePerormanceData(this.memberPerformData[i]['ytd_max_missed_oppotunity']['data']):[]
                };
                if(this.memberPerformData[i]['ytd_max_missed_oppotunity'] && this.memberPerformData[i]['ytd_max_missed_oppotunity']['data']){
                  this.performanceData.push(missedObject)
                }
              }
            }
          })
         
        }else if(mode=='mth' && this.memberPerformData.length>0){
          setTimeout(()=>{
            for(let i=0;i<this.memberPerformData.length;i++){
              if(this.memberPerformData[i]['in_out_supplier']==1){
                this.performanceData = []

                let missedObject:any ={
                  "title":"Categories with Max. Missed Opportunity",
                  "data": this.memberPerformData[i]['mtd_max_missed_oppotunity'] && this.memberPerformData[i]['mtd_max_missed_oppotunity']['data']?this.missedPopulatePerormanceData(this.memberPerformData[i]['mtd_max_missed_oppotunity']['data']):[]
                };
                if(this.memberPerformData[i]['mtd_max_missed_oppotunity'] && this.memberPerformData[i]['mtd_max_missed_oppotunity']['data']){
                  this.performanceData.push(missedObject)
                }
              }
            }
          })
        }else if(mode=='qtr' && this.memberPerformData.length>0){
          setTimeout(()=>{
            for(let i=0;i<this.memberPerformData.length;i++){
              if(this.memberPerformData[i]['in_out_supplier']==1){
                this.performanceData = []

                let missedObject:any ={
                  "title":"Categories with Max. Missed Opportunity",
                  "data":this.memberPerformData[i]['qtd_max_missed_oppotunity'] && 
                  this.memberPerformData[i]['qtd_max_missed_oppotunity']['data']?this.missedPopulatePerormanceData(this.memberPerformData[i]['qtd_max_missed_oppotunity']['data']):[]
                };
                if(this.memberPerformData[i]['qtd_max_missed_oppotunity'] && 
                this.memberPerformData[i]['qtd_max_missed_oppotunity']['data']){
                  this.performanceData.push(missedObject)
                }
              }
            }
          })
        }
      break;
    }
  }
  calculatePercet = (value1:number,value2:number) =>{
    let obj:any ={}
    obj['inside'] = (value1/(value1+value2)*100).toFixed(2);
    obj['outside'] = (value2/(value1+value2)*100).toFixed(2);
    return obj;
  }

  populateCategories = (data:any) =>{
    let childArray:any =[]
    for(let i=0;i<data.length;i++){
      let bubObject:any ={}
      bubObject['Name'] = data[i]['Category'].length>10? data[i]['Category'].substring(0, 17) + "...":data[i]['Category']
      bubObject['Count'] = data[i]['purchase']?data[i]['purchase']:0;
      bubObject['fullName']=data[i]['Category']?data[i]['Category']:''
      childArray.push(bubObject)
    }
    //childArray.sort((a:any, b:any) => parseFloat(a.Count) - parseFloat(b.Count));
    return childArray
  }

  missedPopulatePerormanceData = (data:any) =>{
    let performances:any = []
    if(data.length>0){
      for(let i=0;i<data.length;i++){
        let obj:any= {}
        obj['order'] = data[i]['order']?data[i]['order']:0
        obj['name'] = data[i]['Category'].length>10? data[i]['Category'].substring(0, 17) + "...":data[i]['Category']
        obj['fullName'] = data[i]['Category']?data[i]['Category']:''
        obj['value'] = data[i]['Total Purchase']?this.abbreviateNumber(data[i]['Total Purchase']):0;
        obj['actualDeal'] = data[i]['value']?this.abbreviateNumber(data[i]['value']):0;
        obj['totalDeal'] =10;
        obj['percentage'] = data[i]['yoy']? data[i]['yoy'].toFixed(1):0
        performances.push(obj);
      }
      if(performances && performances.length>0){
        performances.sort((a:any, b:any) => (a.order > b.order) ? 1 : (a.order === b.order) ? ((a.order > b.order) ? 1 : -1) : -1 )
      }

      return performances;
    } else{
      return [];
    }
   
  }

  populatePerormanceData = (data:any) =>{
      let performances:any =[]
      for(let i=0;i<data.length;i++){
        let obj:any= {}
        obj['name'] = data[i]['name']?data[i]['name']:''
        obj['value'] = data[i]['Total Purchase']?this.abbreviateNumber(data[i]['Total Purchase']):0;
        obj['actualDeal'] = data[i]['attainment']?data[i]['attainment']:0;
        obj['totalDeal'] =data[i]['out of']?data[i]['out of']:0;
        obj['percentage'] = data[i]['yoy']?data[i]['yoy'].toFixed(1):0
        performances.push(obj);
      }
    return performances;
  }

  getIcon = (value:any) =>{
    if(value>=0){
      return "up-arrow"
    }else{
      return "down-arrow"
    }
  }

  getIndication = (data:any) =>{
    if(data>0){
      return INDICATION['up']
    }else{
      return INDICATION['down']
    }
  }

  outsideGrpSelected = (data:any) =>{
    this.router.navigate([this.tenantType, 'dashboard','missed-oppurtunity'])
  }

  insideGrpSelected = (data:any)=>{
    this.router.navigate([this.tenantType, 'dashboard','category'])
  }
   
  navigationByTransaction = () =>{
    if(this.selectedTransactionValue=='memberTransaction'){
      this.router.navigate([this.tenantType, 'dashboard','missed-oppurtunity'])
    }else{
      this.router.navigate([this.tenantType, 'dashboard','rebate-summary'])
    }
  }

  selectedValueInPie = (value:any) =>{
    if(value){
      if(value['name']=='Inside Group'){
        this.router.navigate([this.tenantType, 'dashboard','ingroup'])
      } else{
        this.router.navigate([this.tenantType, 'dashboard','missed-oppurtunity'])
      }
    }
  }

  abbreviateNumber = (value:any) => {
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore
      
      notation: "compact",
      compactDisplay: "short",
      style: "currency",currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
}
  
}
