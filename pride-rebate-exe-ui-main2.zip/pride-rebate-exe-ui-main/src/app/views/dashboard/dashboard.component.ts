import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  tenantType:any;
  values:any=[]
  constructor(private httpService: HttpService,public router: Router, 
    public activatedRoute: ActivatedRoute,) { }

  ngOnInit(): void {  
    this.tenantType =this.activatedRoute.snapshot.paramMap.get('type')
  }

  
}
