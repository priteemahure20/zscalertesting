import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpService } from 'src/app/services/http.service';
import * as moment from 'moment';
import { of, Subject, Subscription } from 'rxjs';
import { debounceTime, delay, distinctUntilChanged, map, mergeMap } from 'rxjs/operators';
import { getLastUpdatedDate } from 'src/app/helpers/commonUtils';
import { TitleCasePipe } from '@angular/common';
import { MatDatepicker } from '@angular/material/datepicker';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  supplierTypes:any =1;
  tenantType:any;
  range = new FormGroup({
    start: new FormControl(),
    end: new FormControl(),
  });
  columnsToDisplay:any
  dataSource: any;
  columnsProps:any;
  selectedSupplierName:any = '';
  vendorOptions:any = [];
  vendorTypeOptions:any = [];
  selectedVendor:any;
  selectedVendorType:any='none';
  urlSupplierName:any='none'
  purchaseOrderObj:any={
    "limit": 15,
    "pageNo": 1
  };
  invoiceObj:any = {
    "limit": 15,
    "pageNo": 1
  }
  dataType:any=""
  purchasOrderData:any = [];
  poNumberValue:any ='';
  keyUp = new Subject<KeyboardEvent>();
  subscription: any;
  selectedSupplier:any;
  dateRangeForm: any;
  tableTotal:any;
  invoiceTable:any=[];
  lastUpdatedDate:any;
  constructor(public router: Router, public activatedRoute: ActivatedRoute,
    private httpService: HttpService,private formBuilder: FormBuilder,private titlecasePipe:TitleCasePipe) { }

  ngOnInit(): void {
    this.lastUpdatedDate = getLastUpdatedDate()
    this.tenantType = localStorage.getItem('tenant')
    this.activatedRoute.paramMap.subscribe((params:any) => {
      if(params && params['params'] && params['params']['supplierName']){
        this.urlSupplierName = params['params']['supplierName']
        this.selectedSupplierName = params['params']['supplierName'];
        this.selectedVendor = this.selectedSupplierName
      }
    });
    this.dateRangeForm = this.formBuilder.group({
      fromDate: new FormControl('', Validators.required),
      toDate: new FormControl('', Validators.required)
    });
    const queryType = 'invoice'
    this.getPreRequesteData(queryType);
    this.populateInvoiceHeaders()
    this.invoiceDetails();
    this.searchByPoNumber()

  }
  supplierChange = (value:any) =>{
    this.columnsToDisplay = [];
    this.invoiceObj ={};
    this.purchaseOrderObj ={};
    this.selectedVendor = undefined;
    if(this.purchaseOrderObj && this.purchaseOrderObj['supplierName']==""){
      delete this.invoiceObj.supplierName
    }
    if(this.invoiceObj && this.invoiceObj['supplierName']==""){
      delete this.invoiceObj.supplierName
    }
    let queryType = 'invoice';
    if (value === '1') {
      queryType = 'invoice';
    } else {
      queryType = 'purchase';
    }
    this.getPreRequesteData(queryType);
    if(value['value']==2){
     // this.purchaseOrderDetails()
    }else{
      this.populateInvoiceHeaders();
      this.vendorOptions=[];
      this.vendorTypeOptions=[]
     // this.populateInvoiceHeaders();
     // this.invoiceDetails()
    }
    this.clearAll();


  }


  public getPreRequesteData = (queryType: any) =>{
    this.httpService.getSummaryDetailsPreRequeste(queryType).subscribe((response:any)=>{
      if(response && response['data'] && response['data']['supplierDropdown']){
        this.vendorOptions = response['data']['supplierDropdown']
      }
      if(response && response['data'] && response['data']['supplierType']){
        this.vendorTypeOptions = response['data']['supplierType']
      }
    })
  }

  public selectVendorType = (value:any) =>{
    if(this.supplierTypes==2){
      this.purchaseOrderObj['limit']= 15;
      this.purchaseOrderObj['pageNo']= 1;
      this.purchaseOrderObj['supplierType'] = value
    }

    this.purchaseOrderDetails()
  }

  public selectVendor = (value:any) =>{
    if(this.supplierTypes==1){
      this.invoiceObj['limit']= 15;
      this.invoiceObj['pageNo']= 1;
      this.invoiceObj['supplierName'] = value?value['value']:'';
      if(value==undefined && this.invoiceObj && this.invoiceObj['supplierName']==""){
        delete this.invoiceObj.supplierName
        this.selectedSupplierName = ''
      }
      this.populateInvoiceHeaders();
      this.invoiceDetails();
    }
    if(this.supplierTypes==2){
      this.purchaseOrderObj['supplierName'] = value?value['value']:'';
      if(value==undefined && this.purchaseOrderObj && this.purchaseOrderObj['supplierName']==""){
        delete this.purchaseOrderObj.supplierName
        this.selectedSupplierName = ''
      }
      this.purchaseOrderObj['limit']= 15;
      this.purchaseOrderObj['pageNo']= 1;
      this.purchaseOrderDetails()
    }
   
  }
  populateInvoiceHeaders = () =>{
    this.columnsToDisplay = [  
      {header: 'Vendor Name', field: 'vendorName'}, 
      {header: 'Invoice No', field: 'invoiceNo'}, 
      {header: 'Invoice Date', field: 'invoiceDate'}, 
      {header: 'Product', field: 'product'}, 
      {header: 'Quantity', field: 'quantity'}, 
      {header: 'Price/Unit', field: 'price'}, 
      {header: 'Amount', field: 'amount'}
    ];
    this.columnsProps = this.columnsToDisplay.map((column:any)=> column.field);
    if(this.dataSource && this.dataSource.data.length>0){
      this.dataSource.data =[];
    }
  }

  public purchaseOrderDetails = () => {
    if(this.purchaseOrderObj['pageNo']==1){
      this.dataSource && this.dataSource['data']?this.dataSource['data'] = []:'';
      this.dataType='purchaseOrder'
      this.columnsToDisplay = [  
        {header: 'PO Number', field: 'poNumber'}, 
        {header: 'PO Date', field: 'poDate'}, 
        {header: 'Vendor Name', field: 'vendorName'}, 
        {header: 'Supplier Type', field: 'vp'}, 
        {header: 'Product Description', field: 'productDescription'}, 
        {header: 'Amount', field: 'amount'}, 
      ];
      this.columnsProps = this.columnsToDisplay.map((column:any)=> column.field);
    }

    if(this.selectedSupplierName){
      this.purchaseOrderObj['supplierName'] = this.selectedSupplierName
    }
      this.purchasOrderData = []
      this.httpService.getPurchaseOrderDetails(this.purchaseOrderObj).subscribe((response:any)=>{
          if(response && response['data'] &&  response['data']['poData']){
            this.tableTotal =  response['data']['count'];
            let data= response['data']['poData']
            for(let i=0;i<data.length;i++){
              let obj= {
                'poNumber': data[i]['purchase_order_number'],
                'poDate': this.getDate(data[i]['order_date_key']),
                'vendorName':data[i]['vendor_name']?data[i]['vendor_name']:'NA',
                'vp':data[i]['vp_unapproved_supplier']?data[i]['vp_unapproved_supplier']:'NA',
                'productDescription':data[i]['product_description']?data[i]['product_description']:'NA',
                'amount':data[i]['total_amount']?data[i]['total_amount']:0,  
              }
              this.purchasOrderData.push(obj)
            }
           // this.purchasOrderData.sort((a:any, b:any) => (a.poDate < b.poDate) ? 1 : (a.poDate === b.poDate) ? ((a.poDate < b.poDate) ? 1 : -1) : -1 )

          }
          this.dataSource = new MatTableDataSource(this.purchasOrderData);
        })
    
    
  }
  public getDate = (date:any) =>{
    if(date){
      let modifedDate = moment(date,"YYYYMMDD")
      return modifedDate.format('MM/DD/YYYY')
    }else{
      return 'NA'
    }
  }

  public searchByPoNumber = () => {
    this.keyUp.pipe(
      map(event => event),
      debounceTime(1000),
      distinctUntilChanged(),
      mergeMap(search => of(search).pipe(
        delay(500),
      )),
    ).subscribe((res:any) => {
     
      if(this.supplierTypes==2){
        let poNumber = res['target']['value']
        if(poNumber){
          this.purchaseOrderObj['poNumber'] = poNumber;
        }else{
          delete this.purchaseOrderObj.poNumber
        }
        this.purchaseOrderObj['limit']= 15;
        this.purchaseOrderObj['pageNo']= 1;
        this.purchaseOrderDetails();
      }else if(this.supplierTypes==1){
        this.invoiceObj['limit']= 15;
        this.invoiceObj['pageNo']= 1;
        let invoice = res['target']['value']
        if(invoice){
          this.invoiceObj['invoiceNumber'] = parseInt(invoice);
        }else{
          delete this.invoiceObj.invoiceNumber
        }
       
        this.populateInvoiceHeaders();
        this.invoiceDetails()
      }
    });
  } 

  clearAll = () =>{
    this.poNumberValue ='';
    this.selectedSupplierName = '';
    this.range = new FormGroup({
      start: new FormControl(''),
      end: new FormControl(''),
    });
    this.dateRangeForm = this.formBuilder.group({
      fromDate: new FormControl('', Validators.required),
      toDate: new FormControl('', Validators.required)
    });
    if(this.purchaseOrderObj.poNumber){
      delete this.purchaseOrderObj.poNumber
    }
   
    
    this.selectedVendor = undefined;
    this.selectedVendorType = 'none'
    if(this.supplierTypes==2){
      this.purchaseOrderObj= {
        "limit": 15,
        "pageNo": 1
      }
      if(this.purchaseOrderObj.supplierName){
        delete this.purchaseOrderObj.supplierName;
      }
      this.purchaseOrderDetails();
    }
    if(this.supplierTypes==1){
      this.invoiceObj= {
        "limit": 15,
        "pageNo": 1
      }
     
      if(this.invoiceObj.supplierName){
        delete this.invoiceObj.supplierName;
      }
      this.invoiceDetails();
    }
  }

  startChange = (startDate:any,picker: MatDatepicker<any>) =>{
    if(this.supplierTypes==2){
      if(this.range.valid && this.range.value['start']!=null){
        let utc =  moment.utc(this.range.value['start']).local().format('YYYY-MM-DD')
        this.purchaseOrderObj['startDate'] = utc
        this.purchaseOrderObj['limit']= 15;
        this.purchaseOrderObj['pageNo']= 1;
        // this.purchaseOrderDetails();
      } else if(this.range.value['start']==null){
        if(this.purchaseOrderObj['startDate']){
          delete this.purchaseOrderObj.startDate;
          this.purchaseOrderObj['limit']= 15;
          this.purchaseOrderObj['pageNo']= 1;
          // this.purchaseOrderDetails();
        }
      }
     
    }

    if(this.supplierTypes==1){
      if(this.range.valid && this.range.value['start']!=null){
        let utc =  moment.utc(this.range.value['start']).local().format('YYYY-MM-DD')
        this.invoiceObj['startDate'] = utc
        this.invoiceObj['limit']= 15;
        this.invoiceObj['pageNo']= 1;
        // this.populateInvoiceHeaders();
        // this.invoiceDetails();
      } else if(this.range.value['start']==null){
        if(this.invoiceObj['startDate']){
          delete this.invoiceObj.startDate;
          this.invoiceObj['limit']= 15;
        this.invoiceObj['pageNo']= 1;
          // this.populateInvoiceHeaders();
          // this.invoiceDetails();
        }
      }
     
    }
     picker.open();
  }
  endChange = (endDate:any) =>{
    if(this.supplierTypes==2){
      if(this.range.valid && this.range.value['end']!=null){
        let utc =  moment.utc(this.range.value['end']).local().format('YYYY-MM-DD')
        this.purchaseOrderObj['endDate'] =utc
        this.purchaseOrderObj['limit']= 15;
        this.purchaseOrderObj['pageNo']= 1;
        this.purchaseOrderDetails();
      } else if(this.purchaseOrderObj['endDate']==null){
        if(this.purchaseOrderObj['endDate']){
          delete this.purchaseOrderObj.endDate
          this.purchaseOrderObj['limit']= 15;
          this.purchaseOrderObj['pageNo']= 1;
          this.purchaseOrderDetails();
        }
      }
     
    } 
    if(this.supplierTypes==1){
      if(this.range.valid && this.range.value['end']!=null){
        let utc =  moment.utc(this.range.value['end']).local().format('YYYY-MM-DD')
        this.invoiceObj['endDate'] =utc
        this.invoiceObj['limit']= 15;
        this.invoiceObj['pageNo']= 1;
        this.populateInvoiceHeaders();
        this.invoiceDetails();
      } else if(this.invoiceObj['endDate']==null){
        if(this.invoiceObj['endDate']){
          delete this.invoiceObj.endDate;
          this.invoiceObj['limit']= 15;
        this.invoiceObj['pageNo']= 1;
          this.populateInvoiceHeaders();
          this.invoiceDetails();
        }
      }
     
    }
    
  }

  getNextPage = (data:any) =>{
    
    if(this.supplierTypes==1){
      this.invoiceObj['pageNo'] = parseInt(data['pageIndex'])+1
    this.invoiceObj['limit'] = data['pageSize']
     // this.populateInvoiceHeaders();
      this.invoiceDetails()
    } else{
      this.purchaseOrderObj['pageNo']=  parseInt(data['pageIndex'])+1;
      this.purchaseOrderObj['limit']= data['pageSize'];
      this.purchaseOrderDetails();
    }
  }

  invoiceDetails(){
    this.dataType='invoice'
    if(this.selectedSupplierName){
      this.invoiceObj['supplierName'] = this.selectedSupplierName
    }
    const tableData:any = [];
    this.httpService.getInvoiceDetails(this.invoiceObj).subscribe((response:any)=>{
      if(response && response['data']){
        this.tableTotal =  response['data']['count'];
        let invoiceArray = []
        if(response && response['data'] && response['data']['invoiceData']){
          invoiceArray = response['data']['invoiceData'];
          for(let i=0;i<invoiceArray.length;i++){
            let obj = {
              'vendorName': invoiceArray[i]['supplier_name']?
             invoiceArray[i]['supplier_name']:'NA',
              'invoiceNo': invoiceArray[i]['invoice_number']?invoiceArray[i]['invoice_number']:'NA',
              'invoiceDate':this.getDate(invoiceArray[i]['invoice_date_key'])?this.getDate(invoiceArray[i]['invoice_date_key']):'NA',
              'product':invoiceArray[i]['product_description']?
              invoiceArray[i]['product_description']:'NA',
              'quantity':invoiceArray[i]['quantity']?invoiceArray[i]['quantity']:'NA',
              'price':invoiceArray[i]['prive_per_unit_st'] && invoiceArray[i]['prive_per_unit_st']!='Null'?invoiceArray[i]['prive_per_unit_st']:'NA',
              'amount':invoiceArray[i]['total_amount']?`${invoiceArray[i]['total_amount']}`:'NA'
            }
            tableData.push(obj);
          }
         // tableData.sort((a:any, b:any) => (a.invoiceDate < b.invoiceDate) ? 1 : (a.invoiceDate === b.invoiceDate) ? ((a.invoiceDate < b.invoiceDate) ? 1 : -1) : -1 )

           this.dataSource = new MatTableDataSource(tableData);
        }
       
      }
    })
  }
}
