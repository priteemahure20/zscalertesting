import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {
  @Output()
  selectedYearEmit = new EventEmitter();
  @Output()
  selectedMonthEmit = new EventEmitter();
  @Output()
  selectedModeEmit = new EventEmitter();
  @Output()
  selectedTransactionEmit = new EventEmitter();
  @Input()
  dropDownTransactions:any;
  @Input()
  deaultTransaction:any='';
  @Input()
  type:any;
  @Input()
  mode:any;
  @Input()
  inputMonth:any;
  @Input()
  inputYear:any;
  @Input()
  inputMinYear:any;


  public transactionOptions = 1;
  public selectedVal: string = '';
  public transactionTypes:any;
  public allMonths:any= [
    {month:'JAN',value:1},
    {month:'FEB',value:2},
    {month:'MAR',value:3},
    {month:'APR',value:4},
    {month:'MAY',value:5},
    {month:'JUN',value:6},
    {month:'JUL',value:7},
    {month:'AUG',value:8},
    {month:'SEP',value:9},
    {month:'OCT',value:10},
    {month:'NOV',value:11},
    {month:'DEC',value:12},
  ]
  public years:any = []
  selectedTransaction :any
  selectedYear:any;
  selectedMonth:any;
  minYear:any;
  maxYear = new Date().getFullYear();
  maxMonth = new Date().getMonth()==0?1:new Date().getMonth()+1
  public months:any = [];
  apiDefaultYear:any;
  apiDefaultMonth:any;
  isYearsLoaded = 0;
  constructor(private httpService: HttpService) { }

  ngOnInit(): void {
    let defaultYear =  localStorage.getItem("year")
    let defaultMonth = localStorage.getItem("month")
    let min  = localStorage.getItem("minYear")
    if(min){
      this.populateYears
      (min,this.maxYear,defaultYear,defaultMonth)
    }
    let selectedyear = localStorage.getItem("year");
    if(selectedyear && parseInt(selectedyear)==this.maxYear){
      this.populateMonths(this.maxMonth)
    }else{
      this.populateMonths(12)
    }
      // this.httpService.getYearsData().subscribe((response:any)=>{
      //   if(response && response['data']){
      //     this.apiDefaultYear = response['data']['defaultYear'];
      //     this.apiDefaultMonth = response['data']['defaultMonth']
          
      //   }
      // })
    
   
    this.transactionTypes = this.dropDownTransactions;
    this.selectedTransaction =  this.deaultTransaction;
    let todayDate = new Date();
    if(!this.inputYear){
      this.selectedYear = this.apiDefaultYear;
    }else{
      this.selectedYear = this.inputYear;
    }
    //this.selectYear(this.selectedYear)
    // if(!this.inputMonth){
    //   this.selectedMonth = this.apiDefaultMonth;
    // }else{
    //   this.selectedMonth = this.inputMonth;
    // }
    if(!this.mode){
      this.selectedVal = 'ytd'
    }else{
      this.selectedVal = this.mode
    }
    //this.selectedMonth =  todayDate.getMonth() + 1;

    //let month = this.months[]
  }
  onValChange = (value:any) =>{
    this.selectedModeEmit.emit(value)
  }
  selectYear = (value:any) =>{
    this.selectedYearEmit.emit(parseInt(value))
    if(value==this.maxYear){
      this.populateMonths(this.maxMonth)
    }else{
      this.populateMonths(12)
    }
   
  }

  selectMonth = (value:any) =>{
    this.selectedMonthEmit.emit(value)
  }
  selectTransaction = (value:any) =>{
    this.selectedTransactionEmit.emit(this.selectedTransaction)
  }

  populateYears = (minYear:any,maxYear:any,defaultYear:any,defaultMonth:any) =>{
    for(let i=minYear;i<=maxYear;i++){
      let year = {
        year:i,value:parseInt(i)
      } 
      this.years.push(year)
    }
    this.selectedYear = parseInt(defaultYear)
    localStorage.setItem("year",this.selectedYear.toString())
    this.populateMonths(defaultMonth,defaultMonth)
  }

  populateMonths = (defaultMonth:any,maxMonth?:any) =>{
    this.months =[]
    for(let i=0;i<defaultMonth;i++){
      this.months.push(this.allMonths[i])
    }
    if(maxMonth){
      this.selectedMonth = maxMonth
      localStorage.setItem("month",this.selectedMonth.toString())
    }else{
      this.selectedMonth = localStorage.getItem("month")
      localStorage.setItem("month",this.selectedMonth.toString())
    }
   

  }

}
