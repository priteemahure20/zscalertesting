import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { SummaryComponent } from './summary/summary.component';
import { IngroupPurchaseComponent } from './ingroup-purchase/ingroup-purchase.component';
import { IngroupSummaryComponent } from './ingroup-summary/ingroup-summary.component';
import { RebateSummaryComponent } from './rebate-summary/rebate-summary.component';
import { DetailsComponent } from './details/details.component';
import { MissedOpportunityComponent } from './missed-opportunity/missed-opportunity.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { D3PieComponent } from 'src/app/common/d3-pie/d3-pie.component';
import { D3BubbleChartComponent } from 'src/app/common/d3-bubble-chart/d3-bubble-chart.component';
import { D3BubbleChart2Component } from 'src/app/common/d3-bubble-chart2/d3-bubble-chart2.component';
import { CommonCompsModule } from 'src/app/shared/common-comps.module';
import { FilterComponent } from './filter/filter.component';
import { ShortNumberPipe } from 'src/app/pipes/short-number.pipe';
import { NgSelectModule } from '@ng-select/ng-select';


@NgModule({
  declarations: [
    DashboardComponent,
    SummaryComponent,
    IngroupPurchaseComponent,
    IngroupSummaryComponent,
    RebateSummaryComponent,
    DetailsComponent,
    MissedOpportunityComponent,
    FeedbackComponent,
    D3BubbleChartComponent,
    D3BubbleChart2Component,
    FilterComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    DashboardRoutingModule,
    CommonCompsModule,
    NgSelectModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class DashboardModule { }
