import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatIconRegistry } from '@angular/material/icon';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DomSanitizer } from '@angular/platform-browser';
import { isPngJpeg,isValidSize } from 'src/app/helpers/commonUtils';
import { HttpService } from 'src/app/services/http.service';
import { getLastUpdatedDate } from 'src/app/helpers/commonUtils';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss']
})
export class FeedbackComponent implements OnInit {
  showFeatureNameDropdown = false;
  feedbackFormGroup = new FormGroup({
    subject: new FormControl('',[Validators.required]),
    details: new FormControl('',[Validators.required])
  });
  file: any;
  fileName: any;
  isValidFile:boolean=true;
  feedBackObject:any={}
  constructor(private httpService: HttpService, private snackBar: MatSnackBar,
    private matIconRegistry: MatIconRegistry,private domSanitizer: DomSanitizer) { 
      this.matIconRegistry.addSvgIcon("upload",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/upload_icon.svg"))
    }
  resetRequestType:any=true;
  requestTypes:any=[];
  isRequestTypeSelected=false;
  lastUpdatedDate:any;
  ngOnInit(): void {
    this.lastUpdatedDate = getLastUpdatedDate();
    //this.feedBackObject['request_type']='enhancementRequest';
    this.resetTypeOfRequest();
  }

 

  featureNames = [
    {
      text: 'Dashboard',
      value: 'dashboard'
    },
    {
      text: 'Ingroup Purchase',
      value: 'ingroupPurchase'
    },
    {
      text: 'Ingroup Summary by category',
      value: 'ingroupSummaryByCategory'
    },
    {
      text: 'Rebate Summary',
      value: 'rebateSummary'
    },
    {
      text: 'Details',
      value: 'details'
    },
    {
      text: 'Missed Opportunity',
      value: 'missedOpportunity'
    },
    {
      text: 'Feedback',
      value: 'feedback'
    },
    {
      text: 'Rebate Program',
      value: 'rebateProgram'
    },
    {
      text: 'Supplier Classification',
      value: 'supplierClassification'
    },
    {
      text: 'Product categorization',
      value: 'productCategorization'
    },
    {
      text: 'File Management',
      value: 'fileManagement'
    },
    {
      text: 'User Library',
      value: 'userManagement'
    },
    {
      text: 'Help and Support',
      value: 'helpAndSupport'
    },
  ]

  requestTypeChange(value: any) {
    this.isRequestTypeSelected = true
    if(value === 'bugReport') {
      this.showFeatureNameDropdown = true;
      this.feedBackObject['request_type']= 'dashboard';
     
    }else{
      this.showFeatureNameDropdown = false;
      if(this.feedBackObject &&  this.feedBackObject['featureName']){
        delete  this.feedBackObject.featureName
      }
    }
  }

  featureNameChange(value: any) {
    if(value){
      this.feedBackObject['featureName']=value
    }
  }

  feedbackSubmit(value: any) {
    if(this.feedbackFormGroup.value['subject']){
      this.feedBackObject['subject']=this.feedbackFormGroup.value['subject']
    }
    if(this.feedbackFormGroup.value['details']){
      this.feedBackObject['description']=this.feedbackFormGroup.value['details']
    }
    const formData:any = new FormData();

    if(this.feedbackFormGroup.valid){
      formData.append('request_type', this.feedBackObject['request_type']);
      formData.append('subject', this.feedBackObject['subject']);
      formData.append('description', this.feedBackObject['description']);
      if(this.feedBackObject && this.feedBackObject['featureName']){
        formData.append('feature_name', this.feedBackObject['featureName']);
      }
    }
    if(this.file){
      formData.append('file', this.file)
    }
    this.httpService.saveFeedBackData(formData).subscribe((response:any)=>{
      if(response && response['data']['code']==1){
        this.snackBar.open('Feedback submitted successfully', 'Ok', {
          duration: 2000,
        });
        this.feedbackFormGroup.reset();
        this.showFeatureNameDropdown = false;
        if(this.feedBackObject &&  this.feedBackObject['featureName']){
          delete  this.feedBackObject.featureName
        }
        this.resetRequestType=true
        this.resetTypeOfRequest();
        // this.isRequestTypeSelected = false; // why?
        this.fileName="";
      }else{
        this.snackBar.open('Feedback submission unsuccessful', 'Ok', {
          duration: 2000,
        });
        this.feedbackFormGroup.reset();
        this.feedbackFormGroup.reset();
        this.showFeatureNameDropdown = false;
        if(this.feedBackObject &&  this.feedBackObject['featureName']){
          delete  this.feedBackObject.featureName
        }
        this.resetRequestType=true
        this.resetTypeOfRequest()
        // this.isRequestTypeSelected = false; // why
        this.fileName="";

      }
     
    })   
  }

  resetTypeOfRequest = () =>{
    this.requestTypes = [
      {
        text: 'Enhancement Request',
        value: 'enhancementRequest'
      },
      {
        text: 'Bug Report',
        value: 'bugReport'
      },
      {
        text: 'Feedback',
        value: 'feedback'
      },
    ];
  }

  public changeListener = ($event: any) => {
    const targetElement: any = $event.srcElement.files[0];
    if(targetElement){
      this.file = undefined;
      setTimeout(()=>{
        this.file = targetElement;
        this.fileName = this.file.name
        if(isPngJpeg(this.file)){
          this.isValidFile = true;
        }else{
          this.isValidFile=false
        }
      },500)
    }
  }

  submit() {
    
  }

}
