import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RebateSummaryComponent } from './rebate-summary.component';

describe('RebateSummaryComponent', () => {
  let component: RebateSummaryComponent;
  let fixture: ComponentFixture<RebateSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RebateSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RebateSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
