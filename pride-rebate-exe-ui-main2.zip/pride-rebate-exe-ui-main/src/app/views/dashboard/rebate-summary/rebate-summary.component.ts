import { Component, OnInit } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { MatTableDataSource } from '@angular/material/table';
import { HttpService } from 'src/app/services/http.service';
import { get as _get, reduce as _reduce, isEqual as _isEqual, isEmpty as _isEmpty } from 'lodash';
import { DataProvider } from 'src/app/helpers/constants';
import { Router } from '@angular/router';
import { getLastUpdatedDate,cleanEntityData, fixedDecimalValue } from 'src/app/helpers/commonUtils';
import { TitleCasePipe } from '@angular/common';

@Component({
  selector: 'app-rebate-summary',
  templateUrl: './rebate-summary.component.html',
  styleUrls: ['./rebate-summary.component.scss']
})
export class RebateSummaryComponent implements OnInit {
  transactionTypes:any=[
    {displayText:"BG Admin Transaction",value:'bgTransaction'},
    {displayText:"Supplier Transaction Data",value:'supplierTransaction'},
    // {displayText:"Member Transaction Data",value:'memberTransaction'}
  ]
  columnsToDisplay = [
    {header: 'VP Name', field: 'vpName', displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Program Name', field: 'programName',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Tier', field: 'tier',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Rebate', field: 'rebate',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Total Rebate', field: 'totalRebate',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Target Criteria', field: 'targetCriteria',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Rebate Type', field: 'rebateType',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Volume CY YTD', field: 'volume',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Target', field: 'target',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    {header: 'Attainment (%)', field: 'attainment',displayFilter: false,cell: (element: any) => `${element.name}`}, 
    // {header: 'Last Update', field: 'lastUpdate',displayFilter: false,cell: (element: any) => `${element.name}`}, 

  ];
  columnsProps = this.columnsToDisplay.map(column => column.field);

  dataSource: any;
  selectedTransactionValue: any= 'supplierTransaction';
  screenData: any;
  tableTotal: any;
  selectedModeValue: string =  'ytd';
  year = new Date().getFullYear();
  month = new Date().getMonth() + 1;
  rebateEarned: any = {
    "EARNED REBATES": 0,
    "YOY": 0
  };
  keyPerformanceArea: any = [
    {
      "Total Purchase": 0,
      "attainment": 0,
      "name": "Individual Rebate(Base)",
      "out of": 0,
      "yoy": 0
    },
    {
      "Total Purchase": 0,
      "attainment": 0,
      "name": "Individual Rebate(Growth)",
      "out of": 0,
      "yoy": 0
    },
    {
      "Total Purchase": 0,
      "attainment": 0,
      "name": "Individual Rebate(FBI)",
      "out of": 0,
      "yoy": 0
    },
    {
      "Total Purchase": 0,
      "attainment": 0,
      "name": "Group Rebate(Base)",
      "out of": 0,
      "yoy": 0
    },
    {
      "Total Purchase": 0,
      "attainment": 0,
      "name": "Group Rebate(Growth)",
      "out of": 0,
      "yoy": 0
    }
  ];
  potentialRebate: any = {
    "Potential  Rebate": 0,
    "yoy": 0
  };
  summaryTable: any;
  preservedTableData: any;
  activeTierByProgram: any;
  excessTierRemovedData: any;
  removeExcessToggle: boolean = false;
  inputMonth:any;
  inputYear:any;
  tenantType:any;
  pagination: any = {
    pageNo: 1,
    limit: 15
  }
  lastUpdatedDate:any=''
  constructor(private matIconRegistry: MatIconRegistry,private domSanitizer: DomSanitizer,
    private httpService: HttpService,public router: Router,private titlecasePipe:TitleCasePipe) {
    this.matIconRegistry.addSvgIcon("up-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/up_arrow_icon.svg"))
    this.matIconRegistry.addSvgIcon("down-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/down_icon.svg"))
   }

  ngOnInit(): void {
    // this.fillData()
    this.lastUpdatedDate = getLastUpdatedDate()
    let transactionValue = localStorage.getItem("transaction")
    if(!transactionValue){
      localStorage.setItem("transaction",this.selectedTransactionValue)
    }else{
      if(transactionValue=='memberTransaction'){
        this.selectedTransactionValue = 'supplierTransaction'
      }else{
        this.selectedTransactionValue = transactionValue
      }
    }
    let selectedMode = localStorage.getItem("mode")
    if(!selectedMode){
      localStorage.setItem("mode",this.selectedModeValue)
    }else{
      this.selectedModeValue = selectedMode
    }
    let month = localStorage.getItem("month")
    if(!month){
      localStorage.setItem("month",this.month.toString())
    }else{
      this.inputMonth = parseInt(month);
      this.month = parseInt(month)
    }
    let year = localStorage.getItem("year")
    if(!year){
      localStorage.setItem("year",this.year.toString())
    }else{
      this.inputYear = parseInt(year);
      this.year = parseInt(year)
    }
    if(this.month==0){
      this.month=1;
      localStorage.setItem("month","1")
    }
    this.tenantType = localStorage.getItem('tenant')
    this.fetchData();
  }

  getIcon = (value:any) =>{
    if(value>=0){
      return "up-arrow"
    }else{
      return "down-arrow"
    }
  }

  fillData(response: any, freq: any) {
    const tableData = [];
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < response.length; i++) {
      let data = {
        vpName: '',
        programName: '',
        tier:0,
        rebate:'',
        totalRebate:'',
        targetCriteria:'',
        rebateType:'',
        volume:'',
        target:'',
        attainment: [],
        // lastUpdate:''
      };
      data.vpName = response[i].supplier_name?response[i].supplier_name:'NA';
      data.programName = response[i].program_name?response[i].program_name:'NA';
      data.tier = response[i].tier?response[i].tier:0;
      data.rebate = response[i].rebate?response[i].rebate:0;
      data.totalRebate = response[i].total_rebate?response[i].total_rebate:0;
      data.targetCriteria = response[i].target_criteria;
      data.rebateType = response[i].rebate_type?response[i].rebate_type:'NA';
      data.volume = response[i].volume_cy_ytd;
      data.target = response[i].target? fixedDecimalValue(response[i].target) :0;
      data.attainment = response[i].attainment?response[i].attainment.toString().split(','):0;
      // data.lastUpdate = response[i].last_update;

      tableData.push(data);
      tableData.sort((a:any, b:any) => (a.totalRebate < b.totalRebate) ? 1 : (a.totalRebate === b.totalRebate) ? ((a.totalRebate < b.totalRebate) ? 1 : -1) : -1 )

    }
    this.preservedTableData = tableData;
    this.dataSource = new MatTableDataSource(tableData);
    this.filterTableDataOnTier();

  }

  selectedYear(value: any) {
    localStorage.setItem("year",value.toString())
    this.year = value;
    this.fetchData();
  }

  selectedMonth(value: any) {
    localStorage.setItem("month",value.toString())
    this.month = value;
    this.fetchData();
  }

  fetchData() {
    const payload = {
      "year": this.year,
      "month": this.month,
      "data_provider": DataProvider[this.selectedTransactionValue],
      "limit": this.pagination.limit,
      "pageNo": this.pagination.pageNo
    };

    this.httpService.rebateSummary(payload).subscribe((response)=>{
      this.screenData = response.data;
      this.processData(this.screenData);
    },(error)=>{
      console.log(error);
    });  
  }

  fetchTableData() {
    const payload = {
      "year": this.year,
      "month": this.month,
      "data_provider": DataProvider[this.selectedTransactionValue],
      "limit": this.pagination.limit,
      "pageNo": this.pagination.pageNo
    };
    if(this.pagination.pageNo==1){
      this.dataSource = new MatTableDataSource([])
    }
    this.httpService.rebateSummaryTable(payload).subscribe((response)=>{
      this.screenData = {
        ...this.screenData,
        activeTierByProgram: response?.data?.activeTierByProgram,
        rebateSummaryDetail: response?.data?.rebateSummaryDetail,
        count: response?.data?.count
      };
      // console.log('summary detail', this.screenData);
      this.processData(this.screenData);
    },(error)=>{
      console.log(error);
    });  
  }

  fetchTableWithoutCount() {
    const payload = {
      "year": this.year,
      "month": this.month,
      "data_provider": DataProvider[this.selectedTransactionValue],
      "limit": this.pagination.limit,
      "pageNo": this.pagination.pageNo
    };

    this.httpService.rebateSummaryTablePagination(payload).subscribe((response)=>{
      if (response.data?.count) {
        this.screenData = {
          ...this.screenData,
          activeTierByProgram: response?.data?.activeTierByProgram,
          rebateSummaryDetail: response?.data?.rebateSummaryDetail,
          count: response?.data?.count
        };
      } else {
        this.screenData = {
          ...this.screenData,
          activeTierByProgram: response?.data?.activeTierByProgram,
          rebateSummaryDetail: response?.data?.rebateSummaryDetail,
          
        };
      }
      
      this.processData(this.screenData);
    },(error)=>{
      console.log(error);
    });  
  }

  selectedMode(value: any) {
    localStorage.setItem("mode",value)
    this.selectedModeValue = value
    // this.selectedModeValue = Frequency[value];
   
    this.processData(this.screenData);
  }

  selectedTransaction(value: any) {
    this.selectedTransactionValue = value;
    localStorage.setItem("transaction",this.selectedTransactionValue)
    // this.processData(this.screenData);
    this.resetLimit();
    this.fetchTableData();
  }

  resetLimit() {
    this.pagination.limit = 15;
    this.pagination.pageNo = 1;
  }

  processData(data: any) {
    this.clearVars();
    // console.log('data checking', data);
    if (!data ||data['count']==0 || data['rebateSummaryDetail'].length==0 ) {
      this.dataSource = new MatTableDataSource([]);
      return;
    }
    // data provider vales can be
    // supplier transaction data: 1
    // bg transaction data: 3

    const found = data.summary.rebateEarned.find((element: any) => element.data_provider === DataProvider[this.selectedTransactionValue]);
    // found undefined corner case handle
    if (found) {
      this.rebateEarned = found[this.getMatchedMode(this.selectedModeValue)];
    }

    // potential rebate
    this.potentialRebate = data.potentialRebate[this.getMatchedMode(this.selectedModeValue)];
    if(this.potentialRebate){
      this.potentialRebate.value = this.potentialRebate['Potential  Rebate'];

    }

    const rebatePerformanceFound = data.summary.rebatePerformance.find((element: any) => element.data_provider === DataProvider[this.selectedTransactionValue]);
    if (rebatePerformanceFound) {
      this.keyPerformanceArea = rebatePerformanceFound[this.getMatchedMode(this.selectedModeValue)];
      this.keyPerformanceArea = this.keyPerformanceArea.map((k: any) => {
        return {
          ...k,
          percent: 90
        }
      });

    }
    
    this.activeTierByProgram = data.activeTierByProgram;
    
    const summaryTable = data.rebateSummaryDetail.filter((element: any) => element.data_provider === DataProvider[this.selectedTransactionValue]);
    this.summaryTable = summaryTable;
    this.tableTotal =  data?.count;
    
    this.fillData(this.summaryTable, this.selectedModeValue);
  }

  processRebateSummaryTable = (data: any) => {
    this.clearTableData();
    if (!data ||data['count']==0 || data['rebateSummaryDetail'].length==0 ) {
      this.dataSource = new MatTableDataSource([]);
      return;
    }
    // data provider vales can be
    // supplier transaction data: 1
    // bg transaction data: 3

    

    
    
    this.activeTierByProgram = data.activeTierByProgram;
    
    const summaryTable = data.rebateSummaryDetail.filter((element: any) => element.data_provider === DataProvider[this.selectedTransactionValue]);
    this.summaryTable = summaryTable;
    this.fillData(this.summaryTable, this.selectedModeValue);
  };
  clearVars() {
    // this.clearObj(this.rebateEarned);
    // this.clearObj(this.potentialRebate);
    // this.clearObj(this.keyPerformanceArea);
    this.rebateEarned = {
      "EARNED REBATES": 0,
      "YOY": 0
    };
    this.keyPerformanceArea = [
      {
        "Total Purchase": 0,
        "attainment": 0,
        "name": "Individual Rebate(Base)",
        "out of": 0,
        "yoy": 0
      },
      {
        "Total Purchase": 0,
        "attainment": 0,
        "name": "Individual Rebate(Growth)",
        "out of": 0,
        "yoy": 0
      },
      {
        "Total Purchase": 0,
        "attainment": 0,
        "name": "Individual Rebate(FBI)",
        "out of": 0,
        "yoy": 0
      },
      {
        "Total Purchase": 0,
        "attainment": 0,
        "name": "Group Rebate(Base)",
        "out of": 0,
        "yoy": 0
      },
      {
        "Total Purchase": 0,
        "attainment": 0,
        "name": "Group Rebate(Growth)",
        "out of": 0,
        "yoy": 0
      }
    ];
    this.potentialRebate = {
      "Potential  Rebate": 0,
      "yoy": 0
    };
    this.activeTierByProgram = {};
    this.summaryTable=[]
  }

  clearTableData() {
    this.activeTierByProgram = {};
    this.summaryTable=[]
  };

  clearObj(obj: any) {
    Object.keys(obj).forEach(k => {
      if (typeof obj[k] == "string") {
        obj[k] = '';
      } else if (typeof obj[k] == "number") {
        obj[k] = 0;
      }
    });
  }

  removeExcessTier(checked: boolean) {
    this.removeExcessToggle = checked;
    this.filterTableDataOnTier();
  }
  filterTableDataOnTier() {
    if(this.removeExcessToggle === true) {
      this.excessTierRemovedData = this.preservedTableData.filter((r: any) => {
        return r.tier === this.activeTierByProgram[r.programName];
      });
      this.dataSource = new MatTableDataSource(this.excessTierRemovedData);
    } else {
      this.dataSource = new MatTableDataSource(this.preservedTableData);
    }  
  }

  getMatchedMode = (value:any) =>{
    if (value === 'ytd') {
      return 'ytd';
    } else if (value === 'qtr') {
      return 'qtd';
    } else if (value === 'mth') {
      return 'mtd';
    }else{
      return 'ytd'
    }
  }

  checkNameLength = (name: any) => {
    if (name && name.length > 17) {
      return name = name.substring(0, 17) + "...";
    } else {
      return name
    }
  }

  fixedDecimalValue = (data:any) =>{
    if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      }else{
        return data
      }
      
    }
  }

  navigateToMissedOppurnity = () =>{
    this.router.navigate([this.tenantType, 'dashboard','missed-oppurtunity'])
  }

  getNextPage(event: any) {
    this.pagination.pageNo = parseInt(event.pageIndex, 10) + 1;
    this.fetchTableWithoutCount();
  }
}
