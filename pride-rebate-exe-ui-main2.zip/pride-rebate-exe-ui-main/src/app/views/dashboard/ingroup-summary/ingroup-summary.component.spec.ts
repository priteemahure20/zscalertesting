import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IngroupSummaryComponent } from './ingroup-summary.component';

describe('IngroupSummaryComponent', () => {
  let component: IngroupSummaryComponent;
  let fixture: ComponentFixture<IngroupSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IngroupSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IngroupSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
