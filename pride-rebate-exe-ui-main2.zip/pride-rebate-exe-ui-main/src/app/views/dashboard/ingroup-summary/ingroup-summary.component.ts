import { Component, OnInit } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpService } from 'src/app/services/http.service';
import { getLastUpdatedDate } from 'src/app/helpers/commonUtils';
import { TitleCasePipe } from '@angular/common';

@Component({
  selector: 'app-ingroup-summary',
  templateUrl: './ingroup-summary.component.html',
  styleUrls: ['./ingroup-summary.component.scss']
})
export class IngroupSummaryComponent implements OnInit {
  rebateOptions = 1;
  selectedModeValue:any = 'ytd';
  summaryObj:any
  actualSummaryArray:any=[];
  transactionTypes:any=[
    {displayText:"Supplier Transaction Data",value:'supplierTransaction'},
  ]
  summaryObject:any;
  categoryTable:any=[];
  ytdCategoryTable:any=[];
  qtrCategoryTable:any=[]
  mthCategoryTable:any=[]
  columnsToDisplay:any = [];
  columnsProps:any;
  //columnsProps = this.columnsToDisplay.map(column => column.field);

  dataSource: any;
  tenantType:any;
  pageNo=1;
  limit=15;
  tableTotal:any=0
  selectedTransactionValue:any='supplierTransaction'
  inputMonth:any;
  inputYear:any;
  lastUpdatedDate:any='';
  searchEnabled:boolean = false;
  constructor(private matIconRegistry: MatIconRegistry,private domSanitizer: DomSanitizer,
    public router: Router, public activatedRoute: ActivatedRoute,private httpService: HttpService,
    private titlecasePipe:TitleCasePipe) { 
    this.matIconRegistry.addSvgIcon("up-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/up_arrow_icon.svg"))
    this.matIconRegistry.addSvgIcon("down-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/down_icon.svg"))
  }

  ngOnInit(): void {
    this.lastUpdatedDate = getLastUpdatedDate()
    let todayDate = new Date();
    this.summaryObject = {
      "year": todayDate.getFullYear(),
      "month": todayDate.getMonth(),
      "pageNo":this.pageNo,
      "limit":this.limit
    }
    // this.summaryObject = {
    //   "year": 2020,
    //   "month": 6
    // }
    localStorage.setItem("transaction",this.selectedTransactionValue)
    let selectedMode = localStorage.getItem("mode")
    if(!selectedMode){
      localStorage.setItem("mode",this.selectedModeValue)
    }else{
      this.selectedModeValue = selectedMode
    }
    let month = localStorage.getItem("month")
    if(!month){
      localStorage.setItem("month",todayDate.getMonth().toString())
      this.inputMonth = todayDate.getMonth()
    }else{
      this.inputMonth = parseInt(month)
      this.summaryObject['month'] = parseInt(month)
    }
    let year = localStorage.getItem("year")
    if(!year){
      localStorage.setItem("year",todayDate.getFullYear().toString())
      this.inputYear = todayDate.getFullYear()
    }else{
      this.inputYear = parseInt(year)
      this.summaryObject['year'] = parseInt(year)
    }
    if(this.summaryObject && this.summaryObject['month']==0){
      this.summaryObject['month'] = 1
      localStorage.setItem("month","1")
    }
    this.getIngroupSummary();
 
    this.tenantType = localStorage.getItem('tenant')
  }

  getIngroupSummary = () =>{
    this.categoryTable = []
    this.actualSummaryArray = [];
    this.summaryObj = {};
    this.searchEnabled = false;
    if(this.summaryObject && this.summaryObject['page']==1){
      this.dataSource && this.dataSource['data'].length>0?this.dataSource['data']=[]:0;
    }
   
    this.httpService.getIngroupSummaryCategory(this.summaryObject).subscribe((response:any)=>{
      if(response && response['data'] && Object.keys(response['data']).length>0){
          this.tableTotal=response['data']['count']
          if(response['data'] && response['data']['summary']){
            let summary = response['data']['summary']
            for(let i=0;i<summary.length;i++){
              if(summary[i]['data_provider']==1){
                this.summaryObj = summary[i]
              }
            }
            this.populateSummary(this.selectedModeValue)
          }
          if(response['data'] && response['data']['groupCategory']){
            this.categoryTable = response['data']['groupCategory']
            this.populateCategoryTable(this.selectedModeValue)
          }
      }
    })
  }


  selectedIngroup = (details:any) =>{
    if(details && details['supplierName']){
    this.router.navigate([`/${this.tenantType}/dashboard/details`,{supplierName:details['supplierName']}]);
    }

  }

  public populateSummary = (mode:any) => {
    switch(mode){
      case 'ytd':
        if(Object.keys(this.summaryObj).length>0){
          this.actualSummaryArray = []
          setTimeout(()=>{
            let ytdSummary:any = this.summaryObj['ytd_top_categories']['data']
            for(let i=0;i<5;i++){
               let obj = {
                 "order":ytdSummary[i] && ytdSummary[i]['order']? ytdSummary[i]['order']:0,
                 "category":ytdSummary[i] && ytdSummary[i]['Category']? ytdSummary[i]['Category']:'NA',
                 "purchase":ytdSummary[i]&& ytdSummary[i]['purchase']?ytdSummary[i]['purchase']:0,
                 "rebate": ytdSummary[i] && ['Rebate']?ytdSummary[i]['Rebate']:0, 
                 "yoy":ytdSummary[i] && ['yoy']?ytdSummary[i]['yoy']:0
               }
               ytdSummary[i] && ytdSummary[i]['Category']?this.actualSummaryArray.push(obj):'';
            }
            if(this.actualSummaryArray && this.actualSummaryArray.length>0){
              this.actualSummaryArray.sort((a:any, b:any) => (a.order > b.order) ? 1 : (a.order === b.order) ? ((a.order > b.order) ? 1 : -1) : -1 )
            }
          })
         
        }
         
        break;
      case 'qtr':
        if(Object.keys(this.summaryObj).length>0){
          this.actualSummaryArray = []
          setTimeout(()=>{
            let qtrSummary:any = this.summaryObj['qtd_top_categories']['data']
            for(let i=0;i<5;i++){
               let obj = {
                "order":qtrSummary[i] && qtrSummary[i]['order']? qtrSummary[i]['order']:0,
                 "category":qtrSummary[i] && qtrSummary[i]['Category']? qtrSummary[i]['Category']:'NA',
                 "purchase":qtrSummary[i] && qtrSummary[i]['purchase']?qtrSummary[i]['purchase']:0,
                 "rebate":qtrSummary[i] && qtrSummary[i]['Rebate']?qtrSummary[i]['Rebate']:0,
                 "yoy":qtrSummary[i] && qtrSummary[i]['yoy']?qtrSummary[i]['yoy']:0
               }
               qtrSummary[i] && qtrSummary[i]['Category']?this.actualSummaryArray.push(obj):'';
            }
            console.log('>>>',this.actualSummaryArray)
            if(this.actualSummaryArray && this.actualSummaryArray.length>0){
              this.actualSummaryArray.sort((a:any, b:any) => (a.order > b.order) ? 1 : (a.order === b.order) ? ((a.order > b.order) ? 1 : -1) : -1 )
            }
          })
         
        }
        break;
      case 'mth':
        if(Object.keys(this.summaryObj).length>0){
          this.actualSummaryArray = []
          setTimeout(()=>{
            let mthSummary:any = this.summaryObj['mtd_top_categories']['data']
            for(let i=0;i<5;i++){
               let obj = {
                "order":mthSummary[i] && mthSummary[i]['order']? mthSummary[i]['order']:0,
                 "category":mthSummary[i] && mthSummary[i]['Category']? mthSummary[i]['Category']:'NA',
                 "purchase":mthSummary[i] && mthSummary[i]['purchase']?mthSummary[i]['purchase']:0,
                 "rebate":mthSummary[i] && mthSummary[i]['Rebate']?mthSummary[i]['Rebate']:0,
                 "yoy":mthSummary[i] && mthSummary[i]['yoy']
               }
               mthSummary[i] && mthSummary[i]['Category']?this.actualSummaryArray.push(obj):'';
            }
            if(this.actualSummaryArray && this.actualSummaryArray.length>0){
              this.actualSummaryArray.sort((a:any, b:any) => (a.order > b.order) ? 1 : (a.order === b.order) ? ((a.order > b.order) ? 1 : -1) : -1 )
            }
          })
        
        }
        break;
    }
    
    
  }

  public populateCategoryTable = (mode:any) =>{
      if(this.summaryObject['pageNo']==1){
         this.populateHeaders();
        this.dataSource && this.dataSource['data'].length>0?this.dataSource['data']=[]:0
      }
      this.ytdCategoryTable=[];
      this.qtrCategoryTable=[];
      this.mthCategoryTable=[];
    switch(mode){
      case 'ytd':
        setTimeout(()=>{
          for(let i=0;i<this.categoryTable.length;i++){
          //   let obj = {
          // 'category':this.categoryTable[i] && this.categoryTable[i]? this.titlecasePipe.transform(this.categoryTable[i]['category']):'NA',
          // 'supplierName': this.categoryTable[i] && this.categoryTable[i]['supplier_name']? this.titlecasePipe.transform(this.categoryTable[i]['supplier_name']):'NA',
          // 'totalPurchase':this.categoryTable[i]['ytd_total_purchase'] && this.categoryTable[i]['ytd_total_purchase']>1000?
          // `$${((this.categoryTable[i]['ytd_total_purchase'])/1000).toFixed(2).toString()}k`:`$${this.categoryTable[i]['ytd_total_purchase'].toFixed(2)}`,
          // 'totalRebateEarned':this.categoryTable[i]['ytd_rebate_earned'] && this.categoryTable[i]['ytd_rebate_earned']>1000?
          // `$${((this.categoryTable[i]['ytd_rebate_earned'])/1000).toFixed(2).toString()}k`:`$${this.categoryTable[i]['ytd_rebate_earned'].toFixed(2)}`,
          // 'yoyChangeInPurchase':this.categoryTable[i]['ytd_yoy_change_in_purchase']?`${this.categoryTable[i]['ytd_yoy_change_in_purchase'].toFixed(2)}%`:0
          //   }
            let obj = {
              'category':this.categoryTable[i] && this.categoryTable[i]? this.categoryTable[i]['category']:'NA',
              'supplierName': this.categoryTable[i] && this.categoryTable[i]['supplier_name']? this.categoryTable[i]['supplier_name']:'NA',
              'totalPurchase':this.categoryTable[i]['ytd_total_purchase'] && this.categoryTable[i]['ytd_total_purchase']?
              this.categoryTable[i]['ytd_total_purchase']:0,
              'totalRebateEarned':this.categoryTable[i]['ytd_rebate_earned'] && this.categoryTable[i]['ytd_rebate_earned']?this.categoryTable[i]['ytd_rebate_earned']:0,
              'yoyChangeInPurchase':this.categoryTable[i]['ytd_yoy_change_in_purchase']?`${this.categoryTable[i]['ytd_yoy_change_in_purchase'].toFixed(2)}`:0
                }
            this.ytdCategoryTable.push(obj);
          }
          this.dataSource = new MatTableDataSource(this.ytdCategoryTable);
        })
       
        break;
      case 'qtr':
        setTimeout(()=>{
          for(let i=0;i<this.categoryTable.length;i++){
          //   let obj = {
          // 'category':this.categoryTable[i] && this.categoryTable[i]['category'] ? this.titlecasePipe.transform(this.categoryTable[i]['category']):'NA',
          // 'supplierName': this.categoryTable[i] && this.categoryTable[i]['supplier_name']? this.titlecasePipe.transform(this.categoryTable[i]['supplier_name']):'NA',
          // 'totalPurchase':this.categoryTable[i]['qtd_total_purchase'] && this.categoryTable[i]['qtd_total_purchase']>1000?
          // `$${((this.categoryTable[i]['qtd_total_purchase'])/1000).toFixed(2).toString()}k`:`$${this.categoryTable[i]['qtd_total_purchase'].toFixed(2)}`,
          // 'totalRebateEarned':this.categoryTable[i]['qtd_rebate_earned'] && this.categoryTable[i]['qtd_rebate_earned']>1000?
          // `$${((this.categoryTable[i]['qtd_rebate_earned'])/1000).toFixed(2).toString()}k`:`$${this.categoryTable[i]['qtd_rebate_earned'].toFixed(2)}`,
          // 'yoyChangeInPurchase':this.categoryTable[i]['qtd_yoy_change_in_purchase']?`${this.categoryTable[i]['qtd_yoy_change_in_purchase'].toFixed(2)}%`:0
          //   }

            let obj = {
              'category':this.categoryTable[i] && this.categoryTable[i]['category'] ? this.categoryTable[i]['category']:'NA',
              'supplierName': this.categoryTable[i] && this.categoryTable[i]['supplier_name']? this.categoryTable[i]['supplier_name']:'NA',
              'totalPurchase':this.categoryTable[i]['qtd_total_purchase'] && this.categoryTable[i]['qtd_total_purchase']?this.categoryTable[i]['qtd_total_purchase']:0,
              'totalRebateEarned':this.categoryTable[i]['qtd_rebate_earned'] && this.categoryTable[i]['qtd_rebate_earned']?this.categoryTable[i]['qtd_rebate_earned']:0,
              'yoyChangeInPurchase':this.categoryTable[i]['qtd_yoy_change_in_purchase']?`${this.categoryTable[i]['qtd_yoy_change_in_purchase'].toFixed(2)}%`:0
                }
            this.qtrCategoryTable.push(obj);
          }
          this.dataSource = new MatTableDataSource(this.qtrCategoryTable);
        })
      
        break;
      case 'mth':
        setTimeout(()=>{
          for(let i=0;i<this.categoryTable.length;i++){
          //   let obj = {
          // 'category': this.categoryTable[i] && this.categoryTable[i]['category']? this.titlecasePipe.transform(this.categoryTable[i]['category']):'NA',
          // 'supplierName':this.categoryTable[i] && this.categoryTable[i]['supplier_name']? this.titlecasePipe.transform(this.categoryTable[i]['supplier_name']):'NA',
          // 'totalPurchase':this.categoryTable[i]['mtd_total_purchase'] && this.categoryTable[i]['mtd_total_purchase']>1000?
          // `$${((this.categoryTable[i]['mtd_total_purchase'])/1000).toFixed(2).toString()}k`:`$${this.categoryTable[i]['mtd_total_purchase'].toFixed(2)}`,
          // 'totalRebateEarned':this.categoryTable[i]['mtd_rebate_earned'] && this.categoryTable[i]['mtd_rebate_earned']>1000?
          // `$${((this.categoryTable[i]['mtd_rebate_earned'])/1000).toFixed(2).toString()}k`:`$${this.categoryTable[i]['mtd_rebate_earned'].toFixed(2)}`,
          // 'yoyChangeInPurchase':this.categoryTable[i]['mtd_yoy_change_in_purchase']?`${this.categoryTable[i]['mtd_yoy_change_in_purchase'].toFixed(2)}%`:0
          //   }
          let obj = {
            'category': this.categoryTable[i] && this.categoryTable[i]['category']? this.categoryTable[i]['category']:'NA',
            'supplierName':this.categoryTable[i] && this.categoryTable[i]['supplier_name']? this.categoryTable[i]['supplier_name']:'NA',
            'totalPurchase':this.categoryTable[i]['mtd_total_purchase'] && this.categoryTable[i]['mtd_total_purchase']?this.categoryTable[i]['mtd_total_purchase']:0,
            'totalRebateEarned':this.categoryTable[i]['mtd_rebate_earned'] && this.categoryTable[i]['mtd_rebate_earned']?this.categoryTable[i]['mtd_rebate_earned']:0,
            'yoyChangeInPurchase':this.categoryTable[i]['mtd_yoy_change_in_purchase']?`${this.categoryTable[i]['mtd_yoy_change_in_purchase'].toFixed(2)}%`:0
              }
            this.mthCategoryTable.push(obj);
          }
          this.dataSource = new MatTableDataSource(this.mthCategoryTable);
        })
       
        break;
    }
  }

  getIcon = (value:any) =>{
    if(value>=0){
      return "up-arrow"
    }else{
      return "down-arrow"
    }
  }
  selectedYear = (value:any) =>{
    if(value){
      this.summaryObject['year']=parseInt(value);
      localStorage.setItem("year",value.toString())
      this.dataSource && this.dataSource['data'].length>0?this.dataSource['data']=[]:0;
    }
    if(Object.values(this.summaryObject).length>1){
      this.pageNo =1;
      this.limit =15;
      this.summaryObject['pageNo'] = this.pageNo
      this.summaryObject['limit'] = this.limit
      this.getIngroupSummary();

      // this.httpService.getIngroupSummaryCategory(this.summaryObject).subscribe((response:any)=>{
      //   if(response && response['data'] && Object.keys(response['data']).length>0){
      //       if(response['data'] && response['data']['summary']){
      //         let summary = response['data']['summary']
      //         for(let i=0;i<summary.length;i++){
      //           if(summary[i]['data_provider']==1){
      //             this.summaryObj = summary[i]
      //           }
      //         }
      //         this.populateSummary(this.selectedModeValue)
      //       }
      //       if(response['data'] && response['data']['groupCategory']){
      //         this.categoryTable = response['data']['groupCategory']
      //         this.populateCategoryTable(this.selectedModeValue)
      //       }
      //   }
      // })
    }
  }

  selectedMonth = (value:any) =>{
    if(value){
      this.summaryObject['month']=parseInt(value)
      localStorage.setItem("month",value.toString())
      this.dataSource && this.dataSource['data'].length>0?this.dataSource['data']=[]:0;
    }
    if(Object.values(this.summaryObject).length>1){
      this.pageNo =1;
      this.limit =15;
      this.summaryObject['pageNo'] = this.pageNo
      this.summaryObject['limit'] = this.limit
      this.getIngroupSummary();

      // this.httpService.getIngroupSummaryCategory(this.summaryObject).subscribe((response:any)=>{
      //   if(response && response['data'] && Object.keys(response['data']).length>0){
      //       if(response['data'] && response['data']['summary']){
      //         let summary = response['data']['summary']
      //         for(let i=0;i<summary.length;i++){
      //           if(summary[i]['data_provider']==1){
      //             this.summaryObj = summary[i]
      //           }
      //         }
      //         this.populateSummary(this.selectedModeValue)
      //       }
      //       if(response['data'] && response['data']['groupCategory']){
      //         this.categoryTable = response['data']['groupCategory']
      //         this.populateCategoryTable(this.selectedModeValue)
      //       }
      //   }
      // })
    }
  }

  selectedMode = (value:any) =>{
    this.selectedModeValue = value
    localStorage.setItem("mode",this.selectedModeValue)
   
    if(this.searchEnabled == true){
      this.populateSummary(this.selectedModeValue);
      this.populateSearchCategoryTable(this.selectedModeValue)
    }else{
      this.populateSummary(this.selectedModeValue);
      this.populateCategoryTable(this.selectedModeValue);
    }
    
    
  }

  checkNameLength = (name:any) =>{
    if (name.length > 20) {
    return  name = name.substring(0, 20) + "...";
    }else{
      return name
    }
  }

  getNextPage = (data:any) =>{
    this.summaryObject['pageNo']=parseInt(data['pageIndex'])+1;
    this.summaryObject['limit']=parseInt(data['pageSize']);
    if(this.searchEnabled){
      this.searchData();
    }else{
      this.getIngroupSummary();
    }
  }

  fixedDecimalValue = (data:any) =>{
    if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      }else{
        return data
      }
      
    } else{
      return 0
    }
  }
  filteredColumns = (content:any) =>{
    this.pageNo =1;
    this.limit =15;
    this.summaryObject['pageNo'] = this.pageNo
    this.summaryObject['limit'] = this.limit
    if(content['supplierName'] != ""){
      this.summaryObject['supplier_name'] = content['supplierName']
    } else{
      if(content['supplierName'] == "" && this.summaryObject && this.summaryObject.hasOwnProperty('supplier_name')){
        delete this.summaryObject['supplier_name']
      }
    }
    if(content['category'] != ""){
      this.summaryObject['category'] = content['category']
    }else{
      if(content['category'] == "" && this.summaryObject && this.summaryObject.hasOwnProperty('category')){
        delete this.summaryObject['category']
      }
    }
    if(this.summaryObject.hasOwnProperty('supplier_name') || this.summaryObject.hasOwnProperty('category')){
      this.searchData();
    }else{
      this.getIngroupSummary();
    }
  }

  searchData = () =>{
    this.searchEnabled = true;
    if(this.pageNo==1){
      if(this.dataSource && this.dataSource['data'].length>0){
        this.dataSource['data'] = []
      }
    }
    this.httpService.getIngroupSummaryCategoryBySearch(this.summaryObject).subscribe((response:any)=>{
      if(response && response['data'] && Object.keys(response['data']).length>0){
          this.tableTotal=response['data']['count']
          if(this.tableTotal>0){
            this.categoryTable = response['data']['groupCategory']
            this.populateSearchCategoryTable(this.selectedModeValue)
          } else{
            this.dataSource['data'] = []
          }
      }
    })
  }
  populateSearchCategoryTable = (mode:any) =>{
    // if(this.summaryObject['pageNo']==1){
    //   this.dataSource && this.dataSource['data'].length>0?this.dataSource['data']=[]:0
    // }
    this.ytdCategoryTable=[];
    this.qtrCategoryTable=[];
    this.mthCategoryTable=[];
  switch(mode){
    case 'ytd':
      setTimeout(()=>{
        for(let i=0;i<this.categoryTable.length;i++){
          let obj = {
            'category':this.categoryTable[i] && this.categoryTable[i]? this.categoryTable[i]['category']:'NA',
            'supplierName': this.categoryTable[i] && this.categoryTable[i]['supplier_name']? this.categoryTable[i]['supplier_name']:'NA',
            'totalPurchase':this.categoryTable[i]['ytd_total_purchase'] && this.categoryTable[i]['ytd_total_purchase']?
            this.categoryTable[i]['ytd_total_purchase']:0,
            'totalRebateEarned':this.categoryTable[i]['ytd_rebate_earned'] && this.categoryTable[i]['ytd_rebate_earned']?this.categoryTable[i]['ytd_rebate_earned']:0,
            'yoyChangeInPurchase':this.categoryTable[i]['ytd_yoy_change_in_purchase']?`${this.categoryTable[i]['ytd_yoy_change_in_purchase'].toFixed(2)}`:0
              }
          this.ytdCategoryTable.push(obj);
        }
        this.dataSource['data']=this.ytdCategoryTable
      })
     
      break;
    case 'qtr':
      setTimeout(()=>{
        for(let i=0;i<this.categoryTable.length;i++){
          let obj = {
            'category':this.categoryTable[i] && this.categoryTable[i]['category'] ? this.categoryTable[i]['category']:'NA',
            'supplierName': this.categoryTable[i] && this.categoryTable[i]['supplier_name']? this.categoryTable[i]['supplier_name']:'NA',
            'totalPurchase':this.categoryTable[i]['qtd_total_purchase'] && this.categoryTable[i]['qtd_total_purchase']?this.categoryTable[i]['qtd_total_purchase']:0,
            'totalRebateEarned':this.categoryTable[i]['qtd_rebate_earned'] && this.categoryTable[i]['qtd_rebate_earned']?this.categoryTable[i]['qtd_rebate_earned']:0,
            'yoyChangeInPurchase':this.categoryTable[i]['qtd_yoy_change_in_purchase']?`${this.categoryTable[i]['qtd_yoy_change_in_purchase'].toFixed(2)}%`:0
              }
          this.qtrCategoryTable.push(obj);
        }
        this.dataSource['data']=this.qtrCategoryTable
       // this.dataSource = new MatTableDataSource(this.qtrCategoryTable);
      })
    
      break;
    case 'mth':
      setTimeout(()=>{
        for(let i=0;i<this.categoryTable.length;i++){
        let obj = {
          'category': this.categoryTable[i] && this.categoryTable[i]['category']? this.categoryTable[i]['category']:'NA',
          'supplierName':this.categoryTable[i] && this.categoryTable[i]['supplier_name']? this.categoryTable[i]['supplier_name']:'NA',
          'totalPurchase':this.categoryTable[i]['mtd_total_purchase'] && this.categoryTable[i]['mtd_total_purchase']?this.categoryTable[i]['mtd_total_purchase']:0,
          'totalRebateEarned':this.categoryTable[i]['mtd_rebate_earned'] && this.categoryTable[i]['mtd_rebate_earned']?this.categoryTable[i]['mtd_rebate_earned']:0,
          'yoyChangeInPurchase':this.categoryTable[i]['mtd_yoy_change_in_purchase']?`${this.categoryTable[i]['mtd_yoy_change_in_purchase'].toFixed(2)}%`:0
            }
          this.mthCategoryTable.push(obj);
        }
        this.dataSource['data']=this.mthCategoryTable
       // this.dataSource = new MatTableDataSource(this.mthCategoryTable);
      })
     
      break;
  }
  
  }
  populateHeaders = ()=>{
    this.columnsToDisplay=[
      {header: 'SUPPLIER NAME', field: 'supplierName',displayFilter: false,cell: (element: any) => `${element.name}`}, 
      {header: 'CATEGORY', field: 'category', displayFilter: false,cell: (element: any) => `${element.name}`}, 
      {header: 'TOTAL PURCHASE', field: 'totalPurchase',displayFilter: 'none',cell: (element: any) => `${element.name}`}, 
      {header: 'TOTAL REBATE EARNED', field: 'totalRebateEarned',displayFilter: 'none',cell: (element: any) => `${element.name}`}, 
      {header: 'YOY Change In Purchase (%)', field: 'yoyChangeInPurchase',displayFilter: 'none',cell: (element: any) => `${element.name}`}, 
      {header: 'View Details', field: 'viewDetails'}, 
  
    ];
    this.columnsProps= this.columnsToDisplay.map((column:any) => {return column.field});
  }

}
