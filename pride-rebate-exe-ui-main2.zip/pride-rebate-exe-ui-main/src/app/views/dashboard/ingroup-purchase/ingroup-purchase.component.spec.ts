import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IngroupPurchaseComponent } from './ingroup-purchase.component';

describe('IngroupPurchaseComponent', () => {
  let component: IngroupPurchaseComponent;
  let fixture: ComponentFixture<IngroupPurchaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IngroupPurchaseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IngroupPurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
