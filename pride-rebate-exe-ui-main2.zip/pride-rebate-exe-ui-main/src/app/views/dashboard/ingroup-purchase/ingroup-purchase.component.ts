import { Component, OnInit } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { CONSTANTS, DataProvider, Frequency } from 'src/app/helpers/constants';
import { HttpService } from 'src/app/services/http.service';
import { get as _get, reduce as _reduce, isEqual as _isEqual, isEmpty as _isEmpty, fromPairs } from 'lodash';
import { getLastUpdatedDate } from 'src/app/helpers/commonUtils';
import {TitleCasePipe} from '@angular/common'
@Component({
  selector: 'app-ingroup-purchase',
  templateUrl: './ingroup-purchase.component.html',
  styleUrls: ['./ingroup-purchase.component.scss']
})
export class IngroupPurchaseComponent implements OnInit {
  public supplierTypes =1;
  columnsToDisplay:any = [];
  columnsProps :any//= this.columnsToDisplay.map(column => column.field);
  dataSource: any;
  tenantType:any;
  transactionTypes:any=[
    {displayText:"BG Admin Transaction",value:'bgTransaction'},
    {displayText:"Supplier Transaction Data",value:'supplierTransaction'},
  ]
  selectedTransactionValue: any = 'supplierTransaction';
  summary: any = {
    categories_purchased: {value: 0, of: 0},
    rebate_earned: {value: 0, yoy: 0},
    total_purchase: {value: 0, yoy: 0}
  };
  selectedModeValue: any = 'ytd';
  // selectedModeValue: keyof typeof Frequency = Frequency.ytd;
  preferredSuppliers: any=[];
  supplierTransactions: any;
  searchableTransactions:any;
  screenData: any;
  year = new Date().getFullYear();
  month = new Date().getMonth() + 1;
  pageNo:number=1;
  limit:number=15;
  tableTotal:any=0;
  inputMonth:any;
  inputYear:any;
  lastUpdatedDate:any=''
  summaryObject:any = {};
  isSearchEnabled:boolean = false;
  constructor(private matIconRegistry: MatIconRegistry,private domSanitizer: DomSanitizer,
    public router: Router, public activatedRoute: ActivatedRoute,private titlecasePipe:TitleCasePipe,
    private httpService: HttpService) { 
    this.matIconRegistry.addSvgIcon("up-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/up_arrow_icon.svg"));
    this.matIconRegistry.addSvgIcon("down-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/down_icon.svg"))
  }

  ngOnInit(): void {
      this.lastUpdatedDate = getLastUpdatedDate()
       let transactionValue = localStorage.getItem("transaction")
    if(!transactionValue){
      localStorage.setItem("transaction",this.selectedTransactionValue)
    }else{
      if(transactionValue=='memberTransaction'){
        this.selectedTransactionValue = 'supplierTransaction'
      }else{
        this.selectedTransactionValue = transactionValue
      }
    }
    let selectedMode = localStorage.getItem("mode")
    if(!selectedMode){
      localStorage.setItem("mode",this.selectedModeValue)
    }else{
      this.selectedModeValue = selectedMode
    }
    let month = localStorage.getItem("month")
    if(month){
      this.inputMonth = parseInt(month);
      this.month = parseInt(month)
    }else{
      localStorage.setItem("month",this.month.toString())
    }
    let year = localStorage.getItem("year")
    if(year){
      this.inputYear = parseInt(year);
      this.year = parseInt(year)
    }else{
      localStorage.setItem("year",this.year.toString())

    }
    if(this.month==0){
      this.month=1
      localStorage.setItem("month","1")
    }
    this.fetchData(1,15);
    this.tenantType = localStorage.getItem('tenant')

  }
  getIcon = (value:any) =>{
    if(value>=0){
      return "up-arrow"
    }else{
      return "down-arrow"
    }
  }
  fetchData(pageNo:any,limit:any) {
    // month is 1 for jan, 2 for feb etc
    const payload = {
      "year": this.year,
      "month": this.month,
      "pageNo":pageNo,
      "limit":limit,
      "data_provider": DataProvider[this.selectedTransactionValue]
    };
    // if(pageNo==1){
    //   if(this.dataSource  && this.dataSource['data']>0){
    //     this.dataSource['data'] = []
    //   } 
    // }
    this.httpService.inGroupPurchase(payload).subscribe((response)=>{
      // console.log('inGroupPurchase: ', response);
      this.screenData = response.data;
      this.tableTotal =  response['data']['count'];

      this.processData(this.screenData);
    },(error)=>{
      console.log(error);
    });  
  }
  processData(data: any) {
    if (data['count']==0) {
      this.summary = {
        categories_purchased: {value: 0, of: 0},
        rebate_earned: {value: 0, yoy: 0},
        total_purchase: {value: 0, yoy: 0}
      };
      this.preferredSuppliers = [];
      if(this.dataSource  &&this.dataSource ['data'].length>0){
        this.dataSource = new MatTableDataSource([]);
      }
      return;
    }
    // data provider vales can be
    // supplier transaction data: 1
    // bg transaction data: 3
    
      if(data && data['summary']){
        const found = data.summary.find((element: any) => element.data_provider === DataProvider[this.selectedTransactionValue]);
        // found undefined corner case handle
        if (found) {
          this.summary = found[this.getMatchedMode(this.selectedModeValue)];
        }
      }
  
      if(data && data['preferredSuppliers']){
        const preferredSupplierFound = data.preferredSuppliers.find((element: any) => element.data_provider === DataProvider[this.selectedTransactionValue]);
        // console.log(preferredSupplierFound);
        if(preferredSupplierFound){
          this.preferredSuppliers = preferredSupplierFound[this.getMatchedMode(this.selectedModeValue)];
          if(this.preferredSuppliers && this.preferredSuppliers.length>0){
            this.preferredSuppliers.sort((a:any, b:any) => (a.order > b.order) ? 1 : (a.order === b.order) ? ((a.order > b.order) ? 1 : -1) : -1 )
          }
        }
      }
      if(!this.isSearchEnabled){
      if(data && data['supplierTransactions']){
        const supplierTransactions = data.supplierTransactions.filter((element: any) => element.data_provider === DataProvider[this.selectedTransactionValue]);
        this.supplierTransactions = supplierTransactions;
        this.fillData(this.supplierTransactions, this.selectedModeValue);
      }
    } else{
      this.fillData(this.searchableTransactions, this.selectedModeValue);
    }
 

  }

  fillData(response: any, freq: any) {
    
    const tableData = [];
    // tslint:disable-next-line: prefer-for-of
    if(response.length>0){
      for (let i = 0; i < response.length; i++) {
        let data = {
          supplierName: response[i].supplierName,
          totalPurchase: response[i].totalPurchase[this.getMatchedMode(freq)]?response[i].totalPurchase[this.getMatchedMode(freq)]:0,
          totalRebateEarned:response[i].totalRebateEarned[this.getMatchedMode(freq)]?response[i].totalRebateEarned[this.getMatchedMode(freq)]:0,
          yoyChangeInPurchase:response[i].yoyChangeInPurchase[this.getMatchedMode(freq)]?response[i].yoyChangeInPurchase[this.getMatchedMode(freq)].toFixed(2):0,
        };
        tableData.push(data);
      }
      tableData.sort((a:any, b:any) => (a.totalPurchase > b.totalPurchase) ? 1 : (a.totalPurchase === b.totalPurchase) ? ((a.totalPurchase > b.totalPurchase) ? 1 : -1) : -1 )

    }
    if(!this.isSearchEnabled){
      this.columnsProps = [];
      this.populateColumns();
      this.dataSource = new MatTableDataSource(tableData);
    } else{
      if(this.dataSource && this.dataSource['data']){
        this.dataSource['data'] = tableData
      }
    }
  }

  selectedIngroup = (details:any) =>{
    if(details && details['supplierName']){
      this.router.navigate([`/${this.tenantType}/dashboard/details`,{supplierName:details['supplierName']}])
    } else{
      this.router.navigate([`/${this.tenantType}/dashboard/details`])
    }

  }

  selectedYear(value: any) {
    // console.log('selectedYear: ', value);
    this.year = value;
    localStorage.setItem("year",value.toString())
    this.isSearchEnabled = false;
    if(this.dataSource  &&this.dataSource ['data'].length>0){
      this.dataSource = new MatTableDataSource([]);
    }
    this.fetchData(1,15);
  }

  selectedMonth(value: any) {
    // console.log('selectedMonth: ', value);
    localStorage.setItem("month",value.toString())
    this.month = value;
    this.isSearchEnabled = false;
    if(this.dataSource  &&this.dataSource ['data'].length>0){
      this.dataSource = new MatTableDataSource([]);
    }
    this.fetchData(1,15);
  }

  selectedMode(value: any) {
    // console.log('selectedMode: ', value);
    localStorage.setItem("mode",value)
    this.selectedModeValue = value
    // this.selectedModeValue = Frequency[value];
    // if (value === 'ytd') {
    //   this.selectedModeValue = 'ytd';
    // } else if (value === 'qtr') {
    //   this.selectedModeValue = 'qtd';
    // } else if (value === 'mth') {
    //   this.selectedModeValue = 'mtd';
    // }
    this.processData(this.screenData);
  }

  selectedTransaction(value: any) {
    // console.log('selectedTransaction: ', value);
    this.isSearchEnabled = false;
    this.selectedTransactionValue = value;
    if(this.dataSource  &&this.dataSource ['data'].length>0){
      this.dataSource = new MatTableDataSource([]);
    }
    localStorage.setItem("transaction",this.selectedTransactionValue);
    this.fetchData(1,15);
    // this.processData(this.screenData);
  }
  getNextPage = (data:any) =>{
    let pageNo=parseInt(data['pageIndex'])+1
    let limit= data['pageSize']
    if(this.isSearchEnabled){
      this.getSearchedData(pageNo,limit)
    }else{
      this.fetchData(pageNo,limit);
    }
    
  }

  checkNameLength = (name:any) =>{
    if (name.length > 20) {
    return  name = name.substring(0, 20) + "...";
    }else{
      return name
    }
  }

  getMatchedMode = (value:any) =>{
    if (value === 'ytd') {
      return 'ytd';
    } else if (value === 'qtr') {
      return 'qtd';
    } else if (value === 'mth') {
      return 'mtd';
    }else{
      return 'ytd'
    }
  }

  fixedDecimalValue = (data:any) =>{
  if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      }else{
        return data
      }
      
    }
  }
  getFlooredFixed = (v:any) => {
    return (Math.floor(v * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
  }

  navigateToRebateSummary = () =>{
    this.router.navigate([`/${this.tenantType}/dashboard/rebate-summary`])
  }

  navigateToIngrpSummaryByCategory = () =>{
    this.router.navigate([`/${this.tenantType}/dashboard/category`])
  }

  filteredColumns = (content:any) =>{
    this.isSearchEnabled = true
    if(content['supplierName'] != ""){
      this.summaryObject['supplierName'] = content['supplierName']
    } else{
      if(content['supplierName'] == "" && this.summaryObject && this.summaryObject.hasOwnProperty('supplierName')){
        delete this.summaryObject['supplierName']
        this.isSearchEnabled = false
      }
    }
    if(this.summaryObject && this.summaryObject.hasOwnProperty('supplierName')){
      if(this.dataSource  && this.dataSource ['data'].length>0){
        this.dataSource = new MatTableDataSource([]);
      }
      this.getSearchedData(1,15)
    }else{
      if(this.dataSource  && this.dataSource ['data'].length>0){
        this.dataSource = new MatTableDataSource([]);
      }
      this.fetchData(1,15)
    }
    
   
  }
  getSearchedData = (pageNo:any,limit:any) =>{
    this.summaryObject['year'] = this.year;
    let mth:any = this.month;
    this.summaryObject['month'] = parseInt(mth)
    this.summaryObject['pageNo'] = pageNo;
    this.summaryObject['limit'] = limit;
    this.summaryObject['data_provider'] =  DataProvider[this.selectedTransactionValue];
    this.httpService.inGroupPurchaseSearch(this.summaryObject).subscribe((response:any)=>{
      this.tableTotal=response['data']['count']
      if(this.tableTotal>0){
        const supplierTransactions = response['data'].supplierTransactions.filter((element: any) => element.data_provider === DataProvider[this.selectedTransactionValue]);
      this.supplierTransactions = supplierTransactions;
      this.searchableTransactions = supplierTransactions
      this.fillData(this.supplierTransactions, this.selectedModeValue);
      } else{
        this.dataSource['data'] = []
      }
    })
  }
  populateColumns = () =>{
    this.columnsToDisplay = [
      {header: 'Supplier Name', field: 'supplierName', displayFilter: false,cell: (element: any) => `${element.name}`}, 
      {header: 'Total Purchase', field: 'totalPurchase',displayFilter: 'none',cell: (element: any) => `${element.name}`}, 
      {header: 'Total Rebate Earned', field: 'totalRebateEarned',displayFilter: 'none',cell: (element: any) => `${element.name}`}, 
      {header: 'YOY Change In Purchase (%)', field: 'yoyChangeInPurchase',displayFilter: 'none',cell: (element: any) => `${element.name}`}, 
      {header: 'View Details', field: 'viewDetails',displayFilter: false}, 
    ]
    this.columnsProps= this.columnsToDisplay.map((column:any) => {return column.field});
  }
}
