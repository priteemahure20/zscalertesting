import { Component, Inject, OnInit } from '@angular/core';
import {FormControl, FormGroupDirective, NgForm, Validators, FormGroup, ValidatorFn, FormBuilder} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { get as _get } from 'lodash';
import { v4 as uuidv4 } from 'uuid';
import { HttpService } from 'src/app/services/http.service';
import { AesService } from 'src/app/services/aes.service';
import { ActivatedRoute, NavigationEnd, Router, NavigationStart } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { TermsConditionsComponent } from 'src/app/common/terms-conditions/terms-conditions.component';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Subject } from 'rxjs';
import { isEmpty as _isEmpty } from 'lodash';
import { DataService } from 'src/app/services/data.service';
import { UpdatePasswordComponent } from '../update-password/update-password.component';
import { DOCUMENT, LocationStrategy } from '@angular/common';
import { NotificationsComponent } from 'src/app/common/notifications/notifications.component';
import { getPrivacyLink, getTermsLink } from 'src/app/helpers/commonUtils';
import { RebateNotifierService } from 'src/app/services/rebate-notifier.service';
import { BnNgIdleService } from 'bn-ng-idle';
import { CONSTANTS } from 'src/app/helpers/constants';
import { AuthService } from 'src/app/services/auth.service';
import { environment } from 'src/environments/environment';
/** Error when invalid control is dirty, touched, or submitted. */
// export class MyErrorStateMatcher implements ErrorStateMatcher {
//   isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
//     const isSubmitted = form && form.submitted;
//     return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
//   }
// }

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  signUpErrorMessage: any;
  resetErrorMessage: string = '';
  verificationMessage: string = '';
  resendErrorMessage: string = '';
  tokenGenerated: any;
  loader = false;
  returnUrl: string ='';
  resetSuccess = false;
  resetError = false;
  verifyToken: any;
  resetSuccessMessage: string = '';
  showVerifyErrorMessage: boolean = false;
  verificationErrorMessage: any;
  showResendText = false;
  resendEmailId: any;
  reverified: boolean = false;
  indexPosition =0;
  isSSO = false
  ssoLoginError:any = false
  //matcher = new MyErrorStateMatcher();

  userLoginForm = {
    username: '',
    password: ''
  };
  errorMessage = '';
  resetPw = false;
  signIn = true;
  verMsgShown = false;
  isEmailRequried = false;
  tenantType:any;
  hide = true;
  isFirstLogin=0;
  // imageSrc='https://rbdevdatalakestorage.blob.core.windows.net/rap-images/icons/pride_logo.svg';
  imageSrc='../../../assets/img/icons/rebate-logo-2.png';

  loginFormGroup = new FormGroup({
    loginemail: new FormControl('', [Validators.required, Validators.pattern('^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$')]),
    password: new FormControl('', [Validators.required]),
  });


  resetFormGroup = new FormGroup({
    userEmail: new FormControl('', [Validators.required, Validators.pattern('^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$'), Validators.minLength(1)])
  });
  rbacSubject = new Subject<any>();

  constructor(private httpService: HttpService,
    public router: Router,
    public activatedRoute: ActivatedRoute,
    private aes: AesService,public dialog: MatDialog,
    private matIconRegistry: MatIconRegistry,private domSanitizer: DomSanitizer,
    private dataService: DataService, private locationStrategy: LocationStrategy,
    @Inject(DOCUMENT) private document: Document,
    private rebateNotifierService: RebateNotifierService,
    private bnIdle: BnNgIdleService,
    private authService:AuthService
  ) {


    this.matIconRegistry.addSvgIcon("eye-close",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/eye_close_icon.svg"))
      .addSvgIcon("eye-open",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/eye_open_icon.svg"))
   }





  loginFormReset = (event: { currentTarget: { reset: () => void; }; }) => {
    if(event && event.currentTarget){
      event.currentTarget.reset();
      this.loginFormGroup.reset();
    }

  }

  resetFormReset = (event: { currentTarget: { reset: () => void; }; }) => {
    event.currentTarget.reset();
    this.resetFormGroup.reset();
    this.resetError = false;
    this.resetSuccess = false;
  }

  ngOnInit(): void {
    // console.log("Password",this.aes.decrypt("U2FsdGVkX1+m33UuZOPDzsRSZ1pGhyQn8eLxPvesVqI="));
    this.logout();
    this.tenantType =this.activatedRoute.snapshot.paramMap.get('type');

    this.activatedRoute.queryParams
      .subscribe((params:any) => {
        console.log(params);
        // if(environment.baseUrl.includes('prod') && _isEmpty(params))  window.location.replace(environment.prideUrl);
        if(!_isEmpty(params)){
        if(params && params['error']){
          this.errorMessage =  params['error']
        } else if(params && params['email_address']&&params['pivot_contact_id']&&params['pivot_current_company_id']&&params['wordpress_user_id']){
          this.isSSO = true
          const currentReferrer = document.referrer;
          const allowedReferrer = environment.prideUrl;
          if(environment.baseUrl=='http://localhost:5000'||currentReferrer.includes('pridecentricresources')){}
          else if (!currentReferrer || currentReferrer !== allowedReferrer) {
              window.location.replace(environment.prideUrl);
            }
          this.initSSO({
            email: params['email_address'],
            contactId: params['pivot_contact_id'],
            currentCompanyId: params['pivot_current_company_id'],
            wpUserId: params['wordpress_user_id']
          })
        } else {
          this.ssoLoginError = 'Invalid Login Details'
        }
      }
        setTimeout(()=> {
          this.errorMessage = '';
        }, 5000);
      })
    if(this.tenantType){
      let body = {
        "slug": this.tenantType
      }
      this.httpService.checkValidTenant(body).subscribe((response:any)=>{
        if(response && response['data'] && response['data']['isTenantValid']==1){

        }else{
          this.preventBackButton()
        }
      })
      // this.returnUrl = this.activatedRoute.snapshot.queryParams.returnUrl || `${this.tenantType}/dashboard/summary`;
      // this.returnUrl = `${this.tenantType}/dashboard/summary`;
      this.returnUrl = this.activatedRoute.snapshot.queryParams.returnUrl || `${this.tenantType}/home`;
      this.returnUrl = `${this.tenantType}/home`;
      this.tokenVerify();
      this.testHealth();
    }else{
      this.preventBackButton()
    }

  }
  testHealth() {
    this.httpService.testHealth().subscribe(resp => {
      console.log('api health okay')
    }, (err) => {
    });
  }

  private tokenVerify() {
    this.verifyToken = this.activatedRoute.snapshot.queryParamMap.get('token');
    if (this.verifyToken !== null) {
      const verifyTokenBody = {
          token: this.verifyToken
        };
      this.httpService.emailVerification(verifyTokenBody).subscribe(resp => {
        this.verifyToken = null;
        localStorage.removeItem('userEmail');
        }, (err) => {
          this.showVerifyErrorMessage = true;
          this.verificationErrorMessage = _get(err, 'error.message.msg');
          if (_get(err, 'error.message.email')) {
            this.showResendText = true;
            this.resendEmailId = _get(err, 'error.message.email');
          } else {
            this.showResendText = false;
          }
          this.verifyToken = null;
          console.log(err);
        });
    }
  }

  // if verification failed, reverify called
  reverify() {
    this.showVerifyErrorMessage = false;
    this.verificationErrorMessage = '';
    const userEmail = localStorage.getItem('userEmail') || this.resendEmailId;
    const emailId = {
      email: userEmail
    };
    this.httpService.resendEmail(emailId).subscribe(response => {
      this.showVerifyErrorMessage = true;
      this.verificationErrorMessage = response.data.message;
      this.reverified = true;
    }, err => {
      this.showVerifyErrorMessage = true;
      this.verificationErrorMessage = _get(err, 'error.message');
      console.log(err);
    }
    );
}

initSSO = (userInfo:any) => {
    if(!userInfo || !userInfo['email']) return false;
    this.loader = true;
    const body = {
          email: this.aes.encrypt(_get(userInfo, 'email')),
          userInfo: this.aes.encrypt(JSON.stringify(userInfo)),
          slug:this.tenantType?this.tenantType:'demo'
        };
        this.httpService.ssoLogin(body).subscribe(
          response => {
            console.log('logged in', response['data'])
            // this.sessionTimeout();
  
            const sessionId = uuidv4();
            localStorage.setItem('sessionId', sessionId);
            localStorage.setItem('userMail', this.aes.encrypt(_get(body, 'email')));
  
            this.loader = false;
            // setting userid to local storage
            // sessionStorage suggested, discuss with Prabhanshu
            localStorage.setItem('userId', _get(response, 'data.id'));
            localStorage.setItem('isSSOLogin','true');
            // localStorage.setItem('token', _get(response, 'data.jwtToken'));
            localStorage.setItem('username', response?response['data']['name']:'');
            this.tokenGenerated = response.data.jwtToken;
            localStorage.setItem('token', this.tokenGenerated); // remember me feature
            localStorage.setItem('tenant',response?response['data']['tenantName']:this.tenantType);
            localStorage.setItem('userTypeId',response?response['data']['userTypeId']:'')
            // localStorage.setItem('role',response?response['data']['role']:'')
            // localStorage.setItem('userType',response?response['data']['userType']:'')
            localStorage.setItem('userGroupId',response?response['data']['userGroupId']:'')
            localStorage.setItem('userFirstLogin',response?response['data']['userFirstLogin']:'')
            localStorage.setItem('companyFirstLogin',response?response['data']['companyFirstLogin']:'')
  
            this.httpService.validToken = this.tokenGenerated;
            this.httpService.loggedInUsername = response.data.name;
            this.authService.autoLogin();
            this.dataService.rbacSubject.next();
            this.errorMessage = '';
            window.onbeforeunload = () => {
              if(localStorage.getItem('token'))
              localStorage.setItem('tokenExpirationTime', `${new Date().getTime() + 900000}`); // 900000 ms = 15 minutes
            };
            
            if(response){
              this.httpService.getLastUpdatedDate().subscribe((response:any)=>{
                if(response && response['data']){
                  localStorage.setItem('lastUpdatedDate',response['data'])
                }
              })
            }
              this.router.navigateByUrl(this.returnUrl);
          }, error => {
            console.log('err', error)
            this.ssoLoginError = _get(error, 'error.message', 'Something Went wrong...');
            this.loader = false;
          }
          );
  }

  userloginSubmit = (event: any) => {
    this.rebateNotifierService.addNotification('info', 'hello');

    if (this.loginFormGroup.valid) {
      // reset form
        this.loader = true;
        const body = {
          email: this.aes.encrypt(_get(this.loginFormGroup, 'value.loginemail')),
          password: this.aes.encrypt(_get(this.loginFormGroup, 'value.password')),
          slug:this.tenantType?this.tenantType:'tenant1'
        };
        this.httpService.userLogin(body).subscribe(
        response => {
          console.log('logged in', response['data'])
          // this.sessionTimeout();

          const sessionId = uuidv4();
          localStorage.setItem('sessionId', sessionId);
          localStorage.setItem('userMail', this.aes.encrypt(_get(body, 'email')));

          this.loader = false;
          // setting userid to local storage
          // sessionStorage suggested, discuss with Prabhanshu
          localStorage.setItem('userId', _get(response, 'data.id'));
          // localStorage.setItem('token', _get(response, 'data.jwtToken'));
          localStorage.setItem('username', response?response['data']['name']:'');
          this.tokenGenerated = response.data.jwtToken;
          localStorage.setItem('token', this.tokenGenerated); // remember me feature
          localStorage.setItem('tenant',response?response['data']['tenantName']:this.tenantType);
          localStorage.setItem('userTypeId',response?response['data']['userTypeId']:'')
          // localStorage.setItem('role',response?response['data']['role']:'')
          // localStorage.setItem('userType',response?response['data']['userType']:'')
          localStorage.setItem('userGroupId',response?response['data']['userGroupId']:'')
          localStorage.setItem('userFirstLogin',response?response['data']['userFirstLogin']:'')
          localStorage.setItem('companyFirstLogin',response?response['data']['companyFirstLogin']:'')

          this.httpService.validToken = this.tokenGenerated;
          this.httpService.loggedInUsername = response.data.name;
          this.authService.autoLogin();
          this.dataService.rbacSubject.next();
          this.errorMessage = '';
          if(response){
            this.httpService.getLastUpdatedDate().subscribe((response:any)=>{
              if(response && response['data']){
                localStorage.setItem('lastUpdatedDate',response['data'])
              }
            })
          }
          this.isFirstLogin = response['data']['userFirstLogin']
          // find the user is old or new, then decide which route to send to
          // this.checkUserOldOrNew();

          // defaulted to homepage after first login
          if(response['data']['userFirstLogin']==1){
            this.openDialog(event);
          }
          // else if(response['data']['companyFirstLogin']==1){
          //   this.router.navigate([`/${this.tenantType}/file-management`])
          // }
          else{
            this.router.navigateByUrl(this.returnUrl);
          }
        }, err => {
          this.errorMessage = _get(err, 'error.message');
          setTimeout(()=> {
            this.errorMessage = '';
          }, 5000);
          this.loader = false;
        }
        );
        this.loginFormReset(event);



    }
  }

  // sessionTimeout() {
  //   this.bnIdle.startWatching(CONSTANTS.sessionTimeoutLimit).subscribe((isTimedOut: boolean) => {
  //     if (isTimedOut) {
  //       console.log('session expired');
  //       // alert('bug');
  //       this.logout();
  //     }
  //   });
  // }

  // Reset Password

resetPassword = (event: any) => {
    if (this.resetFormGroup.valid) {
      // reset pw form
      const object = {
        email: _get(this.resetFormGroup, 'value.userEmail'),
        slug:this.tenantType
      };
      this.httpService.resetPassword(object).subscribe(response => {
        this.resetError = false;
        this.resetSuccess = true;
        this.resetSuccessMessage = response.data.message;
        localStorage.setItem('userEmail', _get(object, 'email'));
      }, err => {
        this.resetSuccess = false;
        this.resetError = true;
        this.resetErrorMessage = _get(err, 'error.message');
      }
      );
      this.resetFormReset(event);
    }
  }

signUpForm() {
  //  this.router.navigate(['sign-up']);
    this.signIn = false;
    this.resetPw = false;
  }

resetPasswordForm() {
    this.resetPw = true;
    this.signIn = false;
    this.resetFormGroup.reset();
  }

  resendEmail() {
    this.resetSuccessMessage = '';
    const object = {
      email: localStorage.getItem('userEmail')
    };
    //Un Comment once reset password is integrated with API

    // this.httpService.resetPassword(object).subscribe(response => {
    //   this.resetSuccess = true;
    //   this.resetSuccessMessage = response.data.message;
    // }, err => {
    //   this.resetError = true;
    //   this.resetErrorMessage = _get(err, 'error.message');
    // }
    // );
  }
    //Un Comment if 2 step login is necessary
  // next(pos:any){
  //   if(pos==0){
  //     if(this.loginFormGroup.controls['loginemail'].value !=''  && !this.loginFormGroup.controls['loginemail']?.hasError('pattern')){
  //       this.indexPosition = this.indexPosition+1
  //     }else{

  //     }
  //   }else{

  //   }
  // }

  preventBackButton() {
    this.openNotificationDialog();
      let actualTenant = localStorage.getItem("tenant")
      sessionStorage.clear();
      localStorage.clear()
      // alert('cleared session')
      console.log('localstorage cleared')
  }

  logout() {
    // alert('logout called')
    const tenant = localStorage.getItem('tenant');
    sessionStorage.clear();
    localStorage.clear();
    this.authService.logout();
    console.log('364 localstorage cleared')
    if(tenant){
      console.log('we have a tenant',tenant);
      this.router.navigate([tenant, 'login']);
    }
    // if(tenant===null && environment.baseUrl ==='https://rap-pride-prod-node-app.azurewebsites.net'){
    //   window.location.replace(environment.prideUrl);
    // }else {
    //   console.log('tenent is null');
    // }
  }

  openNotificationDialog = () =>{
    const dialogref= this.dialog.open(NotificationsComponent, {
      //width: '400px',
      //width: '30%'
      width: '366px',
      height: '389px',
      disableClose: true,
      panelClass: 'dialog-container-custom'
    })
    dialogref.afterClosed().subscribe((response:any)=>{
      this.document.location.href = "https://www.rebate.ai/"
    })
  }


  openDialog(event:any): void {
    const dialogRef = this.dialog.open(TermsConditionsComponent, {
      //width: '400px',
      //width: '30%'
      width: '366px',
      disableClose: true,
      panelClass: 'dialog-container-custom'
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result==true){
        const dialogRef2 = this.dialog.open(UpdatePasswordComponent, {
          maxHeight: '90vh',
          minHeight: '40vh',
          data: {"tenenat":this.tenantType,"firstLogin":this.isFirstLogin},
          disableClose: true,
        });
        dialogRef2.afterClosed().subscribe(result => {
          if(result==1){
            this.httpService.updateFirstLogin({"isNew":0}).subscribe((response:any)=>{
              if(response && response['data']['code']==1){
                this.router.navigate([`/${this.tenantType}/home`])
              } else{
                this.router.navigateByUrl(this.returnUrl);
              }
            })

          }else{
            this.router.navigateByUrl(this.returnUrl);
          }
        })
      }


    });
  }

  isDisplay(){
    this.hide = !this.hide
  }

  openPrivacyPolicy = () =>{
    window.open(getPrivacyLink(),"_blank")
  }

  openTerms = () =>{
    window.open(getTermsLink(),"_blank")
  }
 }
