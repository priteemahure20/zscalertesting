import { HttpClient, HttpClientModule, HttpErrorResponse, HttpHandler } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormGroup, FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { HttpService } from 'src/app/services/http.service';
import { SharedModule } from 'src/app/shared/shared.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { LoginComponent } from './login.component';
import { ActivatedRoute, Params } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import SpyObj = jasmine.SpyObj;
import createSpyObj = jasmine.createSpyObj;

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let httpService: HttpService;

  let spyHttpService: SpyObj<HttpService>;

  let originalTimeout: number
  const activatedRouteMock = {
    snapshot: {
      paramMap: {
        get() { return {"type":"IMARK"} }
      },
      queryParamMap:{
        get() { return {"token":"sadasi121njjdsjfdsjf"} }
      },
      queryParams:{
        returnUrl:"IMARK"
      }
    },
  };
  beforeEach(function () {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
  });

  afterEach(function () {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });
  // const formData = {
  //   username: 'sb_admin_user@personalgenome.com',
  //   password: 'atlas123',
  // }
  beforeEach((() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
        // ForgotFakeModule
        BrowserModule,
        AppRoutingModule,
        SharedModule,
        BrowserAnimationsModule,
        HttpClientTestingModule, RouterTestingModule
      ],

      declarations: [

        LoginComponent,
      ],

      providers: [
        HttpClient,
        { provide: ActivatedRoute, useValue: activatedRouteMock },
        HttpService,
        HttpTestingController
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA
      ]
    }
    )
      .compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    httpService = TestBed.inject(HttpService);

  }));
  afterAll(() => {
    TestBed.resetTestingModule();
  });

  it('should create a FormGroup comprised of FormControls', () => {
    component.ngOnInit();
    expect(component.loginFormGroup instanceof FormGroup).toBe(true);
  });

  it('should reset login form', () => {
    let event = { currentTarget: { reset: () => void {} } }
    component.loginFormGroup.controls?.['loginemail']?.setValue("test@gmail.com");
    component.loginFormGroup.controls?.['password']?.setValue("test123");
    fixture.detectChanges();
    component.loginFormReset(event);
  })

  it('should reset resetForm', () => {
    let event = { currentTarget: { reset: () => void {} } }
    component.resetFormReset(event);

  })

  it('should call verify token', () => {
 
    let dataBody = {
      "token": "dcdscdsc#dsfdsfs4fdgfdgfd&dsfsd",
    }
    spyOn(httpService, 'emailVerification').and.returnValue(of(dataBody));
    fixture.detectChanges();
    component['tokenVerify']();   

   
  })
  it('should call verify token to verify Error message', () => {
    spyOn(httpService, 'emailVerification').and.returnValue(throwError({error:{message:{email:"email not found"}}}));
    fixture.detectChanges();
    component['tokenVerify']();
   
  })

  it('should call verify token to verify Error message with else condition', () => {
    spyOn(httpService, 'emailVerification').and.returnValue(throwError({error:{message:{email:undefined}}}));
    fixture.detectChanges();
    component['tokenVerify']();
   
  })



  it('should call reVerify',()=>{
    const mockResult = {
      "data": {
        "message": "Email verified successfully",
      }
    }
    localStorage.setItem('userEmail',"test@gmail.com");
    spyOn(httpService, 'resendEmail').and.returnValue(of(mockResult));
    fixture.detectChanges();
    component.reverify();

   
  })


  it('should call verify token to verify Error message with else condition',()=>{
    spyOn(httpService, 'resendEmail').and.returnValue(throwError({error:{message:undefined}}));
    fixture.detectChanges();
    component.reverify();

  })

  it('should call userloginSubmit for valid form',()=>{
    component.loginFormGroup.controls?.['loginemail']?.setValue("test@gmail.com");
    component.loginFormGroup.controls?.['password']?.setValue("test123")
    component.tenantType="IMARK";
    const mockResult = {
      "data": {
        "id": "gopidinni.kteja@gmail.com",
        "name": "Krishna",
        "jwtToken": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImdvcGlkaW5uaS5rdGVqYUBnbWFpbC5jb20iLCJpYXQiOjE2MzE2OTE0NjMsImV4cCI6MTYzMTc3Nzg2M30.o-cAzJwBM00GGpAEizeXWjh3R6SaoPgBSapWnGILQX99bBWMF-MztbIjY2Bm1SEPMIv2tUHvvE2WRmOvJ8lOuEC8OLBLUjiVxuLwOIwJteAoKohpnHqdMlqBhkRR-BohEk2N_lwE41Q2aieEFiYwpZjbyQ93Ov3LcsPoq7ns9Pg"
      }
    }
    spyOn(httpService, 'userLogin').and.returnValue(of(mockResult));
    let event = { currentTarget: { reset: () => void {} } }
    fixture.detectChanges();
    component.userloginSubmit(event);
    expect(component.tokenGenerated).toBe('eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImdvcGlkaW5uaS5rdGVqYUBnbWFpbC5jb20iLCJpYXQiOjE2MzE2OTE0NjMsImV4cCI6MTYzMTc3Nzg2M30.o-cAzJwBM00GGpAEizeXWjh3R6SaoPgBSapWnGILQX99bBWMF-MztbIjY2Bm1SEPMIv2tUHvvE2WRmOvJ8lOuEC8OLBLUjiVxuLwOIwJteAoKohpnHqdMlqBhkRR-BohEk2N_lwE41Q2aieEFiYwpZjbyQ93Ov3LcsPoq7ns9Pg');
   
  })

   it('should call userloginSubmit for invalid form',()=>{
    component.loginFormGroup.controls?.['loginemail']?.setValue("");
    component.loginFormGroup.controls?.['password']?.setValue("")
    component.tenantType="IMARK";
    const mockResult = {
      "data": {
        "id": "gopidinni.kteja@gmail.com",
        "name": "Krishna",
        "jwtToken": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImdvcGlkaW5uaS5rdGVqYUBnbWFpbC5jb20iLCJpYXQiOjE2MzE2OTE0NjMsImV4cCI6MTYzMTc3Nzg2M30.o-cAzJwBM00GGpAEizeXWjh3R6SaoPgBSapWnGILQX99bBWMF-MztbIjY2Bm1SEPMIv2tUHvvE2WRmOvJ8lOuEC8OLBLUjiVxuLwOIwJteAoKohpnHqdMlqBhkRR-BohEk2N_lwE41Q2aieEFiYwpZjbyQ93Ov3LcsPoq7ns9Pg"
      }
    }
    spyOn(httpService, 'userLogin').and.returnValue(of(mockResult));
    let event = { currentTarget: { reset: () => void {} } }
    fixture.detectChanges();
    component.userloginSubmit(event);
    expect(component.loginFormGroup.invalid).toBeTruthy();
    expect(component.tokenGenerated).toBe(undefined);

  })

  it('should call userloginSubmit for valid form but invalid response',()=>{
    component.loginFormGroup.controls?.['loginemail']?.setValue("test@gmail.com");
    component.loginFormGroup.controls?.['password']?.setValue("test123")
    component.tenantType="IMARK";
    const mockResult = {
      "data": {
        "id": "gopidinni.kteja@gmail.com",
        "name": "Krishna",
        "jwtToken": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImdvcGlkaW5uaS5rdGVqYUBnbWFpbC5jb20iLCJpYXQiOjE2MzE2OTE0NjMsImV4cCI6MTYzMTc3Nzg2M30.o-cAzJwBM00GGpAEizeXWjh3R6SaoPgBSapWnGILQX99bBWMF-MztbIjY2Bm1SEPMIv2tUHvvE2WRmOvJ8lOuEC8OLBLUjiVxuLwOIwJteAoKohpnHqdMlqBhkRR-BohEk2N_lwE41Q2aieEFiYwpZjbyQ93Ov3LcsPoq7ns9Pg"
      }
    }
    spyOn(httpService, 'userLogin').and.returnValue(throwError({error:{message:undefined}}));
    let event = { currentTarget: { reset: () => void {} } }
    fixture.detectChanges();
    jasmine.clock().install();  
    component.userloginSubmit(event);
    jasmine.clock().tick(5000); // waits till 5000 milliseconds
    expect(component.errorMessage).toBe('');  // Then executes this
    jasmine.clock().uninstall();
  })

  it('should call reset form',()=>{
    component.resetFormGroup.controls['userEmail'].setValue("test@gmail.com");
    const mockResult = {
      "data": {
        "message":"email sent successfully"
      }
    }
    spyOn(httpService, 'resetPassword').and.returnValue(of(mockResult));
    let event = { currentTarget: { reset: () => void {} } }
    fixture.detectChanges();
    component.resetPassword(event);

  })

  it('should call reset form invalid response',()=>{
    component.resetFormGroup.controls['userEmail'].setValue("test@gmail.com");
    const mockResult = {
      "data": {
        "message":"email sent successfully"
      }
    }
    spyOn(httpService, 'resetPassword').and.returnValue(throwError({error:{message:undefined}}));
    let event = { currentTarget: { reset: () => void {} } }
    fixture.detectChanges();
    component.resetPassword(event);

  })

  it('should call signup form',()=>{
    component.signUpForm();

  })

  it('should call resetPasswordForm',()=>{
    component.resetPasswordForm();

  })

  it('should call resendEmail',()=>{
    component.resendEmail();

  })

});
