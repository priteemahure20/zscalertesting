import {Component, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserType } from 'src/app/helpers/constants';
import { navs } from 'src/app/rbac/landing-page';
import {MatIconRegistry} from '@angular/material/icon';
import {DomSanitizer} from '@angular/platform-browser';
import { get as _get } from 'lodash';
import { AuthService } from 'src/app/services/auth.service';
import { User } from 'src/app/models/user.model';
import {HttpService} from '../../services/http.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  public tenantType: any;
  navs: any;
  lastUpdateDate:any;
  constructor(public router: Router,
    private activatedRoute: ActivatedRoute,private matIconRegistry: MatIconRegistry,private domSanitizer: DomSanitizer,private authService:AuthService,private httpService: HttpService, private dataService:DataService) {
    this.matIconRegistry.addSvgIcon("associate",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/dasboard-associate.svg"))
        .addSvgIcon("dashboard",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/dashboard-mydashboard.svg"))
        .addSvgIcon("rebate",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/dashboard-rebate.svg"))
        .addSvgIcon("user",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/dashboard-user.svg"))
        .addSvgIcon("payment",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/dashboard-payment.svg"))
        .addSvgIcon("payout",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/dashboard-payout.svg"))
        .addSvgIcon("file-management",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/dashboard-file.svg"))
        .addSvgIcon("database-management",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/dashboard-database.svg"))
        .addSvgIcon("report-generator",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/report-generator-icon.svg"))
        .addSvgIcon("payout-management",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/report-generator-icon.svg"))
        this.dataService.wndowSrollYEmitter.emit(1);

  }

  ngOnInit(): void {

    localStorage.removeItem("governanceTicket")
    // console.log( my-dashboard
    //   'Activated route data in Component:::',
    //   this.activatedRoute.data
    // );
    this.httpService.getLastUpdatedDate().subscribe((response:any)=>{
      if(response && response['data']){
        response['data'] = new Date(response['data']);
        this.lastUpdateDate = response['data'];
        localStorage.setItem('lastUpdatedDate',this.lastUpdateDate)
      }
    })
    if(localStorage.getItem('createdProgramId')){
      localStorage.removeItem('createdProgramId')
    }


    this.activatedRoute.data.subscribe((response: any) => {
      // console.log('data FETCHING', response);
      // console.log('data FETCHED');
    });

    this.tenantType = localStorage.getItem('tenant');
    this.activatedRoute.params.subscribe((value: any) => {
      if(value && value['hierarchy']){
        this.router.navigate([`/${this.tenantType}/my-dashboard`,{hierarchy:true}])
      }
    })
    this.rbac();
  }

  rbac() {
    // const userType = localStorage.getItem('userType') as UserType;
    //const userType = this.authService.getUser()?.userType as UserType;
    // // const userRole = localStorage.getItem('role');
    // const userRole = this.authService.getUser()?.role;
    const {userType,role:userRole} = this.authService.getUser() as User;
    //console.log(userRole,userType, '============user role===========');
    if(userType == 'DEALER'){
      for (let index = 0; index < navs.length; index++) {
        if(navs[index]['name'] == 'User Library'){
          navs[index]['info'] = 'This section allows you to view business associate users'
        } else if(navs[index]['name'] == 'Rebate Library'){
          navs[index]['info'] = 'This section enables you to view the rebate programs'
        }
      }
    }
    
    this.navs = navs.filter(n => {
      if (n.userTypes.includes(userType)) {
        const allowedRoles = _get(n, `roles.${userType}`);
        // console.log(allowedRoles, '=============allowed roles ==============');

        if (allowedRoles.includes(userRole)) {
          return true;
        } else {
          return false;
        }
      } 
      return false;
    });

  }
  

  navigateUrl(urlName:string): void{
    this.router.navigate([`/${this.tenantType}/${urlName}`])
  }

}
