import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberProductCategorizationComponent } from './member-product-categorization.component';

describe('MemberProductCategorizationComponent', () => {
  let component: MemberProductCategorizationComponent;
  let fixture: ComponentFixture<MemberProductCategorizationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MemberProductCategorizationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberProductCategorizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
