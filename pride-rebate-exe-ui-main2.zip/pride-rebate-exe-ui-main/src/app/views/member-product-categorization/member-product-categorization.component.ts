import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTableDataSource } from '@angular/material/table';
import { UpdateAllCategoariesComponent } from 'src/app/common/update-all-categoaries/update-all-categoaries.component';
import { CONSTANTS } from 'src/app/helpers/constants';
import { HttpService } from 'src/app/services/http.service';
import { get as _get, reduce as _reduce, isEqual as _isEqual, isEmpty as _isEmpty } from 'lodash';
import * as moment from 'moment';
import { SpinnerService } from 'src/app/services/spinner.service';
import { TitleCasePipe } from '@angular/common';
import { of, Subject } from 'rxjs';
import { debounceTime, delay, distinctUntilChanged, map, mergeMap } from 'rxjs/operators';

@Component({
  selector: 'app-member-product-categorization',
  templateUrl: './member-product-categorization.component.html',
  styleUrls: ['./member-product-categorization.component.scss']
})
export class MemberProductCategorizationComponent implements OnInit {
  columnsToDisplay = [
    {header: 'Select', field: 'select'},
    {header: 'Supplier Name', field: 'supplierName'}, 
    {header: 'Product Description', field: 'productDescription'}, 
    {header: 'Predicted Category', field: 'predictedCategory'}, 
    {header: 'Updated Category', field: 'updatedCategory'}, 
    {header: 'Last Updated', field: 'lastUpdated'}, 
    {header: 'Updated By', field: 'updatedBy'}
  ];
  columnsProps = this.columnsToDisplay.map(column => column.field);
  dataSource: any;
  products:any = [];
  suppliers:any = [];
  memberProductCategoryData:any =[];
  selectedSupplierValue = '';
  selectedProductValue ='';
  searchValue='';
  rowsSelected:any = [];
  supplierDropdown: any = [];
  dialogRef:any;
  options:any = []
  successMessage:string='';
  selectedOptionLabel:any;
  tableTotal: any = 0; 
  tablePayoad: any = {
    pageNo: 1,
    pageSize: 15,
  };
  pageNo: number = 1;
  keyUp = new Subject<KeyboardEvent>();
  productDescriptionSearchText: any;

  constructor(private httpService: HttpService,public dialog: MatDialog,
    private snackBar: MatSnackBar,
    private spinner: SpinnerService,private titlecasePipe:TitleCasePipe) { }

  ngOnInit(): void {
    this.screenDataFetch();
    this.fetchOptions();
    this.searchByProductDescription();
  }

  public searchByProductDescription = () => {
    this.keyUp.pipe(
      map(event => event),
      debounceTime(1000),
      distinctUntilChanged(),
      mergeMap(search => of(search).pipe(
        delay(500),
      )),
    ).subscribe((res:any) => {
      let searchText = res['target']['value'];
      console.log('searching: ', res['target']['value']);
      this.productDescriptionSearchText = searchText;
      this.tablePayoad.pageNo =1;
      this.searchMemberProductData(this.selectedSupplierValue, this.selectedProductValue, this.productDescriptionSearchText);
    });
  }

  fetchOptions() {
    this.httpService.getMasterCategories().subscribe((response)=>{
      this.supplierDropdown = {
        supplierDropdown: [...response['data']]
      } 
      this.options= [...response['data']];
      this.options.unshift({ displayText: CONSTANTS.mpcNone, value: CONSTANTS.mpcNone });
      // console.log('supplierdropdown none twice: ', this.supplierDropdown);
    })
  }

  screenDataFetch() {
    const payload = {
      pageSize: this.tablePayoad.pageSize,
      pageNo: this.tablePayoad.pageNo
    }
    if(payload && payload['pageNo']==1){
      this.dataSource && this.dataSource.data.length>0?this.dataSource.data=[]:''
    }
    this.httpService.fetchProductCategoryPrequests(payload).subscribe((response)=>{
      if(response){
        this.products = response['data']['product'];
        this.suppliers = response['data']['supplier'];
        this.memberProductCategoryData = response['data']['memberProductCategory'];
        this.tableTotal = response['data']['count'];
        // console.log('tablecount in comp: ', this.tableTotal);
        this.fillData(this.memberProductCategoryData);

      }
    })
  }

  fillData(actualData:any) {
    const tableData = [];
   
    // tslint:disable-next-line: prefer-for-of
    if(actualData && actualData.length>0){
      for (let i = 0; i < actualData.length; i++) {
        let data = {
          supplierName: '',
          productDescription: '',
          predictedCategory: '',
          updatedCategory: '',
          lastUpdated: '',
          updatedBy: '',
          memberId:0
        };
        data.supplierName = actualData[i]&& actualData[i]['SUPPLIER_NAME']?
        actualData[i]['SUPPLIER_NAME']:'NA';
        data.productDescription = actualData[i]&& actualData[i]['PRODUCT_DESCRIPTION']?
        actualData[i]['PRODUCT_DESCRIPTION']:'NA';
        data.predictedCategory = actualData[i]&& actualData[i]['PREDICTED_CATEGORY']?
        actualData[i]['PREDICTED_CATEGORY']:'NA';
        data.updatedCategory = actualData[i]&& actualData[i]['UPDATED_CATEGORY']?
        actualData[i]['UPDATED_CATEGORY']:'None';
        data.lastUpdated = actualData[i]&& actualData[i]['UPDATED_DATE']?actualData[i]['UPDATED_DATE']:'NA';
        data.updatedBy = actualData[i]&& actualData[i]['UPDATED_BY']?
       actualData[i]['UPDATED_BY']:'NA';
        data.memberId = actualData[i]&& actualData[i]['MEMBER_PRODUCT_CATEGORY_ID']?actualData[i]['MEMBER_PRODUCT_CATEGORY_ID']:'NA';
        tableData.push(data);
      }
      this.dataSource = new MatTableDataSource(tableData);
    }
  
  }

  // pageNo, pageSize
  selectedSupplier = (event:any,type:string) =>{   
    
    this.selectedSupplierValue = event && event['value'] ? event['value'] : '';
    this.tablePayoad.pageNo = 1;
    const payload = {
      supplier: this.selectedSupplierValue,
      category: this.selectedProductValue,
      productDescription: this.productDescriptionSearchText,
      pageSize: this.tablePayoad.pageSize,
      pageNo: this.tablePayoad.pageNo
    }
    if(payload && payload['pageNo']==1){
      this.dataSource && this.dataSource.data.length>0?this.dataSource.data=[]:''
    }
    this.httpService.getMemberProductData(payload).subscribe((response)=>{
      if(response && response['data']){
        this.memberProductCategoryData = response['data']['data'];
        this.tableTotal = response['data']['count'];
        this.fillData(this.memberProductCategoryData);
      }
    });
  }

  // pageNo, pageSize
  selectedProduct = (event:any,type:any) =>{
    this.selectedProductValue = event && event['value']?event['value']:'';
    this.tablePayoad.pageNo =1;
    const payload = {
      supplier: this.selectedSupplierValue,
      category: this.selectedProductValue,
      productDescription: this.productDescriptionSearchText,
      pageSize: this.tablePayoad.pageSize,
      pageNo: this.tablePayoad.pageNo
    }
    if(payload && payload['pageNo']==1){
      this.dataSource && this.dataSource.data.length>0?this.dataSource.data=[]:''
    }
    this.httpService.getMemberProductData(payload).subscribe((response)=>{
      if(response && response['data']){
        this.memberProductCategoryData = response['data']['data'];
        this.tableTotal = response['data']['count'];
        this.fillData(this.memberProductCategoryData);
      }
    })
  }

  selectedRows = (data:any) => {
   this.rowsSelected =data
  }

  editAll = () =>{
     this.dialogRef = this.dialog.open(UpdateAllCategoariesComponent, {
      maxHeight: '90vh',
      minHeight: '40vh',
      data: {"options":this.options},
      disableClose: true,
    });
    this.dialogRef.afterClosed().subscribe((result:any) => {
      console.log('dialog editall closed: ', result);
      if (_isEmpty(result)) {
        return;
      }
      let obj:any ={}
      let ids:any=[]
      let allIds:any=[]
      console.log('this.rowSelected: ', this.rowsSelected);
      this.rowsSelected.forEach((element:any) => {
        allIds.push(element['memberId'])
        ids.push({id:element['memberId'],description:element['productDescription']})
      });
      obj['id']=allIds;
      if (_isEqual(result, _get(CONSTANTS, 'mpcNone', 'None'))) {
        obj['updatedCategory'] = result;
      } else {
        obj['updatedCategory'] = parseInt(result);
      }
      this.selectedOptionLabel = this.options.find((obj:any) => {
        if(result == obj['value']){
          return obj;
        }
      });
      console.log('obj for updateProductCategory: ', obj);
      this.httpService.updateProductCategory(obj).subscribe((response:any) => {
        this.snackBar.open(`Update successful`, 'Ok', {
          duration: 2000,
        });
        if(response && response['data'] && response['data']['message']){
            this.successMessage = response['data']['message'];
            if(this.successMessage){
              for(let j=0;j<this.dataSource['data'].length;j++){
                for(let i=0;i<ids.length;i++){
                  let currentUTCDate = this.updateWithCurrentUTCDate();
                  let userName  = localStorage.getItem("userId"); 
                  if(this.dataSource['data'][j]['memberId']==ids[i] || this.dataSource['data'][j]['productDescription']==ids[i]['description']){
                    this.dataSource['data'][j]['updatedBy'] = userName;
                    this.dataSource['data'][j]['lastUpdated'] = currentUTCDate;
                    this.dataSource['data'][j]['updatedCategory'] = this.selectedOptionLabel['displayText'];
                  }
                 
                }
              }
             
             
            // this.dataSource['data'].find((obj:any) => {
            //   let currentUTCDate = this.updateWithCurrentUTCDate();
            //   let userName  = localStorage.getItem("username"); 
            //   obj.lastUpdated = currentUTCDate;
            //   obj.updatedBy = userName
            //   obj.updatedCategory = this.selectedOptionLabel['displayText']
            //   });
            }
        }

      }, (err) => {
        console.log(err);
        const errorMessage = _get(err, 'message') || 'Error occured';
        this.snackBar.open(errorMessage, 'Ok', {
          duration: 2000,
        });
      })

    });
    
  }

  searchMemberProductData(supplier: string, category: string, prodDescSearch: string) {
    const payload = {
      supplier,
      category,
      productDescription: prodDescSearch,
      pageSize: this.tablePayoad.pageSize,
      pageNo: this.tablePayoad.pageNo
    }
    if(payload && payload['pageNo']==1){
      this.dataSource && this.dataSource.data.length>0?this.dataSource.data=[]:''
    }
    this.httpService.getMemberProductData(payload).subscribe((response)=>{
      if(response && response['data']){
        this.memberProductCategoryData = response['data']['data'];
        this.tableTotal = response['data']['count'];
        this.fillData(this.memberProductCategoryData);
      }
    })
  }
  
  updateWithCurrentUTCDate = () =>{
    const format1 = "YYYY-MM-DD HH:mm:ss"
    return moment.utc(new Date()).subtract(8, 'hours').format(format1);
  }
  getNextPage = (data:any) =>{
    const pageNo = parseInt(data['pageIndex']) + 1;
    this.tablePayoad['pageNo'] = pageNo;  
    this.tablePayoad['pageSize'] = data['pageSize'];
    console.log('pageno and pagesize: ', this.tablePayoad);
    if((this.selectedSupplierValue != 'none' && this.selectedSupplierValue !='') || 
    this.selectedProductValue !='none' && this.selectedProductValue !='' ||
    this.productDescriptionSearchText !== ''){
      this.searchMemberProductData(this.selectedSupplierValue, this.selectedProductValue, this.productDescriptionSearchText);
    } else {
      this.screenDataFetch();
    }
  }


}
