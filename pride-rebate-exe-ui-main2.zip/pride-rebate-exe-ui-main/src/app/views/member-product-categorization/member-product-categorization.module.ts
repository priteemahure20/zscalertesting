import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MemberProductCategorizationRoutingModule } from './member-product-categorization-routing.module';
import { MemberProductCategorizationComponent } from './member-product-categorization.component';
import { CommonCompsModule } from 'src/app/shared/common-comps.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { NgSelectModule } from '@ng-select/ng-select';


@NgModule({
  declarations: [
    MemberProductCategorizationComponent
  ],
  imports: [
    CommonModule,
    MemberProductCategorizationRoutingModule,
    CommonCompsModule,
    SharedModule,
    NgSelectModule

  ],
})
export class MemberProductCategorizationModule { }
