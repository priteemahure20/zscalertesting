import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatToolComponent } from './pat-tool.component';

describe('PatToolComponent', () => {
  let component: PatToolComponent;
  let fixture: ComponentFixture<PatToolComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatToolComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PatToolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
