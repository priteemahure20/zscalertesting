import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PatToolRoutingModule } from './pat-tool-routing.module';
import { PatToolComponent } from './pat-tool.component';


@NgModule({
  declarations: [
    PatToolComponent
  ],
  imports: [
    CommonModule,
    PatToolRoutingModule
  ]
})
export class PatToolModule { }
