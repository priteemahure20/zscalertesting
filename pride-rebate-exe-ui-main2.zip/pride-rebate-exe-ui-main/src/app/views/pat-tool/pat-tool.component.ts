import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pat-tool',
  templateUrl: './pat-tool.component.html',
  styleUrls: ['./pat-tool.component.scss']
})
export class PatToolComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
