import { Component, OnInit } from '@angular/core';
import { rbac } from '../../rbac/routes';
import {UserType} from '../../helpers/constants';
import {Router} from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-my-dashboard',
  templateUrl: './my-dashboard.component.html',
  styleUrls: ['./my-dashboard.component.scss']
})
export class MyDashboardComponent implements OnInit {
  userType:any=""
  constructor(public router: Router,private authService:AuthService) { }
  ngOnInit(): void {
    // this.userType = localStorage.getItem('userType') as UserType;
    this.userType = this.authService.getUser()?.userType as UserType;
  }



}
