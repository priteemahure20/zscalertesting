import {Component, OnInit, SimpleChanges} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { DataService } from 'src/app/services/data.service';
import {Role, UserType, YEAR} from '../../../helpers/constants';
import {HttpService} from '../../../services/http.service';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { AuthService } from 'src/app/services/auth.service';
import { SucessMessageModalComponent } from 'src/app/common/sucess-message-modal/sucess-message-modal.component';
import {MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-distributor-dashboard',
  templateUrl: './distributor-dashboard.component.html',
  styleUrls: ['./distributor-dashboard.component.scss']
})
export class DistributorDashboardComponent implements OnInit {
  userType:any;
  tenantType:any="";
  lastUpdateDate:any
  isListView:boolean = true;
  isToogledSupplier:boolean= true;
  totalSales:any=0;
  avgRatePercent:any=0;
  rebatableSales:any=0;
  payout:any=0;
  // growthContentValue:number = 0
  // growthDistributorCnt:number=0;
  // growthProgramCnt:number=0
  settledPayment:number=0
  outStandingBalance:number = 0
  totalDisputes:number=0;
  rebateEarned:any=0;
  rebateSettled:any=0;
  totalPurchaseYoy:any=0;
  rebateEarnedYoy:any=0;
  rebatablePurchase:any=0
  pieChartData:any=[];
  reviewObj:any={}
  pendingObj:any={}
  resolvedObj:any={}
  globalYears:any=[]
  selctedGlobalYear:any;
  control = new FormControl('');
  filteredSuppliers: Observable<any[]> | undefined;
  autoCompleteSuppliers:any=[];
  loggedInSupplierId:any;
  hierarcialData:any=[]
  hierarcialTotalData:any=[]
  growthOpportunityAttainmentValue:number=0;
  selectedDistributorId:any;
  loggedUserRole:any="";
  tokenGenerated:any='';
  ROIPercent:any=0;
  thirdAttainment:any=0;
  secondAttainment:any=0;
  firstAttainment:any=0
  constructor(public router: Router, private httpService: HttpService,
    private dataService: DataService, private authService:AuthService,private activatedRoute: ActivatedRoute,public dialog: MatDialog) { 
      if(window.innerHeight == 923){
        this.dataService.wndowSrollYEmitter.emit(80);
      }else {
        this.dataService.wndowSrollYEmitter.emit(0);
      }
    }

  ngOnInit(): void {
    this.dataService.setDropdownState('rebate');
    this.globalYears = YEAR
    let date = new Date();
    let year = localStorage.getItem("year")
    if(year){
      this.selctedGlobalYear = parseInt(year)
    }else{
      this.selctedGlobalYear = date.getFullYear()
      localStorage.setItem("year",this.selctedGlobalYear.toString())
    }
    this.loggedInSupplierId = localStorage.getItem('userGroupId');
    this.selectedDistributorId = parseInt(this.loggedInSupplierId)
    this.getDistributorDashboardData(this.selctedGlobalYear,this.selectedDistributorId)
    // this.userType = localStorage.getItem('userType') as UserType;
    this.userType = this.authService.getUser()?.userType as UserType;
    this.tenantType = localStorage.getItem('tenant');
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    // this.loggedUserRole = localStorage.getItem('role') as Role;
    this.loggedUserRole = this.authService.getUser()?.role as Role;
    if(this.loggedUserRole == 'REPORTING_LAYER_NONREBATE'){
      this.isToogledSupplier = false;
      this.isListView = false;
      this.getSupplierHierarchyData()
    }
    this.activatedRoute.params.subscribe((value: any) => {
      if(value && value['hierarchy']){
        this.changeView({checked: false})
      }
    })
    this.filteredSuppliers = this.control.valueChanges.pipe(
        startWith(''),
        map((value:any) => this._filter(value || '')),
    );
    // this.httpService.getSupplierDistributors().subscribe((response:any)=>{
    //   if(response && response['data'] && response['data'].length>0){
    //     this.autoCompleteSuppliers =response['data']
    //   }
    // })
  }
  navigateToHomeDashboard = () => {
    this.router.navigate([`/${this.tenantType}/home`])
  }
  selectYear = (year: any) => {
    this.selctedGlobalYear = year;
    localStorage.setItem("year",this.selctedGlobalYear.toString())
    if(!this.isListView){
      this.getSupplierHierarchyData()
    }else{
      this.getDistributorDashboardData(this.selctedGlobalYear,this.selectedDistributorId)
    }
  }

  changeView = (event:any) =>{
    this.isListView = event.checked
    if(!this.isListView){
      this.isToogledSupplier = false
      this.getSupplierHierarchyData()
    }else{
      this.isToogledSupplier = true
      this.getDistributorDashboardData(this.selctedGlobalYear,this.selectedDistributorId)
    }

  }
  ngOnChanges(changes: SimpleChanges): void {
    this.activatedRoute.params.subscribe((value: any) => {
      if(value && value['hierarchy']){
        this.changeValue({checked: false})
      }
    })
  }

    getDistributorDashboardData = (year:any,distributorId:any) =>{
    let obj={
      year:year,
      distributorId:distributorId
    }
      this.totalPurchaseYoy = 0
      this.rebatableSales = 0
      this.rebateEarnedYoy = 0
      this.rebatablePurchase = 0
      this.rebateEarned =0
    this.httpService.getDistributorFinacialHealthDashboard(obj).subscribe((dasboardResponse:any)=>{
      if(dasboardResponse && dasboardResponse['data'].length>0){
        let allData= dasboardResponse['data'][0]
        this.totalPurchaseYoy = allData['rebatable_purchase_yoy']? allData['rebatable_purchase_yoy']:0
        this.rebatablePurchase = allData['rebatable_purchase']?allData['rebatable_purchase']:0
        // enable for payout
        this.rebatableSales = allData['total_purchase']?allData['total_purchase']:0
        // this.rebateEarnedYoy = allData['rebate_earned_yoy']?allData['rebate_earned_yoy']:0
        this.rebateEarned = allData['rebate_earned']?allData['rebate_earned']:0
        // this.payout = allData['payout']?allData['payout']:0
      }
    })
      this.totalDisputes = 0
      this.pieChartData = []
      // let obj2={
      //   year:year,
      //   userGroupId:distributorId
      // }
      // this.httpService.getDistributorDisputeSummary(obj2).subscribe((response:any)=>{
      //   if(response && response['data']){
      //     if(response['data']['summaryData']){
      //       let summaryObj = response['data']['summaryData']
      //       this.reviewObj ={ name: 'In Review', value: this.calculatePercentage(summaryObj['totalInReview'],summaryObj['totalPending'],summaryObj['totalResolved']) &&
      //         this.calculatePercentage(summaryObj['totalInReview'],summaryObj['totalPending'],summaryObj['totalResolved']) != 'NaN'? this.calculatePercentage(summaryObj['totalInReview'],summaryObj['totalPending'],summaryObj['totalResolved']):0, color: '#F69C50',actualValue:summaryObj['totalInReview']?summaryObj['totalInReview']:0  }
      //       this.pendingObj ={ name: 'Pending', value: this.calculatePercentage(summaryObj['totalPending'],summaryObj['totalInReview'],summaryObj['totalResolved'])
      //             && this.calculatePercentage(summaryObj['totalPending'],summaryObj['totalInReview'],summaryObj['totalResolved']) !='NaN'?this.calculatePercentage(summaryObj['totalPending'],summaryObj['totalInReview'],summaryObj['totalResolved']):0, color: '#59595A',actualValue:summaryObj['totalPending']?summaryObj['totalPending']:0 }
      //       this.resolvedObj ={ name: 'Resolved', value: this.calculatePercentage(summaryObj['totalResolved'],summaryObj['totalPending'],summaryObj['totalInReview']) &&
      //         this.calculatePercentage(summaryObj['totalResolved'],summaryObj['totalPending'],summaryObj['totalInReview']) != 'NaN'?this.calculatePercentage(summaryObj['totalResolved'],summaryObj['totalPending'],summaryObj['totalInReview']):0, color: '#24A148',actualValue:summaryObj['totalResolved']?summaryObj['totalResolved']:0 }
      //       this.pieChartData.push(this.reviewObj)
      //       this.pieChartData.push(this.pendingObj)
      //       this.pieChartData.push(this.resolvedObj)
      //       let values = summaryObj['totalInReview']+summaryObj['totalPending']+summaryObj['totalResolved']
      //       this.totalDisputes =  values && values!='NaN'?values:0
      //     }
      //   }
      // })
      this.httpService.getDistributorRebateOptimizationDashboard({year:year}).subscribe((ROIResponse)=>{
        if(ROIResponse && ROIResponse['data']){
          this.ROIPercent = (ROIResponse['data'] && ROIResponse['data']['totalRoiOpportunity'] && ROIResponse['data']['totalRoiOpportunity']['roiAverage'])?
              (ROIResponse['data'] && ROIResponse['data']['totalRoiOpportunity'] && ROIResponse['data']['totalRoiOpportunity']['roiAverage']):0
          this.firstAttainment = (ROIResponse['data'] && ROIResponse['data']['attainments'] && ROIResponse['data']['attainments']['percentageOver95'])?
              ROIResponse['data'] && ROIResponse['data']['attainments'] && ROIResponse['data']['attainments']['percentageOver95']:0
          this.secondAttainment = (ROIResponse['data'] && ROIResponse['data']['attainments'] && ROIResponse['data']['attainments']['percentageBtw95_90'])?
              ROIResponse['data'] && ROIResponse['data']['attainments'] && ROIResponse['data']['attainments']['percentageBtw95_90']:0
          this.thirdAttainment = (ROIResponse['data'] && ROIResponse['data']['attainments'] && ROIResponse['data']['attainments']['percentageBtw80_90'])?
              ROIResponse['data'] && ROIResponse['data']['attainments'] && ROIResponse['data']['attainments']['percentageBtw80_90']:0
        }else{
          this.ROIPercent = 0;
          this.firstAttainment = 0;
          this.secondAttainment = 0;
          this.thirdAttainment =0;

        }

      })

    }

  fixedDecimalValue = (data:any) =>{
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(data);
  }

  abbreviateNumber = (value:any) => {
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore

      notation: "compact",
      display: true,
      style: "currency",currency: "USD",
      digitsInfo:'1.0-0'
    }).format(value);
  }


  navigateToFinancialHealth = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/financial-health`,{distributorId:this.selectedDistributorId}])

  }

  navigateToRebateOptimization = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization`])
  }
  private _filter(value: string): string[] {
    const filterValue = this._normalizeValue(value);
    return this.autoCompleteSuppliers.filter((street:any)=>
        this._normalizeValue(street).includes(filterValue));
  }

  private _normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, '');
  }


  selectedValue = (searchedValue:any) =>{
    let searchedContent:any =[]
    if(searchedValue){
      let content = JSON.parse(JSON.stringify(this.getWholeData()));
      this.hierarcialData  = []
      for(let i=0;i<content.length;i++){
        if(content[i]['title'] == 'Conglomerate Level'){
          if(content[i]['searchValues'].find((a:any) =>a.includes(searchedValue))){
            let eachSearchedData = this.getMatchedValues(content[i],searchedValue)
            searchedContent.push(eachSearchedData)
          }else{
            let eachDataContent = content[i]
            eachDataContent['data']=[]
            searchedContent.push(eachDataContent)
          }
        }
        if(content[i]['title'] == 'Brand Level'){
          if(content[i]['searchValues'].find((a:any) =>a.includes(searchedValue))){
            let eachSearchedData = this.getMatchedValues(content[i],searchedValue)
            searchedContent.push(eachSearchedData)
          }else{
            let eachDataContent = content[i]
            eachDataContent['data']=[]
            searchedContent.push(eachDataContent)          }
        }
        if(content[i]['title'] == 'Location Level'){
          if(content[i]['searchValues'].find((a:any) =>a.includes(searchedValue))){
            let eachSearchedData = this.getMatchedValues(content[i],searchedValue)
            searchedContent.push(eachSearchedData)
          }else{
            let eachDataContent = content[i]
            eachDataContent['data']=[]
            searchedContent.push(eachDataContent)
          }
        }
      }
      this.hierarcialData = searchedContent

    }else{
      this.hierarcialData = [];
      this.hierarcialData = this.hierarcialTotalData;
    }

    let tempData = [];
    for (let index = 0; index < this.hierarcialData.length; index++) {
      if(this.hierarcialData[index]['data'].length == 0){
        tempData.push(index);
        continue;
      } 
    }
    if(tempData.length == this.hierarcialData.length){
      const dialogRef = this.dialog.open(SucessMessageModalComponent, {
        width: '416px',
        height: '185px',
        data: { "type": `Associate Not Found`, actionStatus: 'reject' },
        disableClose: true
      });
    }
  }

  getMatchedValues = (content:any,search:any) =>{
    let data = content['data']
    let matchedArray:any= []
    for(let i=0;i<data.length;i++){
      if(data[i]['name'].includes(search)){
        matchedArray.push(data[i])
      }
    }
    content['data'] = matchedArray
    return content
  }
  changeValue = (value:any) =>{
    if(value=='' || value==null){
      this.hierarcialData = []
      setTimeout(()=>{
        this.getSupplierHierarchyData()

      },100)
    }
  }

  getWholeData = () =>{
    return this.hierarcialTotalData
  }

  /**
   *  Creating the content for Hierarchy view model
   *
   */

  getSupplierHierarchyData = () =>{
    this.hierarcialData =[]
    this.hierarcialTotalData = []
    let allContent:any=[]
    this.httpService.getDistributorHierarchy(this.loggedInSupplierId,this.selctedGlobalYear).subscribe((response:any)=>{
      if(response && response['data']){
         allContent = response['data']
        for(let obj in allContent){
          let eachObj:any={}
          if(obj == 'organization'){
            eachObj['title'] = 'Conglomerate Level'
            eachObj['data']=this.populateEachLevelData(allContent[obj])['data']
            eachObj['searchValues'] =this.populateEachLevelData(allContent[obj])['searchData']
            eachObj['totalSales'] = allContent['salesAndRebate']?.['sales']?.['CONGLOMERATE']?allContent['salesAndRebate']?.['sales']?.['CONGLOMERATE']:0
            eachObj['totalRebate'] = allContent['salesAndRebate']?.['rebates']?.['CONGLOMERATE']?allContent['salesAndRebate']?.['rebates']?.['CONGLOMERATE']:0
            this.hierarcialTotalData.push(eachObj)
          }else if(obj == 'company'){
            eachObj['title'] = 'Brand Level'
            eachObj['data']=this.populateEachLevelData(allContent[obj])['data']
            eachObj['searchValues'] =this.populateEachLevelData(allContent[obj])['searchData']
            eachObj['totalSales'] = allContent['salesAndRebate']?.['sales']?.['BRAND']?allContent['salesAndRebate']?.['sales']?.['BRAND']:0
            eachObj['totalRebate'] = allContent['salesAndRebate']?.['rebates']?.['BRAND']?allContent['salesAndRebate']?.['rebates']?.['BRAND']:0
            this.hierarcialTotalData.push(eachObj)
          }else if(obj=='branch'){
            eachObj['title'] = 'Location Level'
            eachObj['data']=this.populateEachLevelData(allContent[obj])['data']
            eachObj['searchValues'] =this.populateEachLevelData(allContent[obj])['searchData']
            eachObj['totalSales'] = allContent['salesAndRebate']?.['sales']?.['LOCATION']?allContent['salesAndRebate']?.['sales']?.['LOCATION']:0
            eachObj['totalRebate'] = allContent['salesAndRebate']?.['rebates']?.['LOCATION']?allContent['salesAndRebate']?.['rebates']?.['LOCATION']:0
            this.hierarcialTotalData.push(eachObj)
          }
        }
        this.hierarcialData=this.hierarcialTotalData
      }
    })
  }

  /**
   *  Creating the list that comes from API and preparing the data for Hierarchy content like groupName,parentName,sales,etc
   *  and preparing the list of names for autocomplete search
   */

  populateEachLevelData = (data:any) =>{
    let allInfo:any=[]
    let allSearchData:any=[]
    for(let i=0;i<data.length;i++) {
      let objectData: any = {}
      objectData['name'] = data[i]['group_name']?data[i]['group_name']:'NA'
      objectData['parentName'] = data[i]['group_parent_name']?data[i]['group_parent_name']:'NA'
      objectData['selected'] = data[i]['selected']
      objectData['totalSales'] =  data[i]['total_sales']?data[i]['total_sales']:0
      objectData['rebateSales'] =  data[i]['total_rebate']? data[i]['total_rebate']:0
      objectData['associateLevel'] = data[i]['associate_level']?data[i]['associate_level']:'NA'
      objectData['userGrpId'] = data[i]['user_group_id']
      objectData['userGrpParentId'] = data[i]['user_group_parent_id']?data[i]['user_group_parent_id']:'NA'
      objectData['enabled'] = data[i]['enabled']
      allInfo.push(objectData)
      if(!allSearchData.includes(data[i]['group_name'])){
        allSearchData.push(data[i]['group_name'])
      }
      if(!this.autoCompleteSuppliers.includes(data[i]['group_name'])){
        this.autoCompleteSuppliers.push(data[i]['group_name'])
      }
    }
    this.filterDataToAutoComplete();
    return {data:allInfo,searchData:allSearchData}
  }
  /**
   *  Navigating to distributor payment page
   */
   navigateToPayouts = () =>{
    this.router.navigate([`/${this.tenantType}/payoutManagement`])

  }
  /**
   *  Switching the distributor on click of chord of distributor
   */
  switchUser = (userGrpId:any) =>{
    if(userGrpId){
      this.selectedDistributorId = parseInt(userGrpId)
      this.httpService.postMethod('/api/switch/user', { 'switchingGroupId': this.selectedDistributorId, actualUserType:localStorage.getItem('actualUserType') }).subscribe((response: any) => {
        localStorage.setItem('username', response ? response['data']['name'] : '');
        this.tokenGenerated = response.data.jwtToken;
        localStorage.setItem('token', this.tokenGenerated);
        localStorage.setItem('tenant', response ? response['data']['tenantName'] : this.tenantType);
        localStorage.setItem('userTypeId', response ? response['data']['userTypeId'] : '')
        // localStorage.setItem('role', response ? response['data']['role'] : '')
        localStorage.setItem('userType', response ? response['data']['userType'] : '')
        localStorage.setItem('userGroupId', response ? response['data']['userGroupId'] : '')
        localStorage.setItem('userFirstLogin', response ? response['data']['userFirstLogin'] : '')
        localStorage.setItem('companyFirstLogin', response ? response['data']['companyFirstLogin'] : '');
        this.authService.autoLogin();
        this.router.navigate([`${response?.data?.tenantName}/home`,{hierarchy:true}], { replaceUrl: true },).then(() => {
          window.location.reload();
        });;
      })

    }
  // this.changeView({checked:true})
  }


  /**
   *  Adding data to auto-complete by using filter method
   */
  filterDataToAutoComplete = () =>{
    this.filteredSuppliers = this.control.valueChanges.pipe(
        startWith(''),
        map((value:any) => this._filter(value || '')),
    );
  }

  searchHierarchyValue = () =>{
    if(this.control.value){
      this.selectedValue(this.control.value)
    }
  }
  clearSearchFilter = () =>{
    if(this.control.value){
      this.control.setValue('')
      //this.changeValue('')
    }
  }

  navigateToDisputeResolution = () =>{
    this.router.navigate([`/${this.tenantType}/rebateManagement/dispute-resolution`]);
  }

  private calculatePercentage(summaryObjElement1: any,summaryObjElement2: any,summaryObjElement3: any) {
    return ((summaryObjElement1/(summaryObjElement2+summaryObjElement1+summaryObjElement3))*100).toFixed();
  }

  ParseFloat(str:any,val:any) {
    str = str.toString();
    str = str.slice(0, (str.indexOf(".")) + val + 1);
    return str;  
  }
}
