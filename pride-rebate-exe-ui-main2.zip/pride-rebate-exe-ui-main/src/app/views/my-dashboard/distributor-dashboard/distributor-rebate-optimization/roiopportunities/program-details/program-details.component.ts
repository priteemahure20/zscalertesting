import { Component, OnInit } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { getYears, YEAR } from 'src/app/helpers/constants';
import { HttpService } from 'src/app/services/http.service';
import {criteriaBasedType} from '../../../../../../helpers/commonUtils';
import {ReusableService} from '../../../../../../services/reusable.service';
import {MatDialog} from '@angular/material/dialog';
import {DataService} from '../../../../../../services/data.service';
@Component({
  selector: 'app-program-details',
  templateUrl: './program-details.component.html',
  styleUrls: ['./program-details.component.scss']
})
export class ProgramDetailsComponent implements OnInit {
  globalYears:any=[]
  selctedGlobalYear:any;
  lastUpdateDate:any
  tenantType:any;
  programName = ""
  selectedDetailType: any = '';
  opportunityDetails:any;
  programId: any;
  rebateMasterId:any;
  programDetailOverview: any = '';
  selectedProgramDetailType: any = '';
  showExpandedView: boolean = false;
  closeProgramInProgramList: any = false;
  unitsData:any =[
    // {unitName:'Sales CY', percentage:70, currentPurchase:1900000, gap:100000, target:2000000},
  ];
  attainments = [
    {tierName:'Tier 1', percentage:0},
    {tierName:'Tier 2', percentage:100},
    {tierName:'Tier 3', percentage:0},
  ];
  subProgramType:any;
  constructor(public router: Router,private matIconRegistry: MatIconRegistry,public activatedRoute: ActivatedRoute,
              private httpService: HttpService, private domSanitizer: DomSanitizer,private resuableService:ReusableService,public dialog: MatDialog, private dataService:DataService) {
    this.matIconRegistry.addSvgIcon("flag", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/Flag.svg"))
    if(window.innerHeight == 923){
      this.dataService.wndowSrollYEmitter.emit(100);
    }else {
      this.dataService.wndowSrollYEmitter.emit(0);
    }
  }

  ngOnInit(): void {
    this.globalYears = getYears()
    let date = new Date();
    // let year = localStorage.getItem("year")
    // if(year){
    //   this.selctedGlobalYear = parseInt(year)
    // }else{
    //   this.selctedGlobalYear = date.getFullYear()
    //   localStorage.setItem("financialYear",this.selctedGlobalYear.toString())
    // }
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    this.tenantType = localStorage.getItem('tenant');
    this.activatedRoute.params.subscribe((value: any) => {
      if(value){
        this.subProgramType = value['subProgramType'];
        this.programId = value['programId'];
        // this.rebateMasterId = value['rebateMasterId'];
        this.selctedGlobalYear=value['year'];
        this.getProgramDetail();
        this.getRoiOpportunity();
      }
    })

  }

  navigateToHomeDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/home`])
  }

  navigateToRoiOpporyunities = ()=>{
    //this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization/ROIOpportunities`])
    const attainment = this.dataService.getAttaintmentvalue();
    this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization/ROIOpportunities`,{attainment:attainment,programType:"roi", programDetails:'visited',subProgramType:this.subProgramType}])
  }
  navigateToRebateOptimization = ()=>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization`])
  }
  navigateToDistributorDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])
  }

  expand = ($event:any) =>{
    // if($event.selectedType=='catalogDetail'){
    //   const dialogRef = this.dialog.open(CatalogViewModalComponent, {
    //     width: '1193px',
    //     height: '555px',
    //     panelClass: 'dialog-container-custom',
    //     data:{programName:this.programName,programDetails:this.programDetailOverview,supplierId:this. programDetailOverview?.supplier_id,programId:this.programId,type:'modal'}
    //   });
    // }else{
      this.selectedDetailType = $event.selectedType;
      this.closeProgramInProgramList = false;
      this.closeProgramInProgramList = false;
   // }
    // this.showExpandedView = $event.showExpandedView;
    // this.selectedDetailType = $event.selectedType;
    // this.closeProgramInProgramList = false;
  }

  closePDPDetails = () =>{
    this.selectedDetailType = '';
    this.selectedProgramDetailType = '';
    this.closeProgramInProgramList = true;
  }

  getProgramDetail = () => {
    
    let reqObj:any = { 'programId': parseInt(this.programId)}
    if(localStorage.getItem('userType') != 'CORPORATE') reqObj['dealer_id'] = localStorage.getItem('userGroupId')
    this.httpService.postMethod('/api/rebate_library/program/details', reqObj).subscribe((response: any) => {
      this.programDetailOverview = response?.data;
      console.log('program details',this.programDetailOverview);
    })
  }

  getRoiOpportunity = () => {
    const reqObj = {"year": this.selctedGlobalYear,
      "programId": this.programId};
    this.httpService.fetchDistributorRoiOpportunityProgramDetails(reqObj).subscribe((response:any)=>{
      this.opportunityDetails = response?.data;
      let isFound = false;
      this.opportunityDetails.attainmentTracking = this.opportunityDetails.attainmentTracking.map((item:any)=>{
        if(isFound === false && item.tierAttainmentPercent <100){
          isFound = true;
          return {...item, current:true};
        }else{
          return item;
        }
      });
      const {currentPurchase,gap,target,criteria_name} = response?.data?.opportunity;
      const percentage= this.getPercent(currentPurchase,target);
      const modifiedGAP = gap?criteriaBasedType(criteria_name)+this.resuableService.significantNumber2(this.makeFixedDecimalData(gap)):0
      const modifiedTarget = target?criteriaBasedType(criteria_name)+this.resuableService.significantNumber2(this.makeFixedDecimalData(target)):0
      const modifiedCurrentPurchase = currentPurchase?criteriaBasedType(criteria_name)+this.resuableService.significantNumber2(this.makeFixedDecimalData(currentPurchase)):0
      this.unitsData.push({unitName:criteria_name,modifiedCurrentPurchase,modifiedGAP,modifiedTarget,percentage});
    })
  }

  getPercent(current:number,target:number){
    return (current/target)*100;
  }

  makeFixedDecimalData = (data:any)=>{
    if(data && parseFloat(data) !=0){
      if (!Number.isInteger(parseFloat(data))) {
        return Math.round(Math.floor(data * 100) / 100)
      }else {
        return data
      }
    }else{
      return 0
    }
  }

  checkNameLength = (name: any) => {
    if (name && name.length > 1) {
      let values = Array.isArray(name)?name.join(', '):name
      return values.length>40?values.substring(0,40) + "...":values;
    } else {
      return name
     }
    }
}
