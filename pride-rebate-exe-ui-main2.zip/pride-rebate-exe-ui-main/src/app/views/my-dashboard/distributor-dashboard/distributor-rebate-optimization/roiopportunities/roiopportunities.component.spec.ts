import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ROIOpportunitiesComponent } from './roiopportunities.component';

describe('ROIOpportunitiesComponent', () => {
  let component: ROIOpportunitiesComponent;
  let fixture: ComponentFixture<ROIOpportunitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ROIOpportunitiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ROIOpportunitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
