import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DistributorRebateOptimizationComponent } from './distributor-rebate-optimization.component';

describe('DistributorRebateOptimizationComponent', () => {
  let component: DistributorRebateOptimizationComponent;
  let fixture: ComponentFixture<DistributorRebateOptimizationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DistributorRebateOptimizationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DistributorRebateOptimizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
