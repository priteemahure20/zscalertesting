import { Component, OnInit, ElementRef } from '@angular/core';
import {YEAR} from '../../../../../helpers/constants';
import {ActivatedRoute, Router} from '@angular/router';
import {HttpService} from '../../../../../services/http.service';
import {TitleCasePipe} from '@angular/common';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material/icon';
import {ReusableService} from '../../../../../services/reusable.service';
import {criteriaBasedType} from '../../../../../helpers/commonUtils';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import {ExportModalComponent} from '../../../../report-generator/export-modal/export-modal.component';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import {DataService} from '../../../../../services/data.service';
import { SucessMessageModalComponent } from 'src/app/common/sucess-message-modal/sucess-message-modal.component';
import { Tooltip } from 'chart.js';
@Component({
  selector: 'app-roiopportunities',
  templateUrl: './roiopportunities.component.html',
  styleUrls: ['./roiopportunities.component.scss']
})
export class ROIOpportunitiesComponent implements OnInit {
  globalYears:any=[]
  selctedGlobalYear:any;
  lastUpdateDate:any
  tenantType:any;
  ROIPercent:any=0;
  ROIValue:any=0;
  searchName:any=''
  selectedAttainment:any=''
  allAttainments:any=[]
  opportunityData:any=[]
  totalCount:any = 0;
  totalROICount:any;
  selectedPageLimit:any=5
  loggedDistributorId:any;
  pagination:any={
    pageNo:1,
    limit:5
  }
  sliderObj:any={}
  programType:any;
  subProgramType:any;
  totalParentPrograms:any;
  type:any;
  attainments: any = [50,60,70,80,90,91,92,93,94,95];
  SortTypes =[
    // {value:'',displayText:'Sort'},
    {value:'1', displayText:'Vendor name alphabetically - A-Z' },
    {value:'2', displayText:'Vendor name alphabetically - Z-A'},
    {value:'3', displayText:'Descending ROI'},
    {value:'4', displayText:'Descending Opportunity'},
    {value:'5', displayText:'Ascending Gap'}
  ];
  selectedSortType:any='';
  constructor(public router: Router,private httpService: HttpService,private titlecasePipe:TitleCasePipe,private domSanitizer: DomSanitizer,
              private matIconRegistry: MatIconRegistry,public activatedRoute: ActivatedRoute,private resuableService: ReusableService, private elemRef:ElementRef,private dialog:MatDialog, private dataService:DataService) {
    this.matIconRegistry.addSvgIcon("export", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../../assets/img/icons/export.svg"));

  }

  ngOnInit(): void {
    this.globalYears = YEAR
    const selectedAttainment = this.dataService.getAttaintmentvalue();
    this.selectedAttainment = this.attainments[selectedAttainment];
    let date = new Date();
    let year = localStorage.getItem("year")
    if(year){
      this.selctedGlobalYear = parseInt(year)
    }else{
      this.selctedGlobalYear = date.getFullYear()
      localStorage.setItem("year",this.selctedGlobalYear.toString())
    }
    this.loggedDistributorId = localStorage.getItem('userGroupId');
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    this.tenantType = localStorage.getItem('tenant');
    //this.selectedYearOption(this.selctedGlobalYear)
    this.activatedRoute.paramMap.subscribe((params: any) => {
      if(params['params'] && params['params']['programType']){
        this.programType = params['params']['programType'];
        this.subProgramType = params['params']['subProgramType'];
        if(this.programType == 'roi'){
          this.httpService.getAttainmentDropdown().subscribe((response:any)=>{
            if(response && response['data'] && response['data']['attainmentRange']){
              this.allAttainments = response['data']['attainmentRange'];
              this.activatedRoute.paramMap.subscribe((params: any) => {
                if(params['params'] && params['params']['attainment']){
                  this.opportunityData = []
                  this.sliderObj['pageNo'] = this.pagination['pageNo']
                  this.sliderObj['limit'] = this.pagination['limit']
                  this.selectedSortType='0'
                  this.sliderObj['orderBy']='roi';
                  this.sliderObj['orderByType']='desc';
                  //this.selectedAttainmentValue(this.selectedAttainment)
                  //this.selectedYearOption(this.selctedGlobalYear);
                  //setTimeout(() => {
                    if(params['params']['attainment'] == 'showAll' || (params['params']['attainment'] == 0) && (params['params']['programDetails'] == 'visited')){
                      this.selectedAttainment = 0;
                      this.elemRef.nativeElement.querySelector('.attainment').value = "0";
                    }else{
                      let setAttainment = this.selectedAttainment > 90? 90:this.selectedAttainment
                      this.elemRef.nativeElement.querySelector('.attainment').value = setAttainment.toString();
                    }
                    this.selectedYearOption(this.selctedGlobalYear);
                  //}, 50);
                }
              })
            }
          })
        } else if(this.programType == 'parent'){
          this.selectedYearOption(this.selctedGlobalYear);
          this.opportunityData = []
        }
      }
    });
  }

  navigateToHomeDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/home`])

  }

  navigateToDistributorDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])
  }

  navigateToRebateOptimization = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization`])
  }

  navigateToProgramDetails = (data:any) =>{
    //this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization/program-details`,{rebateMasterId:data?.rebateMasterId,programId:data?.programId}]);
    //this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization/program-details`])
    if(data?.type == 'roi'){
      // this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization/program-details`,{rebateMasterId:data?.rebateMasterId,programId:data?.programId,subProgramType:this.subProgramType,year:this.selctedGlobalYear}])
      this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization/program-details`,{programId:data?.programId,subProgramType:this.subProgramType,year:this.selctedGlobalYear}])

    } else if(data?.type == 'parent'){
      let type ='group';
      const queryParams: any = {
        // id: data?.rebateMasterId,
        year: this.selctedGlobalYear,
        programId:data?.programId,
        programName:data?.title,
        supplier:data?.subTitle,
        subProgramType:this.subProgramType
      };
      this.router.navigate(
        [`/${this.tenantType}/rebateManagement/program-details`,data?.type],
        {
          queryParams: queryParams,
        }
      );
    }
  }

  selectedYearOption = (year: any) => {
    this.selctedGlobalYear = year;
    localStorage.setItem("year",this.selctedGlobalYear.toString())
    if(this.programType == 'roi'){
      this.getROIData(year)
      this.selectedAttainmentValue(this.selectedAttainment)
    } else if(this.programType == 'parent'){
      this.sliderObj['pageNo'] = this.pagination['pageNo'];
      this.sliderObj['limit'] = this.pagination['limit'];
      this.getParentProgramData()
    }
  }

  export = () =>{
    // const payoutObj = { payoutTicketNo: payoutId }
    // const transactionObj = _cloneDeep(this.reqObject);
    delete this.sliderObj['pageNo'];
    delete this.sliderObj['limit'];
    this.httpService.getDealerExportData(this.sliderObj).subscribe((response:any)=>{
      if(response && response['data'] && response['data']['count'] == 0){
        const dialogRef = this.dialog.open(ExportModalComponent, {
          width: '416px',
          height: '185px',
          panelClass: 'dialog-container-custom',
          data: { message: "No records found to export" },

        });
        dialogRef.afterClosed().subscribe((result: any) => {
        });
      }else {
        let allData = this.mapTransactionData(response['data']['roiGrowthPrograms']);
        //const allData = ROIResponse?.data?.roiGrowthPrograms;
        if (allData.length > 0) {
          const headers = Object.keys(allData[0]);
          this.downloadFile(allData, headers,"Transaction");
        }
      }
    });
  }

  downloadFile(data: any, header: any, filename = 'data') {
    let csvData = this.resuableService.convertToCSV(data, header);
    let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
    const dialogRef = this.dialog.open(SucessMessageModalComponent, {
      width: '416px',
      height: '185px',
      data: { "type": `Exported ${data.length} records successfully.`, actionStatus: 'success' },
      disableClose: true
    });
  }

  searchByName = (value:string) =>{
    if (value) {
      this.sliderObj['pageNo'] = 1;
      this.sliderObj['limit'] = this.pagination['limit'];
      this.sliderObj['supplierName'] = value
      this.selectedAttainmentValue(this.selectedAttainment);
    } else {
      if (this.sliderObj.hasOwnProperty('supplierName')) {
        this.sliderObj['pageNo'] = 1;
        this.sliderObj['limit'] = this.pagination['limit'];
        delete this.sliderObj.supplierName
        this.selectedAttainmentValue(this.selectedAttainment);
      }
    }
  }

  selectedAttainmentValue = (value:any) =>{
    //this.opportunityData = []
    this.sliderObj['programType'] =this.subProgramType;
    this.sliderObj['year']= this.selctedGlobalYear
    this.sliderObj['distributorId']= this.loggedDistributorId
    this.sliderObj['attainmentRange']= [value?parseInt(value):0,100]
   
    this.httpService.getAttainmentData(this.sliderObj).subscribe((ROIResponse:any)=>{
      if(ROIResponse && ROIResponse['data'] && ROIResponse['data']['count']>0){
        let allData=  ROIResponse['data']['roiGrowthPrograms']
        this.populateRoiProgramData(allData);
        this.totalROICount= ROIResponse['data']['count']
        this.totalCount = this.totalROICount;
      } else {
        this.populateRoiProgramData([]);
      }
    })
  }

  populateRoiProgramData(allData:any){
    const data: any = [];
    for(let i=0;i<allData.length;i++){
      let eachObject = {
        title:allData[i]['programName']?allData[i]['programName']:'NA',
        subTitle:allData[i]['supplierName']?allData[i]['supplierName']:'NA',
        Tooltip:"ROI is the ratio of opportunity and gap to the next tier, it shows the return on the next dollar spend in the program",
        ROIValue:allData[i]['payoutRoi']?'$'+this.resuableService.significantDecimalNumber2(this.resuableService.fixedDecimalValue(allData[i]['payoutRoi'])):'Max',
        ROI:allData[i]['roi']?`${allData[i]['roi'].toFixed(2)}%`:'Max',
        //GAPValue:allData[i]['gap']?criteriaBasedType(allData[i]['criteria_name'])+this.resuableService.significantNumber2(this.resuableService.fixedDecimalValue(allData[i]['gap'])):0,
        GAPValue:allData[i]['gap']?'$'+this.resuableService.significantDecimalNumber2(this.resuableService.fixedDecimalValue(allData[i]['gap'])):'$0',
        attainment:allData[i]['tierAttainmentPercent']?this.resuableService.significantNumber2(this.resuableService.fixedDecimalValue(allData[i]['tierAttainmentPercent']))+'%':0,
        endLabel:allData[i]['rebateCalculatedOn']?allData[i]['rebateCalculatedOn']:'NA',
        rebateMasterId:allData[i]['rebateMasterId'],
        programId:allData[i]['programId'],
        type:'roi',
        tierOrder:allData[i]['tierOrder'],
        lastInvoiceDate:allData[i]['lastInvoiceDate']?allData[i]['lastInvoiceDate']:'NA'
      }
      data.push(eachObject)
    }
    this.opportunityData = data;
    this.type = "ROIOpportunities";
  }

  changeAttaitmentValue(value:any){
    this.selectedAttainment = value;
    this.sliderObj['pageNo'] = 1;
    this.sliderObj['limit'] = this.pagination['limit'];
    this.selectedAttainmentValue(value);
  }

  SortTypeChange(data:any){
    console.log('sorttype', data);
    this.selectedSortType=data;
    if(this.selectedSortType==='1'){
      this.sliderObj['orderBy']='supplierName';
      this.sliderObj['orderByType']='asc';
    }else if(this.selectedSortType==='2'){
            this.sliderObj['orderBy']='supplierName'
            this.sliderObj['orderByType']='desc';
          }else if(this.selectedSortType==='3'){
                        this.sliderObj['orderBy']='roi';
                        this.sliderObj['orderByType']='desc';
                  }else if (this.selectedSortType==='4'){
                    this.sliderObj['orderBy']='payoutRoi';
                    this.sliderObj['orderByType']='desc'
                    }else{
                    this.sliderObj['orderBy']='gap'
                    this.sliderObj['orderByType']='asc'
                    }
      this.selectedAttainmentValue(this.selectedAttainment); 
          
    // this.getFinancialHealthGroupData();
  }

  getParentProgramData(){ 
    //this.opportunityData = []
    this.sliderObj['programType'] =this.subProgramType;
    this.sliderObj['year']= this.selctedGlobalYear
    this.sliderObj['ra_member_id']= this.loggedDistributorId
    this.httpService.getParentPrograms(this.sliderObj).subscribe((response:any)=>{
      if(response && response['data'] && response['data']['count']>0){
        let allData=  response['data']['distributorParentProgramsData']
        this.populateParentProgData(allData);
        this.totalParentPrograms = response['data']['count'];
        this.totalCount = this.totalParentPrograms;
      } else {
        this.populateParentProgData([]);
      }
    });
  }

  populateParentProgData(allData:any){
    const data: any = [];
    for(let i=0;i<allData.length;i++){
      let eachObject = {
        title:allData[i]['program_name']?allData[i]['program_name']:'NA',
        subTitle:allData[i]['supplierName']?allData[i]['supplierName']:'NA',
        ROIValue:allData[i]['paymentRoi']?allData[i]['paymentRoi']:0,
        ROI:allData[i]['roi']?allData[i]['roi']:0,
        //GAPValue:allData[i]['gap']?this.resuableService.significantNumber2(this.resuableService.fixedDecimalValue(allData[i]['gap'])):0,
        GAPValue:allData[i]['gap']?allData[i]['gap']:0,
        rebateMasterId:allData[i]['rebate_master_id'],
        programId:allData[i]['program_id'],
        type:'parent',
      }
      data.push(eachObject);
    }
    this.opportunityData = data;
    this.type = "ParentOpportunities";
  }

  getROIData = (year:any) =>{
    let obj={
      year:year,
      distributorId:this.loggedDistributorId
    }
    this.httpService.getRebateOptimizationROISummary(obj).subscribe((ROIResult:any)=>{
      if(ROIResult && ROIResult['data'] && ROIResult['data']['roiSummary']){
        this.ROIPercent = ROIResult['data']['roiSummary']['roiAverage']?ROIResult['data']['roiSummary']['roiAverage']:0
        this.ROIValue = ROIResult['data']['roiSummary']['opportunity']?ROIResult['data']['roiSummary']['opportunity']:0
      }
    })
  }

  getNextPage = (eventValue:any) =>{
    this.pagination['pageNo']=parseInt(eventValue['pageIndex'])+1
    this.pagination['limit'] = this.selectedPageLimit
    this.sliderObj['pageNo'] = this.pagination['pageNo']
    this.sliderObj['limit'] = this.pagination['limit']
    if(this.programType == 'roi'){
      this.selectedAttainmentValue(this.selectedAttainment)
    } else if(this.programType == 'parent'){
      this.getParentProgramData()
    }
  }

  selectedViewPageLimit = (eventValue:any) =>{
    this.pagination['pageNo']=1
    this.selectedPageLimit = parseInt(eventValue)
    this.pagination['limit'] = this.selectedPageLimit
    this.sliderObj['pageNo'] = this.pagination['pageNo']
    this.sliderObj['limit'] = this.pagination['limit']
    if(this.programType == 'roi'){
      this.selectedAttainmentValue(this.selectedAttainment)
    } else if(this.programType == 'parent'){
      this.getParentProgramData()
    }
  }
 
  goToPageNumber = (event:any) =>{
    let value = Math.ceil(this.totalCount / this.pagination['limit'])
    if (event <= value) {
      this.pagination['pageNo'] = parseInt(event);
      this.sliderObj['limit'] = this.pagination['limit']
      this.sliderObj['pageNo'] = this.pagination['pageNo']
      if(this.programType == 'roi'){
        this.selectedAttainmentValue(this.selectedAttainment)
      } else if(this.programType == 'parent'){
        this.getParentProgramData()
      }
    } else {
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: { "type": "PageNo entered out of range." },
        disableClose: true,
      });
      setTimeout(() => {
        dialogRef.close()
      }, 2000)

      dialogRef.afterClosed().subscribe((result: any) => {
        if (this.opportunityData.length > 0) {
          this.opportunityData = []
        }
        this.pagination['pageNo'] = 1;
        this.sliderObj['limit'] = this.pagination['limit']
        this.sliderObj['pageNo'] = this.pagination['pageNo']
        if(this.programType == 'roi'){
          this.selectedAttainmentValue(this.selectedAttainment)
        } else if(this.programType == 'parent'){
          this.getParentProgramData()
        }
      })
    }
  }

  mapTransactionData = (content: any) => {
    return content.map((row: any) => ({
      "Vendor " : row && row['supplierName'] ? `"${row['supplierName'].replaceAll('"','""')}"` : 'NA',
      "Dealer " : row && row['dealerName'] ? `"${row['dealerName'].replaceAll('"','""')}"` : 'NA',
      "Program Name" : row && row['programName'] ? `"${row['programName'].replaceAll('"','""')}"` : 'NA',
      "Rebate Type" : row && row['rebateType'],
      "Total Volume" : row && row['totalVolume']? row['totalVolume'] :0,
      "Last Invoice Date" : row && row['lastInvoiceDate'],
      "Month Value" : row && row['monthValue'],
      "Estimate Value"  :row && row['estimatedValue']? row['estimatedValue']:0,
      // "Growth Baseline"  : row && row['growthBaseline'] == 0?'0': row['growthBaseline']== null?'No Baseline': row['growthBaseline'],
      "Actual Baseline"  : row && row['actualBaseline'] == 0?'0': row['actualBaseline']== null?'No Baseline': row['actualBaseline'],
      "Current Tier Level to Attain"  : row && row['currentTierLvlToAttain'] == 0?'0': row['currentTierLvlToAttain']== null?'Max':row['currentTierLvlToAttain'],
      "Current Tier Level Target"  : row && row['currentTierLvlTarget']== 0?'0': row['currentTierLvlTarget']== null?'Max':row['currentTierLvlTarget'],
      "Current Tier Level % Estimated to Attain"  :  row && row['currentTierLvlPercentEstimatedToAttain'] == 0?'0%': row['currentTierLvlPercentEstimatedToAttain']== null?'Max':`${row['currentTierLvlPercentEstimatedToAttain']}%` ,
      "Current Tier Level Gap"  : row && row['currentTierLvlGap'],
      "Current Tier Level % to Attain"  : row && row['currentTierLvlPercentToAttain'] == 0?'0%':row['currentTierLvlPercentToAttain'] == null?'Max' :`${row['currentTierLvlPercentToAttain']}%`,
      "Current Tier Level ROI" :  row && row['currentTierLvlRoi'] == 0?'0%': row['currentTierLvlRoi']== null?'Max': `${row['currentTierLvlRoi']}%`,
      "Current Tier Level ROI Dollar Amount"  : row && row['currentTierLvlRoiDollarAmount']== 0?'0': row['currentTierLvlRoiDollarAmount']== null?'Max': row['currentTierLvlRoiDollarAmount'],
      "Next Tier Level Target" : row && row['nextTierLvlTarget']== 0?'0': row['nextTierLvlTarget']== null?'Max':row['nextTierLvlTarget'],
    }))
  }
}
