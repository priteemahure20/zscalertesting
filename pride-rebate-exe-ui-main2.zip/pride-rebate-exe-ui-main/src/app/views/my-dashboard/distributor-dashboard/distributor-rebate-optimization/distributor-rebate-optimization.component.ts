import { Component, OnInit } from '@angular/core';
import {YEAR} from '../../../../helpers/constants';
import {ActivatedRoute, Router} from '@angular/router';
import {HttpService} from '../../../../services/http.service';
import {TitleCasePipe} from '@angular/common';
import {DataService} from '../../../../services/data.service';
import {BgDashboardService} from '../../../../rbac/KPIs/bg-dashboard.service';
import {MatIconRegistry} from '@angular/material/icon';
import {DomSanitizer} from '@angular/platform-browser';
import {CustomStepDefinition, LabelType, Options} from '@angular-slider/ngx-slider';
import { Tooltip } from 'chart.js';


@Component({
  selector: 'app-distributor-rebate-optimization',
  templateUrl: './distributor-rebate-optimization.component.html',
  styleUrls: ['./distributor-rebate-optimization.component.scss']
})
export class DistributorRebateOptimizationComponent implements OnInit {
  globalYears:any=[]
  selctedGlobalYear:any;
  lastUpdateDate:any
  tenantType:any;
  totalPurchaseCurrentYear:any=0;
  totalRebateEarnedCurrentYear:number=0
  avgTotalPurchase:any=0;
  avgRebateEarned:any=0;
  overAllRebatePercent:any=0;
  avgRebatePercent:any=0;
  attainmentTrackingValue:any=0;
  ROIPercent:any=0;
  ROIValue:any=0;
  growthPotentialValue:any=0
  totalPurchaseYoy:any=0
  rebateEarnedYoy:any=0
  avgPurchaseYoy:any=0
  avgRebateEarnedYoy:any=0;
  silderValue:any =90;
  ROIProgramsPercent:any=0
  totalProgramAttainment:any=0
  ROIPrograms:any=[]
  oppParentPrograms:any=[]
  totalROTPrograms:any=0
  totalParentPrograms:any=0
  isInGrp:boolean = false
  isToogledGrp:boolean = false;
  loggedDistributorId:any;
  attainmentRange:any[]=[];
  isIndividualViewRoi:boolean = false;
  isIndividualViewParent:boolean = false;
  programType:any = 'individual';
  alphabet: any = [50,60,70,80,90,91,92,93,94,95];
  sliderOptions: Options = {
    stepsArray: this.alphabet.map((letter: string): CustomStepDefinition => {
      return { value: this.letterToIndex(letter) };
    }),
    translate: (value: number, label: LabelType): string => {
      return this.indexToLetter(value)+'%';
    },

    getPointerColor: (): string => {
      return '#FFFFFF';
    },
    getSelectionBarColor: (value: number): string => {
      return '#40BBA0';
    },
    showTicks: true,
    showTicksValues: true,
    showSelectionBar: true,

  };
  indexToLetter(index: number): string {
    return this.alphabet[index];
  }

  letterToIndex(letter: string): number {
    return this.alphabet.indexOf(letter);
  }
  constructor(public router: Router,private httpService: HttpService,private titlecasePipe:TitleCasePipe,public activatedRoute: ActivatedRoute, private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer,private dataService:DataService) {
    this.matIconRegistry.addSvgIcon("up-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/up_arrow_icon.svg"))
    this.matIconRegistry.addSvgIcon("down-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/down_icon.svg"))
    this.dataService.headerZinedxEmitter.emit(4);
  }

  ngOnInit(): void {
    this.dataService.setAttaintmentvalue(9);
    this.silderValue = this.dataService.getAttaintmentvalue();
    this.globalYears = YEAR
    let date = new Date();
    let year = localStorage.getItem("year")
    if(year){
      this.selctedGlobalYear = parseInt(year)
    }else{
      this.selctedGlobalYear = date.getFullYear()
      localStorage.setItem("year",this.selctedGlobalYear.toString())
    }
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    this.tenantType = localStorage.getItem('tenant');
    this.loggedDistributorId = localStorage.getItem('userGroupId');
    this.selectedYearOption(this.selctedGlobalYear)
    // this.sliderValueChange(this.silderValue)

  }

  navigateToHomeDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/home`])

  }

  navigateToDistributorDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])

  }

  selectedYearOption = (year: any) => {
    this.selctedGlobalYear = year;
    localStorage.setItem("year",this.selctedGlobalYear.toString())
    this.getRebateOptimizationSummary();
    this.sliderValueChange(this.silderValue);
  }

  getRebateOptimizationSummary = () =>{
    let obj={
      year:this.selctedGlobalYear,
      distributorId:this.loggedDistributorId
    }
    this.httpService.getDistributorRebateOptiSummary(obj).subscribe((result:any)=>{
      if(result && result['data']){
        this.totalPurchaseCurrentYear = result['data']['totalPurchase']?result['data']['totalPurchase']:0
        this.totalPurchaseYoy = result['data']['totalPurchaseYoy']?result['data']['totalPurchaseYoy']:0
        this.rebateEarnedYoy = result['data']['rebateEarnedYoy']?result['data']['rebateEarnedYoy']:0
        this.totalRebateEarnedCurrentYear = result['data']['rebateEarned']?result['data']['rebateEarned']:0
        this.overAllRebatePercent = result['data']['overallRebatePercent']?result['data']['overallRebatePercent']:0
        this.avgTotalPurchase = result['data']['avgTotalPurchase']?result['data']['avgTotalPurchase']:0
        this.avgRebateEarned = result['data']['avgRebateEarned']?result['data']['avgRebateEarned']:0
        //this.avgRebatePercent = result['data']['overallRebatePercent']?result['data']['overallRebatePercent']:0
        this.avgRebatePercent = result['data']['avgOverallRebatePercent']?result['data']['avgOverallRebatePercent']:0
      }
    })

    this.httpService.getRebateOptimizationROISummary(obj).subscribe((ROIResult:any)=>{
      if(ROIResult && ROIResult['data'] && ROIResult['data']['roiSummary']){
        this.ROIProgramsPercent = ROIResult['data']['roiSummary']['roiAverage']?ROIResult['data']['roiSummary']['roiAverage']:0
        this.ROIValue = ROIResult['data']['roiSummary']['opportunity']?ROIResult['data']['roiSummary']['opportunity']:0
      }
    })

    this.getRoiPrograms();
    this.getParentPrograms();
  }

  getRoiPrograms(){
    let obj2={
      year:this.selctedGlobalYear,
      distributorId:this.loggedDistributorId,
      limit:5,
      programType: this.programType
    }
    this.ROIPrograms = []
    this.httpService.getRebateROIPrograms(obj2).subscribe((programsResult:any) =>{
      if(programsResult && programsResult['data'] && programsResult['data']['count']>0){
        this.populateROI(programsResult['data']['roiGrowthSummary'])
        this.totalROTPrograms = programsResult['data']['count']
      }
      // else{
      //   for(let i=0;i<5;i++) {
      //     let programObjEmpty = {
      //       name: 'NA',
      //       header1: 'ROI',
      //       headerValue1: 0,
      //       header2: 'GAP',
      //       headerValue2: 0
      //     }
      //     this.ROIPrograms.push(programObjEmpty)

      //   }
      // }
    })
  }

  getParentPrograms(){
    // let reqObj={
    //   year:this.selctedGlobalYear,
    //   ra_member_id:this.loggedDistributorId,
    //   limit:5,
    //   pageNo:1,
    //   programType: this.programType
    // }
    // this.httpService.getParentPrograms(reqObj).subscribe((response:any)=>{
    //   if(response && response['data'] && response['data']['count']>0){
    //     this.populateParentPrograms(response['data']['distributorParentProgramsData'])
    //     this.totalParentPrograms = response['data']['count']
    //   }
    // })
  }


  sliderValueChange = (value:any) =>{
    value = this.alphabet[value];
    this.dataService.setAttaintmentvalue(this.alphabet[value]);
    this.attainmentRange =[value,100];
    let sliderObj= {
      year:this.selctedGlobalYear,
      distributorId:this.loggedDistributorId,
      attainmentRange:[value,100]
    }
    this.totalProgramAttainment = 0
    this.httpService.getROIAttainmentData(sliderObj).subscribe((response:any)=>{
        if(response && response['data']){
          this.totalProgramAttainment = response['data']['totalPrograms']
        }
    })
    //this.populateParentPrograms()
  }

  populateROI =(ROIPrograms:any) =>{
    ROIPrograms.map((eachProgram:any)=>{
      let eachObj={
        name:eachProgram['programName']?eachProgram['programName']:'NA',
        header1:'Opportunity',
        headerValue1:eachProgram['payoutRoi']?eachProgram['payoutRoi']:'Max',
        header2:'GAP',
        headerValue2:eachProgram['gap']?eachProgram['gap']:0,
        header4:'ROI',
        headerValue4:eachProgram['roi']? `${eachProgram['roi']}%`:'0%',
        headerValue5:eachProgram['lastInvoiceDate']?eachProgram['lastInvoiceDate']:'NA',
        Tooltip:"ROI is the ratio of opportunity and gap to the next tier, it shows the return on the next dollar spend in the program",
        programId:eachProgram['programId']?eachProgram['programId']:0,
        rebateMasterId:eachProgram['rebateMasterId']?eachProgram['rebateMasterId']:0,
        supplier:eachProgram['supplier_name']?eachProgram['supplier_name']:'NA',
        type:'roi',
      }
      this.ROIPrograms.push(eachObj)
    })
    if(this.ROIPrograms.length == 0){
      this.dataService.wndowSrollYEmitter.emit(100);
    }
  }

  populateParentPrograms = (parentPrograms: any)=>{
    let oppParentPrograms: any = [];
    parentPrograms.map((eachProgram:any)=>{
    let eachObj={
        name:eachProgram['program_name']?eachProgram['program_name']:'NA',
        header1:'Vendor',
        headerValue1:eachProgram['supplierName']?eachProgram['supplierName']:'NA',
        header2:'Opprtunity',
        headerValue2:eachProgram['paymentRoi']?eachProgram['paymentRoi']:0,
        header3:'GAP',
        headerValue3:eachProgram['gap']?eachProgram['gap']:0,
        programId:eachProgram['program_id']?eachProgram['program_id']:0,
        rebateMasterId:eachProgram['rebate_master_id']?eachProgram['rebate_master_id']:0,
        supplier:eachProgram['supplierName']?eachProgram['supplierName']:'NA',
        type:'parent',
    }
      oppParentPrograms.push(eachObj)
    })
    this.oppParentPrograms = oppParentPrograms;
    if(this.oppParentPrograms.length == 0){
      this.dataService.wndowSrollYEmitter.emit(100);
    }
  }

  viewAllROIPrograms = (slideValue:any, type: any) =>{
    let attainment:any;
    if(type == 'showAll'){
      attainment = 'showAll';
      this.dataService.setAttaintmentvalue(0);
    } else if(type == 'attainment'){
      this.programType = "both";
      attainment = slideValue;
      this.dataService.setAttaintmentvalue(slideValue);
    }
    this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization/ROIOpportunities`,{attainment:attainment,programType:"roi", subProgramType:this.programType}])
    // if(slideValue){
    //   this.dataService.setAttaintmentvalue(slideValue);
    // }else {
    //   this.dataService.setAttaintmentvalue(0);
    // }
    
  }

  viewAllParentPrograms = () =>{
   this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization/ROIOpportunities`,{programType:"parent",subProgramType:this.programType}]);
  }
  selectedData(data:any){
    this.dataService.setAttaintmentvalue(0);
    if(data?.type == 'roi'){
      // this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization/program-details`,{rebateMasterId:data?.rebateMasterId,programId:data?.programId,subProgramType:this.programType,year:this.selctedGlobalYear}])
      this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-optimization/program-details`,{programId:data?.programId,subProgramType:this.programType,year:this.selctedGlobalYear}])
    } else if(data?.type == 'parent'){
      const queryParams: any = {
        // id: data?.rebateMasterId,
        year: this.selctedGlobalYear,
        programId:data?.programId,
        programName:data?.name,
        supplier:data?.supplier,
        subProgramType:this.programType
      };
      this.router.navigate(
        [`/${this.tenantType}/rebateManagement/program-details`,data?.type],
        {
          queryParams: queryParams,
        }
      );
    }
  }

  changeView = (event:any, programType:any) =>{
    this.programType = 'group';
    if(programType =='roi'){
      this.isIndividualViewRoi = event.checked
      if(this.isIndividualViewRoi){
        this.programType = 'group';
      }else{
        this.programType = 'individual';
      }
      this.getRoiPrograms();
    } else if(programType =='parent') {
      this.isIndividualViewParent = event.checked
      if(!this.isIndividualViewParent){
        this.programType = 'group';
      }else{
        this.programType = 'individual';
      }
      this.getParentPrograms();
    }
  }
}
