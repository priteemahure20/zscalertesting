import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material/icon';
import {AuthService} from '../../../../../services/auth.service';
import {HttpService} from '../../../../../services/http.service';
import {MatDialog} from '@angular/material/dialog';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import * as moment from 'moment';
import {RaiseDisputeComponent} from './raise-dispute/raise-dispute.component';
import {MatTableDataSource} from '@angular/material/table';
import {WarningModalComponent} from '../../../../../common/warning-modal/warning-modal.component';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import { ExportModalComponent } from 'src/app/views/report-generator/export-modal/export-modal.component';
import { ReusableService } from 'src/app/services/reusable.service';
import { SucessMessageModalComponent } from 'src/app/common/sucess-message-modal/sucess-message-modal.component';
import { DataService } from 'src/app/services/data.service';
const { cloneDeep:_cloneDeep } = require('lodash');
@Component({
  selector: 'app-transaction-details',
  templateUrl: './transaction-details.component.html',
  styleUrls: ['./transaction-details.component.scss']
})
export class TransactionDetailsComponent implements OnInit {
  tenantType:any;
  lastUpdateDate:any;
  supplierName:any ='3M'
  selectedSupplierId:any;
  categoryType:any=''
  distributorId:any;
  programName:any;
  startDate:any;
  endDate:any
  previousSupplierId:any;
  basicInfoForm!: FormGroup;
  typeTabIndex:any=0;
  columnsToDisplay: any = [];
  columnsProps: any;
  dataSource: any;
  totalCount:number=0;
  reqObject: any = {};
  pagination = {
    limit: 10,
    pageNo: 1,
  }
  selectedPageLimit = this.pagination.limit;
  selectedTab:any = 'transaction';
  sort:any;
  subProgramType:any;
  constructor(public router: Router,private domSanitizer: DomSanitizer,private matIconRegistry: MatIconRegistry,private authService:AuthService,
              private httpService: HttpService, public dialog: MatDialog, private activatedRoute:ActivatedRoute, private fb: FormBuilder,private resuableService:ReusableService, private dataService:DataService) {
    this.matIconRegistry.addSvgIcon("export", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../../assets/img/icons/export.svg"));
    if(window.innerHeight == 923 || window.innerHeight == 707){
      this.dataService.wndowSrollYEmitter.emit(100)
    }else{
      this.dataService.wndowSrollYEmitter.emit(0)
    }
  }

  ngOnInit(): void {
    this.basicInfoForm = this.fb.group({
      startDate: new FormControl('', [Validators.required]),
      endDate: new FormControl('', [Validators.required]),
    }, { validator: this.checkDates });
    this.tenantType = localStorage.getItem('tenant');
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    this.activatedRoute.params.subscribe((value: any) => {
      if (value) {
        this.subProgramType = value['subProgramType'];
        this.selectedSupplierId = value['supplierId']
        this.startDate = value['startDate']
        this.endDate = value['endDate']
        this.distributorId = value['distributorId']
        this.programName = value['programName']=="undefined"?'All Vendors':value['programName']
        this.supplierName = value['supplierName']=="undefined"?'All Vendors':value['supplierName']
        this.categoryType = value['categoryType']
        this.previousSupplierId = value['previousSupplierId']
        if(this.startDate){
          this.basicInfoForm.patchValue({
            startDate:this.startDate ? new Date(this.startDate).toISOString().split('T')[0] : ''
          })
          this.basicInfoForm.controls['startDate'].disable();

        }
        if(this.endDate){
          this.basicInfoForm.patchValue({
            endDate:this.startDate ? new Date(this.endDate).toISOString().split('T')[0] : ''
          })
          this.basicInfoForm.controls['endDate'].disable();

        }
        this.reqObject = {
          supplierId: this.selectedSupplierId,
          invoiceStartDate: this.startDate,
          invoiceEndDate: this.endDate,
          limit: this.pagination.limit,
          pageNo: this.pagination.pageNo,
          type: this.selectedTab
        };
        this.getTransactionDetails()
      }
    })

  }

  checkDates(group: FormGroup) {
    if (group.controls.endDate.value && group.controls.startDate.value
        && group.controls.endDate.value < group.controls.startDate.value) {
      return { notValid: true }
    }
    return null;
  }

  navigateToHome = () =>{
    this.router.navigate([`/${this.tenantType}/home`])
  }

  navigateToMyDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])
  }

  navigateToFinancialHealth = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/financial-health`,{distributorId:this.distributorId,subProgramType:this.subProgramType}]);
  }

  navigateToSupplierDashboard = () =>{
    // this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-program-details`],
    //   { queryParams:{name:this.supplierName,programId:this.distributorId,categoryType:this.categoryType,supplierId:this.distributorId}});
    this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-program-details`],
      { queryParams:{name:this.supplierName,programId:this.distributorId,categoryType:this.categoryType,supplier:this.previousSupplierId}});
  }

  export = () =>{
    // const payoutObj = { payoutTicketNo: payoutId }
    const transactionObj = _cloneDeep(this.reqObject);
    delete transactionObj['pageNo'];
    delete transactionObj['limit'];
    this.httpService.fetchSupplierTransactionData(transactionObj).subscribe(response => {
      if (response && response['data']['transactions'].length == 0) {
        const dialogRef = this.dialog.open(ExportModalComponent, {
          width: '416px',
          height: '185px',
          panelClass: 'dialog-container-custom',
          data: { message: "No records found to export" },

        });
        dialogRef.afterClosed().subscribe((result: any) => {
        });
      } else {
        const allData = this.mapTransactionData(response?.data?.transactions);
        if (allData.length > 0) {
          const headers = Object.keys(allData[0]);
          this.downloadFile(allData, headers,"Transaction");
        }
      }
    })
  }

  downloadFile(data: any, header: any, filename = 'data') {
    let csvData = this.resuableService.convertToCSV(data, header);
    let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
    const dialogRef = this.dialog.open(SucessMessageModalComponent, {
      width: '420px',
      height: '170px',
      data: { "type": `${filename} Exported successfully ${data.length} records.`, actionStatus: 'success' },
      disableClose: true
    });
  }

  raiseDispute = () =>{
    const dialogRef = this.dialog.open(RaiseDisputeComponent, {
      width: '941px',
      height: '407px',
      panelClass: 'dialog-container-custom',
      disableClose: true,
      data: {name:this.programName,startDate:this.startDate,endDate:this.endDate,raisedAganist:this.selectedSupplierId},

    });
    dialogRef.afterClosed().subscribe((result:any)=>{
      console.log("result--->",result)
      if(result){
        this.httpService.saveDistributorDisputeTicket(result).subscribe((response:any)=>{
          if(response && response['data']){
            const closeDialog = this.dialog.open(WarningModalComponent, {
              width: '450px',
              height: '194px',
              data: {type:'agreementDetailsClose',message:`Dispute raised successfully`},
              disableClose: true,
            });
            setTimeout(()=>{
              closeDialog.close();
            },5000)
          }

        })

      }
    })
  }

  populateHeaders = () => {
    this.columnsToDisplay = [
      { header: 'Vendor name', field: 'vendorName'},
      { header: 'Invoice No', field: 'invoiceNo'},
      { header: 'Invoice Date', field: 'invoiceDate',},
      { header: 'Product ID', field: 'productId'},
      { header: 'Product Description', field: 'productDescription'},
      { header: 'Vendor Category', field: 'supplierCategory'},
      { header: 'Quantity', field: 'quantity'},
      { header: 'Transaction AMT', field: 'transactionAMT'},
      { header: 'PO Number', field: 'PONumber'},
      { header: 'Notes', field: 'note'},
    ];
    this.columnsProps = this.columnsToDisplay.map((column: any) => { return column.field });

  }

  populateTransactionDetails = (content: any) => {
    const tableData: any = [];
    for (let i = 0; i < content.length; i++) {
      let obj: any = {};
      obj['vendorName'] = content && content[i]['vendor_name'] ? content[i]['vendor_name'] : 'NA'
      obj['invoiceNo'] = content && content[i]['invoice_no'] ? content[i]['invoice_no'] : 'NA'
      obj['invoiceDate'] = content && content[i]['invoice_date'] ? `${this.getDate(content[i]['invoice_date'])}` : 'NA'
      obj['productId'] = content && content[i]['product_id'] ? content[i]['product_id'] : 'NA'
      obj['productDescription'] = content && content[i]['product_description'] ? content[i]['product_description'] : 'NA'
      obj['supplierCategory'] = content && content[i]['supplier_category'] ? content[i]['supplier_category'] : 'NA'
      obj['quantity'] = content && content[i]['quantity'] ? content[i]['quantity'] : 0
      obj['transactionAMT'] = content && content[i]['transaction_amount'] ? this.resuableService.significantNumber(content[i]['transaction_amount']) : '$0'
      obj['PONumber'] = content && content[i]['po_number'] ? content[i]['po_number'] : 'NA'
      obj['note'] = content && content[i]['note'] ? content[i]['note'] : ''
      tableData.push(obj)
    }
    this.dataSource = new MatTableDataSource(tableData);
  }


  getTransactionDetails = () =>{
    if(this.dataSource && this.dataSource['data'].length>0 && this.pagination['pageNo']==1){
      this.dataSource = new MatTableDataSource([])
    }
    this.populateHeaders();
    this.httpService.fetchSupplierTransactionData(this.reqObject).subscribe(response=>{
      if(response && response['data'] && response['data']['count']>0){
        this.totalCount = response['data']['count']
        this.populateTransactionDetails(response['data']['transactions']);
      }else{
        this.dataSource = new MatTableDataSource([]);
      }
    });
  }

  getNextPage = (event:any) =>{
    this.pagination['pageNo'] = parseInt(event['pageIndex']) + 1
    this.reqObject['limit'] = this.pagination['limit']
    this.reqObject['pageNo'] = this.pagination['pageNo']
    this.getTransactionDetails();
  }

  selectedViewPageLimit = (limitValue:any) =>{
    this.pagination['limit'] = parseInt(limitValue);
    this.selectedPageLimit = this.pagination.limit;
    this.pagination['pageNo'] = 1;
    this.reqObject['limit'] = this.pagination['limit']
    this.reqObject['pageNo'] = this.pagination['pageNo']
    this.getTransactionDetails();
  }

  goToPageNumber = (event:any) =>{
    let value = Math.ceil(this.totalCount / this.pagination['limit'])
    if (event <= value) {
      this.pagination['pageNo'] = parseInt(event);
      this.reqObject['limit'] = this.pagination['limit']
      this.reqObject['pageNo'] = this.pagination['pageNo']
      this.getTransactionDetails();
    } else {
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: { "type": "PageNo entered out of range." },
        disableClose: true,
      });
      setTimeout(() => {
        dialogRef.close()
      }, 2000)

      dialogRef.afterClosed().subscribe((result: any) => {
        if (this.dataSource && this.dataSource['data'] && this.dataSource['data'].length > 0) {
          this.dataSource['data'] = []
        }
        this.pagination['pageNo'] = 1;
        this.reqObject['limit'] = this.pagination['limit']
        this.reqObject['pageNo'] = this.pagination['pageNo']
        this.getTransactionDetails();
      })
    }
  }

  onTabChanged = (event:any)=>{
    if(event && event.hasOwnProperty('tab')){
      // this.reqObject = {}
      this.reqObject['limit']=this.pagination['limit'];
      this.reqObject['pageNo']=this.pagination['pageNo'];
    }

      if(event && event['index']==0){
        this.selectedTab =  'transaction'
      }else if(event && event['index']==1){
        this.selectedTab =  'summary'
      }else{
        this.selectedTab =  'corporate'
      }
      this.reqObject['type'] = this.selectedTab;
      this.getTransactionDetails();
      //this.getAllFilterData()
  }

  mapTransactionData = (content: any) => {
      return content.map((row: any) => ({
        "VENDOR NAME" : row && row['vendor_name'] ? `"${row['vendor_name'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
        "VENDOR PIVOT ID" : row && row['vendor_pivot_id'] ? `"${row['vendor_pivot_id'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
        "INVOICE NO" : row && row['invoice_no'] ? row['invoice_no'] : 'NA',
        "INVOICE DATE" : row && row['invoice_date'] ? `${this.getDate(row['invoice_date'])}` : 'NA',
        "PRODUCT ID" : row && row['product_id'] ? `"${row['product_id'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
        "PRODUCT DESCRIPTION" : row && row['product_description'] ? `"${row['product_description'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
        "SUPPLIER CATEGORY" : row && row['supplier_category'] ? `"${row['supplier_category'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
        "QUANTITY" : row && row['quantity'] ? row['quantity'] : 'NA',
        "TRANSACTION AMOUNT" : row && row['transaction_amount'] ? row['transaction_amount'] : 'NA',
        "PO_NUMBER" : row && row['po_number'] ? `"${row['po_number'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
        "NOTES" : row && row['note'] ? `"${row['note'].replaceAll('"','""').replaceAll(",","")}"` : ''
      }))
  }

  public getDate = (date:any) =>{
    if(date){
      let modifedDate = moment(new Date(date),"YYYYMMDD")
      return modifedDate.format('MM/DD/YYYY')
    }else{
      return 'NA'
    }
  }

  navigateToByRebateProgram(){
    this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-program-details`],{ queryParams: { name: this.supplierName,programId:this.distributorId,categoryType:this.categoryType,subProgramType:this.subProgramType}});
  }

  sortByColumnName = (data:any) =>{
    this.sort = this.dataSource.sort;
    // this.dataSource = new MatTableDataSource([])
    if(data['direction']){
      if(this.reqObject['sorting'] && this.reqObject['sorting'].length > 0){
        const isFound = this.reqObject['sorting'].find((row:any) => row['orderBy'] === data['active']);
        if(isFound){
          this.reqObject['sorting'] = this.reqObject['sorting'].map((row:any)=>{
            if(row['orderBy'] === data['active']){
              row['orderType'] = data['direction']
            }
            return row;
          })
        }
        else{
          this.reqObject['sorting'] = [{orderBy:data['active'],orderType:data['direction']}]
        }
      }else{
        this.reqObject['sorting'] = [{orderBy:data['active'],orderType:data['direction']}]

      }
    }else{
      if(this.reqObject.hasOwnProperty('sorting')){
        delete this.reqObject['sorting']
      }
    }
    this.getTransactionDetails();
  }

}
