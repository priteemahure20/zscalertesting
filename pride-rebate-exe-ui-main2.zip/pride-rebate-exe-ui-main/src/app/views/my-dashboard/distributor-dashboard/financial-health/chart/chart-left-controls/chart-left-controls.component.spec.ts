import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartLeftControlsComponent } from './chart-left-controls.component';

describe('ChartLeftControlsComponent', () => {
  let component: ChartLeftControlsComponent;
  let fixture: ComponentFixture<ChartLeftControlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChartLeftControlsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartLeftControlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
