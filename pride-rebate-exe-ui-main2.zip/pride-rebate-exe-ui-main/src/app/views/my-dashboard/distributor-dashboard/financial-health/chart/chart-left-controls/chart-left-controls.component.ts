import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-chart-left-controls',
  templateUrl: './chart-left-controls.component.html',
  styleUrls: ['./chart-left-controls.component.scss']
})
export class ChartLeftControlsComponent implements OnInit {
  @Input() data: any;
  @Output() 
  selectedControlEvent = new EventEmitter();
  selectedControl: any = 'total_sales';

  constructor(private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer) { 
    this.matIconRegistry.addSvgIcon("up-arrow", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/up_arrow_icon.svg"))
    this.matIconRegistry.addSvgIcon("down-arrow", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/down_icon.svg"))
  }

  ngOnInit(): void {
  }

  abbreviateNumber = (value:any) => {
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore

      notation: "compact",
      compactDisplay: "short",
      style: "currency",currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  }

  control(data: any,selectedLabel:string) {
    console.log("label",selectedLabel);
    
    this.selectedControl = data;
    this.selectedControlEvent.emit({...data,label:selectedLabel});
  }
}
