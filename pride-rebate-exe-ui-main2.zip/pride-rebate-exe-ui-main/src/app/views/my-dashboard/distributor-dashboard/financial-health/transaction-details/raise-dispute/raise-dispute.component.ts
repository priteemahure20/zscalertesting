import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material/icon';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import * as moment from 'moment';
import {MatTableDataSource} from '@angular/material/table';
import {HttpService} from '../../../../../../services/http.service';

@Component({
  selector: 'app-raise-dispute',
  templateUrl: './raise-dispute.component.html',
  styleUrls: ['./raise-dispute.component.scss']
})
export class RaiseDisputeComponent implements OnInit {
  disputeForm!: FormGroup;
  groupName:any;
  constructor(public dialogRef: MatDialogRef<RaiseDisputeComponent>,
              private domSanitizer: DomSanitizer,private matIconRegistry: MatIconRegistry,@Inject(MAT_DIALOG_DATA) public data: any,private fb: FormBuilder, private httpService: HttpService) {
    this.matIconRegistry.addSvgIcon("close", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../../../assets/img/icons/close.svg"));
  }

  close = () =>{
    this.dialogRef.close()
  }


  ngOnInit(): void {
    this.disputeForm = this.fb.group({
      raised_against_name:new FormControl('',[Validators.required]),
      ticketTitle:new FormControl('',[Validators.required]),
      ticketDescription:new FormControl('',[Validators.required]),
      startDate:new FormControl('',[Validators.required]),
      endDate:new FormControl('',[Validators.required]),
    },{ validator: this.checkDates })
    if(this.data){
        this.disputeForm.patchValue({
          raised_against_name:this.data['name']?this.data['name']:'',
          startDate:this.data['startDate'] ? new Date(this.data['startDate']).toISOString().split('T')[0] : '',
          endDate:this.data['endDate'] ? new Date(this.data['endDate']).toISOString().split('T')[0] : ''
        })
      this.disputeForm.controls['raised_against_name'].disable()

    }
    this.fetchGroupName()
  }

  checkDates(group: FormGroup) {
    if (group.controls.endDate.value && group.controls.startDate.value
        && group.controls.endDate.value < group.controls.startDate.value) {
      return { notValid: true }
    }
    return null;
  }
  fetchGroupName() {
    this.httpService.fetchMetadata()
        .subscribe((resp) => {
          this.groupName = resp.data ? resp.data['GROUP_NAME'] : '';
        }, (err) => {
        });
  }

  submitDispute = () =>{
    if(this.disputeForm.valid){
      let finalObj = {
        title:this.disputeForm.value['ticketTitle'],
        raised_against_id:parseInt(this.data['raisedAganist']),
        raised_by_name: this.groupName,
        description:this.disputeForm.value['ticketDescription'],
        raised_against_name:this.data['name'],
        startDate:this.disputeForm.value['startDate'],
        endDate:this.disputeForm.value['endDate']
      }
      this.dialogRef.close(finalObj)
    }
  }

  changeDateFormat = (value:any) =>{
    return moment.utc(value).local().format('MM/DD/YYYY')
  }

}
