import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {HttpService} from '../../../../services/http.service';
import {YEAR} from '../../../../helpers/constants';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {TitleCasePipe} from '@angular/common';
import { DataService } from 'src/app/services/data.service';
import { BgDashboardService } from 'src/app/rbac/KPIs/bg-dashboard.service';
import { ViewMoreDataModalComponent } from 'src/app/views/rebate-management/financial-health/rebate-details-program/view-more-data-modal/view-more-data-modal.component';
import * as moment from 'moment';
import { MatDialog,MatDialogRef } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import {Subject} from 'rxjs';
import { element } from 'protractor';
import { ReusableService } from 'src/app/services/reusable.service';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material/icon';
import { SucessMessageModalComponent } from 'src/app/common/sucess-message-modal/sucess-message-modal.component';
import { downloadFile } from 'src/app/helpers/commonUtils';


@Component({
  selector: 'app-distributor-financial-health',
  templateUrl: './distributor-financial-health.component.html',
  styleUrls: ['./distributor-financial-health.component.scss']
})
export class DistributorFinancialHealthComponent implements OnInit {
  tenantType:any;
  lastUpdateDate:any;
  globalYears:any=[]
  selctedGlobalYear:any;
  totalSelectedValues:number =0;
  searchName:any="";
  filterClear:boolean = false;
  allDistributors:any=[];
  selectedDistributor:any="";
  autoCompleteDistributors:any=[];
  control = new FormControl('');
  filteredDistributors: Observable<any[]> | undefined;
  pagination = {
    limit: 5,
    pageNo: 1,
  }
  selectedPageLimit:number=15;
  isViewResetPagination:boolean = false
  isShowValueAdditive=true;
  valueClick='total_purchase';
  reqObject:any={}
  // financialGrpData:any=[]
  financialGrpData:any=[]
  selectedDistributorId:any
  showViewAllRebateProgramDetail:boolean = true
  rebateTypes = [
    {value:"rebate", displayText:"By Group"},
    {value:"dealer", displayText:"By Program"},
  ];
  selectedRebateType = "dealer";
  label:any='Total Purchase';
  programTypes = [
    {value:'both', displayText:'Both'},
    {value:'group', displayText:'Group'},
    {value:'individual', displayText:'Individual'},
  ]
  selectedProgramType = 'both';
  SortTypes =[
    {value:'',displayText:'Sort By'},
    {value:'supplierName_asc', displayText:'Vendor Name Asc' },
    {value:'supplierName_desc', displayText:'Vendor Name Desc'},
    {value:'totalPurchase_asc', displayText:'Total Purchase Asc'},
    {value:'totalPurchase_desc', displayText:'Total Purchase Desc'}
  ]
  selectedSortType= '';
  columnsToDisplay: any = [];
  columnsProps: any;
  dataSource: any;
  rebateProgramDetals: any = {};
  isListView:boolean = true;
  isToogledSupplier:boolean= false;
  isZeropurchase:boolean=true;
  supplierId:any;
  Obj:any
  isSortApplied: Subject<any> = new Subject();
  tooltip='Rebate % is calculated based on Rebate Earned to date divided by the YTD Purchases reported. This figure does not include any potential/future eligible rebates where thresholds or criteria have not yet been achieved. ';
  supplierDropdownData: any=['All vendors']
  selectSupplier:any

  constructor(public router: Router,private httpService: HttpService,private titlecasePipe:TitleCasePipe,public activatedRoute: ActivatedRoute, private dataService: DataService,  private bgDashboardRbacService: BgDashboardService,public dialog: MatDialog,private reusableService: ReusableService,private resuableService: ReusableService,private domSanitizer: DomSanitizer,private matIconRegistry: MatIconRegistry) {
  //  this.dataService.ValueAdded.subscribe((res)=>{
  //   console.log("res",res);
  //   this.valueClick=res;
  // })
  this.matIconRegistry.addSvgIcon("export", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/export.svg"));

   }

  ngOnInit(): void {
    // this.selectedRebateType = this.dataService.getDropdownState();
    this.subjectsUpdate();
    this.applyRBAC();
    this.globalYears = YEAR
    let date = new Date();
    let year = localStorage.getItem("year")
    if(year){
      this.selctedGlobalYear = parseInt(year)
    }else{
      this.selctedGlobalYear = date.getFullYear()
      localStorage.setItem("year",this.selctedGlobalYear.toString())
    }
    this.tenantType = localStorage.getItem('tenant');
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    this.filteredDistributors = this.control.valueChanges.pipe(
        startWith(''),
        map((value:any) => this._filter(value || '')),
    );
    this.activatedRoute.paramMap.subscribe((params:any) => {
      if (params && params['params'] && params['params']['distributorId']) {
        this.selectedDistributorId = params['params']['distributorId']
        if(params['params']['subProgramType']){
          this.selectedProgramType = params['params']['subProgramType'];
          this.supplierId=params['params']['supplierID'];
        }
        this.reqObject = {
          year:this.selctedGlobalYear,
          group:'dealer',
          distributorId:this.selectedDistributorId
        }
        this.rebateProgramDetals ={
          year:this.selctedGlobalYear,
          distributorId:this.selectedDistributorId
        }
        this.pagination['limit'] = this.selectedPageLimit
        this.pagination['pageNo'] =1
        this.rebateProgramDetals['limit']=this.pagination['limit']
        this.rebateProgramDetals['pageNo']=this.pagination['pageNo']
        // this.getDetails();
        this.reqObject['limit']=this.pagination['limit']
        this.reqObject['pageNo']=this.pagination['pageNo']
        this.reqObject['programType'] = 'both';
        this.zeroVendorChanges(event);
        this.populateHeaders();
        // this.reqObject['supplierName'] ='ASC';
        // this.getFinancialHealthGroupData();
        // this.getFinancialHealthDistributorsGroupData();
      
        this.httpService.postMethod('/api/associate/dropdown?type=distributor',{}).subscribe((response: any) => {
          this.supplierDropdownData = response.data
          this.supplierId=101476
        })
        
      }
    })
  }

  subjectsUpdate() {
    // console.log('subject update called');
    this.dataService.rbacConfigReceivedSubject.subscribe(
      data => {
        console.log('subject internal', this.dataService.roleBasedAccessConfig);
        this.applyRBAC();
      }
    );
  }

  applyRBAC() {
    // console.log('rbac called');
    this.showViewAllRebateProgramDetail = this.bgDashboardRbacService.canShowViewAllRebateProgramDetail();
    // console.log('financial health true or false', this.showViewAllRebateProgramDetail);
    // this.showRebateLibrary = this.bgDashboardRbacService.canShowRebateLibrary();
    // this.showRebateGovernance = this.bgDashboardRbacService.canShowRebateGovernance();
    // this.showFinancialHealth = this.bgDashboardRbacService.canShowFinancialHealth();
    // this.showRebateOptimization = this.bgDashboardRbacService.canShowRebateOptimization();
    // this.showWeeklyLoginReport = this.bgDashboardRbacService.canShowWeeklyLoginReport();
    // throw new Error('Method not implemented.');
  }

  navigateToHomeDashboard = () => {
    this.router.navigate([`/${this.tenantType}/home`])
  }

  navigateToMyDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])
  }
  selectYear = (year: any) => {
    this.selctedGlobalYear = year;
    localStorage.setItem("year",this.selctedGlobalYear.toString())
    this.reqObject = {
      year:this.selctedGlobalYear,
      group:'dealer',
      distributorId:this.selectedDistributorId?this.selectedDistributorId:10003

    }
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    // this.getFinancialHealthGroupData()
    if(this.isToogledSupplier){
      this.rebateProgramDetals['supplier_name'] 
      this.getDetails();
    }else{
      this.reqObject['supplier_name'] 
      this.getFinancialHealthDistributorsGroupData();
    }
  }

  // onTypeChange = (value:any) =>{
  //   this.selectedRebateType = value;
  //   this.reqObject['group'] = this.selectedRebateType
  //   this.pagination['limit'] = this.selectedPageLimit
  //   this.pagination['pageNo'] =1
  //   this.reqObject['limit']=this.pagination['limit']
  //   this.reqObject['pageNo']=this.pagination['pageNo']
  //   if(this.selectedRebateType == 'distributor_segment'){
  //     this.getAutoCompleteDistributors()
  //   }else{
  //     if(this.reqObject && this.reqObject.hasOwnProperty('segment_name')){
  //       delete this.reqObject['segment_name']
  //     }
  //   this.getDetails();
  // }
  searchBySupplier = (event:any) =>{
    this.selectSupplier=event
    this.selectSupplier= this.dataService.setSuppliervalue(this.selectSupplier)
    console.log("suppllier",this.supplierDropdownData)
    console.log("suppllier",this.selectSupplier)
    
    // this.reqObject = {
    //   year:this.selctedGlobalYear,
    //   group:this.selectedRebateType,
    //   distributorId:this.selectedDistributorId
    // }
    // this.rebateProgramDetals ={
    //   year:this.selctedGlobalYear,
    //   group:this.selectedRebateType,
    //   distributorId:this.selectedDistributorId
    // }
    // if(!value){
    //   if(this.reqObject.hasOwnProperty('supplier_name')){
    //     delete this.reqObject['supplier_name']
    //   }else{
    //     delete this.rebateProgramDetals['supplier_name']
    //   }
    // }else{
    //   this.reqObject['supplier_name'] =value
    //   this.rebateProgramDetals['supplier_name'] =value

    // }
    // this.pagination['limit'] = this.selectedPageLimit
    // this.pagination['pageNo'] =1
    // this.reqObject['limit']=this.pagination['limit']
    // this.reqObject['pageNo']=this.pagination['pageNo']
    // this.rebateProgramDetals['limit']=this.pagination['limit']
    // this.rebateProgramDetals['pageNo']=this.pagination['pageNo']
    // // this.getFinancialHealthGroupData()
    // if(this.isToogledSupplier){
    //   this.getDetails();
    // }else{
    //   this.getFinancialHealthDistributorsGroupData();
    // }

  }

  selectDistributor = (value:any) =>{
    this.reqObject = {
      year:this.selctedGlobalYear,
      group:this.selectedRebateType,
      distributorId:this.selectedDistributorId
    }
    this.reqObject['segment_name'] =value
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.getFinancialHealthGroupData()

  }

  getAutoCompleteDistributors=()=>{
    this.control.reset();
    this.autoCompleteDistributors = []
    this.httpService.getSupplierDistributors().subscribe((response:any)=>{
      if(response && response['data'] && response['data'].length>0){
        this.autoCompleteDistributors =response['data']
      }
    })
    // this.selectedDistributor = ""
    // this.httpService.getCreateProgramSegments().subscribe((response: any) => {
    //   if(response && response['data'] && response['data']['segments'].length>0){
    //     this.allDistributors = response['data']['segments'].map((obj:any)=>obj['segment_name'])
    //     this.selectedDistributor = response['data']['segments'][0]['segment_name']
    //     this.reqObject['segment_name'] = this.selectedDistributor
    //     this.getFinancialHealthDistributorsGroupData()
    //   }
    // }
   //
  }

  private _filter(value: string): string[] {
    const filterValue = this._normalizeValue(value);
    return this.autoCompleteDistributors.filter((street
    :any)=> this._normalizeValue(street['name']).includes(filterValue));
  }

  private _normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, '');
  }

  selectedValue = (value:any) =>{
    this.reqObject = {
      year:this.selctedGlobalYear,
      group:this.selectedRebateType,
      distributorId:this.selectedDistributorId
    }
    this.selectedPageLimit = 15
    this.reqObject['segment_name'] =value
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.getFinancialHealthGroupData()
  }
  changeView = (event:any) =>{
    this.isListView = event.checked
    this.isViewResetPagination=true
    if(!this.isListView){
      this.pagination['pageNo']=1
      this.reqObject['pageNo']=1
      this.reqObject['limit']=15
      this.isToogledSupplier = false
      // this.getSupplierHierarchyData()
      this.zeroVendorChanges(event);
      this.populateHeaders();
      
    }else{
      this.isToogledSupplier = true
    
      this.pagination['pageNo']=1
      this.rebateProgramDetals['pageNo']=1
      this.rebateProgramDetals['limit']=15
      this.getDetails();
      this.populateHeaders();
      
    }
  }

  getFinancialHealthGroupData = () =>{
    this.totalSelectedValues = 0;
    this.financialGrpData = []
   this.httpService.getFinancialHealthGrpDistributorData(this.reqObject).subscribe((response:any)=>{
     if(response && response['data'] && response['data']['count']>0){
       this.totalSelectedValues = response['data']['count']
      //  this.populateData(response['data']['data_response'])
       this.GroupTypeDetail([response['data']['data_response']]);
     }else{
      this.GroupTypeDetail([]);
    }
     this.isViewResetPagination = this.totalSelectedValues == 0;
   },error=>{
   })
   
  }
  getFinancialHealthDistributorsGroupData = () =>{
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.reqObject['limit']=this.pagination['limit']
    this.totalSelectedValues = 0;
    this.httpService.getFinancialHealthGrpDistributorData(this.reqObject).subscribe((response:any)=>{
      if(response && response['data'] && response['data']['count']>0){
        this.totalSelectedValues = response['data']['count']
          // this.populateData(response['data']['data_response'])
          this.GroupTypeDetail(response['data']['data_response'])
      }else{
        this.GroupTypeDetail([]);
      }
            this.isViewResetPagination = this.totalSelectedValues == 0;
    })
  }
  getDetails(){
    this.rebateProgramDetals['year'] = this.selctedGlobalYear;
    this.rebateProgramDetals['limit'] = this.pagination.limit;
    this.rebateProgramDetals['pageNo'] = this.pagination.pageNo;
    this.rebateProgramDetals['distributorId'] = this.selectedDistributorId;
    // this.rebateProgramDetals['supplierId'] ="101301" ;
    this.httpService.postMethod('/api/distributor/finance/supplier/details', this.rebateProgramDetals).subscribe((response: any) => {
      if (response && response['data']?.count > 0) {
        this.totalSelectedValues = response['data']['count']
        // this.populateData(response['data']['data_response'])
        this.vendorTypeDetail(response['data']['data_response']);
        this.supplierId=response['data']['data_response'][0]['supplier_id']
        
        // this.totalPrgmDetailCount = distributorResponse && distributorResponse['data']?.count;
      } else {
       
        this.vendorTypeDetail([]);
      }
      this.isViewResetPagination = this.totalSelectedValues == 0;
    },error=>{
    })
  }
  getViewNextPage = (value:any) =>{
    this.pagination['pageNo']=parseInt(value['pageIndex'])+1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    // this.getFinancialHealthGroupData()
    if(this.isToogledSupplier){
      this.getDetails();
    }else{
      this.getFinancialHealthDistributorsGroupData();
    }
  }

  selectedViewPageLimit = (value:any) =>{
    this.isViewResetPagination = true
    this.selectedPageLimit = parseInt(value)
    this.pagination['limit']=parseInt(value)
    this.pagination['pageNo']=1;
    setTimeout(()=>{
      // this.getFinancialHealthGroupData()
      if(this.isToogledSupplier){
        this.getDetails();
      }else{
        this.getFinancialHealthDistributorsGroupData();
      }
    })
    this.isViewResetPagination = false
  }

  goToPageViewNumber = (value:any) =>{
    if(value){
      this.pagination['pageNo']=parseInt(value);
      this.reqObject['limit']=this.pagination['limit']
      this.reqObject['pageNo']=this.pagination['pageNo']
      // this.getFinancialHealthGroupData()
      // this.getFinancialHealthDistributorsGroupData();
      if(this.isToogledSupplier){
        this.getDetails();
      }else{
        this.getFinancialHealthDistributorsGroupData();
      }
    }else {
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: {"type": "PageNo entered out of range."},
        disableClose: true,
      });
      setTimeout(() => {
        dialogRef.close()
      }, 2000)

      dialogRef.afterClosed().subscribe((result: any) => {
        if (this.dataSource && this.dataSource['data'] && this.dataSource['data'].length > 0) {
          this.dataSource['data'] = []
        }
        this.pagination['pageNo'] = 1;
        this.rebateProgramDetals['limit'] = this.pagination['limit']
        this.rebateProgramDetals['pageNo'] = this.pagination['pageNo']
        // this.getAllRebateProgramDetails()
        if(this.isToogledSupplier){
          this.getDetails();
        }else{
          this.getFinancialHealthDistributorsGroupData();
        }
      })
    }
  }

  populateData = (allData:any) =>{
    this.financialGrpData = []
    for(let i=0;i<allData.length;i++){
      let objectData:any={}
      if(this.selectedRebateType== 'rebate'){
        objectData['name'] = allData[i]['rebate_type']
      }else{
        objectData['name'] = allData[i]['supplier_name']
        objectData['supplier_id'] = allData[i]['supplier_id']
      }
      objectData['distributorId'] = this.selectedDistributorId
      objectData['total_purchase'] = allData[i]['total_purchase']
      objectData['rebate_earned'] = allData[i]['rebate_earned']
      objectData['rebatable_purchase'] = allData[i]['rebatable_purchase']
      this.financialGrpData.push(objectData)
    }
    if(this.financialGrpData.length>0){
      this.changeDataBasedOnSummaryType()
    }
  }

  navigateToRebateDetail =() =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/supplier/rebate-program-details`])
  }

  getLabel(label:any){
    this.label=label;
    this.changeDataBasedOnSummaryType()
  }

  categoryChange(data:any){
    this.selectedRebateType=data;
    if(this.selectedRebateType==="dealer"){
      this.isToogledSupplier=true;
      this.getDetails()
      this.populateHeaders();
    }else{
      this.isToogledSupplier=false;
      this.populateHeaders();
    }
    this.selectedProgramType = 'both';
    this.dataService.setDropdownState(data);
    this.reqObject = {
      year:this.selctedGlobalYear,
      group:"dealer",
      distributorId:this.selectedDistributorId?this.selectedDistributorId:10003
    }
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.reqObject['programType'] = "both";
    // this.getFinancialHealthGroupData();
    this.getFinancialHealthDistributorsGroupData();
    }

  programTypeChange(data:any){
    console.log('program type', data);
    this.selectedProgramType=data;
    this.reqObject = {
      year:this.selctedGlobalYear,
      group:this.selectedRebateType,
      distributorId:this.selectedDistributorId?this.selectedDistributorId:10003
    }
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.reqObject['programType'] = this.selectedProgramType;
    this.reqObject['supplierName']='ASC';
    // this.getFinancialHealthGroupData();
  }

  navigateToDetails(data:any){
    if(this.selectedRebateType=='dealer'){
      this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-program-details`],{ queryParams: { name: data?.name,programId:data?.distributorId,categoryType:this.selectedRebateType,supplier:data?.supplier_id}});
    }else{
      this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/rebate-program-details`],{ queryParams: { name: data?.name,programId:data?.distributorId,categoryType:this.selectedRebateType,subProgramType:this.selectedProgramType}});

    }
  }

  changeDataBasedOnSummaryType = () =>{
    if(this.label=='total purchase' || this.label== 'Total Purchase'){
      for(let i=0;i<this.financialGrpData.length;i++){
        this.financialGrpData[i]['totalSales'] = this.financialGrpData[i]['total_purchase']
      }
    }else if(this.label=='covered purchase' || this.label== 'Covered Purchase'){
      for(let i=0;i<this.financialGrpData.length;i++){
        this.financialGrpData[i]['totalSales'] = this.financialGrpData[i]['rebatable_purchase']
      }
    }else {
      for(let i=0;i<this.financialGrpData.length;i++){
        this.financialGrpData[i]['totalSales'] = this.financialGrpData[i]['rebate_earned']
      }
    }
  }

  viewMore = ()=>{
    const dialogRef = this.dialog.open(ViewMoreDataModalComponent, {
      width: '446px',
      height: '314px',
      panelClass: 'dialog-container-custom',
      data:{categoryType:this.selectedRebateType,year:this.selctedGlobalYear,distributorId:this.selectedDistributorId,}
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      if(result){
        // if(this.userType === UserType.Distributor){
          this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/transaction-details`,
            {supplierId:result['selectSupplier'],startDate:this.formatDate(result['startDate']),endDate:this.formatDate(result['endDate']),categoryType:this.selectedRebateType,
            programName:result['supplierName'],distributorId:this.selectedDistributorId ,previousSupplierId:result['selectSupplier'],supplierName:result['supplierName'],subProgramType:"group"}])
        // }
      }
    });
  }
  formatDate = (date:any) => {
    return  moment.utc(date).local().format('YYYY-MM-DD')
  }

  SortTypeChange(data:any){
    console.log('sorttype', data);
    // this.selectedSortType=data;
    this.reqObject = {
      year:this.selctedGlobalYear,
      group:this.selectedRebateType,
      distributorId:this.selectedDistributorId?this.selectedDistributorId:10003
    }
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.reqObject['programType'] = this.selectedProgramType;
    if(data==='supplierName_asc'){
      this.reqObject['supplierName'] ='ASC';
    }else if(data==='supplierName_desc'){
            this.reqObject['supplierName'] ='DESC';}
          else if(data==='totalPurchase_asc'){
                this.reqObject['totalPurchase'] ='ASC';}
                else if(data==='totalPurchase_desc'){
                        this.reqObject['totalPurchase'] ='DESC';
                      }
    // this.getFinancialHealthGroupData();
  }

  populateHeaders = () => {
        if (this.isToogledSupplier){
          this.columnsToDisplay = [
            { header: 'Vendor name', field: 'supplier_name',displayFilter: false,cell: (element: any) => `${element.name}`, placeHolder: 'Vendor name'},
            { header: 'Total Purchase', field: 'total_purchase'},
            { header: 'Covered Purchase', field: 'rebatable_purchase'},
            { header: 'Rebate Earned', field: 'rebate_earned'},
            { header: 'Program type', field: 'rebate_type', displayFilter: false, cell: (element: any) => `${element.name}`, placeHolder: 'Program type' },
            { header: 'Program name', field: 'program_name',displayFilter:false,cell:(element:any)=>`${element.name}`,placeHolder:'Program name' },
            { header: 'Program ID', field: 'program_id'},
            { header: 'Last Invoice Date',field:'last_invoice_date'}
            ];
            // this.columnsProps = this.columnsToDisplay.map((column: any) => { return column.field });
        }else{
              this.columnsToDisplay = [
                { header: 'Vendor name', field: 'supplier_name',displayFilter: false,cell: (element: any) => `${element.name}`, placeHolder: 'Vendor name'},
                { header: 'Total Purchase', field: 'total_purchase'},
                // { header: 'Covered Purchase', field: 'rebatable_purchase'},
                { header: 'Rebate Earned', field: 'rebate_earned'},
                { header: 'YTD Rebate %', field:'rebate_percentage' ,title:'new'},
                { header: 'Last Invoice Date',field:'last_invoice_date'}
                ];
            }
      this.columnsProps = this.columnsToDisplay.map((column: any) => { return column.field });
      
  }
  vendorTypeDetail = (content:any) =>{
    const tableData: any = [];
    for (let i = 0; i < content.length; i++) {
      let obj: any = {};
      obj['supplier_name'] = content && content[i]['supplier_name'] ? content[i]['supplier_name'] : 'NA'
      obj['program_name'] = content && content[i]['program_name'] ? content[i]['program_name'] : 'NA'
      obj['total_purchase'] = content && content[i]['total_purchase'] ? this.significantNumber(this.fixedDecimalValue(content[i]['total_purchase'])) : '$0.00'
      obj['rebatable_purchase'] = content && content[i]['rebatable_purchase'] ? this.significantNumber((content[i]['rebatable_purchase'])):"-"
      obj['rebate_earned'] = content && content[i]['rebate_earned'] ? this.significantNumber(this.fixedDecimalValue(content[i]['rebate_earned'])) : '$0.00'
      obj['program_id']=content && content[i]['program_id']==='0'?'OVERALL':content[i]['program_id']
      obj['rebate_type']=content && content[i]['rebate_type']?content[i]['rebate_type']:'NA',
      obj['last_invoice_date']=content && content[i]['last_invoice_date']?this.DateFormat(content[i]['last_invoice_date']):'NA'
      // obj['rebatable_purchase']=content && content[i]['rebatable_purchase']?content[i]['rebatable_purchase']:'NA'
      tableData.push(obj)
    }
    this.dataSource = new MatTableDataSource(tableData);
    // this.filterColumnwiseData(this.dataSource['filteredData']);
    // this.isSortApplied.next(tableData)
  }
  GroupTypeDetail = (content:any) =>{
    const tableData: any = [];
    for (let i = 0; i < content.length; i++) {
      let obj: any = {};
      obj['supplier_name'] = content && content[i]['supplier_name'] ? content[i]['supplier_name'] : 'NA'
      obj['programName'] = content && content[i]['program_name'] ? content[i]['program_name'] : 'NA'
      obj['total_purchase'] = content && content[i]['total_purchase'] ? this.significantNumber(this.fixedDecimalValue(content[i]['total_purchase'])) : '$0.00'
      obj['rebatable_purchase'] = content && content[i]['rebatable_purchase'] ? this.significantNumber(this.fixedDecimalValue(content[i]['rebatable_purchase'])): '$0.00'
      obj['rebate_earned'] = content && content[i]['rebate_earned'] ? this.significantNumber(this.fixedDecimalValue(content[i]['rebate_earned'])) : '$0.00'
      obj['rebate_percentage']=content && content[i]['rebate_percentage']?`${this.fixedDecimal(content[i]['rebate_percentage'])}%`:content && content[i]['rebate_percentage']=='0'?'0%':'NA'
      obj['last_invoice_date']=content && content[i]['last_invoice_date']?this.DateFormat(content[i]['last_invoice_date']):'NA'
      
      tableData.push(obj)
    }
    this.dataSource = new MatTableDataSource(tableData);
    
    // this.filterColumnwiseData(this.dataSource);
  }
  fixedDecimalValue = (data:any) =>{
    if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      }else{
        return data
      }
    }
  }
  fixedDecimal=(value:any) =>{
    return this.reusableService.roundOff(value);
  }
  significantNumber = (value: any) => {
    
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore
      // notation: "compact",
      // compactDisplay: "short",
      // minimumFractionDigits: 0,
      //maximumSignificantDigits: 2,
      style: "currency", currency: "USD",
    }).format(value);
  }
 
  zeroVendorChanges(event:any){
    this.isViewResetPagination=true
    this.pagination['pageNo']=1
    this.reqObject['pageNo']=this.pagination['pageNo']
    // alert(this.isZeropurchase);
    this.reqObject['non_zero']=this.isZeropurchase.toString();
    this.getFinancialHealthDistributorsGroupData();
  }

  sortByColumnName = (data:any) =>{
    if(!this.isToogledSupplier){
        if(data['direction']){
          this.reqObject['orderBy'] =data['active']
          this.reqObject['orderByType'] = data['direction']
        }else{
          if(this.reqObject.hasOwnProperty('orderBy')){
            delete this.reqObject['orderBy']
            delete this.reqObject['orderByType']
          }
        }
        // this.getAllRebateProgramDetails();
        this.getFinancialHealthDistributorsGroupData();
      }else{
        if(data['direction']){
        this.rebateProgramDetals['orderBy'] =data['active']
        this.rebateProgramDetals['orderByType'] = data['direction']
        }else{
        if(this.rebateProgramDetals.hasOwnProperty('orderBy')){
          delete this.rebateProgramDetals['orderBy']
          delete this.rebateProgramDetals['orderByType']
        }
        }
        this.getDetails();
    }
  }

  filterColumnwiseData = (obj: any) => {
    let isValueExists=0
    if(!this.isToogledSupplier){
      if(obj && obj['supplier_name']){
        this.reqObject['supplier_name']= obj['supplier_name']
        isValueExists=1
      } else if((obj['supplier_name']=='' || obj['supplier_name']=="" || obj['supplier_name']==null)  && this.reqObject.hasOwnProperty('supplier_name')){
        delete this.reqObject.supplier_name
        isValueExists=1
      }
      
    }else{
      if(obj && obj['supplier_name']){
        this.rebateProgramDetals['supplier_name']= obj['supplier_name']
        isValueExists=1
      } else if((obj['supplier_name']=='' || obj['supplier_name']=="" || obj['supplier_name']==null)  && this.rebateProgramDetals.hasOwnProperty('supplier_name')){
        delete this.rebateProgramDetals.supplier_name
        isValueExists=1
      }
      if(obj && obj['program_name']){
        this.rebateProgramDetals['program_name']= obj['program_name']
        isValueExists=1
      } else if((obj['program_name']=='' || obj['program_name']=="" || obj['program_name']==null)  && this.rebateProgramDetals.hasOwnProperty('program_name')){
        delete this.rebateProgramDetals.program_name
        isValueExists=1
      }
      // if(obj && obj['program_id']){
      //   this.rebateProgramDetals['program_id']= obj['program_id']
      //   isValueExists=1
      // } else if((obj['program_id']=='' || obj['program_id']=="" || obj['program_id']==null)  && this.rebateProgramDetals.hasOwnProperty('program_id')){
      //   delete this.rebateProgramDetals.program_id
      //   isValueExists=1
      // }
      if(obj&& obj['rebate_type']){
        this.rebateProgramDetals['rebate_type']= obj['rebate_type']
        isValueExists=1
      } else if((obj['rebate_type']=='' || obj['rebate_type']=="" || obj['rebate_type']==null)  && this.rebateProgramDetals.hasOwnProperty('rebate_type')){
        delete this.rebateProgramDetals.rebate_type
        isValueExists=1
      }
      if(obj&& obj['program_id']){
        this.rebateProgramDetals['program_id']= obj['program_id']
        isValueExists=1
      } else if((obj['program_id']=='' || obj['program_id']=="" || obj['program_id']==null)  && this.rebateProgramDetals.hasOwnProperty('program_id')){
        delete this.rebateProgramDetals.program_id
        isValueExists=1
      }
    }
    if(isValueExists==1){
      // this.getAllRebateProgramDetails(); 
    if(this.isToogledSupplier){
      this.getDetails();
    }else{
      this.getFinancialHealthDistributorsGroupData();
      }
    }
  }

  export(){
    // this.rebateProgramDetals['year'] = this.selctedGlobalYear;
    // this.rebateProgramDetals['limit'] = this.pagination.limit;
    // this.rebateProgramDetals['pageNo'] = this.pagination.pageNo;
    // this.rebateProgramDetals['distributorId'] = this.selectedDistributorId;
    // this.rebateProgramDetals['supplierId'] ="101301" ;
    this.Obj= {
      year:this.selctedGlobalYear,
      distributorId:this.selectedDistributorId,
      export:true,
      "orderBy":"total_purchase",
      "orderByType":"desc"
    }
    this.httpService.postMethod('/api/distributor/finance/supplier/details',this.Obj).subscribe((response: any) => {
  
    let allData=this.mapExportData(response['data']['data_response']);
    let headers:any = Object.keys(allData[0]);
    let csvData = this.resuableService.convertToCSV(allData, headers);
              let fileName =`Dealer_${this.rebateProgramDetals['distributorId']}`
              downloadFile(allData,headers,fileName,csvData);
              const dialogRef = this.dialog.open(SucessMessageModalComponent, {
                width: '416px',
                height: '185px',
                data: { "type": `${fileName} Exported successfully ${allData.length} records.`, actionStatus: 'success' },
                disableClose: true
              });
            })
  }

  mapExportData (content:any){
    return content.map((row:any)=>({
      "Vendor Name":row && row['supplier_name']?`${row['supplier_name'].replaceAll(',','')}`:'NA',
      "Total Purchase":row && row['total_purchase']?`${'$'+row['total_purchase'].toFixed(2)}`:'$0.00',
      "Covered Purchase":row && row['rebatable_purchase']?`${'$'+row['rebatable_purchase'].toFixed(2)}`:'-',
      "Rebate Earned":row && row['rebate_earned']?`${'$'+row['rebate_earned'].toFixed(2)}`:'$0.00',
      "Program Type" : row && row['rebate_type']?row['rebate_type']:'NA',
      "Program Name":row && row['program_name']?row['program_name']:'NA',
      "Program ID":row && row['program_id']==='0'?'OVERALL':row['program_id']
      // "ROI" :row && row['ROI']?row['ROI']:''
      
    }))
  }

  DateFormat(date:any){
    return  moment.utc(date).format('MM/DD/YYYY')

  }
}
