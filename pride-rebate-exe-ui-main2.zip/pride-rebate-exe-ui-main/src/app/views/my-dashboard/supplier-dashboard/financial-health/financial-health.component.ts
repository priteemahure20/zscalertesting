import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {HttpService} from '../../../../services/http.service';
import {YEAR} from '../../../../helpers/constants';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {TitleCasePipe} from '@angular/common';
import { DataService } from 'src/app/services/data.service';
import { BgDashboardService } from 'src/app/rbac/KPIs/bg-dashboard.service';

@Component({
  selector: 'app-financial-health',
  templateUrl: './financial-health.component.html',
  styleUrls: ['./financial-health.component.scss']
})
export class FinancialHealthComponent implements OnInit {
  tenantType:any;
  lastUpdateDate:any;
  globalYears:any=[]
  selctedGlobalYear:any;
  selectedVal:any="categories"
  totalSelectedValues:number =0;
  searchName:any="";
  filterClear:boolean = false;
  allDistributors:any=[];
  selectedDistributor:any="";
  autoCompleteDistributors:any=[];
  control = new FormControl('');
  filteredDistributors: Observable<any[]> | undefined;
  pagination = {
    limit: 5,
    pageNo: 1,
  }
  selectedPageLimit:number=5;
  isViewResetPagination:boolean = false
  reqObject:any={}
  financialGrpData:any=[]
  selectedSupplierId:any
  showViewAllRebateProgramDetail:boolean = true
  label:any='Total Sales';
  constructor(public router: Router,private httpService: HttpService,private titlecasePipe:TitleCasePipe,public activatedRoute: ActivatedRoute, private dataService: DataService,  private bgDashboardRbacService: BgDashboardService) { }

  ngOnInit(): void {
    this.subjectsUpdate();
    this.applyRBAC();
    this.globalYears = YEAR
    let date = new Date();
    let year = localStorage.getItem("year")
    if(year){
      this.selctedGlobalYear = parseInt(year)
    }else{
      this.selctedGlobalYear = date.getFullYear()
      localStorage.setItem("year",this.selctedGlobalYear.toString())
    }
    this.tenantType = localStorage.getItem('tenant');
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    this.filteredDistributors = this.control.valueChanges.pipe(
        startWith(''),
        map((value:any) => this._filter(value || '')),
    );
    this.activatedRoute.paramMap.subscribe((params:any) => {
      if (params && params['params'] && params['params']['supplierId']) {
        this.selectedSupplierId = params['params']['supplierId']
        this.reqObject = {
          year:this.selctedGlobalYear,
          group:this.selectedVal,
          supplierId:this.selectedSupplierId
        }
        this.pagination['limit'] = this.selectedPageLimit
        this.pagination['pageNo'] =1
        this.reqObject['limit']=this.pagination['limit']
        this.reqObject['pageNo']=this.pagination['pageNo']
        this.getFinancialHealthGroupData();
      }
    })
  }

  subjectsUpdate() {
    // console.log('subject update called');
    this.dataService.rbacConfigReceivedSubject.subscribe(
      data => {
        console.log('subject internal', this.dataService.roleBasedAccessConfig);
        this.applyRBAC();
      }
    );
  }

  applyRBAC() {
    // console.log('rbac called');
    this.showViewAllRebateProgramDetail = this.bgDashboardRbacService.canShowViewAllRebateProgramDetail();
    // console.log('financial health true or false', this.showViewAllRebateProgramDetail);
    // this.showRebateLibrary = this.bgDashboardRbacService.canShowRebateLibrary();
    // this.showRebateGovernance = this.bgDashboardRbacService.canShowRebateGovernance();
    // this.showFinancialHealth = this.bgDashboardRbacService.canShowFinancialHealth();
    // this.showRebateOptimization = this.bgDashboardRbacService.canShowRebateOptimization();
    // this.showWeeklyLoginReport = this.bgDashboardRbacService.canShowWeeklyLoginReport();

    // throw new Error('Method not implemented.');
  }

  navigateToHomeDashboard = () => {
    this.router.navigate([`/${this.tenantType}/home`])
  }

  navigateToMyDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])
  }
  selectYear = (year: any) => {
    this.selctedGlobalYear = year;
    localStorage.setItem("year",this.selctedGlobalYear.toString())
    this.reqObject = {
      year:this.selctedGlobalYear,
      group:this.selectedVal,
      supplierId:this.selectedSupplierId
    }
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.getFinancialHealthGroupData()
  }

  onTypeChange = (value:any) =>{
    this.selectedVal = value;
    this.reqObject['group'] = this.selectedVal
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    if(this.selectedVal == 'distributor_segment'){
      this.getAutoCompleteDistributors()

    }else{
      if(this.reqObject && this.reqObject.hasOwnProperty('segment_name')){
        delete this.reqObject['segment_name']
      }
      this.getFinancialHealthGroupData()

    }

  }
  searchByName = (value:any) =>{
    this.reqObject = {
      year:this.selctedGlobalYear,
      group:this.selectedVal,
      supplierId:this.selectedSupplierId
    }
    if(this.selectedVal=='categories'){
      this.reqObject['category_search'] =value
    }else{
      this.reqObject['program_search'] =value
    }
    if(!value){
      if(this.reqObject.hasOwnProperty('category_search')){
        delete this.reqObject['category_search']
      }
      if( this.reqObject.hasOwnProperty('category_search')){
        delete this.reqObject['category_search']
      }
    }
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.getFinancialHealthGroupData()

  }

  selectDistributor = (value:any) =>{
    this.reqObject = {
      year:this.selctedGlobalYear,
      group:this.selectedVal,
      supplierId:this.selectedSupplierId
    }
    this.reqObject['segment_name'] =value
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.getFinancialHealthGroupData()

  }

  getAutoCompleteDistributors=()=>{
    this.control.reset();
    this.autoCompleteDistributors = []
    this.httpService.getSupplierDistributors().subscribe((response:any)=>{
      if(response && response['data'] && response['data'].length>0){
        this.autoCompleteDistributors =response['data']
      }
    })
    this.selectedDistributor = ""
    // this.httpService.getCreateProgramSegments().subscribe((response: any) => {
    //   if(response && response['data'] && response['data']['segments'].length>0){
    //     this.allDistributors = response['data']['segments'].map((obj:any)=>obj['segment_name'])
    //     this.selectedDistributor = response['data']['segments'][0]['segment_name']
    //     this.reqObject['segment_name'] = this.selectedDistributor
    //     this.getFinancialHealthDistributorsGroupData()
    //   }
    // })
  }

  private _filter(value: string): string[] {
    const filterValue = this._normalizeValue(value);
    return this.autoCompleteDistributors.filter((street
    :any)=> this._normalizeValue(street['name']).includes(filterValue));
  }

  private _normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, '');
  }

  selectedValue = (value:any) =>{
    this.reqObject = {
      year:this.selctedGlobalYear,
      group:this.selectedVal,
      supplierId:this.selectedSupplierId
    }
    this.reqObject['segment_name'] =value
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.getFinancialHealthGroupData()
  }

  getFinancialHealthGroupData = () =>{
    this.totalSelectedValues = 0;
   this.httpService.getFinancialHealthGrpData(this.reqObject).subscribe((response:any)=>{
     if(response && response['data'] && response['data']['count']>0){
       this.totalSelectedValues = response['data']['count']
       this.populateData(response['data']['data_response'])
     }
     this.isViewResetPagination = this.totalSelectedValues == 0;
   })
  }
  getFinancialHealthDistributorsGroupData = () =>{
    this.totalSelectedValues = 0;
    this.httpService.getFinancialHealthGrpData(this.reqObject).subscribe((response:any)=>{
      if(response && response['data'] && response['data']['count']>0){
        this.totalSelectedValues = response['data']['count']
        this.populateData(response['data']['data_response'])
      }
      this.isViewResetPagination = this.totalSelectedValues == 0;
    })
  }
  getViewNextPage = (value:any) =>{
    this.pagination['pageNo']=parseInt(value['pageIndex'])+1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.getFinancialHealthGroupData()
  }

  selectedViewPageLimit = (value:any) =>{
    this.isViewResetPagination = true
    this.selectedPageLimit = parseInt(value)
    this.pagination['limit']=parseInt(value)
    this.pagination['pageNo']=1;
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo'];
    setTimeout(()=>{
      this.getFinancialHealthGroupData()
    })
    this.isViewResetPagination = false
  }

  goToPageViewNumber = (value:any) =>{
    if(value){
      this.pagination['pageNo']=parseInt(value);
      this.reqObject['limit']=this.pagination['limit']
      this.reqObject['pageNo']=this.pagination['pageNo']
      this.getFinancialHealthGroupData()
    }
  }

  populateData = (allData:any) =>{
    this.financialGrpData = []
    for(let i=0;i<allData.length;i++){
      let objectData:any={}
      if(this.selectedVal=='categories'){
        objectData['name'] = allData[i]['category']
        objectData['count'] = `${allData[i]['product_count']} Products`
        objectData['totalSales'] =  allData[i]['total_sales']
        objectData['rebateSales'] =  allData[i]['total_rebate']
        objectData['yoy'] = allData[i]['total_sales_yoy']
      }else if(this.selectedVal == 'distributor_segment'){
        objectData['name'] = allData[i]['segment_name']
        objectData['count'] = allData[i]['segment_value']?`${this.titlecasePipe.transform(allData[i]['segment_value'])}`:'NA'
        objectData['totalSales'] =  allData[i]['total_sales']
        objectData['rebateSales'] =  allData[i]['total_rebate']
        objectData['yoy'] = allData[i]['total_sales_yoy']
      }else if(this.selectedVal == 'programs'){
        objectData['name'] = allData[i]['program_name']
        objectData['count'] = `${allData[i]['distributor_count']} Distributors`
        objectData['totalSales'] =  allData[i]['total_sales']
        objectData['rebateSales'] =  allData[i]['total_rebate']
        objectData['maxTier'] = `Max Tiers: ${allData[i]['max_tier']}`
      }
      this.financialGrpData.push(objectData)
    }
  }

  navigateToRebateDetail =() =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/supplier/rebate-program-details`])
  }

  getLabel(label:any){
    this.label=label;
  }

}
