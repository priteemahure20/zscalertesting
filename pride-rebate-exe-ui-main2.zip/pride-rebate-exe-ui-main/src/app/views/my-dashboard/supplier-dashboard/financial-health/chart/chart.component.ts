import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { UserType } from 'src/app/helpers/constants';
import { AuthService } from 'src/app/services/auth.service';
import { DataService } from 'src/app/services/data.service';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss']
})
export class ChartComponent implements OnInit {
  @Input()
  supplierId:any
  @Output()
  selectedLabelEvent = new EventEmitter();
  DistributorId:any=''
  trendLabel: string = 'Total Purchase';
  trendSecondLabel: string = 'Rebate';
  financeSummary: any;
  selectedPeriod = "mom";
  periods = [
    { displayText: "Month over month", value: "mom" },
    { displayText: "Year over year", value: "yoy" }
  ];
  financeChartData: any;
  eventLineData: { data: any; label: string; }[] = [];
  selectedControl = 'total_sales';
  lineChartLabels: any;
  userType:any;
  lineChartType:any='month'

  constructor(private httpService: HttpService, private dataService: DataService, private authService:AuthService) { }

  ngOnInit(): void {
    const {userType} = this.authService.getUser() as any;
    this.userType = userType;
    this.fetchTrendData();
    this.subjectsUpdate();
  }

  subjectsUpdate() {
    this.dataService.yearSubject.subscribe(
      data => {
        console.log(data);
        this.fetchTrendData();
      }
    );
    this.dataService.supplierDropdown.subscribe(
      data => {
        console.log(data);
        this.DistributorId=data
        this.fetchTrendData();
      }
    )
  }

  fetchTrendData() {
    const year = localStorage.getItem('year');
    this.financeSummary = undefined;
    this.financeChartData = undefined;
    this.eventLineData = [];
    if(this.userType === 'DEALER'){
      // this.httpService.fetchSupplierFinanceTreddata(year, this.selectedPeriod,this.supplierId,'')
      // .subscribe((resp) => {
      //   this.financeSummary = resp.data?.financeSummary;
      //   this.financeChartData = resp.data?.trend;
      //   this.eventLineData = this.processChartData(this.selectedPeriod, this.financeChartData);
      //
      // }, (err) => {
      //   this.eventLineData = this.processChartData(this.selectedPeriod, this.financeChartData);
      // });
      this.httpService.fetchDistributorFinanceTrendData(year,this.selectedPeriod,this.supplierId,this.DistributorId).subscribe((response:any)=>{
        if(response && response['data'] &&  response['data']['trend']){
          this.selectedControl = 'total_purchase';
          this.financeChartData= response['data']['trend']
          this.eventLineData = this.processChartData(this.selectedPeriod, this.financeChartData);
        }
        this.httpService.getFinancialDistributorSummary(year,this.supplierId,this.DistributorId).subscribe((summaryResponse)=>{
          if(summaryResponse && summaryResponse['data'] && summaryResponse['data'].length>0){
            let distributorSummary = summaryResponse['data'][0]
            this.financeSummary={
              covered_purchase_yoy: distributorSummary['rebatable_purchase_yoy']?parseInt(distributorSummary['rebatable_purchase_yoy']):0,
              covered_purchase:distributorSummary['rebatable_purchase']?parseInt(distributorSummary['rebatable_purchase']):0,
              rebate_earned: distributorSummary['rebate_earned']?parseInt(distributorSummary['rebate_earned']):0,
              rebate_earned_yoy: distributorSummary['rebate_earned_yoy']?parseInt(distributorSummary['rebate_earned_yoy']):0,
              supplier_id: distributorSummary['user_group_id']?parseInt(distributorSummary['user_group_id']):0,
              tenant_id:distributorSummary['tenant_id'],
              total_purchase: distributorSummary['total_purchase']?parseInt(distributorSummary['total_purchase']):0,
              total_purchase_yoy:distributorSummary['total_purchase_yoy']?parseInt(distributorSummary['total_purchase_yoy']):0,
              year:distributorSummary['year']
            }
          }
        },error=>{
          this.financeSummary={
            covered_purchase_yoy: 0,
            covered_purchase:0,
            rebate_earned: 0,
            rebate_earned_yoy: 0,
            supplier_id: 0,
            tenant_id:0,
            total_purchase: 0,
            total_purchase_yoy:0,
            year:2023
          }
        })


      })

    }
  }

  processChartData(chartType: any, chartData: any) {
    const periodPropertyMap = {
      mom: 'month',
      yoy: 'year'
    }
    const monthMap = {
      1: 'Jan',
      2: 'Feb',
      3: 'Mar',
      4: 'Apr',
      5: 'May',
      6: 'Jun',
      7: 'Jul',
      8: 'Aug',
      9: 'Sep',
      10: 'Oct',
      11: 'Nov',
      12: 'Dec'
    };
    let firstLabel = 'Rebate', secondLabel = '';
    this.trendSecondLabel = secondLabel;
    let xaxis = periodPropertyMap[chartType as keyof typeof periodPropertyMap];
    this.lineChartType = xaxis
    console.log('xaxis is: ', xaxis);

    console.log('yaxis is: ', this.selectedControl);
    // first data
    let firstData = chartData.map((c: any) => {
      return {
        x: monthMap[c[xaxis] as keyof typeof monthMap] || c[xaxis],
        y:this.fixedDecimalValue(c[this.selectedControl=='covered_purchase'?'rebatable_purchase':this.selectedControl])
      }
    });
    console.log('data: ', firstData);
    this.lineChartLabels = prepareLineChartLabels(firstData);

    // second data
    let secondData: any = [];
    // let secondData = chartData.map((c: any) => {
    //   return {
    //     x: c.month,
    //     y: c.PREV_TOTAL_REBATE
    //   }
    // });

    let eventLineData = [{
        data: firstData,
        label: firstLabel,
      xAxisLabel: this.lineChartType
      },
      {
        data: secondData,
        label: secondLabel
      }
    ];
    if(this.userType === "DEALER"){
      eventLineData[0].label = '';
      if(this.selectedPeriod == "mom"){
        let modifyEventData = (data: any) => {
          for (let index = 0; index < data.length; index++) {
            if(data[index]['y'] == 0){
              data.splice(index, 1)
              modifyEventData(data);
            }
          }
        }
        modifyEventData(eventLineData[0].data);
      }
    }
    return eventLineData;
  }

  periodChange(event: any) {
    console.log(event.value);
    this.selectedPeriod = event.value;
    this.fetchTrendData();
  }

  controlTrendChart(data: any) {
    this.trendLabel = data.replace(/_/g,' ');
    this.selectedControl = data;
    this.selectedLabelEvent.emit(this.trendLabel);
    this.eventLineData = this.processChartData(this.selectedPeriod, this.financeChartData);

  }
  fixedDecimalValue = (data:any) =>{
    if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      }else{
        return data
      }

    } else{
      return 0
    }
  }


  abbreviateNumber = (value:any) => {
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore

      notation: "compact",
      compactDisplay: "short",
      style: "currency",currency: "USD",
      display:true,
      digitsInfo:'1.0-0'
    }).format(value);
  }
}
function prepareLineChartLabels(data: any): any {
  return data.map((d: any) => d.x);
}

