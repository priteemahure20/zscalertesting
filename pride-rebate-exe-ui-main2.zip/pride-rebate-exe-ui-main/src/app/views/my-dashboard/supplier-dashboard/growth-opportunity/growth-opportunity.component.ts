import { Component, OnInit } from '@angular/core';
import {YEAR} from '../../../../helpers/constants';
import {ActivatedRoute, Router} from '@angular/router';
import {HttpService} from '../../../../services/http.service';

@Component({
  selector: 'app-growth-opportunity',
  templateUrl: './growth-opportunity.component.html',
  styleUrls: ['./growth-opportunity.component.scss']
})
export class GrowthOpportunityComponent implements OnInit {
  tenantType:any;
  lastUpdateDate:any;
  globalYears:any=[]
  selectedGlobalYear:any;
  summaryData:any=[]
  allIndividualData:any=[]
  allGroupData:any=[];
  selectedSupplierId:any;
  constructor(public router: Router,private httpService: HttpService,public activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.globalYears = YEAR
    let date = new Date();
    let year = localStorage.getItem("year")
    if(year){
      this.selectedGlobalYear = parseInt(year)
    }else{
      this.selectedGlobalYear = date.getFullYear()
      localStorage.setItem("year",this.selectedGlobalYear.toString())
    }
    this.activatedRoute.paramMap.subscribe((params:any) => {
      if (params && params['params'] && params['params']['supplierId']) {
        this.selectedSupplierId = params['params']['supplierId']

      }
    })
    this.getAllGrowthOpportunityDetails()
    this.getGrowthOpportunityIndividualData()
    this.getGrowthOpportunityGrpData()
    this.tenantType = localStorage.getItem('tenant');
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
  }
  navigateToHomeDashboard = () => {
    this.router.navigate([`/${this.tenantType}/home`])
  }

  navigateToMyDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])

  }

  selectYear = (year: any) => {
    this.selectedGlobalYear = year;
    localStorage.setItem("year",this.selectedGlobalYear.toString())
    this.getAllGrowthOpportunityDetails();
    this.getGrowthOpportunityIndividualData();
    this.getGrowthOpportunityGrpData();
  }

  getAllGrowthOpportunityDetails = () =>{
    this.summaryData = []
    this.httpService.getSupplierGrowthOpportunitySummary(this.selectedGlobalYear,this.selectedSupplierId).subscribe((response:any)=>{
      if(response && response['data']){
        let allData = response['data'][0]
        let obj:any={}
        obj['header'] = 'Total Sales'
        obj['sales'] = allData && allData['total_sales']>0?allData['total_sales']:0
        obj['yoy'] = allData && allData['total_sales_yoy']>0?allData['total_sales_yoy']:0
        obj['avg'] = allData && allData['avg_total_sales']>0?allData['avg_total_sales']:0
        this.summaryData.push(obj)
        obj={}
        obj['header'] = 'Covered Sales'
        obj['sales'] = allData && allData['covered_sales']>0?allData['covered_sales']:0
        obj['yoy'] = allData && allData['covered_sales_yoy']>0?allData['covered_sales_yoy']:0
        obj['avg'] = allData && allData['avg_covered_sales']>0?allData['avg_covered_sales']:0
        this.summaryData.push(obj)
        obj={}
        obj['header'] = 'Total Rebates'
        obj['sales'] = allData && allData['rebate_owed']>0?allData['rebate_owed']:0
        obj['yoy'] = allData && allData['rebate_owed_yoy']>0?allData['rebate_owed_yoy']:0
        obj['avg'] = allData && allData['avg_rebate_owed']>0?allData['avg_rebate_owed']:0
        this.summaryData.push(obj)
        obj={}
        obj['header'] = 'Avg. Rebate Rate'
        obj['sales'] = allData && allData['rebate_settled']>0?allData['rebate_settled']:0
        obj['yoy'] = allData && allData['rebate_settled_yoy']>0?allData['rebate_settled_yoy']:0
        obj['avg'] = allData && allData['rebate_settled_average']>0?allData['rebate_settled_average']:0
        this.summaryData.push(obj)

      }
    })
  }

  getGrowthOpportunityIndividualData = () =>{
    let obj = {"year":this.selectedGlobalYear,type:"individual",supplierId:this.selectedSupplierId}
    this.allIndividualData = []
    this.httpService.getDataOfGrowthGrpDetails(obj).subscribe((reponse:any)=>{
      if(reponse && reponse['data'] && reponse['data']['dataResponse'] && reponse['data']['dataResponse'].length>0){
        let grpDetails = reponse['data']['dataResponse'];
        for(let i=0;i<grpDetails.length;i++){
          let eachgrpObj:any = {};
          eachgrpObj['supplierId'] = grpDetails[i]['supplier_id']
          eachgrpObj['growthType'] = 'individual'
          eachgrpObj['name'] = `Attainment Range`
          eachgrpObj['attainmentValue'] = grpDetails[i]['attainment_range']?grpDetails[i]['attainment_range']:`0`
          eachgrpObj['count'] = grpDetails[i]['distributor_count']?`${grpDetails[i]['distributor_count']} Distributors`:`0 Distributors`
          eachgrpObj['totalSales'] =  grpDetails[i]['gap']?grpDetails[i]['gap']:0
          eachgrpObj['rebateSales'] =  grpDetails[i]['roi']?grpDetails[i]['roi']:0
          eachgrpObj['totalCount'] =  grpDetails[i]['selected_program_count'] &&  !grpDetails[i]['total_program_cnt']?
                  `${grpDetails[i]['selected_program_count']} of 0 Programs`: !grpDetails[i]['selected_program_count'] && grpDetails[i]['total_program_cnt']?`0 of ${grpDetails[i]['total_program_cnt']} Programs`:
                  grpDetails[i]['selected_program_count'] &&  grpDetails[i]['total_program_cnt']?
                      `${grpDetails[i]['selected_program_count']} of ${grpDetails[i]['total_program_cnt']} Programs`: `0 of 0 Programs`
        this.allIndividualData.push(eachgrpObj)
        }
      }
    })
  }

  fixedDecimalValue = (data:any) =>{
    if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      }else{
        return data
      }

    } else{
      return 0
    }
  }

  abbreviateNumber = (value:any) => {
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore

      notation: "compact",
      compactDisplay: "short",
      style: "currency",currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  }

  getGrowthOpportunityGrpData = () =>{
    let obj = {"year":this.selectedGlobalYear,type:"group",supplierId:this.selectedSupplierId}
    this.allGroupData = []
    this.httpService.getDataOfGrowthGrpDetails(obj).subscribe((reponse:any)=>{
      if(reponse && reponse['data'] && reponse['data']['dataResponse'] && reponse['data']['dataResponse'].length>0){
        let grpDetails = reponse['data']['dataResponse'];
        for(let i=0;i<grpDetails.length;i++){
          let eachgrpObj:any = {};
          eachgrpObj['supplierId'] = grpDetails[i]['supplier_id']
          eachgrpObj['growthType'] = 'group'
          eachgrpObj['name'] = `Attainment Range`
          eachgrpObj['attainmentValue'] = grpDetails[i]['attainment_range']?grpDetails[i]['attainment_range']:`0`
          eachgrpObj['count'] = grpDetails[i]['distributor_count']?`${grpDetails[i]['distributor_count']} Distributors`:`0 Distributors`
          eachgrpObj['totalSales'] =  grpDetails[i]['gap']?grpDetails[i]['gap']:0
          eachgrpObj['rebateSales'] =  grpDetails[i]['roi']?grpDetails[i]['roi']:0
          eachgrpObj['totalCount'] =  grpDetails[i]['selected_program_count'] &&  !grpDetails[i]['total_program_cnt']?
              `${grpDetails[i]['selected_program_count']} of 0 Programs`: !grpDetails[i]['selected_program_count'] && grpDetails[i]['total_program_cnt']?`0 of ${grpDetails[i]['total_program_cnt']} Programs`:
                  grpDetails[i]['selected_program_count'] &&  grpDetails[i]['total_program_cnt']?
                      `${grpDetails[i]['selected_program_count']} of ${grpDetails[i]['total_program_cnt']} Programs`: `0 of 0 Programs`
          this.allGroupData.push(eachgrpObj)
        }
      }
    })
  }

  selectedValue = (value:any) => {
    this.router.navigate([`/${this.tenantType}/my-dashboard/supplier/growth-opportunity/${value['growthType']}`,{ id:value['supplierId']}])
  }

}
