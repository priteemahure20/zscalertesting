import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpService } from '../../../../../services/http.service';
import { getEffectiveDate } from '../../../../../helpers/commonUtils';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import { ReusableService } from '../../../../../services/reusable.service';
import { YEAR } from 'src/app/helpers/constants';

@Component({
  selector: 'app-opportunity-details',
  templateUrl: './opportunity-details.component.html',
  styleUrls: ['./opportunity-details.component.scss']
})
export class OpportunityDetailsComponent implements OnInit {
  years = YEAR;
  selectedProgramType: any = '';
  tenantType: any;
  lastUpdateDate: any;
  growthOptProgramType: any = '';
  programDetailOverview: any = '';
  selectedProgramDetailType: any = '';
  showExpandedView: boolean = false;
  selectedDetailType: any = '';
  programId: any;
  programDetails: any = [];
  requestPrgmPayload: any = {};
  pagination: any = {
    limit: 20,
    page: 1
  }
  supplierId: any = 0;
  selectedGlobalYear: any;
  distributorPerformanceData: any;
  rebateMasterID: any;
  rebateTypeData: any;
  rejectionComment: any;
  constructor(
    public router: Router,
    private route: ActivatedRoute,
    private httpService: HttpService,
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer,
    public dialog: MatDialog,
    private resuableService: ReusableService,
    //public dialogRef: MatDialogRef<OpportunityDetailsComponent>
  ) {
    this.matIconRegistry
      .addSvgIcon("email-view", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/email-icon.svg"))
  }

  ngOnInit(): void {
    this.tenantType = localStorage.getItem('tenant');
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    let year = localStorage.getItem('year');
    if (year) {
      this.selectedGlobalYear = parseInt(year)
    } else {
      this.selectedGlobalYear = new Date().getFullYear()
      localStorage.setItem("year", this.selectedGlobalYear.toString())
    }
    this.growthOptProgramType = this.route.snapshot.paramMap.get('programsType');
    this.supplierId = this.route.snapshot.paramMap.get('id');
    this.selectedProgramType = this.growthOptProgramType;
    this.requestPayload();
    this.getPrograms();
    this.rebateTypeDropDownData();
  }

  navigateToHomeDashboard = () => {
    this.router.navigate([`/${this.tenantType}/home`]);
  }

  navigateToMyDashboard = () => {
    this.router.navigate([`/${this.tenantType}/my-dashboard`]);
  }

  navigateToGrowth = () => {
    this.router.navigate([`/${this.tenantType}/my-dashboard/supplier/growth-opportunity`]);
  }

  selectYear = (year: any) => {
    this.requestPrgmPayload['year'] = year;
    this.selectedGlobalYear = year;
    localStorage.setItem("year", this.selectedGlobalYear.toString());
    this.getPrograms();
  }

  selectRebateType = (rebateType: any) => {
    this.requestPrgmPayload['rebate_type'] = rebateType;
    this.getPrograms();
  }

  requestPayload = () => {
    this.requestPrgmPayload['year'] = this.selectedGlobalYear;
    this.requestPrgmPayload['supplierId'] = parseInt(this.supplierId);
    this.requestPrgmPayload['rebate_applicable_to'] = this.growthOptProgramType;
    this.requestPrgmPayload['limit'] = this.pagination.limit;
    this.requestPrgmPayload['page'] = this.pagination.page;
  }

  getPrograms = () => {
    this.programDetails = []
    this.programDetailOverview = ""
    this.httpService.postMethod('/api/rebate/programs', this.requestPrgmPayload).subscribe((response: any) => {
      if (response?.data?.rebatePrograms?.length > 0) {
        this.populateRebateAgreements(response?.data?.rebatePrograms);
      }
    });
  }

  private populateRebateAgreements(data: any) {
    for (let i = 0; i < data.length; i++) {
      let obj: any = {};
      obj['programName'] = data[i]['programName'] ? data[i]['programName'] : 'NA'
      obj['programId'] = data[i]['programId'] ? data[i]['programId'] : "NA"
      obj['rebateType'] = data[i]['rebateType'] ? data[i]['rebateType'] : 'NA'
      obj['percentage'] = data[i]['rebateTier'] ? data[i]['rebateTier'].length : 'NA'
      obj['rebateApplicableTo'] = data[i]['rebateApplicableTo'] ? data[i]['rebateApplicableTo'] : 'NA'
      obj['effectiveDate'] = data[i]['effectiveStartDate'] && data[i]['effectiveEndDate'] ? getEffectiveDate(data[i]['effectiveStartDate'], data[i]['effectiveEndDate']) : 'NA'
      obj['status'] = data[i]['rebateStatus'] ? data[i]['rebateStatus'] : 'NA'
      obj['rebateMasterId'] = data[i]['rebateMasterId'] ? data[i]['rebateMasterId'] : 'NA'

      obj['isSelected'] = false
      this.programDetails.push(obj)
      let defaultProgramId = this.programDetails[0]['programId']
      if (defaultProgramId) {
        //this.selectProgram(defaultProgramId)
        this.programDetails[0]['isSelected'] = true
      }

    }
    this.selectProgram(this.programDetails[0]['programId'], this.programDetails[0]['rebateMasterId']);
  }

  private getTotalCount(datumElement: any) {
    if (datumElement && datumElement['data']) {
      return datumElement['data'].length
    } else {
      return 0
    }
  }

  sendMail = (info: any) => {

  }

  distributorPerformance = (rebateMasterId: any) => {
    let reqObj = {
      ...this.requestPrgmPayload,
      'rebate_master_id': rebateMasterId
    }
    reqObj['type'] = this.growthOptProgramType;
    delete reqObj['rebate_applicable_to'];
    
    console.log('reqobj',reqObj);
    this.distributorPerformanceData = [];
    this.httpService.postMethod('/api/supplier/growth/opportunity/performance', reqObj).subscribe((response: any) => {
      if (response?.data?.performanceData?.length > 0) {
        this.distributorPerformanceData = response?.data?.performanceData?.map((item: any) => {
          item['current_purchase_individual'] = item?.current_purchase_individual ? item?.current_purchase_individual?.toFixed(2) : '-';
          item['current_rebate_earned_payment'] = item?.current_rebate_earned_payment ? item?.current_rebate_earned_payment?.toFixed(2) : '-';
          item['target'] = item?.target ? item?.target?.toFixed(2) : '-';
          return item;
        });
      }
    });
  }
  downloadFile(data: any, header: any, filename = 'data') {
    let csvData = this.resuableService.convertToCSV(data, header);
    let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
    const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
      width: '450px',
      height: '194',
      data: { "type": "Successfully exported" },
      disableClose: true,
    });
  }


  exportData = () => {
    let reqObj = {
      "export_type": "growth_opportunity_performance",
      "rebate_master_id": this.rebateMasterID,
      ...this.requestPrgmPayload
    }
    this.httpService.postMethod('/api/export', reqObj).subscribe((response: any) => {
      this.downloadFile(
        response?.data?.performanceData,
        [
          'tenant_id', 'ra_supplier_id', 'distributor_name', 'ra_member_id',
          'rebate_master_id', 'program_name', 'year', 'current_rebate_earned_payment', 'current_purchase_individual'
        ],
        'PerformanceData'
      );
    });
  }


  selectProgram = (program: any, rebateMasterId: any) => {
    this.programId = program;
    let reqObj = { 'programId': program }
    let selectedValue = this.programDetails.map((each: any) => {
      if (each['programId'] == program) {
        each['isSelected'] = true
      } else {
        each['isSelected'] = false
      }
    })
    this.httpService.postMethod('/api/rebate_library/program/details', reqObj).subscribe((response: any) => {
      this.programDetailOverview = response?.data;
      if (response?.data?.hasOwnProperty('rebate_master_detail')) {
        this.rejectionComment =  response?.data?.rebate_master_detail?.rejection_comments;
      }
    });
    this.rebateMasterID = rebateMasterId;
    this.distributorPerformance(rebateMasterId);
  }
  expand = ($event: any) => {
    this.showExpandedView = $event.showExpandedView;
    this.selectedDetailType = $event.selectedType;
  }
  closePDPDetails = () => {
    this.selectedDetailType = '';
  }

  rebateTypeDropDownData = () => {
    this.httpService.postMethod('/api/program/creation/form/dds', { "userGroupType": "distributor" }).subscribe((response: any) => {
      this.rebateTypeData = response && response.data && response.data[0] && response.data[0].dropdown_options;
    });
  }

  onScroll = () => {

  }
}
