import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { DataService } from 'src/app/services/data.service';
import {Role, UserType, YEAR} from '../../../helpers/constants';
import {HttpService} from '../../../services/http.service';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-supplier-dashboard',
  templateUrl: './supplier-dashboard.component.html',
  styleUrls: ['./supplier-dashboard.component.scss']
})
export class SupplierDashboardComponent implements OnInit {
  userType:any;
  tenantType:any="";
  lastUpdateDate:any
  isListView:boolean = true;
  isToogledSupplier:boolean= true;
  totalSales:any=0;
  avgRatePercent:any=0;
  rebatableSales:any=0;
  growthOppurtunityValue:any;
  growthContentValue:number = 0
  growthDistributorCnt:number=0;
  growthProgramCnt:number=0
  settledPayment:number=100000
  outStandingBalance:number = 750000
  totalDisputes:number=22;
  rebateOwed:any=0;
  pieChartData:any=[];
  reviewObj:any={}
  pendingObj:any={}
  resolvedObj:any={}
  globalYears:any=[]
  selctedGlobalYear:any;
  control = new FormControl('');
  filteredSuppliers: Observable<any[]> | undefined;
  autoCompleteSuppliers:any=[];
  loggedInSupplierId:any;
  hierarcialData:any=[]
  growthOpportunityAttainmentValue:number=0;
  selectedSupplierId:any;
  loggedUserRole:any=""
  constructor(public router: Router, private httpService: HttpService,
    private dataService: DataService, private authService:AuthService) { }

  ngOnInit(): void {
    this.globalYears = YEAR
    let date = new Date();
    let year = localStorage.getItem("year")
    if(year){
      this.selctedGlobalYear = parseInt(year)
    }else{
      this.selctedGlobalYear = date.getFullYear()
      localStorage.setItem("year",this.selctedGlobalYear.toString())
    }
    this.loggedInSupplierId = localStorage.getItem('userGroupId');
    this.selectedSupplierId = parseInt(this.loggedInSupplierId)
    this.getSupplierDashboardData(this.selctedGlobalYear,this.selectedSupplierId)
    // this.userType = localStorage.getItem('userType') as UserType;
    this.userType = this.authService.getUser()?.userType as UserType;
    this.tenantType = localStorage.getItem('tenant');
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    // this.loggedUserRole = localStorage.getItem('role') as Role;
    this.loggedUserRole = this.authService.getUser()?.role as Role;
    if(this.loggedUserRole == 'REPORTING_LAYER_NONREBATE'){
      this.isToogledSupplier = false;
      this.isListView = false;
      this.getSupplierHierarchyData()
    }
    this.reviewObj ={ name: 'In Review', value: 30 ? 30 :0, color: '#F69C50'  }
    this.pendingObj ={ name: 'Pending', value: 30 ? 30 :0, color: '#59595A' }
    this.resolvedObj ={ name: 'Resolved', value: 40 ? 40 :0, color: '#24A148' }
    this.pieChartData.push(this.reviewObj)
    this.pieChartData.push(this.pendingObj)
    this.pieChartData.push(this.resolvedObj)
    this.filteredSuppliers = this.control.valueChanges.pipe(
        startWith(''),
        map((value:any) => this._filter(value || '')),
    );
    this.httpService.getSupplierDistributors().subscribe((response:any)=>{
      if(response && response['data'] && response['data'].length>0){
        this.autoCompleteSuppliers =response['data']
      }
    })
  }
  navigateToHomeDashboard = () => {
    this.router.navigate([`/${this.tenantType}/home`])
  }
  selectYear = (year: any) => {
    this.selctedGlobalYear = year;
    localStorage.setItem("year",this.selctedGlobalYear.toString())
    if(!this.isListView){
      this.getSupplierHierarchyData()
    }else{
      this.getSupplierDashboardData(this.selctedGlobalYear,this.selectedSupplierId)
    }
  }

  changeView = (event:any) =>{
    this.isListView = event.checked
    if(!this.isListView){
      this.isToogledSupplier = false
      this.getSupplierHierarchyData()
    }else{
      this.isToogledSupplier = true
      this.getSupplierDashboardData(this.selctedGlobalYear,this.selectedSupplierId)
    }

  }

  getSupplierDashboardData = (year:any,supplierId:any) =>{
    this.httpService.getSupplierDashboardData(year,supplierId).subscribe((response:any)=>{
      if(response && response['data'] && response['data']['financialHealth']){
        let financialHealth = response['data']['financialHealth']
        this.totalSales =  financialHealth['total_sales']>0?financialHealth['total_sales']:0
        this.rebatableSales = financialHealth['covered_sales']?this.abbreviateNumber(financialHealth['covered_sales']):0
        this.rebateOwed = financialHealth['rebate_owed']?this.abbreviateNumber(financialHealth['rebate_owed']):0
        this.avgRatePercent = financialHealth['rebate_paid']>0?`${this.fixedDecimalValue(financialHealth['rebate_paid'])}%`:`0%`
      }
      if(response && response['data'] && response['data']['growthOpportunity']){
        let growthOpportunity = response['data']['growthOpportunity']
        this.growthOppurtunityValue = growthOpportunity['attainment_range']
        this.growthOpportunityAttainmentValue = growthOpportunity['attainment_percentage']?parseInt(growthOpportunity['attainment_percentage']):0
        this.growthDistributorCnt = growthOpportunity['distributor_count']?growthOpportunity['distributor_count']:0
        this.growthProgramCnt = growthOpportunity['selected_program_count']?growthOpportunity['selected_program_count']:0
        this.growthContentValue = growthOpportunity['gap']?growthOpportunity['gap']:0
      }
    })
  }

  fixedDecimalValue = (data:any) =>{
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(data);
  }

  abbreviateNumber = (value:any) => {
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore

      notation: "compact",
      compactDisplay: "short",
      style: "currency",currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  }


  navigateToFinancialHealth = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/supplier/financial-health`,{supplierId:this.selectedSupplierId}])

  }

  navigateToGrowthOpportunity = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/supplier/growth-opportunity`,{supplierId:this.selectedSupplierId}])
  }
  private _filter(value: string): string[] {
    const filterValue = this._normalizeValue(value);
    return this.autoCompleteSuppliers.filter((street:any)=>
        this._normalizeValue(street['name']).includes(filterValue));
  }

  private _normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, '');
  }


  selectedValue = (searchedValue:any) =>{

  }


  getSupplierHierarchyData = () =>{
    this.hierarcialData =[]
    let allContent:any=[]
    this.httpService.getSupplierHierarchy(this.loggedInSupplierId,this.selctedGlobalYear).subscribe((response:any)=>{
      if(response && response['data']){
         allContent = response['data']
        for(let obj in allContent){
          let eachObj:any={}
          if(obj == 'organization'){
            eachObj['title'] = 'Organization Level'
            eachObj['data']=this.populateEachLevelData(allContent[obj])
            eachObj['totalSales'] = 0
            eachObj['totalRebate'] = 0
          }else if(obj == 'company'){
            eachObj['title'] = 'Company Level'
            eachObj['data']=this.populateEachLevelData(allContent[obj])
            eachObj['totalSales'] = 0
            eachObj['totalRebate'] = 0
          }else if(obj=='branch'){
            eachObj['title'] = 'Branch Level'
            eachObj['data']=this.populateEachLevelData(allContent[obj])
            eachObj['totalSales'] = 0
            eachObj['totalRebate'] = 0
          }
          this.hierarcialData.push(eachObj)
        }
      }
    })
  }

  populateEachLevelData = (data:any) =>{
    let allInfo:any=[]
    for(let i=0;i<data.length;i++) {
      let objectData: any = {}
      objectData['name'] = data[i]['group_name']?data[i]['group_name']:'NA'
      objectData['parentName'] = data[i]['group_parent_name']?data[i]['group_parent_name']:'NA'
      objectData['selected'] = data[i]['selected']
      objectData['totalSales'] =  data[i]['total_sales']?data[i]['total_sales']:0
      objectData['rebateSales'] =  data[i]['total_rebate']? data[i]['total_rebate']:0
      objectData['associateLevel'] = data[i]['associate_level']
      objectData['userGrpId'] = data[i]['user_group_id']
      objectData['userGrpParentId'] = data[i]['user_group_parent_id']?data[i]['user_group_parent_id']:'NA'
      objectData['enabled'] = data[i]['enabled']
      allInfo.push(objectData)
    }
    return allInfo
  }

  navigateToPayments = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/supplier/payments`])

  }

  openDataBySupplier = (userGrpId:any) =>{
    if(userGrpId){
      this.selectedSupplierId = parseInt(userGrpId)
    }else{
      this.selectedSupplierId = parseInt(this.loggedInSupplierId)
    }
   // this.changeView({checked:true})
  }

}
