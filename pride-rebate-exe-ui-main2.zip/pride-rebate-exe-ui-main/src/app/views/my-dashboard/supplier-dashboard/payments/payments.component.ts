import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {HttpService} from '../../../../services/http.service';
import {YEAR} from '../../../../helpers/constants';

@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.scss']
})
export class PaymentsComponent implements OnInit {
  tenantType:any;
  lastUpdateDate:any;
  globalYears:any=[]
  selectedGlobalYear:any;
  reqObject:any={}
  pagination = {
    limit: 5,
    pageNo: 1,
  }
  selectedPageLimit:number=5;
  totalSales:any=70;
  rebateOwed:any=750;
  paymentSettled:number=100000
  outstandingBalance:number=750000
  lastTransactionDate:any=new Date();
  paymentId:any=2061
  paymentStatus:any="active"
  outStandingAmount:number=2060000
  totalPrograms:number =40
  paymentsEvents:any=[]
  constructor(public router: Router,private httpService: HttpService) { }

  ngOnInit(): void {
    this.globalYears = YEAR
    let date = new Date();
    let year = localStorage.getItem("year")
    if(year){
      this.selectedGlobalYear = parseInt(year)
    }else{
      this.selectedGlobalYear = date.getFullYear()
      localStorage.setItem("year",this.selectedGlobalYear.toString())
    }
    this.tenantType = localStorage.getItem('tenant');
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    this.getPaymentEvents(this.selectedGlobalYear)
  }
  navigateToHomeDashboard = () => {
    this.router.navigate([`/${this.tenantType}/home`])
  }

  navigateToMyDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])
  }
  selectYear = (year: any) => {
    this.selectedGlobalYear = year;
    localStorage.setItem("year",this.selectedGlobalYear.toString())
    this.reqObject = {
      year:this.selectedGlobalYear,
    }
    this.pagination['limit'] = this.selectedPageLimit
    this.pagination['pageNo'] =1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
  }

  abbreviateNumber = (value:any) => {
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore

      notation: "compact",
      compactDisplay: "short",
      style: "currency",currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  }

   getPaymentEvents(selectedGlobalYear: any) {
    let allData:any=[
        {
          id:20631,
          programType:2,
          transactionData:"08/25/2022",
          outstanding:250000,
          status:"active"
        },
      {
        id:20632,
        programType:3,
        transactionData:"08/25/2022",
        outstanding:250000,
        status:"active"
      },{
        id:20633,
        programType:4,
        transactionData:"08/25/2022",
        outstanding:250000,
        status:"closed"
      },{
        id:20634,
        programType:5,
        transactionData:"08/25/2022",
        outstanding:250000,
        status:"closed"
      },{
        id:20635,
        programType:6,
        transactionData:"08/25/2022",
        outstanding:250000,
        status:"pending"
      },{
        id:20636,
        programType:7,
        transactionData:"08/25/2022",
        outstanding:250000,
        status:"active"
      }
    ]
     this.populatePaymentEvents(allData)
  }

   populatePaymentEvents(allData: any) {
    for(let i=0;i<allData.length;i++) {
      let eachgrpObj: any = {};
      eachgrpObj['name'] = allData[i]['id']?`ID - ${allData[i]['id']}`:'ID - NA'
      eachgrpObj['attainmentValue'] = allData[i]['programType']? `${allData[i]['programType']} Program Type`:'0 Program Type'
      eachgrpObj['lastTransactionDate'] = allData[i]['transactionData']? allData[i]['transactionData']:'NA'
      eachgrpObj['outStanding'] = allData[i]['outstanding']? allData[i]['outstanding']:0
      eachgrpObj['status'] = allData[i]['status']? allData[i]['status']:0
      this.paymentsEvents.push(eachgrpObj)
    }
  }

  selectedValue = (value:any) =>{

  }
}
