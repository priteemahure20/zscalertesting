import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {HttpService} from '../../../services/http.service';
import {DataService} from '../../../services/data.service';
import {YEAR} from '../../../helpers/constants';
import { canShowFinancialHealthService, canShowRebateOptimizationService, canShowWeeklyLoginReportService } from 'src/app/rbac/components/my-dashboard';
import { AuthService } from 'src/app/services/auth.service';
import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-bg-dashboard',
  templateUrl: './bg-dashboard.component.html',
  styleUrls: ['./bg-dashboard.component.scss']
})
export class BgDashboardComponent implements OnInit {
  financialImg = '../../../../assets/pngs/financial.PNG';
  rebateOpt = '../../../../assets/pngs/rebate-opt.JPG';
  unlockIcon = '../../../../assets/img/icons/rebate-unlock.svg';
  tenantType:any="";
  globalYears:any=[]
  selctedGlobalYear:any;
  lastUpdateDate:any;
  showFinancialHealth: boolean = true;
  showRebateOptimization: boolean = true;
  showWeeklyLoginReport: boolean = true
  totalPurchase: any = 0
  totalRebate: any = 0
  missedOppurtunity: any = 0
  optimizationValue = 0;
  supplierLoginPercent:any=0;
  supplierLoginCount:any=0;
  distributorLoginPercent:any=0;
  distributorLoginCount:any=0;
  distributorCount:any=0

  constructor(public router: Router, private httpService: HttpService, private dataService: DataService, private authService:AuthService) {
    this.dataService.wndowSrollYEmitter.emit(100)
   }

  ngOnInit(): void {
    this.globalYears = YEAR
    let date = new Date();
    let year = localStorage.getItem("year")
    if(year){
      this.selctedGlobalYear = parseInt(year)
    }else{
      this.selctedGlobalYear = date.getFullYear()
      localStorage.setItem("year",this.selctedGlobalYear.toString())
    }
    this.selectYear(this.selctedGlobalYear)
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    this.tenantType = localStorage.getItem('tenant');

    this.applyAccessRestriction();


  }

  applyAccessRestriction = () => {
    // const userType: any = localStorage.getItem('userType');
    // const userType: any = this.authService.getUser()?.userType;
    // // const role: any = localStorage.getItem('role');
    // const role = this.authService.getUser()?.role;
    const {userType,role} = this.authService.getUser() as User;
    this.showFinancialHealth = canShowFinancialHealthService(userType, role);
    this.showRebateOptimization = canShowRebateOptimizationService(userType, role);
    this.showWeeklyLoginReport = canShowWeeklyLoginReportService(userType, role);
    // console.log(this.showFinancialHealth, this.showRebateOptimization, this.showWeeklyLoginReport, '======================access control====================');
  }

  selectYear = (year: any) => {
    this.selctedGlobalYear = year;
    localStorage.setItem("year",this.selctedGlobalYear.toString())
    this.getBgDashboardDetails(year)

  }
  navigateToHomeDashboard = () => {
    this.router.navigate([`/${this.tenantType}/home`])
  }

  navigateToFinancialHealth = () => {
    this.router.navigate([`/${this.tenantType}/my-dashboard/corporate/financial-health`]);
  }
  navigateToRebateOptimization = () => {
    this.router.navigate([`/${this.tenantType}/my-dashboard/corporate/rebate-optimization`]);
  }

  navigateToWeeklyReport = (type:any)=>{
    this.router.navigate([`/${this.tenantType}/my-dashboard/corporate/weekly-login-report`], { queryParams: { type: type}});
  }

  abbreviateNumber = (value: any) => {
    return new Intl.NumberFormat('en-US', {
      //@ts-ignore
      notation: "compact",
      compactDisplay: "short",
      style: "currency",
      currency: "USD",
    }).format(value);
  }


   getBgDashboardDetails(year: any) {
    let yearObj ={year:year}
    this.supplierLoginPercent =0
     this.distributorLoginCount =0
     this.distributorCount =0
     this.httpService.getBgDashboardDetails(yearObj).subscribe((response:any)=>{
      if(response && response['data']){
        let allData = response['data']
        this.totalPurchase = allData['financialHealth']['totalPurchase']?allData['financialHealth']['totalPurchase']:0
        this.totalRebate = allData['financialHealth']['totalRebate']?allData['financialHealth']['totalRebate']:0
        this.optimizationValue =allData['rebateOptimization']['memberAssistance']?parseInt(allData['rebateOptimization']['memberAssistance']):0
         this.supplierLoginPercent =allData['weeklyLogin']['suppliers'] && allData['weeklyLogin']['totalSuppliers']?this.calculatePercent( allData['weeklyLogin']['totalSuppliers'],allData['weeklyLogin']['suppliers']):0
        this.distributorLoginPercent = allData['weeklyLogin']['distributors'] && allData['weeklyLogin']['totalDistributors']?this.calculatePercent(allData['weeklyLogin']['distributors'], allData['weeklyLogin']['totalDistributors']):0
        this.distributorLoginCount = allData['weeklyLogin']['totalDistributors']?allData['weeklyLogin']['totalDistributors']:0
        this.supplierLoginCount = allData['weeklyLogin']['totalSuppliers']?allData['weeklyLogin']['totalSuppliers']:0
        this.distributorCount=allData['weeklyLogin']['distributors']?allData['weeklyLogin']['distributors']:0
      }
     })

  }
  fixedDecimalValue (data:any) {
    if (parseInt(data) !=0) {
      if (!Number.isInteger(parseInt(data))) {
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
      } else {
        return data
      }

    }else{
     return  0
    }
  }
  calculatePercent = (summaryObjElement1:any,summaryObjElement2:any) =>{
    return ((summaryObjElement2/(summaryObjElement1))*100).toFixed();
  }
}
