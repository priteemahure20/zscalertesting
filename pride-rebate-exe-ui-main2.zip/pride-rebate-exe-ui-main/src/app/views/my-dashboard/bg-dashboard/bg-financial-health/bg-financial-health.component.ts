import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {MatIconRegistry} from '@angular/material/icon';
import {DomSanitizer} from '@angular/platform-browser';
import {HttpService} from '../../../../services/http.service';
import { canShowKPI, regionWiseTransaction } from 'src/app/rbac/components/financial-health';
import { AuthService } from 'src/app/services/auth.service';
import { User } from 'src/app/models/user.model';
import { YEAR } from 'src/app/helpers/constants';
import { ReusableService } from 'src/app/services/reusable.service';
import * as moment from 'moment';
import { SucessMessageModalComponent } from 'src/app/common/sucess-message-modal/sucess-message-modal.component';
import {MatDialog} from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ExportModalComponent } from 'src/app/views/report-generator/export-modal/export-modal.component';
import { ViewMoreDataModalComponent } from 'src/app/views/rebate-management/financial-health/rebate-details-program/view-more-data-modal/view-more-data-modal.component';
@Component({
  selector: 'app-bg-financial-health',
  templateUrl: './bg-financial-health.component.html',
  styleUrls: ['./bg-financial-health.component.scss']
})

export class BgFinancialHealthComponent implements OnInit {

  isDisplayMap:boolean = false
  public selectedVal: string = 'dealer';
  public valueSelectedType:any='dealer';
  constructor(public router: Router, private reusableService: ReusableService,public dialog: MatDialog, private fb: FormBuilder, private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer,private httpService: HttpService,private authService:AuthService,private resuableService:ReusableService) {
    this.matIconRegistry.addSvgIcon("up-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/up_arrow_icon.svg"))
    this.matIconRegistry.addSvgIcon("down-arrow",this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../assets/img/icons/down_icon.svg"))
  }
  tenantType:any;
  mode='determinate'
  value = 50;
  selectedYear:any;
  years = YEAR;
  overalType:any = 'OVERALL'
  mapRegions=[
    {name:"Region 1",transactionValue:2000,rebateValue:30000,"contains":[ "CA","CO","CT","DE","AK","AS","AL","AZ","AR","DC","FL","FM","GA","GU" ],"color":"#064F60"},
    {name:"Region 2",transactionValue:2000,rebateValue:30000,"contains":[ "IN","IA","JI","JA","KS","KY","KR","LA","ME","MH","HI","ID","HI","IL","MD","UT" ], "color":"#087891"},
    {name:"Region 3",transactionValue:2000,rebateValue:30000,"contains":[ "MI","MI","MN","MA","MS","MO","MT","NI","NE","NV","NH","NJ","NM","NY","NC" ], "color":"#3ED3F4"},
    {name:"Region 4",transactionValue:2000,rebateValue:30000, "contains":[ "ND","OR","PW","PA","PA","PR","RI","SC","SD","MP","OH","OK","TN","TX","UM" ], "color":"#0BA0C1"},
    {name:"Region 5",transactionValue:2000,rebateValue:30000,"contains":[ "VA","VI","WI","VT","WA","WV","WI","WY","AZ" ], "color":"#9FE8F9"},
  ]
  regions:any=[]
  amount:any = {}
  topSpenders:any = [];
  topReducers:any = [];
  topSelling:any=[];
  topRebatePaid:any=[];
  paymentTypeData:any=[];
  patchPaymentTypeData:any=[];
  showRegionWiseTransaction: boolean = true;
  lastUpdateDate:any;
  basicInfoForm!: FormGroup;
  startDate:any='';
  endDate:any='';
  supplierDropdownData:any=["aaa","bbb","ccc"];
  DealerDropdownData:any=["aaa","bbb","ccc"];
  selectSupplier:any='';
  selectDistributor:any;
  userType:any='Dealer'

  resusableservice = this.reusableService;
  ngOnInit(): void {
    setTimeout(()=>{
      this.isDisplayMap = true
    },2000)
    this.tenantType = localStorage.getItem('tenant')
    let year = localStorage.getItem("year");
    if(!year){
      this.selectedYear =new Date().getFullYear()
      localStorage.setItem("year",this.selectedYear)
    }else {
      this.selectedYear = parseInt(year)
    }
    this.getTotalTransaction(this.selectedYear);
    this.populateRegionWiseTopTranactions(this.selectedYear,this.valueSelectedType, true);
    this.applyAccessRestriction();
    this.buildCreateForm();
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    this.getAllSupplier();
    this.getAssociates(this.userType);
  }


  buildCreateForm() {
    this.basicInfoForm = this.fb.group({
      startDate: new FormControl(''),
      endDate: new FormControl(''),
      // selectSupplier:new FormControl(''),
      // selectDistributor:new FormControl('')
    },);
  
      this.basicInfoForm.addControl('selectSupplier',new FormControl('All'))
    
      this.basicInfoForm.addControl('selectDistributor',new FormControl('All'))
  
  }

  applyAccessRestriction = () => {
    // const userType: any = localStorage.getItem('userType');
    // const userType: any = this.authService.getUser()?.userType;
    // // const role: any = localStorage.getItem('role');
    // const role = this.authService.getUser()?.role;
    const {userType,role} = this.authService.getUser() as User;
    this.showRegionWiseTransaction = canShowKPI(regionWiseTransaction, userType, role);
    // this.showRebateOptimization = canShowRebateOptimizationService(userType, role);
    // this.showWeeklyLoginReport = canShowWeeklyLoginReportService(userType, role);
    // console.log(this.showFinancialHealth, this.showRebateOptimization, this.showWeeklyLoginReport, '======================access control====================');
  }

  navigateToBGDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/rebateManagement/bg-dashboard`]);
  }

  navigateToHomeDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/home`])
  }

  abbreviateNumber = (value:any) => {
    return new Intl.NumberFormat(undefined, {
      //@ts-ignore
      notation: "compact",
      compactDisplay: "short",
      style: "currency",currency: "USD",
    }).format(value);
  }
   fixedDecimalValue (data:any) {
    if(parseInt(data)){
      if(!Number.isInteger(parseInt(data))){
        return parseInt(data).toFixed(2)
      }else{
        return data
      }

    }
  }
  significantNumber = (value:any) => {
    if(value){
      return new Intl.NumberFormat(undefined, {
        //@ts-ignore
        // notation: "compact",
        // compactDisplay: "short",
        minimumFractionDigits: 0,
        style: "currency",currency: "USD",
      }).format(parseInt(value));
    }else{
      return `$0`
    }

  }

  onTypeChange = (type:any) =>{
    this.valueSelectedType = type
    this.populateRegionWiseTopTranactions(this.selectedYear,this.valueSelectedType,true)
  }

  getAllSupplier = () => {
    this.httpService.postMethod('/api/associate/dropdown?type=distributor',{}).subscribe((response: any) => {
      this.supplierDropdownData = response?.data.filter((fil:any)=> fil['name']!='PRIDE');
      console.log("Dealers")
    });
  }
  getAssociates = (userType: any) => {
    this.httpService.postMethod('/api/switch/user/associates',{ associate_type: userType.toLowerCase()}).subscribe((response: any) => {
      this.DealerDropdownData = response?.data;
    });
  }
  
  navigateToSummaryPages = () =>{
    if(this.valueSelectedType == 'dealer') {
      this.router.navigate([`/${this.tenantType}/rebateManagement/distributor-purchase`]);
    }else{
      this.router.navigate([`/${this.tenantType}/rebateManagement/supplier-sales`]);
    }
  }

  selectedYearOption = (value:any) => {
    if(value){
      this.selectedYear = value
      localStorage.setItem("year",this.selectedYear)
      this.getTotalTransaction(value);
      this.populateRegionWiseTopTranactions(value,this.valueSelectedType,true)

    }
  }

  getTotalTransaction = (value:any) =>{
    if(value) {
      let body = {year:value}
      this.regions =[]
      this.httpService.getBgDashboardTransactions(body).subscribe((response:any)=>{
        if(response && response['data']){
          let transactionData = response['data']
          for(let i=0;i<transactionData.length;i++){
            let regionObject = {
              name:transactionData[i].hasOwnProperty('region')?transactionData[i]['region']:transactionData[i]['regionId'],
              transactionValue:parseInt(transactionData[i]['transactions']),
              rebateValue:parseInt(transactionData[i]['rebate']),
              color:this.getRandomColor()
            }
            this.regions.push(regionObject)
          }

        }
      })
    }
  }

  getRandomColor = () => {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }

  getAbsValue = (value:number) =>{
    return Math.abs(value)
  }
  populateRegionWiseTopTranactions(selectedYear: number, valueSelectedType: any, initial:any = false) {
    let body = {year:selectedYear,userType:valueSelectedType}
    this.amount = {}
    this.paymentTypeData = [];
    this.httpService.getTopTransactions(body).subscribe((response:any)=>{
      if(response && response['data'] && response['data']['programTypeTransactionCards']){
        this.paymentTypeData = response['data']['programTypeTransactionCards'];
        let amountTransactions = response['data']['totalAmount'];
        this.amount = {
          totalAmountSpent :  amountTransactions['totalAmountSpent']?amountTransactions['totalAmountSpent']:0,
          totalAmountEarned :  amountTransactions['totalRebate']?amountTransactions['totalRebate']:0,
          variancePurchase:amountTransactions['variancePurchase']?parseInt(amountTransactions['variancePurchase']):0,
          varianceRebate:amountTransactions['varianceRebate']?parseInt(amountTransactions['varianceRebate']):0
        }
        if(this.paymentTypeData.length>0){
          for(let i=0;i<this.paymentTypeData.length;i++){
            this.paymentTypeData[i]['isSelected'] = false
          }
        }
        this.populateTopRebateSpendingReduced(initial?'OVERALL':this.paymentTypeData[0]['rebateType'])
      }
    })
  }

  getProgressedAmount(arg0: any, arg1: any) {
    return (arg1/arg0)*100;
  }

  navigateToMyDashboard = () =>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])
  }

  selectedPaymentType = (type:any)=>{
    this.overalType=type;
    type = ['OVERALL','OVERALL1'].includes(type)?'OVERALL':type
    this.populateTopRebateSpendingReduced(type)
    for(let i=0;i<this.paymentTypeData.length;i++){
      if(this.paymentTypeData[i]['rebateType'] ==type){
        this.paymentTypeData[i]['isSelected'] = true
      }else{
        this.paymentTypeData[i]['isSelected'] = false
      }
    }
  }


  private populateTopRebateSpendingReduced(paymentTypeDatumElement: any) {
    let object = {
      year:this.selectedYear,
      rebateType:paymentTypeDatumElement,
      limit:6
    }
    this.topSpenders = [];
    this.topReducers  = [];
    this.topSelling =[];
    this.topRebatePaid = [];
    let topSpendingData = []
    let topReducedData = []
    let topRebatePaid = []
    let topSelling = []
    if(this.valueSelectedType == 'dealer'){
      this.httpService.getTopRebateSpendingReduced(object,this.valueSelectedType).subscribe((response:any)=>{
        if(response && response['data']){
          this.paymentTypeData
          let topTranscation = response['data']
          if(topTranscation){
            let amountTransactions = topTranscation['totalAmount'];
            let topReducedAmount = topTranscation['topReducedAmount']
            if(this.valueSelectedType == 'dealer'){
              topSpendingData = topTranscation['topSpending'];
              console.log('lenght', topSpendingData.lenght);
              topReducedData = topTranscation['topReduced'];
              for(let i=0;i<topSpendingData.length;i++){
                let spendingObj :any= {
                  groupName:topSpendingData[i]['groupName']?topSpendingData[i]['groupName']:'NA',
                  location:topSpendingData[i]['region']?topSpendingData[i]['region']:'NA',
                  amount:topSpendingData[i]['amount']?parseInt(topSpendingData[i]['amount']):0,
                  variance:topSpendingData[i]['variance']?parseInt(topSpendingData[i]['variance']):0,
                }
                if(spendingObj['amount']){
                  if(i==0){
                    spendingObj['processedAmount']=100
                  }else{
                    spendingObj['processedAmount']= this.getProgressedAmount(topSpendingData[0]['amount'],topSpendingData[i]['amount'])
                  }
                }
                this.topSpenders.push(spendingObj)

              }
              for(let i=0;i<topReducedData.length;i++){
                let reducedObj :any= {
                  groupName:topReducedData[i]['groupName']?topReducedData[i]['groupName']:'NA',
                  // location:topReducedData[i]['region']?topReducedData[i]['region']:'NA',
                  amount:topReducedData[i]['amount']?parseInt(topReducedData[i]['amount']):0,
                  variance:topReducedData[i]['variance']?parseInt(topReducedData[i]['variance']):0,
                }
                if(topReducedData[i]['amount']){
                  if(i==0){
                    reducedObj['processedAmount']=100
                  }else{
                    reducedObj['processedAmount']= this.getProgressedAmount(topReducedData[0]['amount'],topReducedData[i]['amount'])
                  }
                }
                this.topReducers.push(reducedObj)
              }
            }

          }
        }


      })

    }else{
      this.httpService.getTopSellingRebatePaid(object,this.valueSelectedType).subscribe((response:any)=>{
        if(response && response['data']){
          this.paymentTypeData
          let topTranscation = response['data']
          if(topTranscation){
            let amountTransactions = topTranscation['topRebatePaid'];
            let topReducedAmount = topTranscation['topSelling']
            if(this.valueSelectedType == 'vendor'){
              topRebatePaid = topTranscation['topSelling']
              topSelling = topTranscation ['topRebatePaid']
              // this.amount = {
              //   totalAmountSpent :  amountTransactions['totalAmountSpent']?amountTransactions['totalAmountSpent']:0,
              //   totalAmountEarned :  amountTransactions['totalRebate']?amountTransactions['totalRebate']:0,
              //   variancePurchase:amountTransactions['variancePurchase']?amountTransactions['variancePurchase']:0,
              //   varianceRebate:amountTransactions['varianceRebate']?amountTransactions['varianceRebate']:0
              // }
              for(let i=0;i<topRebatePaid.length;i++){
                let topSellingdObj :any= {
                  groupName:topRebatePaid[i]['groupName']?topRebatePaid[i]['groupName']:'NA',
                  location:topRebatePaid[i]['region']?topRebatePaid[i]['region']:'NA',
                  amount:topRebatePaid[i]['amount']?parseInt(topRebatePaid[i]['amount']):0,
                  variance:topRebatePaid[i]['variance']?parseInt(topRebatePaid[i]['variance']):0
                }
                if(topRebatePaid[i]['amount']){
                  if(i==0){
                    topSellingdObj['processedAmount']=100
                  }else{
                    topSellingdObj['processedAmount']= this.getProgressedAmount(topRebatePaid[0]['amount'],topRebatePaid[i]['amount'])
                  }
                }

                this.topSelling.push(topSellingdObj)
              }
              for(let i=0;i<topSelling.length;i++){
                let sellingObj:any = {
                  groupName:topSelling[i]['groupName']?topSelling[i]['groupName']:'NA',
                  location:topSelling[i]['region']?topSelling[i]['region']:'NA',
                  amount:topSelling[i]['amount']?parseInt(topSelling[i]['amount']):0,
                  variance:topSelling[i]['variance']?parseInt(topSelling[i]['variance']):0
                }
                if(topSelling[i]['amount']){
                  if(i==0){
                    sellingObj['processedAmount']=100
                  }else{
                    sellingObj['processedAmount']= this.getProgressedAmount(topSelling[0]['amount'],topSelling[i]['amount'])
                  }
                }
                this.topRebatePaid.push(sellingObj)
              }
            }


          }
        }


      })

    }
  }

  transformRebateType(rebateType : string){
    let orgRebateType = rebateType.replace(/_/g, ' ');
    const tranformedRebateType = orgRebateType.split(" ");
    for (let i = 0; i < tranformedRebateType.length; i++) {
      tranformedRebateType[i] = tranformedRebateType[i][0].toUpperCase() + tranformedRebateType[i].substr(1);
    }
    return tranformedRebateType.join(" ");
  }

  exportAll(){
    let SDate=moment.utc(new Date(this.basicInfoForm.value['startDate'])).format("YYYY-MM-DD");
    let EDate=moment.utc(new Date(this.basicInfoForm.value['endDate'])).format("YYYY-MM-DD")
    let transactionObj={
      supplierId:this.basicInfoForm.value['selectSupplier'],
      distributorId:this.basicInfoForm.value['selectDistributor'],
      invoiceStartDate: SDate,
      invoiceEndDate: EDate,
      type:this.valueSelectedType,
      corporateUser:'true'
    }
    console.log("export",this.valueSelectedType,SDate,EDate,)

    // console.log("ExportType",this.valueSelectedType == 'vendor')
    this.httpService.fetchSupplierTransactionData(transactionObj).subscribe(response => {
      if (response && response['data']['transactions'].length == 0) {
        const dialogRef = this.dialog.open(ExportModalComponent, {
          width: '416px',
          height: '185px',
          panelClass: 'dialog-container-custom',
          data: { message: "No records found to export" },

        });
        dialogRef.afterClosed().subscribe((result: any) => {
        });
      } else {
        const allData = this.mapTransactionData(response?.data?.transactions);
        if (allData.length > 0) {
          const headers = Object.keys(allData[0]);
          this.downloadFile(allData, headers,"Transaction");
        }
      }
    })
  }

  export(){
    let SDate=moment.utc(new Date(this.basicInfoForm.value['startDate'])).format("YYYY-MM-DD");
    let EDate=moment.utc(new Date(this.basicInfoForm.value['endDate'])).format("YYYY-MM-DD")
    let obj={
      year:this.selectedYear,
      supplierId:this.basicInfoForm.value['selectSupplier'],
      distributorId:this.basicInfoForm.value['selectDistributor'],
      startDate: SDate,
      endDate: EDate,
    }
    this.httpService.getVendorROIExportData(obj).subscribe((response:any)=>{

    
    if(response.data.length<= 0){
      const dialogRef = this.dialog.open(ExportModalComponent, {
        width: '416px',
        height: '185px',
        panelClass: 'dialog-container-custom',
        data: { message: "No records found to export" },
  
      });
      dialogRef.afterClosed().subscribe((result: any) => {
      });
    }else{
      const allData = this.mapROIExportData(response?.data);
      // let allData:any=['DealerName','VendorName','Total Purchase','Rebate Earned','YTD Rebate %','Last Invoice Date']
      if (allData.length > 0) {
        const headers = Object.keys(allData[0]);
        this.downloadFile(allData, headers,"ROI Data")
      }
    }
    })
  }

  downloadFile(data: any, header: any, filename = 'data') {
    let csvData = this.resuableService.convertToCSV(data, header);
    let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
    const dialogRef = this.dialog.open(SucessMessageModalComponent, {
      width: '420px',
      height: '170px',
      data: { "type": `${filename} Exported successfully ${data.length} records.`, actionStatus: 'success' },
      disableClose: true
    });
  
  }

  mapTransactionData = (content: any) => {
    return content.map((row: any) => ({
      "VENDOR NAME" : row && row['vendor_name'] ? `"${row['vendor_name'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
      "DEALER NAME" : row && row['dealer_name'] ? `"${row['dealer_name'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
      "VENDOR PIVOT ID" : row && row['vendor_pivot_id'] ? `"${row['vendor_pivot_id'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
      "INVOICE NO" : row && row['invoice_no'] ? row['invoice_no'] : 'NA',
      "INVOICE DATE" : row && row['invoice_date'] ? `${this.getDate(row['invoice_date'])}` : 'NA',
      "PRODUCT ID" : row && row['product_id'] ? `"${row['product_id'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
      "PRODUCT DESCRIPTION" : row && row['product_description'] ? `"${row['product_description'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
      "SUPPLIER CATEGORY" : row && row['supplier_category'] ? `"${row['supplier_category'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
      "QUANTITY" : row && row['quantity'] ? row['quantity'] : 'NA',
      "TRANSACTION AMOUNT" : row && row['transaction_amount'] ? row['transaction_amount'] : 'NA',
      "PO_NUMBER" : row && row['po_number'] ? `"${row['po_number'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
      "NOTES" : row && row['note'] ? `"${row['note'].replaceAll('"','""').replaceAll(",","")}"` : ''
    }))
  }
  public getDate = (date:any) =>{
    if(date){
      let modifedDate = moment(new Date(date),"YYYYMMDD")
      return modifedDate.format('MM/DD/YYYY')
    }else{
      return 'NA'
    }
  }
  viewMore = ()=>{
    const dialogRef = this.dialog.open(ViewMoreDataModalComponent, {
      width: '446px',
      height: '314px',
      panelClass: 'dialog-container-custom',
      data:{categoryType:"distributor",year:this.selectedYear,distributorId:this.selectDistributor,}
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      if(result){
        // if(this.userType === UserType.Distributor){
          this.router.navigate([`/${this.tenantType}/my-dashboard/distributor/transaction-details`,
            {supplierId:result['selectSupplier'],startDate:this.formatDate(result['startDate']),endDate:this.formatDate(result['endDate']),categoryType:this.valueSelectedType,
            programName:result['supplierName'],distributorId:this.selectDistributor ,previousSupplierId:result['selectSupplier'],supplierName:result['supplierName'],subProgramType:"group"}])
        // }
      }
    });
  }

  mapROIExportData =(content:any)=>{
    return content.map((row:any)=>({
      "Dealer Name" : row && row['DEALER_NAME'] ? `"${row['DEALER_NAME'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
      "Vendor Name" : row && row['SUPPLIER_NAME'] ? `"${row['SUPPLIER_NAME'].replaceAll('"','""').replaceAll(",","")}"` : 'NA',
      "Total Purchase" : row && row['CUMULATIVE_TOTAL_PURCHASE_DIFF'] ?`${'$'+row['CUMULATIVE_TOTAL_PURCHASE_DIFF'].toFixed(2)}`:'$0.00',
      // "REBATABLE PURCHASE" : row && row['rebatable_purchase'] ? row['rebatable_purchase'] : '0',
      "Rebate Earned" : row && row['REBATE_PAYMENT_AMOUNT_DIFF'] ?`${'$'+row['REBATE_PAYMENT_AMOUNT_DIFF'].toFixed(2)}`:'$0.00',
      "YTD Rebate %" : row && row['YTD_REBATE'] ?`${row['YTD_REBATE'].toFixed(2)+'%'}`:'0.00%',
      "Last Invoice Date" : row && row['LAST_INVOICE_DATE'] ? row['LAST_INVOICE_DATE'] : 'NA',
    }))
  }

  formatDate = (date:any) => {
    return  moment.utc(date).local().format('YYYY-MM-DD')
  }

}
