import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BgFinancialHealthComponent } from './bg-financial-health.component';

describe('BgFinancialHealthComponent', () => {
  let component: BgFinancialHealthComponent;
  let fixture: ComponentFixture<BgFinancialHealthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BgFinancialHealthComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BgFinancialHealthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
