import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventSettlementDialogComponent } from './event-settlement-dialog.component';

describe('EventSettlementDialogComponent', () => {
  let component: EventSettlementDialogComponent;
  let fixture: ComponentFixture<EventSettlementDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventSettlementDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventSettlementDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
