import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { PaymentService } from 'src/app/services/payment.service';

@Component({
  selector: 'app-event-settlement-dialog',
  templateUrl: './event-settlement-dialog.component.html'
})
export class EventSettlementDialogComponent {
  public isFile:boolean=false;
  fileName: string = '';
  file: any;

  constructor(public dialogRef: MatDialogRef<EventSettlementDialogComponent>, @Inject(MAT_DIALOG_DATA) public eventId: number, private paymentService: PaymentService) { }

  onFileSelect(event: any) {
    this.file = event.srcElement.files[0];
    this.fileName = this.file ? this.file.name : '';
  }

  uploadPaymentFile(): void {
   if(this.isFile){
    const formData: any = new FormData();
    formData.append('file', this.file);
    this.paymentService.uploadPaymentFile(this.eventId, formData).subscribe((resp: any) => {
      this.dialogRef.close(resp.message);
    }, (error: any) => {
      this.dialogRef.close(error.error.message);
    });
    }
  }
}
