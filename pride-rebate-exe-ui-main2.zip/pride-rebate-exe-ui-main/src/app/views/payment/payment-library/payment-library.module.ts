import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { CommonCompsModule } from 'src/app/shared/common-comps.module';
import { NgCircleProgressModule } from 'ng-circle-progress';

import { EventCardComponent } from './event-card/event-card.component';
import { EventSettlementDialogComponent } from './event-settlement-dialog/event-settlement-dialog.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { EventLibraryComponent } from './event-library/event-library.component';
import { EventRejectDialogComponent } from './event-reject-dialog/event-reject-dialog.component';
import { CIRCULAR_PROGRESS_DEFAULTS } from 'src/app/helpers/constants';

@NgModule({
  declarations: [
    EventLibraryComponent,
    EventCardComponent,
    EventSettlementDialogComponent,
    EventDetailsComponent,
    EventRejectDialogComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    SharedModule,
    CommonCompsModule,
    NgCircleProgressModule.forRoot(CIRCULAR_PROGRESS_DEFAULTS)
  ],
  exports: [
    EventLibraryComponent,
    EventCardComponent,
    EventSettlementDialogComponent,
    EventDetailsComponent
  ]
})
export class PaymentLibraryModule { }
