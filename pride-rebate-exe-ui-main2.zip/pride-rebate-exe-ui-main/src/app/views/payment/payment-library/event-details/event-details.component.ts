import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { PaginationOptions } from 'src/app/models/pagination-options.model';
import { PaymentService } from 'src/app/services/payment.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { SortBy } from 'src/app/models/sort-by.model';
import { Sort } from '@angular/material/sort';
import { MatDialog } from '@angular/material/dialog';
import { MessageDialog, MessageDialogType } from 'src/app/common/message-dialog/message-dialog.component';
import { EventSettlementDialogComponent } from '../event-settlement-dialog/event-settlement-dialog.component';
import { User } from 'src/app/models/user.model';
import { UserDetailsService } from 'src/app/services/user-details.service';
import { EventCardComponent } from '../event-card/event-card.component';
import * as XLSX from 'xlsx';
import { EventRejectDialogComponent } from '../event-reject-dialog/event-reject-dialog.component';
import { SucessMessageModalComponent } from 'src/app/common/sucess-message-modal/sucess-message-modal.component';

@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html'
})
export class EventDetailsComponent implements OnInit, AfterViewInit {

  eventId: number = 0;
  paymentEvent: any = {};
  rebateTypes: any[] = [];
  user: User;

  sorting: SortBy[] = [];
  filters: any = {};
  dataSource: any[] = [];
  displayedColumns: string[] = [];
  pageOptions: PaginationOptions = { limit: 10, pageNo: 1, length: 0 };

  @ViewChild(EventCardComponent) cardComponent!: EventCardComponent;

  constructor(private router: Router, private activatedRoute: ActivatedRoute, private paymentService: PaymentService, private dialog: MatDialog, public userDetailsService: UserDetailsService) {
    this.user = userDetailsService.getUser();
    if (this.user.userType === userDetailsService.corporate) {
      this.displayedColumns = ['supplierName', 'programName', 'rebateType', 'dueAmount', 'paymentRecieved'];
    } else if (this.user.userType === userDetailsService.supplier) {
      this.displayedColumns = ['programName', 'rebateType', 'memberName', 'coveredSales', 'dueAmount'];
    }
  }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((paramMap: Params) => {
      this.eventId = parseInt(paramMap["eventId"] || 0);
      if (this.eventId) {
        this.paymentService.getPaymentEvent(this.eventId).subscribe((resp: any) => this.paymentEvent = resp.data);
        if (this.user.userType === this.userDetailsService.supplier) {
          this.paymentService.supplierRebateTypeOverview(this.eventId).subscribe((resp: any) => this.rebateTypes = resp.data);
        }
        this.fetchData();
      }
    });
  }

  ngAfterViewInit(): void {

    // Subscribe to Export Button Click on Event Details Card Component.
    this.cardComponent.export.subscribe((eventId: number) => {
      this.paymentService.getPaymentEventDetails(eventId, { download: true }).subscribe((resp: any) => {
        const workbook = XLSX.utils.book_new();
        const sheet = XLSX.utils.json_to_sheet(resp.data.paymentEventDetails);
        XLSX.utils.book_append_sheet(workbook, sheet, "Sheet1");
        XLSX.writeFile(workbook, this.paymentService.getEventExportFileName(this.paymentEvent), { bookType: 'csv' });
        this.dialog.open(MessageDialog, { width: '400px', position: { top: '100px' }, data: { title: 'Payment Event Details', message: 'File Downloaded Successfully' } });
      });
    });

    // Subscribe to Accept/Reject Button Click on Event Details Card Component.
    this.cardComponent.action.subscribe((action: string) => {
      if (action === 'Accept') {
        this.dialog.open(MessageDialog, {
          width: '400px', position: { top: '100px' }, data: { message: `Are you sure you want to ${action} this payment event?`, type: MessageDialogType.CONFIRM }
        }).afterClosed().subscribe((resp: boolean) => {
          console.log(resp);
          if (resp) {
            this.paymentService.supplierPaymentAccept(this.paymentEvent.eventId, {}).subscribe((resp: any) => {
              this.dialog.open(MessageDialog, { width: '400px', position: { top: '100px' }, data: { message: `Payment ${resp.data} successfully` } }).afterClosed().subscribe(() => {
                this.router.navigate(['..'], { relativeTo: this.activatedRoute });
              });
            });
          }
        });
      } else if (action === 'Reject') {
        this.dialog.open(EventRejectDialogComponent, {
          width: '500px', disableClose: true, position: { top: '100px' }, data: { message: `Are you sure you want to ${action} this payment event?`, type: MessageDialogType.CONFIRM }
        }).afterClosed().subscribe((comments: string) => {
          if (comments) {
            this.paymentService.supplierPaymentReject(this.paymentEvent.eventId, comments).subscribe((resp: any) => {
              this.dialog.open(MessageDialog, { width: '400px', position: { top: '100px' }, data: { message: `Payment ${resp.data} successfully` } }).afterClosed().subscribe(() => {
                this.router.navigate([this.user.tenantName, 'file-management'], { relativeTo: this.activatedRoute.root });
              });
            });
          }
        });
      }
    });
  }

  fetchData() {
    this.paymentService.getPaymentEventDetails(this.eventId, { pageNo: this.pageOptions.pageNo, limit: this.pageOptions.limit, ...this.filters, sorting: this.sorting }).subscribe((resp: any) => {
      this.dataSource = resp.data.paymentEventDetails;
      this.pageOptions.length = resp.data.count;
    });
  }

  onSortChange(event: Sort) {
    this.sorting = event.direction ? [{ orderBy: event.active, orderType: event.direction }] : [];
    this.fetchData();
  }

  aplyFilter(filter: any) {
    if (filter.value) {
      this.filters[filter.column] = filter.value;
    } else {
      filter.value="no";
      this.filters[filter.column] =filter.value;
      delete this.filters[filter.column];
    }
    this.fetchData();
  }

  downloadFile(): void {
    this.paymentService.getPaymentEventDetails(this.eventId, { ...this.filters, sorting: this.sorting, download: true }).subscribe((resp: any) => {
      const workbook = XLSX.utils.book_new();
      const allData  = this.mapEventData(resp.data.paymentEventDetails);
      //const sheet = XLSX.utils.json_to_sheet(resp.data.paymentEventDetails);
      const sheet = XLSX.utils.json_to_sheet(allData);
      XLSX.utils.book_append_sheet(workbook, sheet, "Sheet1");
      XLSX.writeFile(workbook, this.paymentService.getEventExportFileName(this.paymentEvent), { bookType: 'csv' });
      //this.dialog.open(MessageDialog, { width: '400px', position: { top: '100px' }, data: { message: 'File Downloaded Successfully' } });
      const dialogRef = this.dialog.open(SucessMessageModalComponent, {
        width: '420px',
        height: '170px',
        data: { "type": `File Downloaded Successfully.`, actionStatus: 'success' },
        disableClose: true
      });
    });
  }

  mapEventData = (content: any) => {
    return content.map((row: any) => ({
      "Vendor ID" : row['Supplier ID'] ? row['Supplier ID'] : 'NA',
      "Vendor Pivot Id"	: row['Vendor Pivot Id'] ? row['Vendor Pivot Id']: 'NA',
      "Vendor Name"	: row['Vendor Name'] ? row['Vendor Name']: 'NA',
      "Program ID"	: row['Program ID'] ? row['Program ID']: 0,
      "Program Name"	: row['Program Name'] ? row['Program Name'] : 'NA',
      "Program Type"	: row['Program Type'] ? `${row['Program Type'].replace('_',' ')}` : 'NA',
      "Covered Sales"	: row['Covered Sales'] ? row['Covered Sales'] : 0,
      "Total Sales"	: row['Total Sales'] ? row['Total Sales'] : 0,
      "Due Amount"	: row['Due Amount'] ? row['Due Amount'] : 0,
      "Payment Received"	: row['Payment Received'] ? row['Payment Received'] : 0,
    }))
  }
  getRebateType(rebateType:any){
    return rebateType.replace('_',' ');
  }

  settlePayment() {
    this.paymentService.getPaymentEventDetails(this.eventId, { ...this.filters, sorting: this.sorting, download: true }).subscribe((resp: any) => {
      const workbook = XLSX.utils.book_new();
      const sheet = XLSX.utils.json_to_sheet(resp.data.paymentEventDetails);
      XLSX.utils.book_append_sheet(workbook, sheet, "Sheet1");
      XLSX.writeFile(workbook, this.paymentService.getEventExportFileName(this.paymentEvent), { bookType: 'csv' });
      const dialogRef = this.dialog.open(SucessMessageModalComponent, {
        width: '370px',
        height: '180px',
        data: { "type": `File Downloaded successfully`, actionStatus: 'success' },
        disableClose: true
      });
      dialogRef.afterClosed().subscribe((result: any) => {
        this.dialog.open(EventSettlementDialogComponent, { width: '500px', disableClose: true, position: { top: '100px' }, data: this.eventId }).afterClosed().subscribe((result: any) => {
          if (result) {

            // this.dialog.open(MessageDialog, { width: '400px', position: { top: '100px' }, data: { message: `Payment Event Settled successfully`, actionStatus: 'success'  } }).afterClosed().subscribe(() => {
            //   this.router.navigate(['.'], { relativeTo: this.activatedRoute.parent });
            // });
            const dialogRef = this.dialog.open(SucessMessageModalComponent, {
              width: '370px',
              height: '180px',
              data: { "type": `Payment Event Settled successfully`, actionStatus: 'success' },
              disableClose: true
            }).afterClosed().subscribe(() => {
                this.router.navigate(['.'], { relativeTo: this.activatedRoute.parent })})
          }
        });
      });
    });
  }
}
