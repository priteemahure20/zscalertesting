import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-event-reject-dialog',
  templateUrl: './event-reject-dialog.component.html',
  styleUrls: ['./event-reject-dialog.component.scss']
})
export class EventRejectDialogComponent {

  textInput: FormControl = new FormControl();

  constructor(public dialogRef: MatDialogRef<EventRejectDialogComponent>) {
    this.textInput.reset();
  }

  confirmComment() {
    if (this.textInput.value) {
      this.dialogRef.close(this.textInput.value);
    } else {
      this.textInput.setErrors({ required: true });
    }
  }
}
