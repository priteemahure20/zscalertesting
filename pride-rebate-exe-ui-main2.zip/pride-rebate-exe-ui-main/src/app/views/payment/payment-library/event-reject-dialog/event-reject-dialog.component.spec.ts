import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventRejectDialogComponent } from './event-reject-dialog.component';

describe('EventRejectDialogComponent', () => {
  let component: EventRejectDialogComponent;
  let fixture: ComponentFixture<EventRejectDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventRejectDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventRejectDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
