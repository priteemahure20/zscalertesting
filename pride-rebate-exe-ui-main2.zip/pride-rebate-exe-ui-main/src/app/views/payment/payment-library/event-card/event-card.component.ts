import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { UserDetailsService } from 'src/app/services/user-details.service';
import { ReusableService } from 'src/app/services/reusable.service';
import * as moment from 'moment';
@Component({
  selector: 'app-event-card',
  templateUrl: './event-card.component.html',
  host: {
    'class': 'col'
  }
})
export class EventCardComponent {

  @Input() paymentEvent: any = {};
  @Input() rebateTypes: any[] = [];
  @Input() detailed: boolean = false;
  @Input() show: any;

  @Output() export: EventEmitter<number> = new EventEmitter<number>();
  @Output() action: EventEmitter<any> = new EventEmitter<any>();

  user: User;
  isSupplierUser: boolean = false;
  isCorporateUser: boolean = false;

  constructor(private router: Router, public activatedRoute: ActivatedRoute, public userDetailsService: UserDetailsService, private reusableService:ReusableService) {
    this.user = userDetailsService.getUser();
    this.isSupplierUser = this.user.userType === userDetailsService.supplier;
    this.isCorporateUser = this.user.userType === userDetailsService.corporate;
  }

  getPercentage() {
    return (this.paymentEvent?.paymentRecieved ?? 0) / (this.paymentEvent?.dueAmount ?? 0) * 100;
  }

  isLibraryView() {
    return this.router.isActive(this.router.createUrlTree([this.user.tenantName, 'payment'], { relativeTo: this.activatedRoute.root }), true)
      || this.router.isActive(this.router.createUrlTree([this.user.tenantName, 'my-dashboard', 'supplier', 'payment'], { relativeTo: this.activatedRoute.root }), true);
  }

  openDetailsPage() {
    if (this.isLibraryView()) {
      this.router.navigate([this.paymentEvent.eventId], { relativeTo: this.activatedRoute });
    }
  }
  formatDate = (date:any) => {
    if(date){
      return this.reusableService.formatDateToMTZ(moment(date).format('YYYY-MM-DD'));
    } 
  }
}
