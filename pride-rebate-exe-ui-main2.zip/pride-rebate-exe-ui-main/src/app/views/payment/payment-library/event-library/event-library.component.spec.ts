import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventLibraryComponent } from './event-library.component';

describe('EventLibraryComponent', () => {
  let component: EventLibraryComponent;
  let fixture: ComponentFixture<EventLibraryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventLibraryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventLibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
