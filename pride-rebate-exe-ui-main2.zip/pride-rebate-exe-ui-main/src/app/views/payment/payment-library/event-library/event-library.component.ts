import { Component, OnInit } from '@angular/core';
import { PaginationOptions } from 'src/app/models/pagination-options.model';
import { PaymentService } from 'src/app/services/payment.service';
import { User } from 'src/app/models/user.model';
import { UserDetailsService } from 'src/app/services/user-details.service';

@Component({
  selector: 'app-event-library',
  templateUrl: './event-library.component.html',
  styleUrls: ['./event-library.component.scss']
})
export class EventLibraryComponent implements OnInit {

  user: User;
  isSupplierUser: boolean = false;

  firstEvent: any = {};
  paymentEvents: any[] = [];
  pageOptions: PaginationOptions = { limit: 5, pageNo: 1, length: 0 };
  paymentOverview: any = {};

  constructor(private paymentService: PaymentService, public userDetailsService: UserDetailsService) {
    this.user = userDetailsService.getUser();
    this.isSupplierUser = this.user.userType === userDetailsService.supplier;
  }

  ngOnInit(): void {
    this.paymentService.getPaymentEvents({ limit: 1, pageNo: 1 }).subscribe((resp: any) => {
      this.firstEvent = resp.data.paymentEvents[0];
    });
    this.loadPaymentOverview();
    this.fetchData();
  }

  loadPaymentOverview() {
    if (this.isSupplierUser) {
      this.paymentService.supplierPaymentOverview({ year: new Date().getFullYear() }).subscribe((resp: any) => {
        this.paymentOverview = resp.data;
      });
    }
  };

  fetchData() {
    this.paymentService.getPaymentEvents({ limit: this.pageOptions.limit, pageNo: this.pageOptions.pageNo, skipRows: 1 }).subscribe((resp: any) => {
      this.paymentEvents = resp.data.paymentEvents;
      this.pageOptions.length = resp.data.count;
    });
  }
}
