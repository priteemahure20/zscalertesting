import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { UserDetailsService } from 'src/app/services/user-details.service';

@Component({
  selector: 'app-payment-bg',
  templateUrl: './payment-bg.component.html'
})
export class PaymentBgComponent {

  user: User;

  constructor(private router: Router, public activatedRoute: ActivatedRoute, public userDetailsService: UserDetailsService) {
    this.user = userDetailsService.getUser();
  }

  isHomeActive(): boolean {
    return this.router.isActive(this.router.createUrlTree([this.user.tenantName, 'payment'], { relativeTo: this.activatedRoute.root }), true);
  }

  isCreateActive(): boolean {
    return this.router.isActive(this.router.createUrlTree([this.user.tenantName, 'payment', 'create'], { relativeTo: this.activatedRoute.root }), true);
  }
}
