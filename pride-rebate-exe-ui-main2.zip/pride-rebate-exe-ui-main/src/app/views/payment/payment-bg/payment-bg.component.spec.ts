import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentBgComponent } from './payment-bg.component';

describe('PaymentBgComponent', () => {
  let component: PaymentBgComponent;
  let fixture: ComponentFixture<PaymentBgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentBgComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentBgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
