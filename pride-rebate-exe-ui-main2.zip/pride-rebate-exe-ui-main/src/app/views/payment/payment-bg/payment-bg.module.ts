import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PaymentBgRoutingModule } from './payment-bg-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { CommonCompsModule } from 'src/app/shared/common-comps.module';
import { PaymentCreateModule } from '../payment-create/payment-create.module';
import { PaymentLibraryModule } from '../payment-library/payment-library.module';
import { PaymentBgComponent } from './payment-bg.component';


@NgModule({
  declarations: [
    PaymentBgComponent
  ],
  imports: [
    CommonModule,
    PaymentBgRoutingModule,
    SharedModule,
    CommonCompsModule,
    PaymentCreateModule,
    PaymentLibraryModule
  ]
})
export class PaymentBgModule { }
