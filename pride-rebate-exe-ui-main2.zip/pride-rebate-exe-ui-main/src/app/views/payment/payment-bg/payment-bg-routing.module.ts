import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PaymentBgComponent } from './payment-bg.component';
import { PaymentCreateComponent } from '../payment-create/payment-create.component';
import { EventDetailsComponent } from '../payment-library/event-details/event-details.component';
import { EventLibraryComponent } from '../payment-library/event-library/event-library.component';

const routes: Routes = [{
  path: '', component: PaymentBgComponent, children: [
    { path: 'create', component: PaymentCreateComponent, pathMatch: 'full' },
    { path: ':eventId', component: EventDetailsComponent, pathMatch: 'full' },
    { path: '', component: EventLibraryComponent, pathMatch: 'full' }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PaymentBgRoutingModule { }
