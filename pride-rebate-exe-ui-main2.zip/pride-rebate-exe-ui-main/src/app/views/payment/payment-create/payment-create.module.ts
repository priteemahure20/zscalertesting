import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaymentCreateComponent } from './payment-create.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CommonCompsModule } from 'src/app/shared/common-comps.module';
import { SupplierFilterDialogComponent } from './supplier-filter-dialog/supplier-filter-dialog.component';

@NgModule({
  declarations: [
    PaymentCreateComponent,
    SupplierFilterDialogComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    CommonCompsModule
  ],
  exports: [
    PaymentCreateComponent
  ]
})
export class PaymentCreateModule { }
