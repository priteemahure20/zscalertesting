import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { PaginationOptions } from 'src/app/models/pagination-options.model';
import { PaymentService } from 'src/app/services/payment.service';
import { MatDialog } from '@angular/material/dialog';
import { SupplierFilterDialogComponent } from './supplier-filter-dialog/supplier-filter-dialog.component';
import { MatOption } from '@angular/material/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageDialog, MessageDialogType } from 'src/app/common/message-dialog/message-dialog.component';
import { DropdownOption } from '../../../models/dropdown-option.model';
import { SucessMessageModalComponent } from 'src/app/common/sucess-message-modal/sucess-message-modal.component';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-payment-create',
  templateUrl: './payment-create.component.html',
  styleUrls: ['./payment-create.component.scss']
})
export class PaymentCreateComponent implements OnInit {

  nextStep: boolean = false;
  isFormInvalid : boolean = false;

  lastFileDate: any = '';
  rebateTypeList: DropdownOption[] = [];
  fbiEligibleList: string[] = [];
  membershipStatusList: string[] = [];
  associateLevelList: string[] = [];

  supplierList: any[] = [];
  filteredSupplierList: any[] = [];
  selectAllSupplier: boolean = false;
  selectedSupplierIds: number[] = [];
  supplierFilters: any = { associateLevel: '' };
  supplierSearch: string = '';
  pageOptions: PaginationOptions = { limit: 12, pageNo: 1, length: 0 };

  rebateTypeControl = new FormControl('');
  eventFormGroup = new FormGroup({
    fileDateControl: new FormControl(''),
    rebateTypeControl: this.rebateTypeControl,
    eventTitleControl: new FormControl(''),
    settleAdjustmentControl: new FormControl(false)
  });

  @ViewChild('allSelected') private allSelected!: MatOption;

  constructor(private router: Router, private activatedRoute: ActivatedRoute, private paymentService: PaymentService, private dialog: MatDialog, private dataService:DataService) {
    this.paymentService.getPaymentEventCreatePrerequisite().subscribe((resp: any) => {
      this.lastFileDate = new Date(resp.data.lastFileDate);
      this.rebateTypeList = resp.data.rebateTypeList;
      this.associateLevelList = resp.data.associateLevelList;
    });
  }

  ngOnInit(): void { }

  fetchData() {
    if (this.eventFormGroup.valid) {
      console.log('form submitted');
      this.paymentService.getPaymentEventCreateSuppliers({
        fileDate: new Intl.DateTimeFormat('en-US').format(new Date(this.eventFormGroup.controls.fileDateControl.value)),
        settleAdjustment: this.eventFormGroup.controls.settleAdjustmentControl.value,
        rebateTypes: this.rebateTypeControl.value.includes('all') ? this.rebateTypeList.map((option: DropdownOption) => option.value) : this.rebateTypeControl.value
      }).subscribe((resp: any) => {
        this.supplierList = resp.data;
        this.pageOptions.length = this.supplierList.length;
        if (this.pageOptions.length > 0) {
          this.eventFormGroup.disable();
          this.nextStep = true;
          this.filterSuppliers();
        } else {
          this.dialog.open(MessageDialog, { width: '500px', position: { top: '100px' }, data: { message: 'No suppliers found having payment due amounts. Please select different file date.' } });
        }
      });
    } else {
      this.isFormInvalid = true;
    }
  }

  rebateTypeSelectAll() {
    if (this.allSelected.selected) {
      this.rebateTypeControl.patchValue([...this.rebateTypeList.map((option: DropdownOption) => option.value), 'all']);
    } else {
      this.rebateTypeControl.patchValue([]);
    }
  }
  getDisplayText(): any {
    if (this.rebateTypeControl.value && this.rebateTypeControl.value[0]) {
      const selectedItem = this.rebateTypeList.find(item => item.value === this.rebateTypeControl.value[0]);
      return selectedItem ? selectedItem.displayText : '';
    }
    return '';
  }

  tosslePerOne() {
    if (this.allSelected.selected) {
      this.allSelected.deselect();
      return false;
    }
    if (this.rebateTypeControl.value.length === this.rebateTypeList.length) {
      this.allSelected.select();
    }
  }

  openSupplierFilterDialog() {
    this.dialog.open(SupplierFilterDialogComponent, {
      width: '350px', disableClose: true, position: { top: '100px' }, data: {
        associateLevelList: this.associateLevelList,
        associateLevel: this.supplierFilters.associateLevel
      }
    }).afterClosed().subscribe((appliedFilters: any) => {
      this.supplierFilters = appliedFilters;
      this.filterSuppliers();
    });
  }

  filterSuppliers() {
    let filteredSuppliers: any[] = this.supplierList;
    if (this.supplierFilters.associateLevel) {
      filteredSuppliers = filteredSuppliers.filter((row: any) => String(row.associateLevel).toLowerCase() === String(this.supplierFilters.associateLevel).toLowerCase());
    }
    if (this.supplierSearch) {
      filteredSuppliers = filteredSuppliers.filter((row: any) => row.supplierName.toLowerCase().includes(this.supplierSearch.toLowerCase()));
    }
    this.filteredSupplierList = filteredSuppliers;
    this.pageOptions.length = this.filteredSupplierList.length;
    this.pageOptions.pageNo = 1;
    this.selectedSupplierIds = [];
    this.selectAllSupplier = false;
  }

  paginatedSupplierList(): any[] {
    return this.filteredSupplierList.slice((this.pageOptions.pageNo - 1) * this.pageOptions.limit, this.pageOptions.limit + (this.pageOptions.pageNo - 1) * this.pageOptions.limit);
  }

  selectAllSupplierChange() {
    if (this.selectAllSupplier) {
      this.selectedSupplierIds = this.filteredSupplierList.map((supplier: any) => supplier.supplierId);
    } else {
      this.selectedSupplierIds = [];
    }
  }

  selectSupplier(checked: boolean, supplierId: number) {
    if (checked) {
      if (!this.selectedSupplierIds.includes(supplierId)) {
        this.selectedSupplierIds.push(supplierId);
      }
    } else {
      const index: number = this.selectedSupplierIds.indexOf(supplierId);
      if (index > -1) {
        this.selectedSupplierIds.splice(index, 1);
      }
    }
    this.selectAllSupplier = this.selectedSupplierIds.length === this.filteredSupplierList.length;
  }

  discard() {
    this.dialog.open(MessageDialog, { width: '400px', position: { top: '100px' }, data: { message: 'Are you sure you want ot discard changes?', type: MessageDialogType.CONFIRM } }).afterClosed().subscribe((confirm: boolean) => {
      if (confirm) {
        this.eventFormGroup.reset();
        this.eventFormGroup.enable();
        this.nextStep = false;
        this.isFormInvalid = false;
      }
    });
  }

  initiatePayment() {
    if (this.selectedSupplierIds.length > 0) {
      this.paymentService.initiatePaymentEvent({
        eventName: this.eventFormGroup.controls.eventTitleControl.value,
        fileDate: new Intl.DateTimeFormat('en-US').format(new Date(this.eventFormGroup.controls.fileDateControl.value)),
        settleAdjustment: this.eventFormGroup.controls.settleAdjustmentControl.value,
        rebateTypes: this.rebateTypeControl.value.includes('all') ? this.rebateTypeList.map((option: DropdownOption) => option.value) : this.rebateTypeControl.value,
        selectedSupplierIds: this.selectedSupplierIds
      }).subscribe((resp: any) => {
        const dialogRef =this.dialog.open(SucessMessageModalComponent, { width: '400px', position: { top: '100px' },  data: { "type": `Payment Event Intiated successfully`, actionStatus: 'success' } }).afterClosed().subscribe(() => {
          this.router.navigate(['.'], { relativeTo: this.activatedRoute.parent });
        });
        this.dataService.notificationEmitter.emit(true);
      });
    } else {
      this.dialog.open(MessageDialog, { width: '400px', position: { top: '100px' }, data: { message: 'Please select suppliers to initiate payment event' } })
    }
  }

  checkNameLength = (name: any,size:number) => {
    if (name && name.length > 1) {
      let values = Array.isArray(name)?name.join(', '):name
      return values.length>size?values.substring(0, size) + "...":values;
    } else {
      return name
    }
  }

}
