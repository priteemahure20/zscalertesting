import { Component, Inject } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

export interface SupplierFilterDialogData {
  associateLevelList: string[];
  associateLevel: any;
}

@Component({
  selector: 'app-supplier-filter-dialog',
  templateUrl: './supplier-filter-dialog.component.html'
})
export class SupplierFilterDialogComponent {

  associateLevelControl: FormControl = new FormControl();

  constructor(public dialogRef: MatDialogRef<SupplierFilterDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: SupplierFilterDialogData) {
    this.associateLevelControl.setValue(data.associateLevel);
  }

  applyFilters(): void {
    this.dialogRef.close({
      associateLevel: this.associateLevelControl.value ? this.associateLevelControl.value : ''
    });
  }

  reset(): void {
    this.dialogRef.close({ associateLevel: '' });
  }

}
