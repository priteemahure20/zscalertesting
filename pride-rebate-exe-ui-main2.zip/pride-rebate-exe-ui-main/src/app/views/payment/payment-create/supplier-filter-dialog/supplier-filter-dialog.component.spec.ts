import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupplierFilterDialogComponent } from './supplier-filter-dialog.component';

describe('SupplierFilterDialogComponent', () => {
  let component: SupplierFilterDialogComponent;
  let fixture: ComponentFixture<SupplierFilterDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SupplierFilterDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SupplierFilterDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
