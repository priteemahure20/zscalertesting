import { NgModule,CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FileManagementRoutingModule } from './file-management-routing.module';
import { FileManagementComponent } from './file-management.component';
import { DynamicFormComponent } from 'src/app/common/dynamic-form/dynamic-form.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { MatSelectModule } from '@angular/material/select';
import { CommonCompsModule } from 'src/app/shared/common-comps.module';
import { NgxSkeletonLoaderModule } from "ngx-skeleton-loader";


@NgModule({
  declarations: [
    FileManagementComponent,
    DynamicFormComponent
  ],
  imports: [
    CommonModule,
    FileManagementRoutingModule,
    CommonModule,
    SharedModule,
    MatSelectModule,
    CommonCompsModule,
    NgxSkeletonLoaderModule
  ],
  schemas:[CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA]
})
export class FileManagementModule { }
