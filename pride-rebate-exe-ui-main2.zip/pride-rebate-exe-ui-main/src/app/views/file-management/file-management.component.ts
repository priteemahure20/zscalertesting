import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { NgxCsvParser, NgxCSVParserError } from 'ngx-csv-parser';
import { isCSVFile, isValidSize } from 'src/app/helpers/commonUtils';
import { HttpService } from 'src/app/services/http.service';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { MatMenuTrigger } from '@angular/material/menu';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatSnackBar } from '@angular/material/snack-bar';
import { get as _get, reduce as _reduce, isEqual as _isEqual, isEmpty as _isEmpty } from 'lodash';
import { CONSTANTS, FILE_TYPE, MappingFileType } from 'src/app/helpers/constants';
import { TitleCasePipe } from '@angular/common';
import readXlsxFile from 'read-excel-file'
import * as XLSX from 'xlsx';
import { Router } from '@angular/router';
import { ThrowStmt } from '@angular/compiler';
type AOA = any[][];
import * as moment from 'moment';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { ReusableService } from 'src/app/services/reusable.service';
import { throttleTime } from 'rxjs/operators';
import { AuthService } from 'src/app/services/auth.service';
import { SuccessErrorModalComponent } from '../../common/success-error-modal/success-error-modal.component';
import { MatDialog } from '@angular/material/dialog';
import { FILE } from 'dns';
import { MatDatepicker } from '@angular/material/datepicker';
import { Subject } from 'rxjs/internal/Subject';
import { ItemsList } from '@ng-select/ng-select/lib/items-list';
import { MatPaginator } from '@angular/material/paginator';

export class RAErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'app-file-management',
  templateUrl: './file-management.component.html',
  styleUrls: ['./file-management.component.scss'],
})
export class FileManagementComponent implements OnInit {
  @ViewChild('selectedFileName') selectedFileName: any;

  // effectiveDate: any = new FormControl();
  fileFormGroup = new FormGroup({
    // effectiveDate: new FormControl(null, [Validators.required]),
  });
  // get effectiveDateFormControl() { return this.fileFormGroup.get('effectiveDate'); }
  matcher = new RAErrorStateMatcher();
  lastUpdateDate?: any;
  
  // minEffectiveDate: Date = new Date();
  constructor(
    private ngxCsvParser: NgxCsvParser,
    private httpService: HttpService,
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer,
    private snackBar: MatSnackBar,
    private titlecasePipe: TitleCasePipe,
    public router: Router,
    private reusableService: ReusableService,
    private authService: AuthService,
    private dialog: MatDialog,
  ) {
    this.matIconRegistry.addSvgIcon(
      'causion',
      this.domSanitizer.bypassSecurityTrustResourceUrl(
        '../assets/img/icons/causion_icon.svg'
      )
    );
    this.matIconRegistry.addSvgIcon(
      'notification',
      this.domSanitizer.bypassSecurityTrustResourceUrl(
        '../assets/img/icons/notification-icon.svg'
      )
    );
    this.matIconRegistry.addSvgIcon(
      'calendar',
      this.domSanitizer.bypassSecurityTrustResourceUrl(
        '../assets/img/icons/calendar.svg'
      )
    );
  }
  @ViewChild(MatMenuTrigger) trigger: any;
  @ViewChild('checkBox') checkBox: any;
  @ViewChild('paginator') paginator: MatPaginator | any;
  @ViewChild('paginatorpd') paginatorpd: MatPaginator | any;
  // @ViewChild('picker') datepicker: MatDatepicker<Date>;
  formData: any = {};
  public fileName: any;
  public csvRecords: any[] = [];
  public header = false;
  public allHeaders: any = [];
  public file: any;
  public fileTypes: any = 'Product_Catalog';
  public isUploadedData: boolean = false;
  public isSampleFileSelected: boolean = false;
  public processOptions: any = 1;
  public isDisabled: boolean = true;
  public isDisabledRefresh: boolean = true;
  public isConfigSelected: boolean = false;
  public isChecked: boolean = false;
  public isEditMode = false;
  public isDisabledUpload: boolean = false;
  convertedJson: any;
  uploadedFileJsonDataLength:any;
  public previousMappedFields: any = [];
  columnsToDisplay = [
    { header: 'File Name', field: 'filename' },
    { header: 'Time Stamp', field: 'timeStamp' },
    // { header: 'File Type', field: 'fileType' },

    { header: 'Uploaded By', field: 'uploadedBy' },
    { header: 'Status', field: 'status' },
    // { header: 'Type', field: 'uploadedType' },
    { header: 'Download', field: 'download' },
  ];
  columnsProps = this.columnsToDisplay.map((column) => column.field);
  columnsToDisplaypd = [
    { header: 'Time Stamp', field: 'timestamp' },
    { header: '#Records Pulled', field: 'records_pulled' },
    { header: '#Processed Records', field: 'processed_records' },
    // { header: 'Uploaded By', field: 'uploadedBy' },
    // { header: 'Status', field: 'status' },
    // { header: 'Type', field: 'uploadedType' },
    { header: 'Download', field: 'download' },
  ];
  columnsPropspd = this.columnsToDisplaypd.map((column) => column.field);
  // dataSourcehistory: any;
  // dataSourcepivot:any;
  dataSource: any;
  dataSource1: any;
  companyFirst: any;
  reqObject: any = {};
  associateObj: any = {};
  filePagination: any = {
    pageNo: 1,
    limit: 10,
  };
  userEmail:any;
  sort: any;
  isSortApplied: Subject<any> = new Subject();
  statusData: any;
  historyTableCount: any = 0;
  pivotTableCount: any = 0;
  historyType = '';
  tableName: any;
  status: any;
  SUPPLIER_TRANSACTION: any;
  searchPlaceholder = 'Sourcefilename';
  isFileSearchEnabled: boolean = false;
  isFilterSearchEnabled: boolean = false;
  isDatePivotSearchEnabled: boolean = false;
  fileSearchContent: any;
  statusSearchContent: any;
  datePivotSearchContent: any;
  userType: any;
  userTypeId: any;
  tenantType: any;
  selectedFile = 'Product_Catalog';
  radioButtons: any = [];
  metaData: any = [];
  metaTransactionData: any = [];
  showSkeletonLoader = false;
  filterForm: any;

  ngOnInit(): void {
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    console.log("last date file",this.lastUpdateDate)
    this.companyFirst = localStorage.getItem('companyFirstLogin');
    // this.userType = localStorage.getItem('userType');
    this.userType = this.authService.getUser()?.userType;
    this.userTypeId = localStorage.getItem('userTypeId');
    this.tenantType = localStorage.getItem('tenant');
    this.userEmail = localStorage.getItem('userId');
    this.httpService
    // .getAllFileTypes(this.userType)
    // .subscribe((response: any) => {
    //   if (response || response['data']) {
    //     // this.fileTypes = response['data'][0]['METADATA'];
    //     this.metaData = response['data'][1]['METADATA'];
    //     let radios = response['data'][1]['METADATA']['Transaction_Files'];
    //     this.metaTransactionData = radios;
    //     for (let i = 0; i < radios.length; i++) {
    //       this.radioButtons.push({
    //         displayText: radios[i]['displayText'],
    //         value: radios[i]['value'] == 1 ? 1 : 2,
    //       });
    //     }
    //   }
    // });

    // commenting because can't get column mapping without a filetype selected first
    // this.httpService.getTranscationColumnMapping('PC').subscribe((response:any)=>{
    //   if(response && response['data']){
    //     this.previousMappedFields = response['data']['columnMapping']
    //     if(this.previousMappedFields.length==0){
    //       this.isDisabled = false;
    //       this.isSampleFileSelected = true;
    //       this.checkBox['checked']=true
    //       this.isEditMode = true;
    //     }
    //     if( response['data']['processingType']=="rd"){
    //       this.processOptions=2;
    //     }
    //     if(response['data']['processingType']=="a"){
    //       this.processOptions=1;
    //     }
    //     if(response['data']['processingType']=="append"){
    //       this.processOptions=1;
    //     }
    //     if( response['data']['processingType']=="replace"){
    //       this.processOptions=2;
    //     }
    //   }
    // })
    // this.reqObject = {
    //   limit: this.filePagination.limit,
    //   pageNo: this.filePagination.pageNo
    // };
    this.associateObj = {
      limit: this.filePagination.limit,
      pageNo: this.filePagination.pageNo
    }
    this.getHistory();
    // this.selectedFileTypeOption();
    this.selectedFileTypeOption(this.fileTypes);
    this.selectedFile == 'Product_Catalog'
  }

  getHistory = () => {
    let body = {
      historyType: 'Product_Catalog',
      pageNo: this.filePagination.pageNo,
      limit: this.filePagination.limit,
      sorting: this.reqObject.sorting,
      file: this.fileSearchContent,
      status: this.statusSearchContent?.status ? this.statusSearchContent.status : '',
    };
    // if (this.filePagination.pageNo == 1) {
    //   this.historyTableCount = 0;
    //   this.dataSource && this.dataSource['data']

    //     ? (this.dataSource['data'] = new MatTableDataSource([]))
    //     : '';
    // }
    if (this.dataSource && this.dataSource['data'].length > 0 && this.filePagination['pageNo'] == 1) {

      this.dataSource = new MatTableDataSource([])
    }
    this.httpService.getUploadHistory(body).subscribe((response: any) => {
      this.historyTableCount = response['data']['count'];
      if (response && response['data']['history'].length > 0) {
        this.populateHistoryData(response['data']['history']);
        console.log("historydata1", response['data']['history']);

        if (response?.data?.status.length > 0) {
          var data = []
          for (let item of response.data.status) {
            data.push({ displayText: item, value: item });
          }
          this.statusData = data
        }

        console.log("removedupicate", this.statusData);


      } else {
        //this.historyTableCount =0;
        this.populateHistoryData([]);
      }
    });
  };

  populateHistoryData = (content: any) => {
    if (content.length == 0) {
      this.dataSource = new MatTableDataSource([]);
    }
    const tableData = [];
    for (let i = 0; i < content.length; i++) {
      let data = {
        timeStamp: '',
        fileType: 'Product_Catalog',
        filename: '',
        fullSourceFileUrl: '',
        uploadedBy: '',
        status: '',
        uploadedType: '',
      };
      let sourceFileTemp =
        content &&
        content[i].HISTORY_INFORMATION['source_file']?.split('/')?.reverse()[0];
      sourceFileTemp =
        sourceFileTemp.substring(0, sourceFileTemp.lastIndexOf('_')) +
        sourceFileTemp.substring(
          sourceFileTemp.lastIndexOf('.'),
          sourceFileTemp.length
        );
      data.filename = content && content[i]['INPUT_FILE_NAME']
        ? content[i]['INPUT_FILE_NAME']
        : '-';
      // data.filename = this.titlecasePipe.transform(sourceFileTemp); // required?
      data.fullSourceFileUrl =
        content && content[i]['HISTORY_INFORMATION']
          ? content[i]['HISTORY_INFORMATION']['source_file']
            ? content[i]['HISTORY_INFORMATION']['source_file']
            : '-'
          : '-';
      data.timeStamp =
        content && content[i]['UPDATED_DATE']
          ? this.reusableService.formatDateToMTZ(content[i]['UPDATED_DATE'])
          : '-';
      data.uploadedBy = content && content[i]['EMAIL']? content[i]['EMAIL']: '-';
        // content && content[i]['FIRST_NAME']
        //   ? this.titlecasePipe.transform(content[i]['FIRST_NAME'])
        //   : '-';
      data.status =
        content && content[i]['HISTORY_INFORMATION']
          ? content[i]['HISTORY_INFORMATION']['status']
            ? this.titlecasePipe.transform(
              content[i]['HISTORY_INFORMATION']['status']
            )
            : '-'
          : '-';
      data.fileType = 'Product_Catalog'
      // content && content[i]['HISTORY_INFORMATION']
      //   ? content[i]['HISTORY_INFORMATION']['file_type']
      // ? content[i]['HISTORY_INFORMATION']['file_type'].replace(/_/g, ' ')
      // ? this.titlecasePipe.transform(content[i]['HISTORY_INFORMATION']['file_type'].replace(/_/g, ' '))
      // ? this.getFileType(content[i]['HISTORY_INFORMATION']['file_type'])
      //   : '-'
      // : '-';



      // data.uploadedType =
      //   content && content[i]['HISTORY_INFORMATION']
      //     ? content[i]['HISTORY_INFORMATION']['origin']
      //       ? content[i]['HISTORY_INFORMATION']['origin']
      //       : '-'
      //     : '-';
      tableData.push(data);
    }
    this.dataSource = new MatTableDataSource(tableData);
    this.isSortApplied.next(tableData)
  };

  removeDuplicates(arr: any) {
    const uniqueIds: any = []
    const unique = arr.filter((item: any) => {
      const isDuplicate = uniqueIds.includes(item.HISTORY_INFORMATION.status);
      console.log("isDuplicate", isDuplicate);

      if (!isDuplicate) {
        uniqueIds.push({ displayText: item.HISTORY_INFORMATION.status, value: item.HISTORY_INFORMATION.status });
      }
    });
    return uniqueIds;
  };

  checkNameLength = (name: any) => {
    if (name && name.length > 1) {
      let values = Array.isArray(name)?name.join(', '):name
      return values.length>15?values.substring(0,18) + "...":values;
    } else {
      return name
    }
  }

  getHistorypivot = () => {
    let body = {
      historyType: 'SUPPLIER_TRANSACTION',
      pageNo: this.filePagination.pageNo,
      limit: this.filePagination.limit,
      searchDate: this.datePivotSearchContent,
      sorting: this.associateObj.sorting,
    };
    if (this.dataSource && this.dataSource['data'].length > 0 && this.filePagination['pageNo'] == 1) {

      this.dataSource = new MatTableDataSource([])
    }
    this.httpService.getUploadHistorypivot(body).subscribe((response: any) => {

      this.pivotTableCount = response['data']['count'];
      console.log("pivot count",this.pivotTableCount)
      if (response && response['data']['pivotData'].length > 0) {
        this.populateHistorypivotData(response['data']['pivotData']);
        console.log("pivot data", response);

      } else {
        //this.historyTableCount =0;
        this.populateHistorypivotData([]);
        console.log("else pivoy history");

      }
    });
  };

  populateHistorypivotData = (content: any) => {
    if (content.length == 0) {
      this.dataSource = new MatTableDataSource([]);
    }
    const tableData = [];
    for (let i = 0; i < content.length; i++) {
      let data = {
        timestamp: '',
        fileType: 'Product_Catalog',
        records_pulled: '',
        processed_records: '',
        fullSourceFileUrl: '',
        filename: '',
        // uploadedBy: '',
        // status: '',
        // uploadedType: '',
      };
      data.timestamp =
        content && content[i]['timestamp']
          ? this.reusableService.formatDateToMTZ(content[i]['timestamp'])
          : '-';

      data.records_pulled =
        content && content[i]['records_pulled']
          ? content[i]['records_pulled']
          : '-';
      data.processed_records =
        content && content[i]['processed_records']
          ? content[i]['processed_records']
          : '-';
      data.fileType = 'Product_Catalog'
      content && content[i]['HISTORY_INFORMATION']
        ? content[i]['HISTORY_INFORMATION']['file_type']
          // ? content[i]['HISTORY_INFORMATION']['file_type'].replace(/_/g, ' ')
          ? this.titlecasePipe.transform(content[i]['HISTORY_INFORMATION']['file_type'].replace(/_/g, ' '))
          // ? this.getFileType(content[i]['HISTORY_INFORMATION']['file_type'])
          : '-'
        : '-';
      let sourceFileTemp =
        content &&
        content[i].HISTORY_INFORMATION['source_file'].split('/').reverse()[0];
      sourceFileTemp =
        sourceFileTemp.substring(0, sourceFileTemp.lastIndexOf('_')) +
        sourceFileTemp.substring(
          sourceFileTemp.lastIndexOf('.'),
          sourceFileTemp.length
        );
      data.filename = this.titlecasePipe.transform(sourceFileTemp); // required?
      data.fullSourceFileUrl =
        content && content[i]['HISTORY_INFORMATION']
          ? content[i]['HISTORY_INFORMATION']['source_file']
            ? content[i]['HISTORY_INFORMATION']['source_file']
            : '-'
          : '-';
      // data.records_pulled =
      // content && content[i]['HISTORY_INFORMATION']
      // ? content[i]['HISTORY_INFORMATION']['records_pulled']
      //   ? this.titlecasePipe.transform(
      //     content[i]['HISTORY_INFORMATION']['records_pulled']
      //   )
      //   : '-'
      // : '-';
      // data.processed_records =
      //   content && content[i]['HISTORY_INFORMATION']
      //     ? content[i]['HISTORY_INFORMATION']['processed_records']
      //       ? this.titlecasePipe.transform(
      //         content[i]['HISTORY_INFORMATION']['processed_records']
      //       )
      //       : '-'
      //     : '-';
      // data.uploadedType =
      //   content && content[i]['HISTORY_INFORMATION']
      //     ? content[i]['HISTORY_INFORMATION']['origin']
      //       ? content[i]['HISTORY_INFORMATION']['origin']
      //       : '-'
      //     : '-';
      tableData.push(data);
    }
    this.dataSource = new MatTableDataSource(tableData);
    this.isSortApplied.next(tableData)
  };



  public changeListener = ($event: any) => {
    const targetElement: any = $event.srcElement.files[0];
    if (targetElement) {
      this.file = '';
      setTimeout(() => {
        this.file = targetElement;
        this.fileName = this.file.name;

        let jsonData = null;
        const reader = new FileReader();
        reader.onload = (event) => {
          const data = reader.result;
          let workBook = XLSX.read(data, { type: 'binary' });
          console.log("xlxs",workBook);
          let headers:any = [];
          jsonData = workBook.SheetNames.reduce((initial: any, name: any) => {
            const sheet = workBook.Sheets[name];
            initial[name] = XLSX.utils.sheet_to_json(sheet);
            for (const cell in sheet) {
              const cellDetails = XLSX.utils.decode_cell(cell);
              if (cellDetails.r === 0) {
                headers.push(sheet[cell].v);
              }
            }
            return initial;
          }, {})
          console.log("jsondata getting", jsonData.Sheet1.length);
          this.uploadedFileJsonDataLength = jsonData.Sheet1.length;
          if(!this.uploadedFileJsonDataLength){
            this.file = '';
            this.fileName = '';
            this.snackBar.open('Please upload file with data', 'Ok', {
              duration: 4000,
            });
          } else {
            const dataString = headers.toString(); // enable for new upload archecture
            // const dataString = JSON.stringify(arrayJsonData);
            this.convertedJson = dataString;
          }
          // console.log(dataString);          
          // this.checkFile(this.file, dataString);
        }
        reader.readAsBinaryString(this.file);
      }, 500);
    }
  };

  public readCSV = (file: any) => {
    this.allHeaders = [];
    this.ngxCsvParser
      .parse(file, { header: this.header, delimiter: ',' })
      .pipe()
      .subscribe(
        (result: any) => {
          let headerValues = result[0];
          if (headerValues.length > 0) {
            for (let i = 0; i < headerValues.length; i++) {
              let eachValue = {
                selected: true,
                value: headerValues[i],
              };
              this.allHeaders.push(eachValue);
            }
          } else {
            this.snackBar.open('Please upload file with data', 'Ok', {
              duration: 2000,
            });
            console.log('Please upload file with data');
          }
        },
        (error: NgxCSVParserError) => {
          console.log('Error', error);
        }
      );
  };

  public readXLXS = (file: any) => {
    this.allHeaders = [];
    readXlsxFile(file).then((rows) => {
      let headerValues = rows[0];
      if (headerValues) {
        for (let i = 0; i < headerValues.length; i++) {
          let eachValue = {
            selected: true,
            value: headerValues[i],
          };
          this.allHeaders.push(eachValue);
        }
      }
    });
  };

  public readXLS = (file: any) => {
    this.allHeaders = [];
    let readFile = new FileReader();
    readFile.onload = (e) => {
      let storeData: any = readFile.result;
      var data = new Uint8Array(storeData);
      var arr = new Array();
      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);
      var bstr = arr.join('');
      var workbook = XLSX.read(bstr, { type: 'binary' });
      var first_sheet_name = workbook.SheetNames[0];
      let worksheet = workbook.Sheets[first_sheet_name];
      let jsonData = XLSX.utils.sheet_to_json(worksheet, { raw: false, blankrows: true, header: "A" });
      if (jsonData && jsonData.length > 0) {
        let objectData: any = jsonData[0];
        let headerValues = Object.values(objectData);
        if (headerValues.length > 0) {
          for (let i = 0; i < headerValues.length; i++) {
            let eachValue = {
              selected: true,
              value: headerValues[i],
            };
            this.allHeaders.push(eachValue);
          }
        } else {
          this.snackBar.open('Please upload file with headers', 'Ok', {
            duration: 2000,
          });
        }
      } else {
        this.snackBar.open('Please upload file with data', 'Ok', {
          duration: 2000,
        });
      }
    };
    readFile.readAsArrayBuffer(this.file);
  };

  refreshMapCSV() {
    if (isCSVFile(this.file)) {
      if (isValidSize(this.file)) {
        if (this.checkBox['checked'] == true) {
        if (this.isEditMode) {
          console.log("mapping data 1");

          setTimeout(() => {
            this.isUploadedData = true;
            this.readXLS(this.file);
          }, 500);
          this.isDisabled = false;
          console.log("mapping data 2");
        }
      }
    }
  }
}
  // uploadCSV() {
  //   if (isCSVFile(this.file)) {
  //     if (isValidSize(this.file)) {
  //       if (this.isEditMode) {
  //         setTimeout(() => {
  //           this.isUploadedData = true;
  //           this.readXLS(this.file);
  //         }, 500);
  //         this.isDisabled = true;
  //         this.snackBar.open('File is being uploaded', 'Ok', {
  //           duration: 2000,
  //         });
  //       }
  //       else {

  //         // if (!this.checkConstraints()) {
  //         //   this.snackBar.open('Please select effective date', 'Ok', {
  //         //     duration: 2000,
  //         //   });
  //         //   return;
  //         // };

  //         const formData = new FormData();
  //         formData.append('file', this.file);
  //         // const processingType = JSON.stringify(this.getProcessTypeData()); // 'rd' or 'a' applicable
  //         // formData.append('processingType', processingType);
  //         formData.append('fileType', this.selectedFile);

  //         // const date: any = this.fileFormGroup.get('effectiveDate')!.value;
  //         // formData.append('effectiveDate', this.formatDate(date));
  //         formData.append('companyFirstLogin', this.companyFirst);
  //         formData.append('origin', 'UI');
  //         formData.append('jsonData', this.convertedJson);
  //         this.snackBar.open('File is being uploaded', 'Ok', {
  //           duration: 2000,
  //         });
  //         // this.fileFormGroup.get('effectiveDate')?.setValue(null);
  //         // this.fileFormGroup.get('effectiveDate')?.markAsUntouched();
  //         this.httpService.saveMappingData(formData).subscribe(
  //           (response) => {
  //             // this.fileFormGroup.get('effectiveDate')?.setValue(null);
  //             // this.fileFormGroup.get('effectiveDate')?.markAsUntouched();
  //             this.file = '';
  //             this.fileName = '';
  //             this.snackBar.open('File Upload successful', 'Ok', {
  //               duration: 2000,
  //             });
  //             this.getHistory();
  //             this.isUploadedData = false;
  //             // this.effectiveDate = undefined;
  //             //   this.showDate = false;
  //             this.fileFormGroup.reset();
  //           },
  //           (error) => {
  //             console.log('error->', error);
  //           }
  //         ); null
  //           ; this.file = '';
  //         this.fileName = '';
  //       }
  //     } else {
  //       this.snackBar.open('File size should not exceed 2 MB', 'Ok', {
  //         duration: 2000,
  //       });
  //       console.log('File size should not exceed 2 MB');
  //     }
  //   } else {
  //     this.snackBar.open('Please upload CSV or XLXS or XLS files', 'Ok', {
  //       duration: 2000,
  //     });
  //     console.log('Please upload CSV file');
  //   }
  // }
  uploadCSV() {
    if(this.uploadedFileJsonDataLength){
      if (isCSVFile(this.file)) {
    
        if (isValidSize(this.file)) {
          if (this.checkBox['checked'] == true) {
            this.isEditMode = true
            console.log("mapping data 1");
  
            setTimeout(() => {
              this.isUploadedData = true;
              this.readXLS(this.file);
            }, 500);
            this.isDisabled = true;
            // this.isDisabled = false;
            console.log("mapping data 2");
            this.snackBar.open('File upload done', 'Ok', {
                        duration: 2000,
                   
                      });
                       this.isDisabledRefresh = false
          } else {
            
            // if (!this.checkConstraints()) {
            //   this.snackBar.open('Please select effective date', 'Ok', {
            //     duration: 2000,
            //   });
            //   return;
            // };
            console.log("mapping data 3");
            const formData = new FormData();
            formData.append('file', this.file);
            // const processingType = JSON.stringify(this.getProcessTypeData()); // 'rd' or 'a' applicable
            // formData.append('processingType', processingType);
            formData.append('fileType', this.selectedFile);
            formData.append('email', this.userEmail);
            formData.append('userName', this.tenantType);
            // const date: any = this.fileFormGroup.get('effectiveDate')!.value;
            // formData.append('effectiveDate', this.formatDate(date));
            formData.append('companyFirstLogin', this.companyFirst);
            formData.append('origin', 'UI');
            formData.append('jsonData', this.convertedJson);
            this.snackBar.open('File is being uploaded', 'Ok', {
              duration: 2000,
            });
            // this.fileFormGroup.get('effectiveDate')?.setValue(null);
            // this.fileFormGroup.get('effectiveDate')?.markAsUntouched();
            this.httpService.saveMappingData(formData).subscribe(
              (response) => {
                // this.fileFormGroup.get('effectiveDate')?.setValue(null);
                // this.fileFormGroup.get('effectiveDate')?.markAsUntouched();
                this.file = '';
                this.fileName = '';
                this.snackBar.open('File Upload successful', 'Ok', {
                  duration: 2000,
                });
                this.getHistory();
                this.isUploadedData = false;
                // this.effectiveDate = undefined;
                //   this.showDate = false;
                this.fileFormGroup.reset();
              },
              (error) => {
                this.snackBar.open(error['error']['message']||'The upload has failed. Please try later', 'Ok', {
                  duration: 4000,
                });
                console.log('error->', error);
              }
            ); null
              ; this.file = '';
            this.fileName = '';
          }
        } else {
          this.snackBar.open('File size should not exceed 4 MB', 'Ok', {
            duration: 2000,
          });
          console.log('File size should not exceed 4 MB');
        }
      } else {
        this.snackBar.open('Please upload CSV or XLXS or XLS files', 'Ok', {
          duration: 2000,
        });
      }
    }
  }
  checkConstraints() {
    // const date: any = this.fileFormGroup.get('effectiveDate')!.value;
    // console.log('checkConstraints: ', date);
    // if (this.selectedFile === 'Product_Catalog' && !date) {
    if (this.selectedFile === 'Product_Catalog') {
      //   if(!date) {
      console.log('mat error for effective date')
      return false;
      //   }
    }
    return true;
  }

  mappedData = (data: any) => {
    const formData = new FormData();
    if (this.isEditMode) {
      formData.append('email', this.userEmail);
      formData.append('userName', this.tenantType);
      formData.append('file', this.file);
      const columnMappingData = JSON.stringify(data);
      formData.append('data', columnMappingData);
      formData.append('fileType', this.selectedFile);
      // const processingType = JSON.stringify(this.getProcessTypeData()); // 'rd' or 'a' applicable
      // formData.append('processingType', processingType);
      formData.append('companyFirstLogin', this.companyFirst);
      formData.append('origin', 'UI');
    } else {
      formData.delete('data');
    }
    if (this.isEditMode && data.length > 0) {
      // this.fileFormGroup.get('effectiveDate')?.setValue(null);
      // this.fileFormGroup.get('effectiveDate')?.markAsUntouched();
      this.httpService.saveMappingData(formData).subscribe(
        (response) => {
          this.file = '';
          this.fileName = '';
          this.allHeaders = [];
          this.checkBox['checked'] = false;
          this.isSampleFileSelected = false;
          this.isDisabled = true;
          this.isEditMode = false;
          this.isDisabledUpload = false
          this.snackBar.open('File mapping is successful', 'Ok', {
            duration: 2000,
          });

          // find mappingType and fetch column mapping data
          const mappingType = this.reusableService.findMappingType(
            this.selectedFile,
            this.userType
          );
          this.callColumnMappingConfigData(mappingType);

          this.getHistory();
          // this.getHistorypivot();
        },
        (error) => {
          console.log('error->', error);
        }
      );
    }
  };
  // getProcessTypeData = () => {
  //   if (this.selectedFile == 'Product_Catalog') {
  //     if (this.processOptions == 1) {
  //       return { processingType: 'append' };
  //     } else {
  //       return { processingType: 'replace' };
  //     }
  //   } else {
  //     if (this.processOptions == 1) {
  //       return { processingType: 'a' };
  //     } else {
  //       return { processingType: 'rd' };
  //     }
  //   }
  // };

  toggle(event: any) {
    this.isSampleFileSelected = event;
    if (this.isSampleFileSelected && this.isUploadedData) {
      setTimeout(() => {
        //this.readCSV(this.file)
        this.readXLS(this.file);
      }, 500);
    }
  }
  openMyMenu() {
    this.trigger.toggleMenu();
  }
  closeMyMenu() {
    this.trigger.closeMenu();
  }
  toggleConfig(event: any) {
    this.isConfigSelected = event;
    this.isSampleFileSelected = true;
    this.isDisabled = true;
  }

  checkboxChange(event: any) {
    console.log(event['checked'], "event checking");
    this.isEditMode = event['checked'];
    if (event['checked']) {
      this.isSampleFileSelected = event['checked'];
      this.isDisabledUpload = true;
      // this.isDisabledRefresh = true
      this.isEditMode = event['checked'];
      if (this.isUploadedData) {
        setTimeout(() => {
          this.readCSV(this.file)
          this.readXLS(this.file);
        }, 500);


      }


    }
    else {
      this.isSampleFileSelected = event['checked'];
      this.isDisabledUpload = true;
      this.isDisabled = true;
      this.isEditMode = true;
      this.isDisabledRefresh = true
      // this.isDisabled = event['checked'];
      if (this.previousMappedFields.length == 0) {
        //this.isDisabled = false;
        this.isSampleFileSelected = true;
        this.checkBox['checked'] = false;



        // this.isEditMode = false;
      } else {
        //this.isEditMode = false;
      }
    }

  }

  // throttling implemented here 
  timer: any;
  download(value: any) {
    console.log('download function called');
    if (this.timer) {
      return;
    }

    this.timer = setTimeout(() => {
      const name = value.fullSourceFileUrl;
      const fileName = value.filename;
      console.log("filename", name);

      this.httpService.downloadFile({ name })
        .subscribe(
          (response: any) => {
            console.log("response file", response);
            const dataType = response.type;
            const binaryData = [];
            binaryData.push(response);
            const downloadLink = document.createElement('a');
            downloadLink.href = window.URL.createObjectURL(
              new Blob(binaryData, { type: dataType })
            );
            if (name) {
              downloadLink.setAttribute('download', fileName);
            }
            document.body.appendChild(downloadLink);
            downloadLink.click();
          },
          (error) => {
            const errorMessage =
              _get(error, 'error.message') ||
              _get(error, 'message') ||
              'Download failed';
            this.snackBar.open(errorMessage, 'Ok', {
              duration: 2000,
            });
          }
        );
      this.timer = undefined;
    }, CONSTANTS.downloadThrottleDelay);
  }

  downloadpivot(value: any) {
    if (this.timer) {
      return;
    }

    this.timer = setTimeout(() => {
      const name = value.fullSourceFileUrl;
      const fileName = value.filename;
      console.log("filename pivot", name);
      console.log("filename", fileName);

      this.httpService.downloadPivotFile({ name })
        .subscribe(
          (response: any) => {
            console.log("response file", response);
            const dataType = response.type;
            const binaryData = [];
            binaryData.push(response);
            const downloadLink = document.createElement('a');
            downloadLink.href = window.URL.createObjectURL(
              new Blob(binaryData, { type: dataType })
            );
            if (name) {
              downloadLink.setAttribute('download', fileName);
            }
            document.body.appendChild(downloadLink);
            downloadLink.click();
          },
          (error) => {
            const errorMessage =
              _get(error, 'error.message') ||
              _get(error, 'message') ||
              'Download failed';
            this.snackBar.open(errorMessage, 'Ok', {
              duration: 2000,
            });
          }
        );
      this.timer = undefined;
    }, CONSTANTS.downloadThrottleDelay);
  }

  callColumnMappingConfigData = (mappingType: any) => {
    this.showSkeletonLoader = true;
    this.httpService
      .getTranscationColumnMapping(mappingType)
      .subscribe((response: any) => {
        if (response && response['data']) {
          this.previousMappedFields = response['data']['columnMapping'];
          if(this.previousMappedFields.length == 0){
            this.isChecked = true;
          }
          if (this.previousMappedFields.length == 0) {
            this.isDisabled = false;
            this.isSampleFileSelected = true;
            this.checkBox['checked'] = true;
            this.isEditMode = false;
          } else {
            this.checkBox['checked'] = false;
            this.isEditMode = false;
            this.showSkeletonLoader = false;
            this.isDisabled = true;
          }
          // if (response['data']['processingType'] == 'rd') {
          //   this.processOptions = 2;
          // }
          // if (response['data']['processingType'] == 'a') {
          //   this.processOptions = 1;
          // }
          // if (response['data']['processingType'] == 'append') {
          //   this.processOptions = 1;
          // }
          // if (response['data']['processingType'] == 'replace') {
          //   this.processOptions = 2;
          // }
        }

      });
  };
  getHistoryNextPage = (data: any) => {
    const pageNo = parseInt(data['pageIndex']) + 1;
    this.filePagination.pageNo = pageNo;
    this.filePagination.limit = parseInt(data['pageSize']);
    if (this.isFileSearchEnabled) {
      this.fillSearchedHistoryTable();

      // this.fillSearchedPivotHistoryTable();
    } else if (this.isFilterSearchEnabled) {
      this.fillStatusdHistoryTable();
    }
    else {
      this.getHistory();
      // this.getHistorypivot();
    }
  };
  getPivotHistoryNextPage = (data: any) => {
    const pageNo = parseInt(data['pageIndex']) + 1;
    this.filePagination.pageNo = pageNo;
    this.filePagination.limit = parseInt(data['pageSize']);
    if (this.isDatePivotSearchEnabled) {
      // this.fillSearchedHistoryTable();
      this.fillSearchedPivotHistoryTable();
    } else {
      // this.getHistory();
      this.getHistorypivot();
    }
  };
  filterHistory = (history: any) => {
    this.resetHistoryPagination();
    if (history) {
      this.isFileSearchEnabled = true;
      // this.isFilterSearchEnabled = true;
      this.fileSearchContent = history;
      this.fillSearchedHistoryTable();
      // this.fillSearchedPivotHistoryTable();
    } else {
      this.isFileSearchEnabled = false;
      // this.isFilterSearchEnabled = false;
      this.fileSearchContent = '';
      this.getHistory();
      // this.getHistorypivot();
    }
  };
  filterpivotHistory = (pivotData: any) => {
    this.resetHistoryPagination();
    if (history) {
      this.isDatePivotSearchEnabled = true;
      this.datePivotSearchContent = pivotData;
      this.fillSearchedPivotHistoryTable();
      console.log("search pivot data",this.fillSearchedPivotHistoryTable)
    } else {
      this.isDatePivotSearchEnabled = false;
      this.datePivotSearchContent = '';
      // this.getHistory();
      this.getHistorypivot();
    }
  };
  resetHistoryPagination = () => {
    this.filePagination.pageNo = 1;
    this.filePagination.limit = 10;
  };

  fillSearchedHistoryTable = () => {
    const body = {
      historyType: 'Product_Catalog',
      pageNo: this.filePagination.pageNo,
      limit: this.filePagination.limit,
      file: this.fileSearchContent,
      status: this.statusSearchContent?.status ? this.statusSearchContent.status : '',
    };
    // if (this.filePagination.pageNo == 1) {
    //   //this.historyTableCount = 0;
    //   this.dataSource && this.dataSource['data']
    //     ? (this.dataSource['data'] = new MatTableDataSource([]))
    //     : '';
    // }
    if (this.dataSource && this.dataSource['data'].length > 0 && this.filePagination['pageNo'] == 1) {

      this.dataSource = new MatTableDataSource([])
    }
    this.httpService.getSearchUploadHistory(body).subscribe(
      (response: any) => {
        if (response && response['data']['count'] > 0) {
          this.historyTableCount = response['data']['count'];
          this.populateHistoryData(response['data']['history']);
        } else {
          this.populateHistoryData([]);
          //this.historyTableCount =0
        }
      },
      (err) => {
        console.log(err);
        this.snackBar.open('error occured', 'Ok', {
          duration: 2000,
        });
      }
    );
  };

  fillSearchedPivotHistoryTable = () => {
    console.log("pivot date");

    const body = {
      historyType: 'SUPPLIER_TRANSACTION',
      pageNo: this.filePagination.pageNo,
      limit: this.filePagination.limit,
      searchDate: this.datePivotSearchContent,
      // sorting: this.associateObj.sorting,
    };
    // if (this.filePagination.pageNo == 1) {
    //   //this.historyTableCount = 0;
    //   this.dataSource && this.dataSource['data']
    //     ? (this.dataSource['data'] = new MatTableDataSource([]))
    //     : '';
    // }
    if (this.dataSource && this.dataSource['data'].length > 0 && this.filePagination['pageNo'] == 1) {

      this.dataSource = new MatTableDataSource([])
    }
    this.httpService.getSearchUploadpivotHistory(body).subscribe(


      (response: any) => {
        if (response && response['data']['count'] > 0) {
          this.pivotTableCount = response['data']['count'];
          this.populateHistorypivotData(response['data']['pivotData']);
        } else {
          this.populateHistorypivotData([]);
          //this.historyTableCount =0
        }
      },
      (err) => {
        console.log(err);
        this.snackBar.open('error occured', 'Ok', {
          duration: 2000,
        });
      }
    );
  };

  navigateToHome = () => {
    this.router.navigate([`/${this.tenantType}/home`]);
  };

  selectedFileTypeOption = (fileType = 'Product_Catalog') => {
    this.isChecked = false;
    console.log("in selectedFileTypeOption");
    // this.fileFormGroup.get('effectiveDate')?.setValue(null);
    // this.fileFormGroup.get('effectiveDate')?.markAsUntouched();
    if (fileType) {
      this.isSampleFileSelected = false;
      if (fileType == 'Product_Catalog') {
        // this.radioButtons = [];
        // let radios = this.metaData[fileType];
        // for (let i = 0; i < radios.length; i++) {
        //   this.radioButtons.push({
        //     displayText: radios[i]['displayText'],
        //     value: radios[i]['value'] == 1 ? 1 : 2,
        //   });
        // }


      } else {
        this.radioButtons = [];
        this.metaTransactionData;
        let radios = this.metaTransactionData;
        for (let i = 0; i < radios.length; i++) {
          this.radioButtons.push({
            displayText: radios[i]['displayText'],
            value: radios[i]['value'] == 1 ? 1 : 2,
          });
        }
      }
      this.getMappedDataBasedOnSelectedFileType(fileType);
      const mappingType = this.reusableService.findMappingType(
        fileType,
        this.userType
      );
      this.callColumnMappingConfigData(mappingType);
    }
  };

  getMappedDataBasedOnSelectedFileType = (fileType: any) => {
    // let mappingFileType
    //   if(this.userType == "DISTRIBUTOR"){
    //  mappingFileType = MappingFileType.MemberTransaction;
    //   }
    //   if(this.userType == "SUPPLIER"){
    //     mappingFileType = MappingFileType.SupplierTransaction;
    //     // SupplierTransaction = 'ST',
    //     // SupplierSumamary = 'SS',
    //     // ProductCatalog = 'PC'

    //  }

    const mappingFileType = this.reusableService.findMappingType(
      fileType,
      this.userType
    );
    this.showSkeletonLoader = true;
    this.httpService.getMasterData(mappingFileType).subscribe((values: any) => {
      let data = values['data'];
      let allFields = [
        {
          name: '',
          label: '',
          value: '',
          type: 'select',
          isRequired: false,
          validators: {
            required: false,
          },
        },
      ];
      for (let i = 0; i < data.length; i++) {
        let controls = {
          name: data[i]['COLUMN_MASTER_ID'],
          label: data[i]['COLUMN_MASTER_NAME'],
          value: '',
          type: 'select',
          isRequired: data[i]['COLUMN_TYPE'] == 'MANDATORY' ? true : false,
          validators: {
            required: data[i]['COLUMN_TYPE'] == 'MANDATORY' ? true : false,
          },
        };
        allFields.push(controls);
      }
      this.formData = {
        controls: allFields,
      };
      this.showSkeletonLoader = false;
    });
  };

  selectedPageLimit = (limitValue: any) => {
    this.filePagination.pageNo = 1;
    this.filePagination.limit = parseInt(limitValue);
    if (this.isFileSearchEnabled) {
      this.fillSearchedHistoryTable();
    } if (this.isFilterSearchEnabled) {
      this.fillStatusdHistoryTable();
    }
    else {
      this.getHistory();
    }
  };

  selectedPageLimitPivot = (limitValue: any) => {
    this.filePagination.pageNo = 1;
    this.filePagination.limit = parseInt(limitValue);
    if (this.isDatePivotSearchEnabled) {
      this.fillSearchedPivotHistoryTable();
    } 
    else {
      this.getHistorypivot();
    }
  };

  goToPageNumber = (event: any) => {
    let value = Math.ceil(this.historyTableCount/this.filePagination['limit'])
    if (event <= value) {
      this.filePagination['pageNo'] = parseInt(event);
      if (this.isFileSearchEnabled) {
        this.fillSearchedHistoryTable();
      } if (this.isFilterSearchEnabled) {
        this.fillStatusdHistoryTable();
      } else {
        this.getHistory();
      }
    } else {
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: { "type": "PageNo entered out of range." },
        disableClose: true,
      });
      setTimeout(() => {
        this.paginator.pageIndex = 0;
        dialogRef.close()
      }, 2000)
   
      dialogRef.afterClosed().subscribe((result: any) => {
        if (this.dataSource && this.dataSource['data'] && this.dataSource['data'].length > 0) {
          this.dataSource['data'] = []
         
        }
        this.filePagination['pageNo'] = 1;
        if (this.isFileSearchEnabled) {
          this.fillSearchedHistoryTable();
        } 
        if (this.isFilterSearchEnabled) {
          this.fillStatusdHistoryTable();
        } 
        else {
          this.getHistory();
        }
      })
    }
    // if (event) {
    //   this.filePagination['pageNo'] = parseInt(event);
    //   if (this.isFileSearchEnabled) {
    //     this.fillSearchedHistoryTable();
    //   } if (this.isFilterSearchEnabled) {
    //     this.fillStatusdHistoryTable();
    //   } else {
    //     this.getHistory();
    //   }
    // }
  };

  goToPageNumberPivot = (event: any) => {
    let value = Math.ceil(this.pivotTableCount / this.filePagination['limit'])
    if (event <= value) {
      this.filePagination['pageNo'] = parseInt(event);
      if (this.isDatePivotSearchEnabled) {
        this.fillSearchedPivotHistoryTable();
      } else {
        this.getHistorypivot();
      }
    } else {
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: { "type": "PageNo entered out of range." },
        disableClose: true,
      });
      setTimeout(() => {
        this.paginatorpd.pageIndex = 0;
        dialogRef.close()
      }, 2000)

      dialogRef.afterClosed().subscribe((result: any) => {
        if (this.dataSource && this.dataSource['data'] && this.dataSource['data'].length > 0) {
          this.dataSource['data'] = []
        }
        this.filePagination['pageNo'] = 1;
        if (this.isDatePivotSearchEnabled) {
          this.fillSearchedPivotHistoryTable();
        } else {
          this.getHistorypivot();
        }
      })
    }
    // if (event) {
    //   this.filePagination['pageNo'] = parseInt(event);
    //   if (this.isDatePivotSearchEnabled) {
    //     this.fillSearchedPivotHistoryTable();
    //   } else {
    //     this.getHistorypivot();
    //   }
    // }
  };

  startChange = (event: any) => {
    if (event.value) {
      let startUTC = moment.utc(event.value).local().format('YYYY-MM-DD')
      console.log("startUTC: ", startUTC);
    }
  }
  endChange = (event: any) => {
    if (event.value) {
      let endUTC = moment.utc(event.value).local().format('YYYY-MM-DD')
      console.log("endChange: ", endUTC);
    }
  }

  effectiveDateSelected(event: any) {
    console.log('effective date: ', event.value);
    // this.effectiveDate = event.value;
    // this.showDate = !!this.fileFormGroup.get('effectiveDate')!.value;
  }

  checkUploadConditions() {
    return !(this.selectedFile || this.fileName) || !(this.selectedFile !== 'Product_Catalog');
  }

  showDate() {
    return !!this.fileFormGroup.get('effectiveDate')!.value;
  };

  getFileType(value: keyof typeof FILE_TYPE) {
    // return FILE_TYPE[value] ?FILE_TYPE[value] : '-';
    return FILE_TYPE[value];
  }

  formatDate = (date: any) => {
    return moment.utc(date).local().format('YYYY-MM-DD')
  }
  applyFilter = (values: any) => {
    console.log("in filter ts file");

    if (values['status'] != null) {
      this.associateObj['status'] = values['status']
    } else if (values['status'] == null) {
      if (values['status'] == null && this.associateObj.hasOwnProperty('status')) {
        delete this.associateObj.status
      }
    }
    this.selectedPageLimit(this.filePagination.limit)
  }

  fillStatusdHistoryTable = () => {
    const body = {
      historyType: 'Product_Catalog',
      pageNo: this.filePagination.pageNo,
      limit: this.filePagination.limit,
      status: this.statusSearchContent.status ? this.statusSearchContent.status : '',
      file: this.fileSearchContent,
    };
    // if (this.filePagination.pageNo == 1) {
    //   //this.historyTableCount = 0;
    //   this.dataSource && this.dataSource['data']
    //     ? (this.dataSource['data'] = new MatTableDataSource([]))
    //     : '';
    // }
    if (this.dataSource && this.dataSource['data'].length > 0 && this.filePagination['pageNo'] == 1) {

      this.dataSource = new MatTableDataSource([])
    }
    this.httpService.getfilterUploadHistory(body).subscribe(
      (response: any) => {
        if (response && response['data']['count'] > 0) {
          this.historyTableCount = response['data']['count'];
          this.populateHistoryData(response['data']['history']);
        } else {
          this.populateHistoryData([]);
          //this.historyTableCount =0
        }
      },
      (err) => {
        console.log(err);
        this.snackBar.open('error occured', 'Ok', {
          duration: 2000,
        });
      }
    );
  };

  filterHistoryStatusSearch = (history: any) => {
    this.resetHistoryPagination();
    if (history) {
      this.isFilterSearchEnabled = true;
      this.statusSearchContent = history;
      this.fillStatusdHistoryTable();
      // this.fillSearchedPivotHistoryTable();
    } else {
      this.isFilterSearchEnabled = false;
      this.statusSearchContent = '';
      this.getHistory();
      // this.getHistorypivot();
    }
  };
  // filterStatus = (status: any) => {
  //   console.log("in filter status");

  //   const body = {
  //     historyType: 'Product_Catalog',
  //     pageNo: this.filePagination.pageNo,
  //     limit: this.filePagination.limit,
  //     file: this.statusSearchContent.status,
  //   };
  //   // if (this.filePagination.pageNo == 1) {
  //   //   //this.historyTableCount = 0;
  //   //   this.dataSource && this.dataSource['data']
  //   //     ? (this.dataSource['data'] = new MatTableDataSource([]))
  //   //     : '';
  //   // }
  //   if (this.dataSource && this.dataSource['data'].length > 0 && this.filePagination['pageNo'] == 1) {

  //     this.dataSource = new MatTableDataSource([])
  //   }
  //   this.httpService.filterStatus(body).subscribe(


  //     (response: any) => {
  //       if (response && response['data']['count'] > 0) {
  //         this.historyTableCount = response['data']['count'];
  //         this.populateHistoryData(response['data']['history']);
  //       } else {
  //         // this.populateHistoryData([]);
  //         //this.historyTableCount =0
  //       }
  //     },
  //     (err) => {
  //       console.log(err);
  //       this.snackBar.open('error occured', 'Ok', {
  //         duration: 2000,
  //       });
  //     }
  //   );
  // };
  sortByColumnName = (data: any) => {
    console.log("DataSource", this.dataSource);
    this.sort = this.dataSource.sort;
    if (data['direction']) {
      if (this.reqObject['sorting'] && this.reqObject['sorting'].length > 0) {
        const isFound = this.reqObject['sorting'].find((row: any) => row['orderBy'] === data['active']);
        if (isFound) {
          this.reqObject['sorting'] = this.reqObject['sorting'].map((row: any) => {
            if (row['orderBy'] === data['active']) {
              row['orderType'] = data['direction']
            }
            return row;
          })
        }
        else {
          this.reqObject['sorting'] = [{ orderBy: data['active'], orderType: data['direction'] }]
        }
      }
      else {
        this.reqObject['sorting'] = [{ orderBy: data['active'], orderType: data['direction'] }]
      }
    } else {
      if (this.reqObject.hasOwnProperty('sorting')) {
        delete this.reqObject['sorting']
      }
    }

    this.getHistory();
  }
  sortByColumnNamePivot = (data: any) => {
    console.log("DataSource", this.dataSource);

    this.sort = this.dataSource.sort;
    // this.dataSource = new MatTableDataSource([])
    if (data['direction']) {
      if (this.associateObj['sorting'] && this.associateObj['sorting'].length > 0) {
        const isFound = this.associateObj['sorting'].find((row: any) => row['orderBy'] === data['active']);
        if (isFound) {
          this.associateObj['sorting'] = this.associateObj['sorting'].map((row: any) => {
            if (row['orderBy'] === data['active']) {
              row['orderType'] = data['direction']
            }
            return row;
          })
        }

        else {
          this.associateObj['sorting'] = [{ orderBy: data['active'], orderType: data['direction'] }]
        }
      }
      else {
        this.associateObj['sorting'] = [{ orderBy: data['active'], orderType: data['direction'] }]
      }
    } else {
      if (this.associateObj.hasOwnProperty('sorting')) {
        delete this.associateObj['sorting']
      }
    }
    this.getHistorypivot();

  }
  // filterColumnwiseData = (values:any)=>{
  //   let isValueExists=0
  //   if(values && values['status']){
  //     this.associateObj['status']= values['status']
  //     isValueExists=1
  //   } else if((values['status']=='' || values['status']=="" || values['status']==null)  && this.associateObj.hasOwnProperty('status')){
  //     delete this.associateObj.status
  //     isValueExists=1
  //   }




  //   if(isValueExists==1){
  //     this.selectedViewPageLimit(this.filPagination.limit)

  //   }
  // }
}

