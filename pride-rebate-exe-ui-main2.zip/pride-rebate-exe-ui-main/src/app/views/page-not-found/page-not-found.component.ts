import { DOCUMENT } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationsComponent } from 'src/app/common/notifications/notifications.component';

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.scss']
})
export class PageNotFoundComponent implements OnInit {
  tenantType:any
  constructor(public router: Router,public activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    @Inject(DOCUMENT) private document: Document) { }

  ngOnInit(): void {
    console.log('>>>',this.activatedRoute.snapshot['url'])
    let isNotValidPath = this.activatedRoute.snapshot['url']
    if(isNotValidPath.length<2){
      this.tenantType =this.activatedRoute.snapshot.paramMap.get('type');
      //  console.log('tenant-->',this.tenantType)
        if(!this.tenantType) {
          this.openDialog();
          let actualTenant = localStorage.getItem("tenant")
          sessionStorage.clear();
          localStorage.clear()
          // alert('cleared session')
          console.log('29 cleared')
        }else{
          let tenant = this.activatedRoute.snapshot['url'][0]['path']
          this.router.navigateByUrl(`${tenant}/dashboard/summary`);
        }
    }

  }
  openDialog = () =>{
    const dialogref= this.dialog.open(NotificationsComponent, {
       //width: '400px',
       //width: '30%'
       width: '366px',
       height: '389px',
       disableClose: true,
       panelClass: 'dialog-container-custom'
     })
     dialogref.afterClosed().subscribe((response:any)=>{
       this.document.location.href = "https://www.rebate.ai/"
     })
   }
}
