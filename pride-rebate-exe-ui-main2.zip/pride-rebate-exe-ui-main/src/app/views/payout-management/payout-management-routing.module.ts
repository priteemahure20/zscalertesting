import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PayoutManagementComponent } from './payout-management.component';
import { CreatePayoutComponent } from './create-payout/create-payout.component';
import { PayoutDetailsComponent } from './payout-details/payout-details.component';
import { AssessentDetailsComponent } from './assessent-details/assessent-details.component';

const routes: Routes = [
  {path:'', component:PayoutManagementComponent},
  {path:'create-payout', component:CreatePayoutComponent},
  {path:'payout-details/:payoutId', component:PayoutDetailsComponent},
  {path:'assessment-details', component:AssessentDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PayoutManagementRoutingModule { }
