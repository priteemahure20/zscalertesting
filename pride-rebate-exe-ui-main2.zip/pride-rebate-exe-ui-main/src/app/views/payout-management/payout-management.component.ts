import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { map as _map } from "lodash";
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import { UserType } from 'src/app/helpers/constants';
import { AuthService } from 'src/app/services/auth.service';
import { DataService } from 'src/app/services/data.service';
import { HttpService } from 'src/app/services/http.service';
import { ReusableService } from 'src/app/services/reusable.service';
import { ExportModalComponent } from '../report-generator/export-modal/export-modal.component';
import { SucessMessageModalComponent } from 'src/app/common/sucess-message-modal/sucess-message-modal.component';
import * as moment from 'moment';
@Component({
  selector: 'app-payout-management',
  templateUrl: './payout-management.component.html',
  styleUrls: ['./payout-management.component.scss']
})
export class PayoutManagementComponent implements OnInit {
  tenantType:any;
  lastUpdateDate:any;
  totalCount=0;
  payouts:any[]=[];
  latestPayoutObj:any;
  userType:any;
  reqObject:any={};
  pagination={
    limit:5,
    pageNo:1,
  }
  selectedPageLimit = this.pagination.limit;
  latestPayout=[{title: "Total Payout", isProgram: false, coveredSales: 1200, cummulativePayout: 100.98, assessment:"17%"},
  {title: "CJD", isProgram: true, coveredSales: 1500, cummulativePayout: 120.98,assessment:"37%"},
  {title: "GIP", isProgram: true, coveredSales: 1400, cummulativePayout: 130.98,assessment:"0%"}];
  constructor(private router:Router,private domSanitizer: DomSanitizer,private matIconRegistry: MatIconRegistry,private dataService:DataService,
    private httpService:HttpService,private dialog:MatDialog, private resuableService:ReusableService, private authService:AuthService) {
    this.matIconRegistry.addSvgIcon("settings", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/setting-icon.svg"));
   }

  ngOnInit(): void {
    this.tenantType = localStorage.getItem('tenant')
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    const {userType} = this.authService.getUser() as any;
    this.userType = userType;
    this.reqObject={
      limit:this.pagination.limit,
      pageNo:this.pagination.pageNo
    };
    this.populateLatestPayout()
  }

  navigateToHome = ()=>{
    this.router.navigate([`/${this.tenantType}/home`]);
  }

  createPayout = () =>{
    this.router.navigate([`/${this.tenantType}/payoutManagement/create-payout`]);
  }

  navigateToPayoutDetail = (payoutId:any) =>{
    this.router.navigate([`/${this.tenantType}/payoutManagement/payout-details/${payoutId}`]);
  }

  selectedViewPageLimit = (limitValue:any)=>{
    this.pagination['limit']=parseInt(limitValue);
    this.selectedPageLimit=this.pagination.limit;
    this.pagination['pageNo']=1;
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.populateLatestPayout();
  }

  goToPageViewNumber = (event:any)=>{
    let value = Math.ceil(this.totalCount/this.pagination['limit'])
    if(event<=value){
      this.pagination['pageNo']=parseInt(event);
      this.reqObject['limit']=this.pagination['limit']
      this.reqObject['pageNo']=this.pagination['pageNo']
      this.populateLatestPayout();
    }else{
        const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
          width: '370px',
          height: '180',
          data: {"type":"PageNo entered out of range."},
          disableClose: true,
        });
        setTimeout(()=>{
          dialogRef.close()
        },2000)

        dialogRef.afterClosed().subscribe((result:any) => {
          if(this.payouts  && this.payouts.length>0){
            this.payouts = []
          }
          this.pagination['pageNo']=1;
          this.reqObject['limit']=this.pagination['limit']
          this.reqObject['pageNo']=this.pagination['pageNo']
          this.populateLatestPayout();
        })
      }
  }
  getNextPage = (event:any)=>{
    this.pagination['pageNo']=parseInt(event['pageIndex'])+1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.populateLatestPayout();
  }

  onConfigure = ()=>{
    this.router.navigate([`/${this.tenantType}/payoutManagement/assessment-details`]);
  }

  populateLatestPayout=()=>{
    if(this.payouts && this.payouts.length>0 && this.pagination['pageNo']==1){
      this.payouts = [];
    }
    if(this.userType === UserType.Corporate){
      // this.latestPayoutObj ={
      //   "payoutTicketNo": 10019,
      //   "payoutTicketName": "payout test",
      //   "lastFileDate": "2023-06-08",
      //   "distributorCount": 2,
      //   "supplierCount": 2,
      //   "summary": [
      //     {
      //       "title": "Total Payout",
      //       "isProgram": false,
      //       "transactionAmount": 104260.76,
      //       "payout": 2097.18
      //     },
      //     {
      //       "title": "CJD",
      //       "isProgram": true,
      //       "transactionAmount": 104260.76,
      //       "payout": 2097.18
      //     },
      //     {
      //       "title": "GIP",
      //       "isProgram": true,
      //       "transactionAmount": 0,
      //       "payout": 0
      //     }
      //   ]
      // }
      // this.payouts = [
      //   {
      //     "payoutTicketNo": 10018,
      //     "payoutTicketName": "payout test",
      //     "distributorCount": 82,
      //     "supplierCount": 15,
      //     "lastFileDate": "2023-06-03",
      //     "totalTransactionAmount": 32288907.75,
      //     "totalPayout": 1328599.11,
      //     "programTypesCount": 2
      //   },
      //   {
      //     "payoutTicketNo": 10015,
      //     "payoutTicketName": "1/13/2023",
      //     "distributorCount": 82,
      //     "supplierCount": 16,
      //     "lastFileDate": "2023-05-18",
      //     "totalTransactionAmount": 21688495.76,
      //     "totalPayout": 717507.41,
      //     "programTypesCount": 2
      //   },
      //   {
      //     "payoutTicketNo": 10014,
      //     "payoutTicketName": "test1",
      //     "distributorCount": 80,
      //     "supplierCount": 15,
      //     "lastFileDate": "2023-05-12",
      //     "totalTransactionAmount": 15830180.27,
      //     "totalPayout": 575478.28,
      //     "programTypesCount": 1
      //   },
      //   {
      //     "payoutTicketNo": 10013,
      //     "payoutTicketName": "3/1/2023",
      //     "distributorCount": 82,
      //     "supplierCount": 16,
      //     "lastFileDate": "2023-04-11",
      //     "totalTransactionAmount": 21688495.76,
      //     "totalPayout": 717507.41,
      //     "programTypesCount": 2
      //   },
      //   {
      //     "payoutTicketNo": 10017,
      //     "payoutTicketName": "Title",
      //     "distributorCount": 81,
      //     "supplierCount": 15,
      //     "lastFileDate": "2023-04-01",
      //     "totalTransactionAmount": 16535273.64,
      //     "totalPayout": 601842.55,
      //     "programTypesCount": 2
      //   },
      //   {
      //     "payoutTicketNo": 10003,
      //     "payoutTicketName": "JAN2023 CJD PAYOUT",
      //     "distributorCount": 133,
      //     "supplierCount": 15,
      //     "lastFileDate": "2023-01-31",
      //     "totalTransactionAmount": 31155979.96,
      //     "totalPayout": 73871,
      //     "programTypesCount": 1
      //   }
      // ]
      this.httpService.getLatestPayout(this.reqObject).subscribe(response=>{
        this.totalCount = response && response['data']['count']
        if(response && response['data']['count']>0){
        if(this.pagination.pageNo === 1){
          response.data.recentPayoutTicket['lastFileDate'] = new Date(this.resuableService.formatDateToMTZ(response.data.recentPayoutTicket['lastFileDate']));
          this.latestPayoutObj = response?.data?.recentPayoutTicket;
          this.dataService.setRecentPayout(this.latestPayoutObj);
        }
        this.payouts = response?.data?.otherPayoutTickets;
      }
      })
    }else if(this.userType === UserType.Distributor){
      this.httpService.fetchPayoutLibrary(this.reqObject).subscribe(response=>{
        this.totalCount = response && response['data']['count']
        if(response && response['data']['count']>0){
          this.payouts = response?.data?.payoutEvents;
        }
      })
      // this.payouts = [
      //   {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10,payout:10000},
      //   {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10,payout:10000},
      //   {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10,payout:10000},
      //   {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10,payout:10000},
      //   {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10,payout:10000},
      //   // {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10},
      //   // {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10}
      // ]
      // this.payouts = [
      //   {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10}, 
      //   {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10},
      //   {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10},
      //   {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10}, 
      //   {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10}, 
      //   // {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10}, 
      //   // {payoutTicketName:"Q1 2022", supplierCount:10, coveredPurchase:1200000, totalPayout:450000, programTypesCount:4, programCount:10} 
      // ]
    }
  }

  onExport(payoutId:any){
    const payoutObj = {payoutTicketNo:payoutId}
    this.httpService.fetchPayoutTicketDetails(payoutObj).subscribe(response=>{
      if(response && response['data']['count'] === 0){
        const dialogRef = this.dialog.open(ExportModalComponent, {
          width: '416px',
          height: '185px',
          panelClass: 'dialog-container-custom',
          data: {message:"No records found to export for the selected ticket"},

        });
        dialogRef.afterClosed().subscribe((result: any) => {
        });
      }else{
        //const allData = response?.data?.payoutTicketDetails;
        const allData = this.mapPayoutData(response?.data?.payoutTicketDetails);
        if(allData.length > 0){
          const headers = Object.keys(allData[0]);
          this.downloadFile(allData,headers,`${this.latestPayoutObj['payoutTicketName']}_Payout_${payoutId}`);
        }
      }
    })
  }

  downloadFile(data: any, header: any, filename = 'data') {
    let csvData = this.resuableService.convertToCSV(data, header);
    let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
    const dialogRef = this.dialog.open(SucessMessageModalComponent, {
      width: '420px',
      height: '170px',
      data: { "type": `${filename} Exported successfully ${data.length} records.`, actionStatus: 'success' },
      disableClose: true
    });
  }

  navigateToMyDashboard =()=>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])
  }

  mapPayoutData = (content: any) => {
    return content.map((row: any) => ({
      "Payout Ticket Number" : row['payoutTicketNo'] ? row['payoutTicketNo'] : 'NA',
      "Dealer Name"	: row['distributorname'] ? `"${row['distributorname'].replace('"','""')}"` : 'NA',
      "Dealer Pivot Id"	: row['dealerPivotId'] ? `"${row['dealerPivotId'].replace('"','""')}"` : 'NA',
      "Vendor Name"	: row['supplierName'] ? `"${row['supplierName'].replace('"','""')}"` : 'NA',
      "Venor Pivot Id"	: row['vendorPivotId'] ? `"${row['vendorPivotId'].replace('"','""')}"` : 'NA',
      "Program Name"	: row['programName'] ? `"${row['programName'].replace('"','""')}"` : 'NA',
      "Program Id"	: row['programId'] ? row['programId'] : 0,
      "Program Type"	: row['programType'] ? `"${row['programType'].replace('"','""').replace('_',' ')}"` : 'NA',
      "Covered Sales"	: row['coveredSales'] ? row['coveredSales'] : 0,
      "Payment"	: row['payment'] ? row['payment'] : 0,
      "Payout"	: row['payout'] ? row['payout'] : 0,
    }))
  }

  formatDate = (date:any) => {
    if(date){
      return this.resuableService.formatDateToMTZ(date);
    }
  }
}


