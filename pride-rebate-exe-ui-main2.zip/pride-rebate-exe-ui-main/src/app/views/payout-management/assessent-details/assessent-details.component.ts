import { TitleCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { Subject } from 'rxjs/internal/Subject';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import { YEAR } from 'src/app/helpers/constants';
import { DataService } from 'src/app/services/data.service';
import { HttpService } from 'src/app/services/http.service';
@Component({
  selector: 'app-assessent-details',
  templateUrl: './assessent-details.component.html',
  styleUrls: ['./assessent-details.component.scss']
})
export class AssessentDetailsComponent implements OnInit {
  tenantType: any;
  lastUpdateDate: any;
  isButtonDisabled = false;
  resetFile = false;
  dataSource:any = new MatTableDataSource([]);
  dataSource2:any= new MatTableDataSource([]);
  totalCount:any=0;
  totalCount2:any=0;
  columnsToDisplay :any= [];
  columnsProps:any;
  columnsToDisplay2 :any= [];
  columnsProps2:any;
  reqObject:any={};
  reqObject2:any={};
  pagination={
    limit:10,
    pageNo:1,
  }
  pagination2={
    limit:5,
    pageNo:1,
  }
  selectedPageLimit = this.pagination.limit;
  selectedPageLimit2 = this.pagination2.limit;
  sort:any;
  selectedMemberName:any;
  selectedYear:any;
  years = YEAR;
  full: boolean = true;
  selector: string='';
  public formData = new FormData();
  isSortApplied: Subject<any> = new Subject();
  constructor(private router:Router, private httpService:HttpService,private titlecasePipe:TitleCasePipe, private dialog:MatDialog,
    private dataService: DataService) { }

  ngOnInit(): void {
    this.tenantType = localStorage.getItem('tenant')
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    let year = localStorage.getItem("year")
    if(!year){
      this.selectedYear =new Date().getFullYear()
      localStorage.setItem("year",this.selectedYear)
    }else {
      this.selectedYear = parseInt(year)
    }
    this.reqObject={
      limit:this.pagination.limit,
      pageNo:this.pagination.pageNo
    };
    this.getAssessmentDetails();
  }

  navigateToHome = ()=>{
    this.router.navigate([`/${this.tenantType}/home`]);
  }

  navigateToPayoutMgmt=()=>{
    this.router.navigate([`/${this.tenantType}/payoutManagement`]);
  }

  populateHeaders = () => {
    this.columnsToDisplay=[
      {header: 'Email id',field: 'distributorId',displayFilter: false,cell: (element: any) => `${element.name}`,placeHolder:'Email id',ellipseLength:15},
      {header: 'Dealer name',field: 'distributorName',displayFilter: false,cell: (element: any) => `${element.name}`,placeHolder:'Distributor',ellipseLength:15, clickable:true},
    {header: 'Assessment %',field: 'assessment'},
    {header: 'Effective Date',field: 'effectiveDate'},
    ];
    this.columnsProps= this.columnsToDisplay.map((column:any) => {return column.field});
  }

  populateHeaders2 = () => {
    this.columnsToDisplay2=[
    {header: 'Assessment %',field: 'assessment'},
    {header: 'Effective Date',field: 'effectiveDate'},
    ];
    this.columnsProps2= this.columnsToDisplay2.map((column:any) => {return column.field});
  }

  uploadedFile = (file:any) =>{
    if(file){
      console.log("File",file);
      // const modifiedFile = this.renameFile(file,`123_${file['name']}`);
      // console.log("File Modified",modifiedFile);
     this.formData.append("file",file)
     console.log("Form Data",this.formData);
    }
  }

  onConfigure = ()=>{
    this.resetFile = true;
    if(this.formData.has('file')){
      this.httpService.uploadAssessentFile(this.formData).subscribe((response)=>{
        if(response && response['data']['uploadResult']){
          if(response['data']['uploadResult']=='successful'){
            this.showSuccessOrError("Assessment Configuration Uploaded Successful")
          }

        }
      },error=>{
        this.showSuccessOrError("Error occured while uploading file")
      })
    };
  }

  downloadSample =(type: string)=>{
    this.dataService.download(type, `${type + '.csv'}`);
  }

  isDisabled = (event:any)=>{
    this.isButtonDisabled = event;
  }

  // DataSource Assessment History
  populateAssessmentData = (content:any[]) =>{
    const tableData:any = [];
    for(let i=0;i<content.length;i++){
      let obj:any={};
      obj['raMemberId']= content && content[i]['raMemberId']? content[i]['raMemberId']:'NA'
      obj['distributorName']= content && content[i]['distributorName']? this.titlecasePipe.transform(content[i]['distributorName']):'NA'
      obj['distributorId']= content && content[i]['distributorId']? content[i]['distributorId']:'NA'
      obj['assessment']= content && content[i]['assessment']? `${content[i]['assessment']} %`:'NA'
      obj['effectiveDate']= content && content[i]['effectiveDate']? `${this.getDate(content[i]['effectiveDate'])}`:"--/--/----"
      tableData.push(obj);
    }
    this.dataSource = new MatTableDataSource(tableData);
    this.isSortApplied.next(tableData)
  }
  getAssessmentDetails = () =>{
    if(this.dataSource && this.dataSource['data'].length>0 && this.pagination['pageNo']==1){
      this.dataSource = new MatTableDataSource([])
    }
    this.populateHeaders();
    this.httpService.fetchAssessment(this.reqObject).subscribe((response:any)=>{
      console.log("Assessment",response);
      if(response && response['data']['count']>0){
        this.totalCount = response && response['data']['count']
        this.populateAssessmentData(response['data']['payoutAssessmentDetails']);
      }else{
        this.dataSource = new MatTableDataSource([]);
      }
    });
  }

  filterColumnwiseData = (values:any) =>{
    if(values['distributorName']!=null && values['distributorName']!=""){
      this.reqObject['distributorName'] = values['distributorName']
    }else{
      if(this.reqObject.hasOwnProperty('distributorName')){
        delete this.reqObject['distributorName']
      }
    }
    if(values['distributorId']!=null && values['distributorId']!=""){
      this.reqObject['distributorId'] = values['distributorId']
    }else{
      if(this.reqObject.hasOwnProperty('distributorId')){
        delete this.reqObject['distributorId']
      }
    }
    if(values['assessment']!=null && values['assessment']!=""){
      this.reqObject['assessment'] = values['assessment']
    }else{
      if(this.reqObject.hasOwnProperty('assessment')){
        delete this.reqObject['assessment']
      }
    }
    this.pagination['pageNo'] = 1;
    this.pagination['limit'] = this.selectedPageLimit;
    this.getAssessmentDetails();
  }

  applyFilter = (values:any) => {
    if(values.hasOwnProperty('effectiveDateFrom')){
      this.reqObject['effectiveDateFrom'] = values['effectiveDateFrom']+this.appendTimeStamp()
    }else if(!values.hasOwnProperty('effectiveDateFrom')){
      if(this.reqObject.hasOwnProperty('effectiveDateFrom')){
        delete this.reqObject.effectiveDateFrom
      }
    }
    if(values.hasOwnProperty('effectiveDateTo')){
      this.reqObject['effectiveDateTo'] = values['effectiveDateTo']+this.appendTimeStamp()
    }else if(!values.hasOwnProperty('effectiveDateTo')){
      if(this.reqObject.hasOwnProperty('effectiveDateTo')){
        delete this.reqObject.effectiveDateTo
      }
    }
    this.pagination['pageNo'] = 1;
    this.pagination['limit'] = this.selectedPageLimit;
    this.getAssessmentDetails();
  }

  getNextPage = (event:any)=>{
    this.pagination['pageNo']=parseInt(event['pageIndex'])+1
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.getAssessmentDetails();
  }

  selectedViewPageLimit = (limitValue:any) =>{
    this.pagination['limit']=parseInt(limitValue);
    this.selectedPageLimit=this.pagination.limit;
    this.pagination['pageNo']=1;
    this.reqObject['limit']=this.pagination['limit']
    this.reqObject['pageNo']=this.pagination['pageNo']
    this.getAssessmentDetails();
  }

  goToPageNumber = (event:any) =>{
    let value = Math.ceil(this.totalCount/this.pagination['limit'])
    if(event<=value){
      this.pagination['pageNo']=parseInt(event);
      this.reqObject['limit']=this.pagination['limit']
      this.reqObject['pageNo']=this.pagination['pageNo']
      this.getAssessmentDetails();
    }else{
        const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
          width: '370px',
          height: '180',
          data: {"type":"PageNo entered out of range."},
          disableClose: true,
        });
        setTimeout(()=>{
          dialogRef.close()
        },2000)

        dialogRef.afterClosed().subscribe((result:any) => {
          if(this.dataSource && this.dataSource['data'] && this.dataSource['data'].length>0){
            this.dataSource['data'] = []
          }
          this.pagination['pageNo']=1;
          this.reqObject['limit']=this.pagination['limit']
          this.reqObject['pageNo']=this.pagination['pageNo']
          this.getAssessmentDetails();
        })
      }
  }

  sortByColumnName = (data:any) =>{
    console.log("DataSource",this.dataSource);
    this.sort = this.dataSource.sort;
    if(data['direction']){
      if(this.reqObject['sorting'] && this.reqObject['sorting'].length > 0){
        const isFound = this.reqObject['sorting'].find((row:any) => row['orderBy'] === data['active']);
        if(isFound){
          this.reqObject['sorting'] = this.reqObject['sorting'].map((row:any)=>{
            if(row['orderBy'] === data['active']){
              row['orderType'] = data['direction']
            }
            return row;
          })
        }else{
          this.reqObject['sorting'] = [...this.reqObject['sorting'],{orderBy:data['active'],orderType:data['direction']}]
        }
      }else{
        this.reqObject['sorting'] = [{orderBy:data['active'],orderType:data['direction']}]
      }
    }else{
      if(this.reqObject.hasOwnProperty('sorting')){
        delete this.reqObject['sorting']
      }
    }
        this.getAssessmentDetails();
  }

  // DataSource 2 Assessment History

  populateAssessmentHistoryData = (content:any[]) =>{
    if(content.length > 0){
      const tableData:any = [];
      for(let i=0;i<content.length;i++){
        let obj:any={};
        obj['assessment']= content && content[i]['assessment']? `${content[i]['assessment']} %`:'0%'
        obj['effectiveDate']= content && content[i]['effectiveDate']? `${this.getDate(content[i]['effectiveDate'])}`:"--/--/----"
        tableData.push(obj);
      }
      const tableData2 = this.dataSource2 ? [...this.dataSource2.data, ...tableData] :tableData;
      console.log("daddada",tableData2);

      this.dataSource2 = new MatTableDataSource(tableData2);
    }
  }
  getAssessmentHistoryDetails = () =>{
    // if(this.dataSource2 && this.dataSource2['data'].length>0 && this.pagination2['pageNo']==1){
    //   this.dataSource2 = new MatTableDataSource([])
    // }
    this.populateHeaders2();
    this.httpService.fetchAssessmentHistory(this.reqObject2).subscribe((response:any)=>{
      console.log("Assessment",response);
      if(response && response['data']['count']>0){
        this.totalCount2 = response && response['data']['count']
        this.populateAssessmentHistoryData(response['data']['payoutAssessmentHitoryDetails']);
      }else{
        this.dataSource2 = new MatTableDataSource([])
      }
    })
  }

  filterColumnwiseData2 = (values:any) =>{
    if(values['assessment']!=null && values['assessment']!=""){
      this.reqObject2['assessment'] = values['assessment']
    }else{
      if(this.reqObject2.hasOwnProperty('assessment')){
        delete this.reqObject2['assessment']
      }
    }
    this.pagination2['pageNo'] = 1;
    this.pagination2['limit'] = this.selectedPageLimit;
    this.getAssessmentHistoryDetails();
  }

  applyFilter2 = (values:any) => {
    if(values.hasOwnProperty('effectiveDateFrom')){
      this.reqObject2['effectiveDateFrom'] = values['effectiveDateFrom']+this.appendTimeStamp()
    }else if(!values.hasOwnProperty('effectiveDateFrom')){
      if(this.reqObject2.hasOwnProperty('effectiveDateFrom')){
        delete this.reqObject2.effectiveDateFrom
      }
    }
    if(values.hasOwnProperty('effectiveDateTo')){
      this.reqObject2['effectiveDateTo'] = values['effectiveDateTo']+this.appendTimeStamp()
    }else if(!values.hasOwnProperty('effectiveDateTo')){
      if(this.reqObject2.hasOwnProperty('effectiveDateTo')){
        delete this.reqObject2.effectiveDateTo
      }
    }
    this.pagination2['pageNo'] = 1;
    this.pagination2['limit'] = this.selectedPageLimit2;
    this.getAssessmentHistoryDetails();
  }

  getNextPage2 = (event:any)=>{
    this.pagination2['pageNo']=parseInt(event['pageIndex'])+1
    this.reqObject2['limit']=this.pagination2['limit']
    this.reqObject2['pageNo']=this.pagination2['pageNo']
    this.getAssessmentHistoryDetails();
  }

  selectedViewPageLimit2 = (limitValue:any) =>{
    this.pagination2['limit']=parseInt(limitValue);
    this.selectedPageLimit2=this.pagination2.limit;
    this.pagination2['pageNo']=1;
    this.reqObject2['limit']=this.pagination2['limit']
    this.reqObject2['pageNo']=this.pagination2['pageNo']
    this.getAssessmentDetails();
  }

  goToPageNumber2 = (event:any) =>{
    let value = Math.ceil(this.totalCount/this.pagination2['limit'])
    if(event<=value){
      this.pagination2['pageNo']=parseInt(event);
      this.reqObject2['limit']=this.pagination2['limit']
      this.reqObject2['pageNo']=this.pagination2['pageNo']
      this.getAssessmentHistoryDetails();
    }else{
        const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
          width: '370px',
          height: '180',
          data: {"type":"PageNo entered out of range."},
          disableClose: true,
        });
        setTimeout(()=>{
          dialogRef.close()
        },2000)

        dialogRef.afterClosed().subscribe((result:any) => {
          if(this.dataSource2 && this.dataSource2['data'] && this.dataSource2['data'].length>0){
            this.dataSource2['data'] = []
          }
          this.pagination2['pageNo']=1;
          this.reqObject2['limit']=this.pagination2['limit']
          this.reqObject2['pageNo']=this.pagination2['pageNo']
          this.getAssessmentHistoryDetails();
        })
      }
  }

  public getDate = (date:any) =>{
    if(date){
      let modifedDate = moment(date,"YYYYMMDD")
      return modifedDate.format('MM/DD/YYYY')
    }else{
      return 'NA'
    }
  }

  viewMore = (data:any)=>{
    this.selector= ".history";
    this.reqObject2={
      limit:this.pagination2.limit,
      pageNo:1
    };
    if(this.dataSource2 && this.dataSource2['data'].length>0 && this.pagination2['pageNo']==1){
        this.dataSource2 = new MatTableDataSource([])
      }
    const {raMemberId, distributorName} =data;
    this.selectedMemberName = distributorName;
    this.reqObject2={
      raMemberId,
      limit:this.pagination2.limit,
      pageNo:this.pagination2.pageNo
    }
    this.getAssessmentHistoryDetails();
  }

  selectedYearOption = (value: any) => {
    if(value){
      this.selectedYear = value
      localStorage.setItem("year",this.selectedYear)
    }
  }

  appendTimeStamp =()=>{
    return 'T00:00:00.000Z'
  }

  hasMore = () => {
    console.log(!this.dataSource2 || this.dataSource2.data.length < this.totalCount2);
    return !this.dataSource2 || this.dataSource2.data.length < this.totalCount2;
  };

  onScroll = () =>{
    console.log("Scrolled");
    if(this.hasMore()){
      this.reqObject2.pageNo = this.reqObject2.pageNo+1;
      this.getAssessmentHistoryDetails()
    }
  }

  showSuccessOrError = (message:any) =>{
    if(message){
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: {"type":message},
        disableClose: true,
      });

      dialogRef.afterClosed().subscribe(result => {
      })
    }

  }
}
