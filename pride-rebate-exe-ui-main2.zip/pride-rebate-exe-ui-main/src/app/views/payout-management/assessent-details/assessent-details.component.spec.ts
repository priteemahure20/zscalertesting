import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssessentDetailsComponent } from './assessent-details.component';

describe('AssessentDetailsComponent', () => {
  let component: AssessentDetailsComponent;
  let fixture: ComponentFixture<AssessentDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssessentDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssessentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
