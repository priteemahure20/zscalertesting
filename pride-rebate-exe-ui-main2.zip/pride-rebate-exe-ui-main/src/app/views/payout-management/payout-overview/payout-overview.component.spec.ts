import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayoutOverviewComponent } from './payout-overview.component';

describe('PayoutOverviewComponent', () => {
  let component: PayoutOverviewComponent;
  let fixture: ComponentFixture<PayoutOverviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PayoutOverviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PayoutOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
