import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-payout-overview',
  templateUrl: './payout-overview.component.html',
  styleUrls: ['./payout-overview.component.scss']
})
export class PayoutOverviewComponent implements OnInit {
@Input() latestPayout:any;
@Output() onExportEmitter = new EventEmitter();
@Output() onDateSelectEmitter = new EventEmitter();
@Output() onViewMoreEmitter = new EventEmitter();
isClickable = false;
userType:any;
  constructor(private domSanitizer: DomSanitizer,private matIconRegistry: MatIconRegistry,private authService:AuthService) { 
    this.matIconRegistry.addSvgIcon("export", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../../../assets/img/icons/export.svg"));
    this.matIconRegistry.addSvgIcon("info", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../../../assets/img/icons/info.svg"));
  }

  ngOnInit(): void {
    console.log(this.latestPayout);
    
    const {userType} = this.authService.getUser() as any;
    this.userType = userType;
    this.isClickable = this.onViewMoreEmitter.observers.length ===0 ? false :true
  }

  export=(payoutId:any)=>{
    this.onExportEmitter.emit(payoutId);
  }

  onDateSelect =(data:any)=>{
    this.onDateSelectEmitter.emit();
  }

  viewDetails = (payoutId:any) =>{
    this.onViewMoreEmitter.emit(payoutId);
  }

  checkKey(object:any,key:string){
    if(object.hasOwnProperty(key)){
      return true;
    }else{
        return false;
    }
  }

  getRebateType(rebateType:any){
    rebateType = rebateType.replaceAll('_', ' ');
    if(rebateType.toLowerCase() == 'membership qualification'){
      rebateType = 'pride incentive';
    }
    return rebateType;
  }

}
