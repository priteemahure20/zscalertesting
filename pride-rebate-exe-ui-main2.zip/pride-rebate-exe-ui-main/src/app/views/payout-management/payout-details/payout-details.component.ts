import { TitleCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs/internal/Subject';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import { UserType } from 'src/app/helpers/constants';
import { AuthService } from 'src/app/services/auth.service';
import { HttpService } from 'src/app/services/http.service';
import { ReusableService } from '../../../services/reusable.service';
import { ExportModalComponent } from '../../report-generator/export-modal/export-modal.component';
import { SucessMessageModalComponent } from 'src/app/common/sucess-message-modal/sucess-message-modal.component';
@Component({
  selector: 'app-payout-details',
  templateUrl: './payout-details.component.html',
  styleUrls: ['./payout-details.component.scss']
})
export class PayoutDetailsComponent implements OnInit {
  tenantType: any;
  lastUpdateDate: any;
  latestPayoutObj: any;
  datas: any[] = [];
  latestPayout = [{ title: "Total Payout", isProgram: false, coveredSales: 1200, cummulativePayout: 100.98, assessment: "17" },
  { title: "CJD", isProgram: true, coveredSales: 1500, cummulativePayout: 120.98, assessment: "37" },
  { title: "GIP", isProgram: true, coveredSales: 1400, cummulativePayout: 130.98, assessment: "0" }];
  dataSource: any;
  totalCount: any = 0;
  reqObject: any = {};
  pagination = {
    limit: 10,
    pageNo: 1,
  }
  selectedPageLimit = this.pagination.limit;
  userType: any;
  sort:any;
  constructor(private router: Router, private reusableService: ReusableService, private titlecasePipe: TitleCasePipe, private activatedRoute: ActivatedRoute, private httpService: HttpService,
    private dialog: MatDialog, private resuableService: ReusableService, private authService: AuthService, private domSanitizer: DomSanitizer, private matIconRegistry: MatIconRegistry) {
    this.matIconRegistry.addSvgIcon("settings", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/setting-icon.svg"));
  }

  data = [
    { supplierSegment: 2000, supplierName: "Brizo", programName: "Program Name 1", programType: "CJD", coveredSales: "460000", payout: 6900 },
    { supplierSegment: 2000, supplierName: "Brizo", programName: "Program Name 1", programType: "CJD", coveredSales: "460000", payout: 6900 },
    { supplierSegment: 2000, supplierName: "Brizo", programName: "Program Name 1", programType: "CJD", coveredSales: "460000", payout: 6900 },
    { supplierSegment: 2000, supplierName: "Brizo", programName: "Program Name 1", programType: "CJD", coveredSales: "460000", payout: 6900 },
    { supplierSegment: 2000, supplierName: "Brizo", programName: "Program Name 1", programType: "CJD", coveredSales: "460000", payout: 6900 },
    { supplierSegment: 2000, supplierName: "Brizo", programName: "Program Name 1", programType: "CJD", coveredSales: "460000", payout: 6900 },
  ]
  columnsToDisplay: any = [];
  columnsProps: any;
  isSortApplied: Subject<any> = new Subject();
  ngOnInit(): void {
    const { userType } = this.authService.getUser() as any;
    this.userType = userType;
    const payoutId = this.activatedRoute.snapshot.paramMap.get('payoutId');
    this.reqObject = {
      payoutTicketNo: payoutId,
      limit: this.pagination.limit,
      pageNo: this.pagination.pageNo
    };
    this.tenantType = localStorage.getItem('tenant')
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    this.populateLatestPayout(payoutId);
    this.getPayoutDetails();
    // this.populatePayoutData(this.data);
  }


  // Payout overview
  populateLatestPayout = (payoutId: any) => {
    if (this.userType === UserType.Corporate) {
      // this.latestPayoutObj = {
      //   "payoutTicketNo": 10019,
      //   "payoutTicketName": "payout test",
      //   "lastFileDate": "2023-06-08",
      //   "distributorCount": 2,
      //   "supplierCount": 2,
      //   "summary": [
      //     {
      //       "title": "Total Payout",
      //       "isProgram": false,
      //       "transactionAmount": 104260.76,
      //       "payout": 2097.18
      //     },
      //     {
      //       "title": "CJD",
      //       "isProgram": true,
      //       "transactionAmount": 104260.76,
      //       "payout": 2097.18
      //     },
      //     {
      //       "title": "GIP",
      //       "isProgram": true,
      //       "transactionAmount": 0,
      //       "payout": 0
      //     }
      //   ]
      // }
      this.httpService.fetchPayoutDetails(payoutId).subscribe(res => {
        this.latestPayoutObj = res?.data;
      });
    } else if (this.userType === UserType.Distributor) {
      let payOutObj={
        payoutTicketNo:payoutId
      }
      // this.latestPayoutObj = {payoutTicketName:'Q1 2022', summary:this.latestPayout};
      this.httpService.fetchDistributorPayoutTicketDetails(payOutObj).subscribe(response => {
        const {data:{payoutTicketName,lastFileDate,rebateTypeAmounts,payoutTicketNo }} = response;
        this.latestPayoutObj = {lastFileDate, payoutTicketName,summary: rebateTypeAmounts,payoutTicketNo };
      });
      // let dummyData = {
      //   "data": {
      //     "payoutTicketNo": 10015,
      //     "payoutTicketName": "10015",
      //     "supplierCount": 2,
      //     "coveredPurchase": 182028.96,
      //     "payout": 4784.02,
      //     "programTypesCount": 2,
      //     "programCount": 3,
      //     "lastFileDate": "2023-05-18",
      //     "rebateTypeAmounts": [
      //       {
      //         "title": "Total Payout",
      //         "isProgram": false,
      //         "coveredPurchase": 182028.96,
      //         "cumulativePayout": 4784.02,
      //         "assessment": 13.12
      //       },
      //       {
      //         "title": "CJD",
      //         "isProgram": true,
      //         "coveredPurchase": 182028.96,
      //         "cumulativePayout": 4784.02,
      //         "assessment": 13.12
      //       },
      //       {
      //         "title": "GIP",
      //         "isProgram": true,
      //         "coveredPurchase": 177468.66,
      //         "cumulativePayout": 0,
      //         "assessment": 0
      //       }
      //     ]
      //   }
      // }
      // const {data:{payoutTicketName,lastFileDate,rebateTypeAmounts,payoutTicketNo }} = dummyData;
      // this.latestPayoutObj = {lastFileDate, payoutTicketName,summary: rebateTypeAmounts,payoutTicketNo };
    }
  }

  navigateToHome = () => {
    this.router.navigate([`/${this.tenantType}/home`]);
  }

  createPayout = () => {
    this.router.navigate([`/${this.tenantType}/payoutManagement/create-payout`]);
  }

  navigateToPayoutMgmt = () => {
    this.router.navigate([`/${this.tenantType}/payoutManagement`]);
  }

  populatePayoutData(content: any[]) {
    const tableData: any = [];
    if (this.userType === UserType.Corporate) {
      for (let i = 0; i < content.length; i++) {
        let obj: any = {};
        obj['distributorname'] = content && content[i]['distributorname'] ? content[i]['distributorname'] : 'NA'
        obj['supplierName'] = content && content[i]['supplierName'] ? content[i]['supplierName'] : 'NA'
        obj['programName'] = content && content[i]['programName'] ? content[i]['programName'] : 'NA'
        obj['programType'] = content && content[i]['programType'] ? this.titlecasePipe.transform(content[i]['programType'].replace('_', ' ')) : 'NA'
        obj['coveredSales'] = content && content[i]['coveredSales'] ? this.reusableService.significantNumber(parseInt(content[i]['coveredSales'])) : 0
        obj['payment'] = content && content[i]['payment'] ? this.reusableService.significantNumber((content[i]['payment'])) : 0
        obj['assessment'] = content && content[i]['assessment'] ? `${content[i]['assessment']} %` : 0
        obj['payout'] = content && content[i]['payout'] ? `${this.reusableService.significantNumber(parseInt(content[i]['payout']))}` : 0
        tableData.push(obj);
      }
    } else if (this.userType === UserType.Distributor) {
      for (let i = 0; i < content.length; i++) {
        let obj: any = {};
        obj['VendorPiovtId'] = content && content[i]['VendorPiovtId'] ? content[i]['VendorPiovtId'] : 0
        obj['VendorName'] = content && content[i]['VendorName'] ? content[i]['VendorName'] : 'NA'
        obj['ProgramType'] = content && content[i]['ProgramType'] ? this.titlecasePipe.transform(content[i]['ProgramType'].replace('_', ' ')) : 'NA'
        obj['ProgramName'] = content && content[i]['ProgramName'] ? content[i]['ProgramName'] : 'NA'
        obj['CoveredPurchase'] = content && content[i]['CoveredPurchase'] ? this.reusableService.significantNumber(parseInt(content[i]['CoveredPurchase'])) : 0
        obj['Payout'] = (content && content[i]['ProgramType'] == "CJD") ? '-' : (content && content[i]['Payout']) ? `${this.reusableService.significantNumber(parseInt(content[i]['Payout']))}` : 0
        tableData.push(obj);
      }
    }
    this.dataSource = new MatTableDataSource(tableData);
    this.isSortApplied.next(tableData)
  }

  populateHeaders = () => {
    if (this.userType === UserType.Corporate) {
      this.columnsToDisplay = [
        { header: 'Dealer', field: 'distributorname', displayFilter: false, cell: (element: any) => `${element.name}`, placeHolder: 'Distributor', ellipseLength: 15, searchable: true },
        { header: 'Vendor ', field: 'supplierName', displayFilter: false, cell: (element: any) => `${element.name}`, placeHolder: 'Supplier', ellipseLength: 15, searchable: true },
        { header: 'Program Name', field: 'programName', displayFilter: false, cell: (element: any) => `${element.name}`, placeHolder: 'Program Name', searchable: true },
        { header: 'Program Type', field: 'programType', displayFilter: false, cell: (element: any) => `${element.name}`, placeHolder: 'Program Type' },
        { header: 'Covered Sales', field: 'coveredSales' },
        { header: 'Payment', field: 'payment' },
        // { header: 'Assessment %', field: 'assessment' },
        { header: 'Payout', field: 'payout' },
      ];
    } else if (this.userType === UserType.Distributor) {
      this.columnsToDisplay = [
        { header: 'Vendor Pivot ID', field: 'VendorPiovtId', displayFilter: false, cell: (element: any) => `${element.name}`, placeHolder: 'Supplier Segment', ellipseLength: 15, searchable: true },
        { header: 'Name of the vendor', field: 'VendorName', displayFilter: false, cell: (element: any) => `${element.name}`, placeHolder: 'Supplier Name', ellipseLength: 15, searchable: true },
        { header: 'Program Type', field: 'ProgramType', displayFilter: false, cell: (element: any) => `${element.name}`, placeHolder: 'Program Type' },
        { header: 'Program Name', field: 'ProgramName', displayFilter: false, cell: (element: any) => `${element.name}`, placeHolder: 'Program Name', searchable: true },
        { header: 'Covered Purchase', field: 'CoveredPurchase' },
        { header: 'Payout', field: 'Payout' },
      ];
    }
    this.columnsProps = this.columnsToDisplay.map((column: any) => { return column.field });
  }

  filterColumnwiseData(values: any) {
    this.pagination['pageNo'] = 1;
    this.pagination['limit'] = this.selectedPageLimit;
    if (this.userType === UserType.Corporate) {
      this.checkKey(values, 'distributorname');
      this.checkKey(values, 'supplierName');
      this.checkKey(values, 'programName');
      this.checkKey(values, 'programType');
      this.checkKey(values, 'coveredSales');
      this.checkKey(values, 'payment');
      this.checkKey(values, 'assessment');
      this.checkKey(values, 'payout');
      this.getPayoutDetails();
    } else if (this.userType === UserType.Distributor) {
      this.checkKey(values, 'VendorPiovtId');
      this.checkKey(values, 'VendorName');
      this.checkKey(values, 'ProgramType');
      this.checkKey(values, 'ProgramName');
      // this.checkKey(values,'coveredSales');
      // this.checkKey(values,'payout');
      this.getPayoutDetails();
    }

  }

  goToPageNumber = (event: any) => {
    let value = Math.ceil(this.totalCount / this.pagination['limit'])
    if (event <= value) {
      this.pagination['pageNo'] = parseInt(event);
      this.reqObject['limit'] = this.pagination['limit']
      this.reqObject['pageNo'] = this.pagination['pageNo']
      this.getPayoutDetails();
    } else {
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: { "type": "PageNo entered out of range." },
        disableClose: true,
      });
      setTimeout(() => {
        dialogRef.close()
      }, 2000)

      dialogRef.afterClosed().subscribe((result: any) => {
        if (this.dataSource && this.dataSource['data'] && this.dataSource['data'].length > 0) {
          this.dataSource['data'] = []
        }
        this.pagination['pageNo'] = 1;
        this.reqObject['limit'] = this.pagination['limit']
        this.reqObject['pageNo'] = this.pagination['pageNo']
        this.getPayoutDetails();
      })
    }
  }

  getNextPage = (event: any) => {
    this.pagination['pageNo'] = parseInt(event['pageIndex']) + 1
    this.reqObject['limit'] = this.pagination['limit']
    this.reqObject['pageNo'] = this.pagination['pageNo']
    this.getPayoutDetails();
  }

  selectedViewPageLimit = (limitValue: any) => {
    this.pagination['limit'] = parseInt(limitValue);
    this.selectedPageLimit = parseInt(limitValue);
    this.pagination['pageNo'] = 1;
    this.reqObject['limit'] = this.pagination['limit']
    this.reqObject['pageNo'] = this.pagination['pageNo']
    this.getPayoutDetails();
  }

  // Payout Event Detail Summary
  getPayoutDetails() {
    if (this.dataSource && this.dataSource['data'].length > 0 && this.pagination['pageNo'] == 1) {
      this.dataSource = new MatTableDataSource([])
    }
    this.populateHeaders();
    if (this.userType === UserType.Corporate) {
      this.httpService.fetchPayoutTicketDetails(this.reqObject).subscribe(response => {
        if (response && response['data']['count'] > 0) {
          this.totalCount = response && response['data']['count']
          this.populatePayoutData(response['data']['payoutTicketDetails']);
        }
      })
    } else if (this.userType === UserType.Distributor) {
      this.httpService.fetchDistributorPayoutEventSummary(this.reqObject).subscribe(response => {
        if (response && response['data']['count'] > 0) {
          this.totalCount = response && response['data']['count'];
          this.populatePayoutData(response['data']['payoutEventDetailSummary']);
        }
      })
    }
  }

  onExport = (payoutId: any) => {
    if (this.userType === UserType.Corporate) {
      const payoutObj = { payoutTicketNo: payoutId }
      this.httpService.fetchPayoutTicketDetails(payoutObj).subscribe(response => {
        if (response && response['data']['count'] === 0) {
          const dialogRef = this.dialog.open(ExportModalComponent, {
            width: '416px',
            height: '185px',
            panelClass: 'dialog-container-custom',
            data: { message: "No records found to export for the selected ticket" },

          });
          dialogRef.afterClosed().subscribe((result: any) => {
          });
        } else {
          //const allData = response?.data?.payoutTicketDetails;
          const allData  = this.mapPayoutData(response?.data?.payoutTicketDetails);
          if (allData.length > 0) {
            const headers = Object.keys(allData[0]);
            this.downloadFile(allData, headers, `${this.latestPayoutObj['payoutTicketName']}_Payout_${payoutId}`);
          }
        }
      })
    } else if (this.userType === UserType.Distributor) {
      const payoutObj = { payoutTicketNo: payoutId }
      this.httpService.fetchDistributorPayoutEventSummary(payoutObj).subscribe(response => {
        if (response && response['data']['count'] === 0) {
          const dialogRef = this.dialog.open(ExportModalComponent, {
            width: '416px',
            height: '185px',
            panelClass: 'dialog-container-custom',
            data: { message: "No records found to export for the selected ticket" },

          });
          dialogRef.afterClosed().subscribe((result: any) => {
          });
        } else {
          //const allData = response?.data?.payoutEventDetailSummary;
          const allData  = this.mapPayoutDataForDealer(response?.data?.payoutEventDetailSummary);
          const modifyData = allData.map((res:any)=>{
                if(res['programType'] == 'CJD'){
                  res['payout'] = '-';
                }
                return res;
          })
          if (modifyData.length > 0) {
            const headers = Object.keys(modifyData[0]);
            this.downloadFile(modifyData, headers, `${this.latestPayoutObj['payoutTicketName']}_Payout_${payoutId}`);
          }
        }
      })
    }
  }

  downloadFile(data: any, header: any, filename = 'data') {
    let csvData = this.resuableService.convertToCSV(data, header);
    let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
    const dialogRef = this.dialog.open(SucessMessageModalComponent, {
      width: '420px',
      height: '170px',
      data: { "type": `${filename} Exported successfully ${data.length} records.`, actionStatus: 'success' },
      disableClose: true
    });
  }

  onConfigure = () => {
    this.router.navigate([`/${this.tenantType}/payoutManagement/assessment-details`]);
  }

  checkKey(values: any, key: string) {
    if (values[key] != null && values[key] != "") {
      this.reqObject[key] = values[key]
      // isValueExists=1
    } else {
      if (this.reqObject.hasOwnProperty(key)) {
        delete this.reqObject[key]
      }
    }
  }

  navigateToMyDashboard =()=>{
    this.router.navigate([`/${this.tenantType}/my-dashboard`])
  }

  sortByColumnName = (data:any) =>{
    this.sort = this.dataSource.sort;
    // this.dataSource = new MatTableDataSource([])
    if(data['direction']){
      if(this.reqObject['sorting'] && this.reqObject['sorting'].length > 0){
        const isFound = this.reqObject['sorting'].find((row:any) => row['orderBy'] === data['active']);
        if(isFound){
          this.reqObject['sorting'] = this.reqObject['sorting'].map((row:any)=>{
            if(row['orderBy'] === data['active']){
              row['orderType'] = data['direction']
            }
            return row;
          })
        }
        else{
          this.reqObject['sorting'] = [{orderBy:data['active'],orderType:data['direction']}]
        }
      }else{
        this.reqObject['sorting'] = [{orderBy:data['active'],orderType:data['direction']}]

      }
    }else{
      if(this.reqObject.hasOwnProperty('sorting')){
        delete this.reqObject['sorting']
      }
    }
    this.getPayoutDetails();
  }

  mapPayoutData = (content: any) => {
    return content.map((row: any) => ({
      "Payout Ticket Number" : row['payoutTicketNo'] ? row['payoutTicketNo'] : 'NA',
      "Dealer Name"	: row['distributorname'] ? `"${row['distributorname'].replace('"','""')}"` : 'NA',
      "Dealer Pivot Id"	: row['dealerPivotId'] ? `"${row['dealerPivotId'].replace('"','""')}"` : 'NA',
      "Vendor Name"	: row['supplierName'] ? `"${row['supplierName'].replace('"','""')}"` : 'NA',
      "Venor Pivot Id"	: row['vendorPivotId'] ? `"${row['vendorPivotId'].replace('"','""')}"` : 'NA',
      "Program Name"	: row['programName'] ? `"${row['programName'].replace('"','""')}"` : 'NA',
      "Program Id"	: row['programId'] ? row['programId'] : 0,
      "Program Type"	: row['programType'] ? `"${row['programType'].replace('"','""').replace('_',' ')}"` : 'NA',
      "Covered Sales"	: row['coveredSales'] ? row['coveredSales'] : 0,
      "Payment"	: row['payment'] ? row['payment'] : 0,
      "Payout"	: row['payout'] ? row['payout'] : 0,
    }))
  }
  
  mapPayoutDataForDealer = (content: any) => {
    return content.map((row: any) => ({
      "Vendor Piovt Id" : row['VendorPiovtId'] ? row['VendorPiovtId'] : 'NA',
      "Vendor Name"	: row['VendorName'] ? `"${row['VendorName'].replace('"','""')}"` : 'NA',
      "Program Type"	: row['ProgramType'] ? `"${row['ProgramType'].replace('"','""').replace('_',' ')}"` : 'NA',
      "Program Name"	: row['ProgramName'] ? `"${row['ProgramName'].replace('"','""')}"` : 'NA',
      "Program Id"	: row['Program_Id'] ? row['Program_Id'] : 0,
      "Covered Purchases"	: row['CoveredPurchase'] ? row['CoveredPurchase'] : 0,
      "Payout"	: row['Payout'] ? row['Payout'] : 0
    }))
  }


}
