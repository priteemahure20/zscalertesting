import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PayoutManagementComponent } from './payout-management.component';
import { PayoutManagementRoutingModule } from './payout-management-routing.module';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { NgSelectModule } from '@ng-select/ng-select';
import { MentionModule } from 'angular-mentions';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { CommonCompsModule } from 'src/app/shared/common-comps.module';
import { MaterialModule } from 'src/app/shared/material.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { PayoutOverviewComponent } from './payout-overview/payout-overview.component';
import { CreatePayoutComponent } from './create-payout/create-payout.component';
import { PayoutDetailsComponent } from './payout-details/payout-details.component';
import { AssessentDetailsComponent } from './assessent-details/assessent-details.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { ScrollingModule } from '@angular/cdk/scrolling';



@NgModule({
  declarations: [
    PayoutManagementComponent,
    PayoutOverviewComponent,
    CreatePayoutComponent,
    PayoutDetailsComponent,
    AssessentDetailsComponent
  ],
  imports: [
    CommonModule,
    PayoutManagementRoutingModule,
    SharedModule,
    MaterialModule,
    CommonCompsModule,
    MatProgressBarModule,
    NgSelectModule,
    NgCircleProgressModule.forRoot({
      // set defaults here
      radius: 100,
      outerStrokeWidth: 16,
      outerStrokeColor: "#0BA0C1",
      animationDuration: 300,
    }),
    NgMultiSelectDropDownModule.forRoot(),
    InfiniteScrollModule,
    MentionModule,
    NgxSkeletonLoaderModule,
    ScrollingModule
  ]
})
export class PayoutManagementModule { }
