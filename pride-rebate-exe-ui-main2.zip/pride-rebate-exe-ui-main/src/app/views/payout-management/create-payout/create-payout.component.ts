import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { SucessMessageModalComponent } from 'src/app/common/sucess-message-modal/sucess-message-modal.component';
import { mapCreatePayout } from 'src/app/mapper/outbound/associate';
import { HttpService } from 'src/app/services/http.service';
import { ReusableService } from 'src/app/services/reusable.service';
import * as moment from 'moment';
import { SuccessErrorModalComponent } from 'src/app/common/success-error-modal/success-error-modal.component';
import { DataService } from 'src/app/services/data.service';
import { ExportModalComponent } from '../../report-generator/export-modal/export-modal.component';
import { YEAR } from 'src/app/helpers/constants';

@Component({
  selector: 'app-create-payout',
  templateUrl: './create-payout.component.html',
  styleUrls: ['./create-payout.component.scss']
})
export class CreatePayoutComponent implements OnInit {
  tenantType: any;
  lastUpdateDate: any;
  years = YEAR;
  selectedYear: any;
  programTypes: any = [];
  payoutForm = new FormGroup({
    lastFileDate: new FormControl('', [Validators.required]),
    programType: new FormControl('', [Validators.required]),
    exportTitle: new FormControl('', [Validators.required])
  });
  isSubmitted = false;
  isCorporateSelected: boolean = false;
  isCorporateSelected2: boolean = false;
  isDashedLine: boolean = false;
  isDashedLine2: boolean = false;
  resetFile = false;
  isButtonDisabled = false;
  isChooseFileDisabled=true;
  state = "edit";
  firstState = "done";
  secondState = "done";
  step = 1;
  public formData = new FormData();
  recentLastFileDate: any;
  dropdownSettings = {
    "singleSelection": false,
    "defaultOpen": false,
    "idField": "value",
    "textField": "displayText",
    "selectAllText": "Select All",
    "unSelectAllText": "UnSelect All",
    "enableCheckAll": true,
    "itemsShowLimit": 1,
    "allowSearchFilter": true
  };
  modifiedFileName: any;
  // step1Icon="circleDot";
  // step2Icon = "circleDot";
  constructor(private router: Router, private httpService: HttpService, private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer, private dialog: MatDialog,
    private resuableService: ReusableService, private dataService: DataService) {
    this.matIconRegistry.addSvgIcon("tickMarkCircle", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/tick-mark-cirlce.svg"))
    this.matIconRegistry.addSvgIcon("circleMark", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/circle-icon-stepper.svg"))
    this.matIconRegistry.addSvgIcon("circleDot", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/circle-dot.svg"));
  }

  ngOnInit(): void {
    const { lastFileDate } = this.dataService.getRecentPayout();
    if (lastFileDate) {
      this.recentLastFileDate = lastFileDate;
      localStorage.setItem("recentLastFileDate", this.recentLastFileDate)
    } else {
      if(localStorage.getItem('recentLastFileDate')) {
        const lastDate = new Date(String(localStorage.getItem('recentLastFileDate')));
        this.recentLastFileDate = new Date(lastDate.getTime() + 86400000);
      }
    }
    this.tenantType = localStorage.getItem('tenant')
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    let year = localStorage.getItem("year")
    if (!year) {
      this.selectedYear = new Date().getFullYear()
      localStorage.setItem("year", this.selectedYear)
    } else {
      this.selectedYear = parseInt(year)
    }
    this.getProgramTypes();
    this.firstState = 'edit';
  }

  navigateToHome = () => {
    this.router.navigate([`/${this.tenantType}/home`]);
  }

  navigateToPayoutMgmt = () => {
    this.router.navigate([`/${this.tenantType}/payoutManagement`]);
  }
  createPayout = () => {
    if (this.payoutForm.valid) {
      const formValue: any = mapCreatePayout(this.payoutForm.value);
      this.httpService.createPayout(formValue).subscribe(response => {
        if (response && response['data'] && response['data']['count'] == 0) {
          const dialogRef = this.dialog.open(ExportModalComponent, {
            width: '416px',
            height: '185px',
            panelClass: 'dialog-container-custom',
            data: { message: "No records found" },

          });
          dialogRef.afterClosed().subscribe((result: any) => {
          });
        } else {
          const { lastFileDate, exportTitle, programType } = response?.data;
          let date = new Date();
          const modifiedDate = moment(lastFileDate, 'YYYY-MM-DD').format('YYYYMMDD');
          //const fileName = `${modifiedDate}_${programType.toString().replace(',', '_')}_${exportTitle}`;
          const fileName = `${modifiedDate}${date.getHours()}${date.getMinutes()}${date.getSeconds()}_${exportTitle}`
          this.modifiedFileName  = fileName;
          const allData = this.mapPayoutData(response?.data?.payoutExportResult);
          if (allData.length > 0) {
            let headers = Object.keys(allData[0]);
            // this.payoutForm.reset();
            this.downloadFile(allData, headers, fileName);
            this.isChooseFileDisabled=false;
          }
        }
      })
    }
  }

  onDiscard = () => {
    if (this.step > 1) {
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '382px',
        height: '180',
        data: { "type": "Are you sure discard your changes ?" },
        disableClose: true,
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result != 'cancel') {
          this.router.navigate([`/${this.tenantType}/payoutManagement`]);
        }
      })
    } else {
      this.router.navigate([`/${this.tenantType}/payoutManagement`]);
    }
  }

  selectedYearOption = (value: any) => {
    if (value) {
      this.selectedYear = value;
      localStorage.setItem("year", this.selectedYear)
    }
  }

  selectDate(data: any) {

  }

  getProgramTypes = () => {
    this.httpService.fetchProgramType().subscribe((response: any) => {
      if (response && response['data']['program_types'].length > 0) {
        this.programTypes = response['data']['program_types'];
        this.recentLastFileDate = response['data']['date'];
        if(this.recentLastFileDate){
          const date1 = new Date( this.recentLastFileDate);
          let fullDate = (date1.getMonth()+1)+'-'+ date1.getDate()+'-'+ date1.getFullYear();
          const date2 = new Date();
          const parts = fullDate.split('-');
          const month = parseInt(parts[0]);
          date2.setFullYear(parseInt(parts[2]), month-1, parseInt(parts[1])); // year, month (0-based), day
          date2.setTime(date2.getTime() + 86400000);
          const finalMonth = (date2.getMonth() + 1) < 10 ? '0'+(date2.getMonth() + 1):(date2.getMonth() + 1)
          const finalDay = date2.getDate() < 10 ? '0'+date2.getDate():date2.getDate()
          this.recentLastFileDate = `${date2.getFullYear()+'-'+finalMonth+'-'+ finalDay}`;
        }
      }
    })
  }

  changeProgramType = (event: any) => { }

  uploadedFile = (file: any) => {
    if (file) {
      console.log("File", file);
      if (this.formData.has("file")) {
        this.formData.delete('file')
      }
      // const modifiedFile = this.renameFile(file,`123_${file['name']}`);
      // console.log("File Modified",modifiedFile);
      this.formData.append("file", file)
      console.log("Form Data", this.formData);
    }
  }

  renameFile(originalFile: any, newName: string) {
    return new File([originalFile], newName, {
      type: originalFile.type,
      lastModified: originalFile.lastModified,
    });
  }

  isDisabled = (event: any) => {
    if (this.step > 1) {
      this.isButtonDisabled = event;
    } else {
      this.isButtonDisabled = false;
    }
  }

  uploadFile = () => {
    const formValue: any = mapCreatePayout(this.payoutForm.value);
    if(formValue.hasOwnProperty('exportTitle')){
        formValue['fileName'] = this.modifiedFileName + '.csv';
    }
    this.resetFile = true;
    this.formData.append('ticketDetails', JSON.stringify(formValue));
    if (this.formData.has('file')) {
      this.httpService.uploadPayoutFile(this.formData).subscribe((response) => {
        if (response && response['data']['uploadResult']) {
          if (response['data']['uploadResult'] == 'successful') {
            //this.showSuccessOrError("Payout Event Created Successfully")
            const dialogRef = this.dialog.open(SucessMessageModalComponent, {
              width: '370px',
              height: '180px',
              data: { "type": `Payout Event Created Successfully`, actionStatus: 'success' },
              disableClose: true
            }).afterClosed().subscribe(() => {
              this.payoutForm.reset();
              this.navigateToPayoutMgmt();
            });
            this.dataService.notificationEmitter.emit(true)
          }

        }
      }, error => {
        this.showSuccessOrError("Error occured while uploading file")
      })
    }
    this.step = 3;
  }

  downloadFile(data: any, header: any, filename = 'data') {
    let csvData = this.resuableService.convertToCSV(data, header, false);
    let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
    const dialogRef = this.dialog.open(SucessMessageModalComponent, {
      width: '370px',
      height: '180',
      data: { "type": `File Downloaded successfully`, actionStatus: 'success' },
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      this.step = 2;
      this.secondState = 'edit';
    });
  }

  mapPayoutData = (content: any) => {
    return content.map((row: any) => ({
      "Dealer Name"	: row['DEALER_NAME'] ? `"${row['DEALER_NAME'].replace('"','""')}"` : 'NA',
      "Dealer Pivot Id" : row['PIVOT_ID'] ? `"${row['PIVOT_ID'].replace('"','""')}"` : 'NA',
      "Dealer GP Id"	: row['GP_ID'] ? `"${row['GP_ID'].replace('"','""')}"` : 'NA',
      "Vendor Name"	: row['PIVOT_NAME'] ? `"${row['PIVOT_NAME']}"` : 'NA',
      "Vendor Pivot Id"	: row['PIVOT_VENDOR_ID'] ? `"${row['PIVOT_VENDOR_ID'].replace('"','""')}"` : 'NA',
      "Vendor GP Id"	: row['VENDOR_GP_ID'] ? `"${row['VENDOR_GP_ID'].replace('"','""')}"` : 'NA',
      "Program Id"	: row['REBATE_PROGRAM_ID'] ? row['REBATE_PROGRAM_ID'] : 'NA',
      "Program Name"	: row['REBATE_PROGRAM_NAME'] ? `"${row['REBATE_PROGRAM_NAME']}"` : 'NA',
      "Program Type"	: row['REBATE_PROGRAM_TYPE'] ? `"${row['REBATE_PROGRAM_TYPE']}"` : 'NA',
      "Covered Purchase" : row['COVERED_PURCHASE'] ? this.resuableService.significantNumber(row['COVERED_PURCHASE']).replaceAll(',', '') : this.resuableService.significantNumber(0),
      "Rebate Earned"	: row['REBATE_EARNED'] ? this.resuableService.significantNumber(row['REBATE_EARNED']).replaceAll(',', '') : this.resuableService.significantNumber(0),
      "Rebate Pending" : row['REBATE_PENDING'] ? this.resuableService.significantNumber(row['REBATE_PENDING']).replaceAll(',', '') : this.resuableService.significantNumber(0),
      "Rebate Payout"	: row['REBATE_PAYOUT'] ? this.resuableService.significantNumber(row['REBATE_PAYOUT']).replaceAll(',', '') : this.resuableService.significantNumber(0),
    }))
  }

  showSuccessOrError = (message: any) => {
    if (message) {
      const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
        width: '370px',
        height: '180',
        data: { "type": message },
        disableClose: true,
      });

      dialogRef.afterClosed().subscribe(result => {
        if (result == 'ok') {
          this.router.navigate([`/${this.tenantType}/payoutManagement`]);
        }
      })
    }

  }
}
