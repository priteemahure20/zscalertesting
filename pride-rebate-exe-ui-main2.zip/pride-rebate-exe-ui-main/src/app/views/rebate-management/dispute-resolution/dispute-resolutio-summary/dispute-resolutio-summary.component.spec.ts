import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisputeResolutioSummaryComponent } from './dispute-resolutio-summary.component';

describe('DisputeResolutioSummaryComponent', () => {
  let component: DisputeResolutioSummaryComponent;
  let fixture: ComponentFixture<DisputeResolutioSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisputeResolutioSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisputeResolutioSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
