import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-dispute-resolutio-summary',
  templateUrl: './dispute-resolutio-summary.component.html',
  styleUrls: ['./dispute-resolutio-summary.component.scss']
})
export class DisputeResolutioSummaryComponent implements OnInit,OnChanges  {
  @Input() year:any;
  reviewObj: any;
  pendingObj: any;
  resolvedObj: any;
  pieChartData: any = [];
  tenantType: string | null = '';
  showSkeletonLoader:any = false;

  constructor(private httpService: HttpService,
    private router: Router,
    ) { }

  ngOnInit(): void {
    this.tenantType = localStorage.getItem('tenant');    
    this.getSummary(this.year);
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);
    const year = changes['year'].currentValue;
    this.getSummary(year);
  }
  
  getSummary(year:any) {
    this.showSkeletonLoader = true;
    this.httpService.getBgAdminPieChartData(year).subscribe((response:any)=>{
      if(response && response['data']){
        if(response['data']['summaryData']){
          let summaryObj = response['data']['summaryData']
          this.reviewObj ={ name: 'In Review', value: summaryObj['totalInReview'] ? summaryObj['totalInReview'] :0, color: '#F69C50'  }
          this.pendingObj ={ name: 'Pending', value: summaryObj['totalPending'] ? summaryObj['totalPending'] :0, color: '#59595A' }
          this.resolvedObj ={ name: 'Resolved', value: summaryObj['totalResolved'] ? summaryObj['totalResolved'] :0, color: '#24A148' }
          this.pieChartData.push(this.reviewObj)
          this.pieChartData.push(this.pendingObj)
          this.pieChartData.push(this.resolvedObj)
        }
      }
      this.showSkeletonLoader = false;
    })
  }

  private calculatePercentage(summaryObjElement1: any,summaryObjElement2: any,summaryObjElement3: any) {
    return ((summaryObjElement1/(summaryObjElement2+summaryObjElement1+summaryObjElement3))*100).toFixed(2);
  }

  navigateToDisputeResolution = () =>{
    this.router.navigate([`/${this.tenantType}/rebateManagement/dispute-resolution`]);
  }
}
