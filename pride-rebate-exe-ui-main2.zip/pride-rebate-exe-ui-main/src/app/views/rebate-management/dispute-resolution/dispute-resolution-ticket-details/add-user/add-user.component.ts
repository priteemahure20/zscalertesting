import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {MatIconRegistry} from '@angular/material/icon';
import {DomSanitizer} from '@angular/platform-browser';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {
  filterClear =  false
  addUserGroup!: FormGroup;
  userEmails:any=[]
  userType:any;
  buttonValue:any=''
  header:any=''
  constructor(public dialogRef: MatDialogRef<AddUserComponent>,@Inject(MAT_DIALOG_DATA) public data: {tenent: string,userContent:any,type:any},private fb:FormBuilder) { }

  ngOnInit(): void {
    this.addUserGroup = this.fb.group({
      emailId: new FormControl('', [Validators.required, Validators.pattern('^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$')]),
    })
    this.userEmails = this.data['userContent']
    this.userType = this.data['type']
    if(this.userType=='add'){
      this.buttonValue = 'Add';
      this.header = 'Add User'
    }else {
      this.buttonValue = 'Assign';
      this.header = 'Assign User'
    }
  }

  addEmail = () =>{
    if(this.addUserGroup.valid){
      this.dialogRef.close({type:this.userType,value:this.addUserGroup.value['emailId']});
    }
  }

}
