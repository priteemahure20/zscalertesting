import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material/dialog';
import {MatIconRegistry} from '@angular/material/icon';
import {DomSanitizer} from '@angular/platform-browser';
import {get as _get} from 'lodash';
import {HttpService} from '../../../../../services/http.service';
import {MatSnackBar} from '@angular/material/snack-bar';
import {SuccessErrorModalComponent} from '../../../../../common/success-error-modal/success-error-modal.component';
import { ReusableService } from 'src/app/services/reusable.service';

@Component({
  selector: 'app-view-list-modal',
  templateUrl: './view-list-modal.component.html',
  styleUrls: ['./view-list-modal.component.scss']
})
export class ViewListModalComponent implements OnInit {

  type:any;
  list:any=[];
  addUser1 = '../../../../../../assets/pngs/add-user-1.png';
  addUser2 = '../../../../../../assets/pngs/add-user-2.png';
  addUser3 = '../../../../../../assets/pngs/add-user-3.png';
  addUser4 = '../../../../../../assets/pngs/add-user-4.png';
  excel = '../../../../../../assets/pngs/excel-img.png';
  pdf = '../../../../../../assets/pngs/pdf-img.png';

  usersIcons = [this.addUser1,this.addUser2,this.addUser3,this.addUser4]
  constructor(public dialogRef: MatDialogRef<ViewListModalComponent>,@Inject(MAT_DIALOG_DATA) public data: {type: string,dataList:any},
              private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer,private httpService: HttpService, private snackBar: MatSnackBar,public dialog: MatDialog,
              private reusableService: ReusableService) {
    this.matIconRegistry.addSvgIcon("close", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/close.svg"))
    this.matIconRegistry.addSvgIcon("download", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/download.svg"))


  }

  ngOnInit(): void {
    this.type = this.data['type'];
    this.list = this.data['dataList'];
    if(this.type =='users'){
      this.addIconsToList()
    }
  }
  close(): void {
    this.dialogRef.close(1);
  }

  getIcon = () =>{
    const random = Math.floor(Math.random() * this.usersIcons.length);
    return this.usersIcons[random]
  }

  private addIconsToList() {
    for(let i=0;i<this.list.length;i++){
      this.list[i]['icon'] = this.getIcon()
    }
  }

  downloadFile(value: any) {
    const name = value;
    this.httpService.downloadTicketAttachment({ name }).subscribe(
        (response: any) => {
          const dataType = response.type;
          const binaryData = [];
          binaryData.push(response);
          const downloadLink = document.createElement('a');
          downloadLink.href = window.URL.createObjectURL(
              new Blob(binaryData, { type: dataType })
          );
          if (name) {
            downloadLink.setAttribute('download', name);
          }
            this.dialog.closeAll();
          document.body.appendChild(downloadLink);
          downloadLink.click();
            const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
                width: '450px',
                height: '194',
                data: { "type": "Transaction Detail has been downloaded successfully" },
                disableClose: true,
            });
            setTimeout(()=>{
                dialogRef.close();
            },5000)
        },
        (error) => {
          const errorMessage =
              _get(error, 'error.message') ||
              _get(error, 'message') ||
              'Download failed';
          // this.snackBar.open(errorMessage, 'Ok', {
          //   duration: 2000,
          // });
            const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
                width: '450px',
                height: '194',
                data: { "type": "Download Failed" },
                disableClose: true,
            });
        }
    );
  }
  download(value: any) {
    this.reusableService.throttle(() => {
      this.downloadFile(value);
    })
  }
    checkNameLength = (name: any) => {
        if (name && name.length > 30) {
            return name = name.substring(0, 30) + "...";
        } else {
            return name
        }
    }
}
