import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpService } from '../../../../services/http.service';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { AddUserComponent } from './add-user/add-user.component';
import { UploadFileComponent } from './uploadFile/upload-file.component';
import * as moment from 'moment';
import { UserType } from 'src/app/helpers/constants';
import { SuccessErrorModalComponent } from '../../../../common/success-error-modal/success-error-modal.component';
import { ViewListModalComponent } from './view-list-modal/view-list-modal.component';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-dispute-resolution-ticket-details',
  templateUrl: './dispute-resolution-ticket-details.component.html',
  styleUrls: ['./dispute-resolution-ticket-details.component.scss']
})
export class DisputeResolutionTicketDetailsComponent implements OnInit {
  rbacBgUserLogged: boolean = false;

  selectedStatus: any;
  status = [{ displayText: 'In Review', value: 'in review' }, { displayText: 'Pending', value: 'pending' }, { displayText: 'Resolved', value: 'resolved' }]
  excel = '../../../../../assets/pngs/excel-img.png';
  pdf = '../../../../../assets/pngs/pdf-img.png';
  addUser1 = '../../../../../assets/pngs/add-user-1.png';
  addUser2 = '../../../../../assets/pngs/add-user-2.png';
  addUser3 = '../../../../../assets/pngs/add-user-3.png';
  usersList: any = []
  tenant: any;
  ticketId: any;
  ticketInfo: any;
  userListLength: any = 0;
  attachmnetListLength: any = 0
  ticketDetails: any;
  ticketStatus: any;
  ticketAttachmentList: any = [];
  allTicketAttachmentList: any = []
  totalTicketAttachments: any = []
  userContent: any = [];
  messagesObj: any = [];
  allUsersList: any = [];

  isEffectiveDateToggled: boolean = true;
  userList: any = ['Shashank Dubey', 'Ayudh Nanda', 'Jai vardhan'];
  userType: any = ""
  userGroupId: any = ""
  addUsersList: any = []
  assignedToUserContent: any = [];
  modifiedAssignedUsers: any = [];
  pageLimit: any = {
    page: 1,
    pageSize: 20
  };
  messagesObjList: any = [];
  isScroll:any = false;
  isChatDisplay:boolean = true
  constructor(private matIconRegistry: MatIconRegistry, private domSanitizer: DomSanitizer,
    private httpService: HttpService, public router: Router, public activatedRoute: ActivatedRoute, public dialog: MatDialog, private authService:AuthService) {
    this.matIconRegistry.addSvgIcon("close", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/close.svg"))
    this.matIconRegistry.addSvgIcon("attachment", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/add-attachment.svg"))
    this.matIconRegistry.addSvgIcon("comment", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/comment-icon.svg"))
    this.matIconRegistry.addSvgIcon("back-arrow", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/back-arrow.svg"))
    this.matIconRegistry.addSvgIcon("add-user-1", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/add-user-1.svg"))
    this.matIconRegistry.addSvgIcon("add-user-2", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/add-user-1.svg"))
    this.matIconRegistry.addSvgIcon("add-user-3", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/add-user-1.svg"))
    this.matIconRegistry.addSvgIcon("edit", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/modify.svg"))

    this.matIconRegistry
      .addSvgIcon("email-view", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/email-icon.svg"))
      .addSvgIcon("user-icon", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/circleUser-icon.svg"))
      .addSvgIcon("user-msg-sent-icon", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../assets/img/icons/user-msg-sent-icon.svg"))

  }

  ngOnInit(): void {
    this.tenant = localStorage.getItem('tenant');
    // this.userType = localStorage.getItem('userType');
    this.userType = this.authService.getUser()?.userType;

    this.applyRBAC();

    this.userGroupId = localStorage.getItem('userGroupId')
    this.activatedRoute.paramMap.subscribe((params: any) => {
      this.ticketId = parseInt(params['params']['ticketId']);
      this.ticketStatus = params['params']['status'];
      if (this.ticketId) {
        this.getTicketInformation(this.ticketId, this.ticketStatus);
      }

      // if (this.userType == 'CORPORATE') {
      //   let payLoad = {
      //     "tenant_id": this.tenant,
      //     "user_group_id": [parseInt(this.userGroupId)]// raised by and raised against group ids comma separated
      //   }
      //   this.getUserDataBasedOnLoggedInType(payLoad, 'addUserType')
      // } else {
      //   let payLoad = {
      //     "user_group_id": [parseInt(this.userGroupId)]
      //   }
      //   this.getUserDataBasedOnLoggedInType(payLoad, 'addUserType')
      // }
      // let assignedToPayLoad = {
      //   "tenant_id": this.tenant,
      // }
      // this.getUserDataBasedOnLoggedInType(assignedToPayLoad, 'assignedUserType');

      this.ticketAttachment({ 'ticketNo': this.ticketId });
      this.activitiesComment({ 'ticketNo': this.ticketId }, this.pageLimit);
    })
  }
  applyRBAC() {
    this.rbacBgUserLogged = this.userType === UserType.Corporate;
  }
  navigateBack = () => {
    this.router.navigate([`/${this.tenant}/rebateManagement/dispute-resolution`]);
  }
  private getTicketInformation(ticketId: any, ticketStatus: any) {
    this.httpService.getBgAdminTicketDetails({ "ticketNo": ticketId }).subscribe((response: any) => {
      this.ticketDetails = response['data'];
      this.populateTicketInfo({
        heading: this.ticketDetails && this.ticketDetails['title'] ? this.ticketDetails['title'] : 'NA',
        summary: this.ticketDetails && this.ticketDetails['description'] ? this.ticketDetails['description'] : 'NA',
        createdOn: this.ticketDetails && this.ticketDetails['created_date'] ? this.changeDateFormat(this.ticketDetails['created_date']) : 'NA',
        updatedOn: this.ticketDetails && this.ticketDetails['updated_date'] ? this.changeDateFormat(this.ticketDetails['updated_date']) : 'NA',
        status: this.ticketDetails && this.ticketDetails['status'] ? this.ticketDetails['status'] : 'NA',
        raisedBy: this.ticketDetails && this.ticketDetails['raised_by_name'] ? this.ticketDetails['raised_by_name'] : 'NA',
        raisedAganist: this.ticketDetails && this.ticketDetails['raised_against_name'] ? this.ticketDetails['raised_against_name'] : 'NA',
        assignedTo: this.ticketDetails && this.ticketDetails['assigned_to_name'] ? this.ticketDetails['assigned_to_name'] : 'NA',
        assignedToId: this.ticketDetails && this.ticketDetails['assigned_to_id'] ? this.ticketDetails['assigned_to_id'] : 'NA',
        ticketId: this.ticketDetails && this.ticketDetails['ticket_no'] ? this.ticketDetails['ticket_no'] : 'NA',
        dueDate: this.ticketDetails && this.ticketDetails['due_date'] ? this.changeDateFormat(this.ticketDetails['due_date']) : 'NA',
        attachments: [],
        userGroupEmail: this.ticketDetails && this.ticketDetails['user_group_email'] ? this.ticketDetails['user_group_email'] : 'NA',
        users: this.ticketDetails.usersInfo
      });
      if (this.userType == 'CORPORATE') {
        let payLoad = {
          "tenant_id": this.tenant,
          "user_group_id": [parseInt(this.userGroupId)],
          "userType": ["corporate", "distributor"]
        }
        this.getUserDataBasedOnLoggedInType(payLoad, 'addUserType')
      } else {
        let payLoad = {
          "user_group_id": [parseInt(this.userGroupId),parseInt(this.ticketDetails['assigned_to_id'])]
        }
        this.getUserDataBasedOnLoggedInType(payLoad, 'addUserType')
      }
      let assignedToPayLoad = {
        "tenant_id": this.tenant,
      }
      this.getUserDataBasedOnLoggedInType(assignedToPayLoad, 'assignedUserType');

    });
  }

  private populateTicketInfo(param: any) {
    this.ticketInfo = param;
    //console.log('>>>',this.ticketInfo)
    this.selectedStatus = this.ticketInfo['status']
    if (this.ticketInfo && this.ticketInfo['users']) {
      this.populateUsersList(this.ticketInfo['users'])
    }

  }
  selectedStatusOption = (statusValue: any) => {
    let saveStatus = {
      "ticketNo": this.ticketId,
      "status": statusValue,
    }

    this.httpService.editTicketDetails(saveStatus).subscribe((response: any) => {
      if (response && response['data'] && response['data']['code'] == 1) {
        if (statusValue == 'resolved') {
          let message = `Ticket no.- ${this.ticketId}, Dashboard shows lower rebates than expected has been ${statusValue} sucessfully`
          const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
            width: '450px',
            height: '194',
            data: { "type": message },
            disableClose: true,
          });
        }

      }

    })
  }

  populateUsersList = (userList: any) => {
    if (userList.length > 0) {
      let count = 0
      for (let i = 0; i < userList.length; i++) {
        let obj = {
          displayText: userList[i]['name'],
          value: userList[i]['email']
        }
        if (i < 3) {
          this.usersList.push(obj)
        } else {
          count = count + 1;
        }
        this.allUsersList.push(obj)
      }
      this.userListLength = count

    } else {
      this.userListLength = 0
    }
  }
  populateAttachmentsList = (attachmentList: any) => {
    this.totalTicketAttachments = []
    this.ticketAttachmentList = []
    this.attachmnetListLength = 0
    if (attachmentList.length > 0) {
      let count = 0
      for (let i = 0; i < attachmentList.length; i++) {
        let obj = {
          fileName: attachmentList[i]['filename'] ? attachmentList[i]['filename'] : 'NA',
          fileType: attachmentList[i]['fileType'] ? attachmentList[i]['fileType'] : 'NA',
          uploadBy: attachmentList[i]['uploadedBy'] ? attachmentList[i]['uploadedBy'] : 'NA',
          uploadDate: attachmentList[i]['uploadedDate'] ? this.changeDateFormat(attachmentList[i]['uploadedDate']) : 'NA',
          downloadURL: attachmentList[i]['downloadUrl'] ? attachmentList[i]['downloadUrl'] : 'NA'
        }
        if (i < 4) {
          this.ticketAttachmentList.push(obj)
        } else {
          count = count + 1;
        }
        this.totalTicketAttachments.push(obj)
      }
      this.attachmnetListLength = count

    } else {
      this.attachmnetListLength = 0
    }
  }
  addUserToList = (type: any) => {
    const dialogRef = this.dialog.open(AddUserComponent, {
      width: '268px',
      height: '170px',
      disableClose: false,
      data: { "tenent": this.tenant, userContent: type == 'add' ? this.userContent : this.modifiedAssignedUsers, type: type },
      panelClass: 'dialog-container-custom'
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result && result['value']) {
        if (result['type'] == 'add') {
          let getUserData = this.getMatchedAddUser(result['value'])
          if (getUserData && getUserData['email']) {
            let allEmails = this.ticketInfo['userGroupEmail']
            let isEmailAppended = allEmails.indexOf(getUserData['email']) != -1;
            if (!isEmailAppended) {
              let addUser = {
                "ticketNo": this.ticketId,
                "user_group_email": this.ticketInfo && this.ticketInfo['userGroupEmail'] ? this.ticketInfo['userGroupEmail'] + '|' + getUserData['email'] : getUserData['email'],
              }
              this.httpService.editTicketDetails(addUser).subscribe((response: any) => {
                if (response && response['data'] && response['data']['code'] == 1) {
                  // this.populateUsersList([result['value']])
                  let obj = {
                    displayText: getUserData['name'],
                    value: getUserData['email']
                  }
                  if (this.usersList.length < 3) {
                    this.usersList.push(obj)
                  } else {
                    this.userListLength = this.userListLength + 1
                  }
                  this.allUsersList.push(obj)
                    this.isChatDisplay = false
                  setTimeout(()=>{
                    this.isChatDisplay = true
                  },300)
                }
              })
            } else {
              const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
                width: '450px',
                height: '194',
                data: { "type": "This user is added already" },
                disableClose: true,
              });
            }
          } else {
            const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
              width: '450px',
              height: '194',
              data: { "type": "User not found" },
              disableClose: true,
            });
          }



        } else {
          let getUserData = this.getMatchedUser(result['value'])
          if (getUserData) {
            let saveAssignedTo = {
              "ticketNo": this.ticketId,
              "assignedToId": getUserData['user_id'],
              "assignedToName": getUserData['name'],
            }
            this.httpService.editTicketDetails(saveAssignedTo).subscribe((response: any) => {
              if (response && response['data'] && response['data']['code'] == 1) {
                this.ticketInfo['assignedTo'] = getUserData['name']
              }
            })
          } else {
            const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
              width: '450px',
              height: '194',
              data: { "type": "User not found" },
              disableClose: true,
            });
          }

        }

      }
    })
  }

  activitiesComment = (ticketID: any, pageLimit: any) => {
    this.httpService.getActivitiesComment(ticketID, pageLimit).subscribe((response: any) => {
      this.messagesObj = response['data']['comments'];
      this.messagesObjList = this.messagesObj;
    });
  }

  ticketAttachment = (ticketId: any) => {
    this.httpService.getTicketAttachments(ticketId).subscribe((response: any) => {
      this.allTicketAttachmentList = response['data']['attachmentsList'];
      this.populateAttachmentsList(this.allTicketAttachmentList)
    });
  }

  selectedMessage = (item: any) => {
    this.httpService.sendActivitiesComment({ 'ticketNo': this.ticketId, 'text': item.text }).subscribe((response: any) => {
      let obj = {
        'commentDate':response['data'].comment_date,
        'commentText':response['data'].comment_text,
        'firstName':response['data'].firstName,
        'lastName':response['data'].lastName,
        'incoming':false,
        'userType':response['data'].userType
      }
      this.messagesObjList.push(obj);
      setTimeout(()=>{
        const El = document.getElementById('chatMsg') as HTMLInputElement;
        El.scrollTo({top: El.scrollHeight, behavior: 'smooth'});
      },1000);
    });
  }

  private populateAddUserData(addUsersList: any, userType: any) {
    for (let i = 0; i < addUsersList.length; i++) {
      let obj = {
        displayText: addUsersList[i]['name'],
        value: addUsersList[i]['email']
      }
      if (userType == 'addUserType') {
        this.userContent.push(obj)
      } else {
        this.modifiedAssignedUsers.push(obj)
      }

    }
  }

  private getUserDataBasedOnLoggedInType(payLoad: any, userType: any) {
    this.httpService.getUserDataForTickets(payLoad).subscribe((response: any) => {
      if (response && response['data'] && response['data']['userList'] && response['data']['userList'].length > 0) {
        if (userType == 'addUserType') {
          this.addUsersList = response['data']['userList'];
          this.populateAddUserData(this.addUsersList, userType)
        } else {
          this.assignedToUserContent = response['data']['userList'];
          this.populateAddUserData(this.assignedToUserContent, userType)
        }

      }
    })
  }
  selectDate = (event: any) => {
    if (event.target.value) {
      let saveDate = {
        "ticketNo": this.ticketId,
        "dueDate": moment.utc(event.target.value).local().format('YYYY-MM-DD') + this.appendTimeStamp()
      }
      this.httpService.editTicketDetails(saveDate).subscribe((response: any) => {
        if (response && response['data'] && response['data']['code'] == 1) {
          this.ticketInfo['dueDate'] = this.changeDateFormat(saveDate['dueDate'])
        }
      })

    }
  }
  onClose = (event: any) => {

  }
  changeDateFormat = (date: any) => {
    return moment.utc(date).local().format('MM/DD/YYYY')
  }
  appendTimeStamp = () => {
    return 'T00:00:00.000Z'
  }

  private getMatchedUser(resultElement: any) {
    return this.assignedToUserContent.find((obj: any) => {
      if (obj['email'] == resultElement) {
        return obj
      } else {
        return undefined
      }
    })
  }
  private getMatchedAddUser = (resultElement: any) => {
    return this.addUsersList.find((obj: any) => {
      if (obj['email'] == resultElement) {
        return obj
      } else {
        return undefined
      }
    })
  }
  viewAll = (type: any) => {
    let obj: any = {};
    if (type == 'users') {
      obj['type'] = type
      obj['dataList'] = this.allUsersList

    } else {
      obj['type'] = type
      obj['dataList'] = this.totalTicketAttachments
    }

    const dialogRef = this.dialog.open(ViewListModalComponent, {
      width: '450px',
      height: '463px',
      data: obj,
      disableClose: true,
    });

  }

  uploadFiles = (item: any) => {
    const dialogRef = this.dialog.open(UploadFileComponent, {
      width: '568px',
      height: '270px',
      disableClose: true,
      data: { "ticketId": this.ticketId },
      panelClass: 'dialog-container-custom'
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result !== 1) {
        this.httpService.getTicketAttachments({ 'ticketNo': result.ticketId }).subscribe((response: any) => {
          this.ticketAttachment({ 'ticketNo': this.ticketId })
          if (this.ticketAttachmentList.length < 4) {
            this.ticketAttachmentList.push(result);
          } else {
            this.attachmnetListLength = this.attachmnetListLength + 1
          }
        });
      }
    })
  }

  scrollToUp = () => {
    this.pageLimit['page'] = ++this.pageLimit['page'];
    this.httpService.getActivitiesComment({ 'ticketNo': this.ticketId }, this.pageLimit).subscribe((response: any) => {
      if (response['data']['comments'].length > 0) {
        this.messagesObj = response['data']['comments'];
        this.messagesObjList.unshift(...this.messagesObj);
      }
    });
  }

  getStatus(value: string) {
    const found = this.status.find(s => s.value === value);
    return found?.displayText;
  }
  // changeDateFormat = (date:any) =>{
  //   return moment.utc(date).local().format('MM/DD/YYYY')
  // }
}
