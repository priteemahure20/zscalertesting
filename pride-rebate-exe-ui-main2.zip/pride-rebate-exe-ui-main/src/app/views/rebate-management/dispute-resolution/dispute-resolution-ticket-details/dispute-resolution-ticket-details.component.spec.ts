import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisputeResolutionTicketDetailsComponent } from './dispute-resolution-ticket-details.component';

describe('DisputeResolutionTicketDetailsComponent', () => {
  let component: DisputeResolutionTicketDetailsComponent;
  let fixture: ComponentFixture<DisputeResolutionTicketDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisputeResolutionTicketDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisputeResolutionTicketDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
