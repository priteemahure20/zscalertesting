import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpService } from '../../../../../services/http.service';
import { get as _get, reduce as _reduce, isEqual as _isEqual, isEmpty as _isEmpty } from 'lodash';
import { MatSnackBar } from '@angular/material/snack-bar';
import { SuccessErrorModalComponent } from '../../../../../common/success-error-modal/success-error-modal.component';

@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.scss']
})
export class UploadFileComponent implements OnInit {
  ticketId: any;
  file: any;
  fileType: any;

  constructor(public dialogRef: MatDialogRef<UploadFileComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { ticketId: any }, private httpService: HttpService,
    public activatedRoute: ActivatedRoute, private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer, private snackBar: MatSnackBar, public dialog: MatDialog) {
    this.matIconRegistry.addSvgIcon("close", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../../../../assets/img/icons/close.svg"))
  }

  ngOnInit(): void {
  }

  uploadFile = (e: any) => {
    e.preventDefault();
    if (this.file !== undefined) {
      let formData = new FormData();
      formData.append('file', this.file);
      formData.append('ticketNo', this.data.ticketId);
      const extractedFileNameArray = _get(this.file, 'name').split('.');
      const fileExtension = extractedFileNameArray.pop();
      formData.append('attachmentType', fileExtension);
      this.fileType = fileExtension
      this.httpService.uploadFile(formData).subscribe((response: any) => {
        const dialogRef = this.dialog.open(SuccessErrorModalComponent, {
          width: '450px',
          height: '194',
          data: { "type": "Successfully file uploaded" },
          disableClose: true,
        });
        setTimeout(() => {
          dialogRef.close();
        }, 5000);
        this.dialogRef.close({ ticketId: this.data.ticketId, file: this.file, fileType: this.fileType });
      });
    } else {
      this.snackBar.open('Please select file to upload', 'Ok', {
        duration: 2000,
      });
    }
  }

  fileInputChange = ($event: any) => {
    this.file = $event.target.files['0'];
  }

  close(): void {
    this.dialogRef.close(1);
  }
}
