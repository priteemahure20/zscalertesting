import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewListModalComponent } from './view-list-modal.component';

describe('ViewListModalComponent', () => {
  let component: ViewListModalComponent;
  let fixture: ComponentFixture<ViewListModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewListModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewListModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
