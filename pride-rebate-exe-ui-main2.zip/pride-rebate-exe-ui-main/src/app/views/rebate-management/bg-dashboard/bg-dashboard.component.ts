import { Component, OnInit } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { toUpper } from 'lodash';
import { YEAR } from 'src/app/helpers/constants';
// import { canShowDisputeResolution, canShowFinancialHealth, canShowRebateGovernance, canShowRebateLibrary, canShowRebateOptimization, canShowWeeklyLoginReport } from 'src/app/rbac/KPIs/bg-dashboard';
import { BgDashboardService } from 'src/app/rbac/KPIs/bg-dashboard.service';
import { DataService } from 'src/app/services/data.service';
import {HttpService} from '../../../services/http.service';

@Component({
  selector: 'app-bg-dashboard',
  templateUrl: './bg-dashboard.component.html',
  styleUrls: ['./bg-dashboard.component.scss']
})
export class BgDashboardComponent implements OnInit {

  financialImg = '../../../assets/pngs/financial.PNG';
  rebateOpt = '../../../assets/pngs/rebate-opt.JPG';
  unlockIcon = '../../../assets/img/icons/rebate-unlock.svg';
  totalPurchase: any = 2000000000
  totalRebate: any = 20000000
  missedOppurtunity: any = 50000000
  optimizationValue = 40;
  supplierValue = 20;
  distributorValue = 20;
  tenantType: any;
  unLockRequest: any = ['Supplier 1', 'Supplier 2', 'Supplier 3', 'Supplier 4', 'Supplier 5'];
  pieChartData: any = [];
  reviewObj:any;
  pendingObj:any;
  resolvedObj:any;
  rebateGovUnlockCnt=0;
  rebateGovActivateCnt=0
  rebateGovDeActivateCnt=0;
  selectedYear:any;
  totalRebateLibrary:any=0;
  approvedRebate:any=0;
  inReviewRebate:any=0;
  pendingRebate:any=0;
  totalRebateLibraryPercent:any=0;
  approvedRebatePercent:any=0;
  inReviewRebatePercent:any=0;
  pendingRebatePercent:any=0;
  showDisputeResolution: boolean = true;
  showRebateGovernance: boolean = true;
  showRebateLibrary: boolean = true;
  showFinancialHealth: boolean = true;
  showRebateOptimization: boolean = true;
  showWeeklyLoginReport: boolean = true;
  lastUpdateDate:any;
  // selectedYear:any;
  years = YEAR;
  constructor(private domSanitizer: DomSanitizer, private matIconRegistry: MatIconRegistry, public router: Router,
    public activatedRoute: ActivatedRoute,private httpService: HttpService,
    private bgDashboardRbacService: BgDashboardService,
    private dataService: DataService) {

    this.matIconRegistry.addSvgIcon("settings", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/setting-icon.svg"));
    this.matIconRegistry.addSvgIcon("unlockIcon", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/rebate-unlock.svg"))
    this.matIconRegistry.addSvgIcon("active", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/gov-active.svg"))
    this.matIconRegistry.addSvgIcon("de-active", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/gov-deactive.svg"))
    this.matIconRegistry.addSvgIcon("unlock", this.domSanitizer.bypassSecurityTrustResourceUrl("../../../assets/img/icons/gov-unlock.svg"))

  }

  ngOnInit(): void {
    this.subjectsUpdate();
    // this.applyRBAC();
    this.tenantType = localStorage.getItem('tenant')
    let date = new Date()
    // this.selectedYear = date.getFullYear();
    let year = localStorage.getItem("year")
    if(!year){
      this.selectedYear =new Date().getFullYear()
      localStorage.setItem("year",this.selectedYear)
    }else {
      this.selectedYear = parseInt(year)
    }
    this.getStatusData({year:this.selectedYear});
    this.httpService.getBgAdminPieChartData(this.selectedYear).subscribe((response:any)=>{
      if(response && response['data']){
        if(response['data']['summaryData']){
          let summaryObj = response['data']['summaryData']
           this.reviewObj ={ name: 'In Review', value: this.calculatePercentage(summaryObj['totalInReview'],summaryObj['totalPending'],summaryObj['totalResolved'])? this.calculatePercentage(summaryObj['totalInReview'],summaryObj['totalPending'],summaryObj['totalResolved']):0, color: '#F69C50',actualValue:summaryObj['totalInReview']?summaryObj['totalInReview']:0  }
          this.pendingObj ={ name: 'Pending', value: this.calculatePercentage(summaryObj['totalPending'],summaryObj['totalInReview'],summaryObj['totalResolved'])?this.calculatePercentage(summaryObj['totalPending'],summaryObj['totalInReview'],summaryObj['totalResolved']):0, color: '#59595A',actualValue:summaryObj['totalPending']?summaryObj['totalPending']:0 }
          this.resolvedObj ={ name: 'Resolved', value: this.calculatePercentage(summaryObj['totalResolved'],summaryObj['totalPending'],summaryObj['totalInReview'])?this.calculatePercentage(summaryObj['totalResolved'],summaryObj['totalPending'],summaryObj['totalInReview']):0, color: '#24A148',actualValue:summaryObj['totalResolved']?summaryObj['totalResolved']:0 }
          this.pieChartData.push(this.reviewObj)
          this.pieChartData.push(this.pendingObj)
          this.pieChartData.push(this.resolvedObj)

        }
      }
    })
    this.httpService.getRebateGovernanceDefaultCounts('in review',this.selectedYear).subscribe((response:any)=>{
      if(response && response['data'].length>0){
        let data = response['data']
        this.rebateGovUnlockCnt =data[0]['cnt'];
        this.rebateGovActivateCnt =data[1]['cnt'];
        this.rebateGovDeActivateCnt =data[2]['cnt']
      }
    })
    this.lastUpdateDate = localStorage.getItem('lastUpdatedDate');
    }

  subjectsUpdate() {
    this.dataService.rbacConfigReceivedSubject.subscribe(
      data => {
        // this.applyRBAC();
      }
    );
  }

  applyRBAC() {
    this.showDisputeResolution = this.bgDashboardRbacService.canShowDisputeResolution();
    this.showRebateLibrary = this.bgDashboardRbacService.canShowRebateLibrary();
    this.showRebateGovernance = this.bgDashboardRbacService.canShowRebateGovernance();
    this.showFinancialHealth = this.bgDashboardRbacService.canShowFinancialHealth();
    this.showRebateOptimization = this.bgDashboardRbacService.canShowRebateOptimization();
    this.showWeeklyLoginReport = this.bgDashboardRbacService.canShowWeeklyLoginReport();

    // throw new Error('Method not implemented.');
  }


  abbreviateNumber = (value: any) => {
    return new Intl.NumberFormat('en-US', {
      //@ts-ignore
      notation: "compact",
      compactDisplay: "short",
      style: "currency",
      currency: "USD",
    }).format(value);
  }

  private getStatusData = (body:any) => {
    this.httpService.getRebateProgramPrecis(body).subscribe((response:any)=>{
      if(response && response['data']){
        this.totalRebateLibrary = response['data']['totalPrograms']?response['data']['totalPrograms']:0
        this.approvedRebate = response['data']['totalApproved']?response['data']['totalApproved']:0
        this.inReviewRebate = response['data']['totalInReview']?response['data']['totalInReview']:0
        this.pendingRebate = response['data']['totalPending']?response['data']['totalPending']:0
        this.totalRebateLibraryPercent = response['data']['totalPrograms']?
            this.calculateRebatePercentage(
                response['data']['totalPrograms'],
                response['data']['totalApproved']?response['data']['totalApproved']:0,
                response['data']['totalInReview']?response['data']['totalInReview']:0,response['data']['totalPending']?response['data']['totalPending']:0):0

        this.approvedRebatePercent =  response['data']['totalApproved']?
            this.calculateRebatePercentage(
                response['data']['totalApproved']?response['data']['totalApproved']:0,
            response['data']['totalPrograms']?response['data']['totalPrograms']:0,response['data']['totalInReview']?response['data']['totalInReview']:0,
            response['data']['totalPending']?response['data']['totalPending']:0):0
        this.inReviewRebatePercent = response['data']['totalInReview']?
            this.calculateRebatePercentage(
                response['data']['totalInReview']?response['data']['totalInReview']:0,
            response['data']['totalPrograms']?response['data']['totalPrograms']:0,response['data']['totalApproved']?response['data']['totalApproved']:0,
                response['data']['totalPending']?response['data']['totalPending']:0):0
        this.pendingRebatePercent =  response['data']['totalPending']?
            this.calculateRebatePercentage(
                response['data']['totalPending']?response['data']['totalPending']:0,
            response['data']['totalPrograms']?response['data']['totalPrograms']:0,
            response['data']['totalApproved']?response['data']['totalApproved']:0,
            response['data']['totalInReview']?response['data']['totalInReview']:0):0

      }
    })

  }

  getRebateGoverenceCount(year:any){
    this.httpService.getRebateGovernanceDefaultCounts('in review',year).subscribe((response:any)=>{
      if(response && response['data'].length>0){
        let data = response['data']
        this.rebateGovUnlockCnt =data[0]['cnt'];
        this.rebateGovActivateCnt =data[1]['cnt'];
        this.rebateGovDeActivateCnt =data[2]['cnt']
      }
    })
  }

  getBGAdminPieChartData(year:any){
    this.pieChartData = [];
    this.httpService.getBgAdminPieChartData(year).subscribe((response:any)=>{
      if(response && response['data']){
        if(response['data']['summaryData']){
          let summaryObj = response['data']['summaryData']
           this.reviewObj ={ name: 'In Review', value: this.calculatePercentage(summaryObj['totalInReview'],summaryObj['totalPending'],summaryObj['totalResolved'])? this.calculatePercentage(summaryObj['totalInReview'],summaryObj['totalPending'],summaryObj['totalResolved']):0, color: '#F69C50',actualValue:summaryObj['totalInReview']?summaryObj['totalInReview']:0  }
          this.pendingObj ={ name: 'Pending', value: this.calculatePercentage(summaryObj['totalPending'],summaryObj['totalInReview'],summaryObj['totalResolved'])?this.calculatePercentage(summaryObj['totalPending'],summaryObj['totalInReview'],summaryObj['totalResolved']):0, color: '#59595A',actualValue:summaryObj['totalPending']?summaryObj['totalPending']:0 }
          this.resolvedObj ={ name: 'Resolved', value: this.calculatePercentage(summaryObj['totalResolved'],summaryObj['totalPending'],summaryObj['totalInReview'])?this.calculatePercentage(summaryObj['totalResolved'],summaryObj['totalPending'],summaryObj['totalInReview']):0, color: '#24A148',actualValue:summaryObj['totalResolved']?summaryObj['totalResolved']:0 }
          this.pieChartData.push(this.reviewObj)
          this.pieChartData.push(this.pendingObj)
          this.pieChartData.push(this.resolvedObj)
          console.log("===",this.pieChartData);

        }
      }
    })
  }

  navigateToFinancialHealth = () => {
    this.router.navigate([`/${this.tenantType}/rebateManagement/financial-health`]);
  }
  navigateToRebateOptimization = () => {
    this.router.navigate([`/${this.tenantType}/rebateManagement/rebate-optimization`]);
  }
  navigateToBGHome = () => {
    this.router.navigate([`/${this.tenantType}/home`]);
  }

  navigateToWeeklyReport = (type:any)=>{
    this.router.navigate([`/${this.tenantType}/rebateManagement/weekly-login-report`], { queryParams: { type: type}});
  }
  navigateToDisputeResolution = () =>{
    this.router.navigate([`/${this.tenantType}/rebateManagement/dispute-resolution`]);
  }

  private calculatePercentage(summaryObjElement1: any,summaryObjElement2: any,summaryObjElement3: any) {
    return ((summaryObjElement1/(summaryObjElement2+summaryObjElement1+summaryObjElement3))*100).toFixed();
  }
  navigateToRebateGoverence = () =>{
    this.router.navigate([`/${this.tenantType}/rebateManagement/rebate-governance`]);

  }
  navigateToRebateLibrary = () =>{
    this.router.navigate([`/${this.tenantType}/rebateManagement/rebate-library`]);
  }
  private calculateRebatePercentage(summaryObjElement1: any,summaryObjElement2: any,summaryObjElement3: any,summaryObjElement4: any) {
    return ((summaryObjElement1/(summaryObjElement2+summaryObjElement1+summaryObjElement3+summaryObjElement4))*100).toFixed();
  }

  selectedYearOption = (value:any) => {
    if(value){
      // this.supplierObj['year'] =value
      this.selectedYear = value;
      localStorage.setItem("year",this.selectedYear)
      // this.getTopRebateSuppliers();
      this.getStatusData({year:this.selectedYear});
      this.getBGAdminPieChartData(this.selectedYear);
      this.getRebateGoverenceCount(this.selectedYear);
    }
  }
}

