import {AfterViewInit, Component, DoCheck, OnInit, ViewChild, HostListener} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconRegistry } from '@angular/material/icon';
import { MatSidenav } from '@angular/material/sidenav';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { of, Subject, timer } from 'rxjs';
import { TermsConditionsComponent } from './common/terms-conditions/terms-conditions.component';
import { CONSTANTS, Role, UserType, UserTypeId } from './helpers/constants';
import { DataService } from './services/data.service';
import { HttpService } from './services/http.service';
import { SpinnerService } from './services/spinner.service';
import { UpdatePasswordComponent } from './views/update-password/update-password.component';
import { SwitchUserComponent } from './views/switch-user/switch-user.component';
import { BnNgIdleService } from 'bn-ng-idle';
import { catchError, delay, retryWhen } from 'rxjs/operators';
import { genericRetryStrategy } from './helpers/rxjs-utils';
import { RebateNotifierService } from './services/rebate-notifier.service';
import { version } from '../../package.json';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';
import { rbacConfig } from './rbac/KPIs/kpi-config';
import { AuthService } from './services/auth.service';
import { User } from './models/user.model';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit,AfterViewInit,DoCheck  {
  public version: string = version;
  groupName = '';
  public tenantType: any;
  isExpanded = false;
  showSubmenu: boolean = false;
  isShowing = false;
  showSubSubMenu: boolean = false;
  title = 'ra-angular';
  notifications:any = [];
  loggedInEmail:any;
  loggedInName:any;
  showSwitchUser:any= false
  public visibility: boolean = false;
  rbacShow: boolean = false;
  imageSrcPride:any='../assets/img/icons/pride_logo.svg';
  imageSrc:any='../assets/img/icons/rebate-logo-2.png';
  menuImg:any='../assets/img/icons/rap_icon.svg'
  loggedInUserId:any;
  unSeenNotificationCount:any;
  isSsoLogin:any = 'false';
  private inactivityTime = environment.inactiveTime; // 5 seconds
  private timeoutId: any;
  windowScrolly = 0;
  isNavbarFixed: boolean = true;
  zIndex = '';

  @HostListener('window:scroll', ['$event']) onScroll() {
    //console.log('window.scrollY', window.scrollY);
    // if (window.scrollY > this.windowScrolly) {
    //   this.isNavbarFixed = true;
    // } else {
    //   this.isNavbarFixed = false;
    // }
  }
  constructor(public router: Router,
    public activatedRoute: ActivatedRoute,private matIconRegistry: MatIconRegistry,private domSanitizer: DomSanitizer,public dialog: MatDialog,
    private dataService: DataService,
    private spinnerService: SpinnerService,
    private httpService: HttpService,
    // private bnIdle: BnNgIdleService,
    private dialogRef: MatDialog,
    private rebateNotifierService: RebateNotifierService,
    private authService:AuthService
    ) {
      this.dataService.headerZinedxEmitter.subscribe((zIndex)=>{
        this.zIndex = zIndex;
      })
      this.matIconRegistry.addSvgIcon("rebate",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/rebate_icon.svg"))
      .addSvgIcon("dashboard",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/dashboard_icon.svg"))
      .addSvgIcon("supplier",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/supp_icon.svg"))
      .addSvgIcon("product-category",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/product_category_icon.svg"))
      .addSvgIcon("file",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/file_icon.svg"))
      .addSvgIcon("user",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/user_icon.svg"))
      .addSvgIcon("help",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/help_icon.svg"))
      .addSvgIcon("notification",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/notification_icon.svg"))
      .addSvgIcon("rebateLogo",this.domSanitizer.bypassSecurityTrustResourceUrl("../assets/img/icons/rebatelogo.svg"))

      console.log("App version: ", this.version);
      dataService.notificationEmitter.subscribe(
        (data) => {
          if(data){
            this.ngAfterViewInit();
          }
        }
      );
    }
  @HostListener('document:mousemove', ['$event'])
  @HostListener('document:click', ['$event'])
  @HostListener('document:keypress', ['$event'])
  resetTimer() {
    clearTimeout(this.timeoutId);
    this.timeoutId = setTimeout(() => {
      this.logout()
    }, this.inactivityTime);
  }

  ngAfterViewInit(): void {
    this.loggedInUserId = localStorage.getItem('userGroupId');
    let obj = {userGroupId:this.loggedInUserId}
    this.httpService.getUnseenNotifaction(obj).subscribe((result:any)=>{
      console.log("Notification result->",result)
      if(result && result['data'] ){
        this.unSeenNotificationCount = result['data']['unSeenCount']
        this.notifications = result['data']['list']
      }
    })
  }
  ngDoCheck(): void {
    this.tenantType = localStorage.getItem('tenant')
    if(localStorage.getItem('userId')){
      this.loggedInEmail = localStorage.getItem('userId')
      this.loggedInName = localStorage.getItem('username')
    }
  }
  ngOnInit(): void {
    // this.sessionTimeout();
    this.authService.getLatestNotification().subscribe((isUpdate)=>{
      if(isUpdate){
        this.ngAfterViewInit();
        this.isSsoLogin = localStorage.getItem('ssoLogin') ? localStorage.getItem('ssoLogin'):'false';
        console.log("sss",this.isSsoLogin);
        
      } 
    })
    this.authService.autoLogin();
    this.subjectsUpdate();
    this.rbacProcess();
    this.fetchGroupName();
    this.loggedInUserId = localStorage.getItem('userGroupId')

    this.spinnerService.visibility.subscribe(state => {
      setTimeout(()=>{
        this.visibility = state;
      })
    });

    this.spinnerService.notVisibility.subscribe(state => {
      setTimeout(()=>{
        this.visibility = state;
      })
    });

    
    // this.notifications = [
    //   "Lorem ipsum is placeholder text commonly used in the graphic, print, and .doe@tredence.com",
    //   "Lorem ipsum is placeholder text commonly used in the graphic, print, and .doe@tredence.com",
    //   "Lorem ipsum is placeholder text commonly used in the graphic, print, and .doe@tredence.com",
    //   "Lorem ipsum is placeholder test , print, and .doe@tredence.com",
    //   "Lorem ipsum is placeholder text commonly used in the graphic, print, and .doe@tredence.com",
    //   "Lorem ipsum is placeholder text commonly used in the graphic, print, and .doe@tredence.com",
    //   "Lorem ipsum is placeholder text commonly used in the graphic, print, and .doe@tredence.com",
    //   "Lorem ipsum is placeholder text commonly used in the graphic, print, and .doe@tredence.com",
    //   "Lorem ipsum is placeholder text commonly used in the graphic, print, and .doe@tredence.com",
    //   "Lorem ipsum is placeholder text commonly used in the graphic, print, and .doe@tredence.com",
    //   "Lorem ipsum is placeholder text commonly used in the graphic, print, and .doe@tredence.com",
    //
    // ]
  }

  // sessionTimeout() {
  //   this.bnIdle.startWatching(CONSTANTS.sessionTimeoutLimit).subscribe((isTimedOut: boolean) => {
  //     if (isTimedOut) {
  //       console.log('session expired');
  //       this.logout();
  //     }
  //   });
  // }

  fetchGroupName() {
    this.httpService.fetchMetadata()
    .subscribe((resp) => {
      this.groupName = resp.data ? resp.data['GROUP_NAME'] : '';
    }, (err) => {
    });
  }

  fetchRBACConfig() {
    this.httpService.fetchRBACConfiguration()
    // .pipe(
    //   retryWhen(genericRetryStrategy({
    //     maxRetryAttempts: 5,
    //     scalingDuration: 5000,
    //     excludedStatusCodes: [500]
    //   })),
    //   catchError(error => of(error))
    // )
    .subscribe((resp) => {
      this.dataService.roleBasedAccessConfig = resp.data?.config;
      this.dataService.rbacConfigReceivedSubject.next();
    }, (err) => {
    });
  }

  subjectsUpdate() {
    this.dataService.rbacSubject.subscribe(
      data => {
        console.log(data);
        this.rbacProcess();
        this.fetchGroupName();
      }
    );
  }

  navigateUrl(urlName:string){
    this.router.navigate([`/${this.tenantType}/${urlName}`])
  }

  logout() {
    const tenant = localStorage.getItem('tenant');
    const isSSOLogin = localStorage.getItem('isSSOLogin');
    sessionStorage.clear();
    localStorage.clear();
    this.authService.logout();
    console.log('localstorage cleared')
    this.loggedInEmail='';
    this.loggedInName='';
    this.dialogRef.closeAll();
    if(isSSOLogin) {
      location.replace(environment.prideUrl);
    }
    else if(tenant) {
      this.router.navigate([tenant, 'login']);
    }
  }

  openDialog(){
    const dialogRef = this.dialog.open(TermsConditionsComponent, {
      //width: '400px',
      //width: '30%'
      width: '366px',
      height: '389px',
      disableClose: true,
      panelClass: 'dialog-container-custom'
    });
  }
  resetPassword() {
    console.log('add user in user mgmt component')
    const dialogRef = this.dialog.open(UpdatePasswordComponent, {
      maxHeight: '90vh',
      minHeight: '40vh',
      data: {"tenenat":this.tenantType,"firstLogin":0},
      disableClose: true,
    });

  }

  switchUser(){
    const dialogRef = this.dialog.open(SwitchUserComponent, {
      maxHeight: '90vh',
      minHeight: '40vh',
      width: '320px',
      disableClose: true,
    });
  }

  rbacProcess() {
    // const role = localStorage.getItem('role');
    // const role = this.authService.getUser()?.role;
    // const userType = localStorage.getItem('userType');
    // const userType = this.authService.getUser()?.userType;
    const {userType,role} = this.authService.getUser() as any;
    this.showSwitchUser = localStorage.getItem('Sassociate')|| userType == UserType.Corporate || userType == UserType.Distributor;
    if (userType == UserType.Member || userType == UserType.Supplier && role === Role.Admin) {
      this.rbacShow = true;
    } else {
      this.rbacShow = false;
    }

    // else if (userType === UserType.Supplier && role === Role.Admin) {
    //   this.rbacShow = false;
    // }

    this.fetchRBACConfig();
  }

selectedNotification = (notes:any)=>{
  if(notes && notes['NOTIFICATION_LINK'] ){
    let obj = { userGroupId: this.loggedInUserId,notificationId:notes['NOTIFICATION_ID'] }
    this.unSeenNotificationCount = 0
    this.notifications = []
    this.httpService.seenNotification(obj).subscribe((response:any)=>{
     if(response && response['data']){
       this.unSeenNotificationCount = response['data']['unSeenCount']
       this.notifications = response['data']['list']
       let notificationData = JSON.parse(notes['NOTIFICATION_LINK'])
       if(notificationData && notificationData['queryParams'] && notificationData['params']){
         this.router.navigate([notificationData['link'],{...notificationData['queryParams']}],{queryParams:notificationData['params']})
       }else if(notificationData && notificationData['queryParams'] && !notificationData['params']){
         this.router.navigate([notificationData['link'],{...notificationData['queryParams']}])
       }else if(notificationData && !notificationData['queryParams'] && notificationData['params']){
         this.router.navigate([notificationData['link']],{queryParams:notificationData['params']})
       }
       else if(notificationData && !notificationData['queryParams'] && !notificationData['params']){
        this.router.navigate([notificationData['link']])
      }
     }
   })
  }
}

  openedNotifications = () =>{
    if(this.notifications.length>0){
      let allNotificationId = this.notifications.map((choice:any) => (choice['NOTIFICATION_ID']));
    }
  }
   checkNameLength = (name:string, length = 25) => {
    if (name && name.length > length) {
      return name = name.substring(0, length) + "...";
    }
    else {
      return name;
    }
  };
  clearAllNotifications = () =>{
    this.httpService.seenAllNotifactions().subscribe((result:any)=>{
      if(result && result['data']){
        let obj = {userGroupId:this.loggedInUserId}
        this.httpService.getUnseenNotifaction(obj).subscribe((result:any)=>{
          if(result && result['data'] ){
            this.unSeenNotificationCount = result['data']['unSeenCount']
            this.notifications = result['data']['list']
          }
        })
      }
    })
  }
}
