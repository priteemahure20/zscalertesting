export interface SortBy {
    orderBy: string;
    orderType: string;
}
