export interface DropdownOption {
    value: number | string;
    displayText: number | string;
}
