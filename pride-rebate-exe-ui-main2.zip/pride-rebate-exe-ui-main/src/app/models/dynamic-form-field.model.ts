export interface DynamicFormFieldModel {
    id: string;
    type: 'text' | 'select';
    label: string;
    items: any;
}