// import { UserType } from "../helpers/constants";

import { UserType } from "../helpers/constants";


export interface User{
    userId:number;
    userName:string;
    lastName:string;
    userGroupId:number;
    userType:UserType;
    email:string;
    tenantId:number;
    tenantName:string;
    role:string;
    iat:number;
    exp:number;
}