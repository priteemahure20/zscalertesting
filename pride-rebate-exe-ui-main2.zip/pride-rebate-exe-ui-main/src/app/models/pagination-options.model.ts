export interface PaginationOptions {
    limit: number;
    pageNo: number;
    length: number;
}
