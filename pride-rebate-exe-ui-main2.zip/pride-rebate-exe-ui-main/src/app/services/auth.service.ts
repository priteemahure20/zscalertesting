import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { AppComponent } from '../app.component';
import { NotificationsComponent } from '../common/notifications/notifications.component';
import { User } from '../models/user.model';
// import { BehaviorSubject, Observable } from 'rxjs';
import jwt_decode from "jwt-decode";
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject=new BehaviorSubject<User|any>({});
  private updateNotification = new Subject<boolean>();

  // public currentUser: Observable<any>;

  constructor( public activatedRoute: ActivatedRoute,public dialog: MatDialog,public router: Router,
    @Inject(DOCUMENT) private document: Document) {
    // this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('username')));
    // this.currentUser = this.currentUserSubject.asObservable();
   }

  // public get currentUserValue(): any {
  //   return this.currentUserSubject.value;
  // }

  public isAuthenticated(urlTenanet:any): boolean {
    console.log('isAuthenticated - urlTenanet: ', urlTenanet);
    const userId = localStorage.getItem('userId');
    const localTenant =  localStorage.getItem('tenant');
    console.log('localTenant and urlTenant: ', localTenant, ' & ', urlTenanet);
    if(urlTenanet != undefined) {
      console.log('checking tenant logout bug');
    } else {
      console.log('else check bug');
    }

    if(((urlTenanet != undefined) && localTenant &&  (urlTenanet!=localTenant))){
      const isValidTenant = this.openDialog()
      sessionStorage.clear();
      localStorage.clear();
      // alert('cleared session')
      console.log('session cleared in urlTenanet flow');
      this.router.navigate([urlTenanet, 'login']);
      return false;
    } else {
      if (userId != null)
      {
          return true;
      }
      else{
        console.log("userid: ", userId);
        console.log('logging out from userId null flow');
        return false;
      }
    }

  }

  openDialog = () =>{
   const dialogref= this.dialog.open(NotificationsComponent, {
      //width: '400px',
      //width: '30%'
      width: '366px',
      height: '389px',
      disableClose: true,
      panelClass: 'dialog-container-custom'
    })
    dialogref.afterClosed().subscribe((response:any)=>{
      this.document.location.href = "https://www.rebate.ai/"
    })
  }

  autoLogin(){
    let token = localStorage.getItem("token");
    if(!token){
        return;
    }
    const user:User = jwt_decode(token);
    if(!user){
      return;
    }
    this.setUpdateNotification();
    this.currentUserSubject.next(user);
  }

  setUpdateNotification(){
    this.updateNotification.next(true);
  }

  getLatestNotification():Observable<boolean>{
   return this.updateNotification.asObservable();
  }

  getUser():User|any{
    const user:User|null = this.currentUserSubject.value;
    if(user){
      return user;
    }
  }

  logout(){
    this.currentUserSubject.next(null);
  }

 
}
