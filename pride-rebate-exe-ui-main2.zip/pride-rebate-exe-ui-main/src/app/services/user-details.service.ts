import { Injectable } from '@angular/core';
import { User } from '../models/user.model';
import jwt_decode from "jwt-decode";
import { UserType } from '../helpers/constants';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  user: User;
  token: string;
  corporate: UserType = UserType.Corporate;
  supplier: UserType = UserType.Supplier;
  distributor: UserType = UserType.Distributor;
  userTypes: UserType[];

  constructor() {
    this.userTypes = [UserType.Corporate, UserType.Supplier, UserType.Distributor];
    this.token = localStorage.getItem("token") ?? '';
    this.user = jwt_decode(this.token);
  }

  getUser() {
    return this.user;
  }
}
