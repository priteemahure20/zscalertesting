import { HttpErrorResponse, HttpEvent, HttpHandler, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { SpinnerService } from './spinner.service';
import { finalize, delay } from 'rxjs/operators';
import { CONSTANTS,SPINNERHIDE,APIMETHOD } from '../helpers/constants';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService {
  // spinnerUrlTrackList: any = [];
  spinnerTrackSum = 0;

  // exclusion to be implemented later
  // bring urls from excludeLoaderUrls array in constants
  // excludeSpinnerUrls = [];

  constructor(private router: Router,
    private spinner: SpinnerService) { }

  // not working, check later
  handleError(error: HttpErrorResponse, req: HttpRequest<any>) {
    // console.log("lalalalalalalala", this.router.url);
    if (error.status === 401) {
      const tenant = localStorage.getItem('tenant');
      this.router.navigate([tenant, 'login'], { queryParams: { returnUrl: this.router.url } });
      // this.router.navigate(['login']);
    }
    return throwError(error);
  }

  intercept(req: HttpRequest<any>, next: HttpHandler):
    Observable<HttpEvent<any>> {

    if (req.url.indexOf(SPINNERHIDE.assets) === -1) {
      this.spinner.visibility.emit(true);
      this.spinnerTrackSum += 1;
    } else {
    }

    if (req.url.indexOf(SPINNERHIDE.masterDataAPI) !== -1 && req.method === APIMETHOD.GET) {      
      this.spinner.visibility.emit(false);
    }

    if (req.url.indexOf(SPINNERHIDE.columnMappingAPI) !== -1 && req.method === APIMETHOD.GET) {      
      this.spinner.visibility.emit(false);
    }

    if (req.url.indexOf(SPINNERHIDE.summaryAPI) !== -1 && req.method === APIMETHOD.GET) {
      this.spinner.visibility.emit(false);
    }

    return next.handle(req)
      .pipe(
        finalize(() => {
          if (req.url.indexOf("assets") === -1) {
            if (this.spinnerTrackSum === 0) {
              this.spinner.notVisibility.emit(false);
            }
          }
        }),
        catchError((error: HttpErrorResponse) => {
          if (req.url.indexOf("assets") === -1) {
            this.spinnerTrackSum -= 1;
            console.log('req in progress - catcherror: ', this.spinnerTrackSum);
          }

          console.log('error caught: ', error);
          let errorMsg = '';
          if (error.error instanceof ErrorEvent) {
            console.log('this is client side error');
            errorMsg = `Error: ${error.error.message}`;
          } else if(error.status ==423){
            error = error
          }else{
            console.log(`this is server side ${error.message}`);
            errorMsg = `Error Code: ${error.status},  Message: ${error.error.message}`;
            if (error.status === 401) {
              const tenant = localStorage.getItem('tenant');
              this.router.navigate([tenant, 'login'], { queryParams: { returnUrl: this.router.url } });
              // this.router.navigate(['login']);
            } else if (error.status === 500) {
              error.error.message = CONSTANTS.error500;
            }
          }
          console.log(errorMsg);
          return throwError(error);
        })
      )
      .pipe(map<HttpEvent<any>, any>((evt: HttpEvent<any>) => {
        if (evt instanceof HttpResponse) {
          // console.log('spinner hiding with this event: ', evt);
          if (req.url.indexOf("assets") === -1) {
            this.spinnerTrackSum -= 1;
            //console.log('req in progress - pipe: ', this.spinnerTrackSum, req.url);
          }
        }
        return evt;
      }));
  }
}
