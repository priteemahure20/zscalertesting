import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RebateNotifierService {
  notificationContainer;
  NOTIFICATION_TYPES: any;

  constructor() {
    console.log('inside notifer servcice')
    
    this.notificationContainer = document.getElementById('rebate-notification-container');
    this.NOTIFICATION_TYPES = {
        INFO: 'info',
        SUCCESS: 'success',
        WARNING: 'warning',
        DANGER: 'danger'
    };

    // setTimeout(() => {
    //   const info = this.addNotification(this.NOTIFICATION_TYPES.INFO, 'Info text added');
    //     // this.removeNotification(info);
    // }, 5000);
   }

   addNotification(type: string, text: string) {
    // create the DIV and add the required classes
    const newNotification = document.createElement('div');
    newNotification.classList.add('notification', `notification-${type}`);

    const innerNotification = `
		<strong>${type}:</strong> ${text}
	`;

    // insert the inner elements
    newNotification.innerHTML = innerNotification;

    // add the newNotification to the container
    this.notificationContainer?.appendChild(newNotification);

    return newNotification;
}

  removeNotification(notification: any) {
    notification.classList.add('hide');

    // remove notification from the DOM after 0.5 seconds
    setTimeout(() => {
        this.notificationContainer?.removeChild(notification);
    }, 500);
  }
}
