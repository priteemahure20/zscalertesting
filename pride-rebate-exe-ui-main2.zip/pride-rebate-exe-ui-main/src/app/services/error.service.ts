import { HttpErrorResponse } from '@angular/common/http';
import { Injectable, Injector } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ErrorService {

  constructor(private injector: Injector) { }

  // not being used as of now
  handleError(error: any) {
    // const router = this.injector.get(Router);
    if (Error instanceof HttpErrorResponse) {
      console.log(error.status);
    }
    else {
      console.error("an error occurred here");
      console.error(error)
    }
    // not working directly. Had to refresh page for this navigation to work.
    // router.navigate(['error']);
  }
}
