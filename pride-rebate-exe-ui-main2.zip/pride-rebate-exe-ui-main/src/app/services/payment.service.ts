import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

export interface PaymentEvent {
  eventId: number;
  eventName: string;
  lastFileDate: string;
  paymentRecieved: number;
  dueAmount: number;
  adjustmentAmount: number;
  suppliersCount: number;
  programsCount: number;
  eventStatus: string;
}

export const EMPTY_PAYMENT_EVENT: PaymentEvent = {
  eventId: 0,
  eventName: 'Event Name',
  lastFileDate: 'NA',
  paymentRecieved: 0,
  dueAmount: 0,
  adjustmentAmount: 0,
  suppliersCount: 0,
  programsCount: 0,
  eventStatus: 'NA'
};

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  httpOptions: any;

  constructor(private http: HttpClient) {
    this.httpOptions = { headers: new HttpHeaders().set('Authorization', 'Bearer ' + localStorage.getItem('token')) };
  }

  private buildUrl(path: string): string {
    return environment.baseUrl + path;
  }

  getPaymentEvents(body: any) {
    return this.http.post(this.buildUrl('/api/payment/events'), body, this.httpOptions);
  }

  getPaymentEvent(eventId: number) {
    return this.http.get(this.buildUrl('/api/payment/events/' + eventId), this.httpOptions);
  }

  getPaymentEventDetails(eventId: number, body: any) {
    return this.http.post(this.buildUrl('/api/payment/events/' + eventId + '/details'), body, this.httpOptions);
  }

  getPaymentEventCreatePrerequisite() {
    return this.http.get(this.buildUrl('/api/payment/create/prerequisite'), this.httpOptions);
  }

  getPaymentEventCreateSuppliers(body: any) {
    return this.http.post(this.buildUrl('/api/payment/create/suppliers'), body, this.httpOptions);
  }

  initiatePaymentEvent(body: any) {
    return this.http.post(this.buildUrl('/api/payment/create/initiate'), body, this.httpOptions);
  }

  uploadPaymentFile(eventId: number, body: any) {
    return this.http.post(this.buildUrl('/api/payment/events/' + eventId + '/settle'), body, this.httpOptions);
  }

  supplierPaymentOverview(body: any) {
    return this.http.post(this.buildUrl('/api/payment/supplier/overview'), body, this.httpOptions);
  }

  supplierRebateTypeOverview(eventId: number) {
    return this.http.get(this.buildUrl('/api/payment/events/' + eventId + '/rebate-type'), this.httpOptions);
  }

  supplierPaymentAccept(eventId: number, body: any) {
    return this.http.post(this.buildUrl('/api/payment/events/' + eventId + '/accept'), body, this.httpOptions);
  }

  supplierPaymentReject(eventId: number, rejectionComments: string) {
    return this.http.post(this.buildUrl('/api/payment/events/' + eventId + '/reject'), { rejectionComments }, this.httpOptions);
  }

  getEventExportFileName(eventDetails: any) {
    const eventName: string = eventDetails.eventName ? String(eventDetails.eventName).split(' ').join('_') : 'NA';
    return `${eventDetails.eventId}_${eventName}_Payment_Event.csv`;
  }
}
