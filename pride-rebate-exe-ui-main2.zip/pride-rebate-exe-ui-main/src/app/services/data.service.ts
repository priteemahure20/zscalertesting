import { Injectable,EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BehaviorSubject, Subject } from 'rxjs';
import { HttpService } from './http.service';
import { get as _get, reduce as _reduce, isEqual as _isEqual, isEmpty as _isEmpty } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  public rbacSubject = new Subject<any>();
  public roleBasedAccessConfig: any;
  public rbacConfigReceivedSubject = new Subject<any>();
  public yearSubject = new Subject<any>();
  public supplierDropdown= new Subject<any>();
  // public lastPayoutSubject = 
  private recentPayoutSubject=new BehaviorSubject<any>({});
  private dropdownSubject=new BehaviorSubject<any>('rebate');
  private paginationSubject= new BehaviorSubject<number>(1);
  private attaintmentSubject= new BehaviorSubject<number>(0);
  private programNameSubject= new BehaviorSubject<string>('');
  public notificationEmitter = new EventEmitter();
  public wndowSrollYEmitter = new EventEmitter();
  public headerZinedxEmitter = new EventEmitter();
  public ValueAdded=new EventEmitter();

  constructor(private httpService: HttpService,
    private snackBar: MatSnackBar) { }

  download(value: any, downloadedFileName: string = 'download') {
    this.httpService.downloadSampleFile(value).subscribe(
      (response: any) => {
        // console.log(response);
        const dataType = response.type;
        const binaryData = [];
        binaryData.push(response);
        const downloadLink = document.createElement('a');
        downloadLink.href = window.URL.createObjectURL(
          new Blob(binaryData, { type: dataType })
        );
        downloadLink.setAttribute('download', downloadedFileName);
        document.body.appendChild(downloadLink);
        downloadLink.click();
      },
      (error) => {
        const errorMessage = _get(error, 'error.message') || _get(error, 'message') || 'Download failed';
        this.snackBar.open(errorMessage, 'Ok', {
          duration: 2000,
        });
      }
    );
  }

  private getValFromLocalstorage(x: string) {
    return localStorage.getItem(x);
  }

  public cachingLocalStorage(x: string) {
    let cache = new Map();

    if (cache.has(x)) {    // if there's such key in cache
      return cache.get(x); // read the result from it
    }

    let result = this.getValFromLocalstorage(x);  // otherwise call func

    cache.set(x, result);  // and cache (remember) the result
    return result;
  }

  setRecentPayout(obj:any){
    this.recentPayoutSubject.next(obj);
  }

  getRecentPayout(){
    return this.recentPayoutSubject.value;
  }

  setDropdownState(state:any){
    this.dropdownSubject.next(state);
  }

  getDropdownState(){
    return this.dropdownSubject.value;
  }

  setpaginationState(state:any){
    this.paginationSubject.next(state);
  }

  getpaginationState(){
    return this.paginationSubject.value;
  }

  setAttaintmentvalue(state:any){
    this.attaintmentSubject.next(state);
  }

  getAttaintmentvalue(){
    return this.attaintmentSubject.value;
  }

  setProgramName(name:any){
    this.programNameSubject.next(name);
  }

  getProgramName(){
    return this.programNameSubject.value;
  }

  setSuppliervalue(state:any){
    this.supplierDropdown.next(state);
  }
  

}
