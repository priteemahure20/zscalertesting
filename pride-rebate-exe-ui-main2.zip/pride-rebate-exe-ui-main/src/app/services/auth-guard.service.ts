import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(private router: Router,
    private authService: AuthService) { }

  canActivate(
    next: any,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    let urlTenanet = "";
    // if(next && next['_routerState']['url'].includes('dashboard')){
    //   urlTenanet = next['parent']['params']['type']
    //   console.log('urlTenanet issue in dashboard: ', next);
    // }else{
    // }
    urlTenanet = next['params']['type']

    console.log('urlTenanet: ', urlTenanet);
    console.log('localstorage: ', localStorage);
    if (!this.authService.isAuthenticated(urlTenanet)) {
      // new system doesn't have tenant, where will it go?
      // take tenant from url itself
      const tenant = localStorage.getItem('tenant');
      if(urlTenanet){
        this.router.navigate([urlTenanet, 'login']);
      }
      return false;
    }
    return true;
  }
}
