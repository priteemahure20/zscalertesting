import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';
import { AuthService } from './auth.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class RoleGuardService implements CanActivate {
  constructor(
    private router: Router,
    private snackBar: MatSnackBar,
    private authService: AuthService
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    // const role = localStorage.getItem('role');
    // const role = this.authService.getUser()?.role;
    // const userType: any = this.authService.getUser()?.userType;
    const {userType,role} = this.authService.getUser() as User;
    console.log('role and usertype in roleguard: ', role, ' and ', userType);

    if (route.data.userTypes && route.data.userTypes.indexOf(userType) === -1) {
      // userType not allowed, redirect to login
      const tenant = localStorage.getItem('tenant');
      console.log('Unauthorized 1');
      this.snackBar.open(`Unauthorized`, 'Ok', {
        duration: 2000,
      });
      if(environment.baseUrl === 'https://rap-pride-prod-node-app.azurewebsites.net'){
        console.log('baseUrl',environment.baseUrl)
        // this.router.navigateByUrl("https://portal.pridecentricresources.com/")
        window.location.replace(environment.prideUrl);
      }else{
        this.router.navigate([tenant, 'login']);
      }
      return false;
      // } else if (route.data.roles && route.data.roles.indexOf(role) === -1) {
    } else if (route.data.roles && !route.data.roles[userType].includes(role)) {
      // role not authorised so redirect to home page
      console.log('Unauthorized 2');
      this.snackBar.open(`Unauthorized`, 'Ok', {
        duration: 2000,
      });
      // const tenant = localStorage.getItem('tenant');
      // this.router.navigate([tenant, 'dashboard', 'summary']);
      return false;
    }

    // authorised so return true
    console.log('before allowing through role guard');
    return true;
  }
}
