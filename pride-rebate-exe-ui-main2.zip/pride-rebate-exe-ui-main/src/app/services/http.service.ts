import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, Injector } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Observable, of, ReplaySubject, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  validToken: any;
  targetObject: any;
  testObject: any;
  headers: HttpHeaders;
  execId: any;
  trainFilesForAddExec: any;
  testFilesForAddExec: any;
  tourSubject = new Subject<string>();
  themeSubject = new Subject<string>();
  public targetSubject = new Subject<any>();

  verticalsDataSub = new Subject<any>();
  loggedInUsername: any;

  constructor(
    public http: HttpClient,
    private router: Router,
    private injector: Injector,
    private snackBar: MatSnackBar
  ) {
    this.validToken = localStorage.getItem('token'); // remember me change
    const expirationTime = localStorage.getItem('tokenExpirationTime');
    if(expirationTime){
      if (!this.validToken || new Date().getTime() > parseInt(expirationTime)) {
        location.replace(environment.prideUrl);
        sessionStorage.clear();
        localStorage.clear()
      }
    }
    this.headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    // console.log('running mlops constructor');
  }

  userLogin(body: any) {
    return this.http.post<any>(environment.baseUrl + '/api/user/login', body);
  }

  ssoLogin(body: any) {
    return this.http.post<any>(environment.baseUrl + '/api/user/login/sso', body);
  }

  checkValidTenant(body: any) {
    return this.http.post<any>(environment.baseUrl + '/api/user/valid/tenant', body);

  }

  userSignUp(obj: any) {
    return this.http.post<any>(environment.baseUrl + '/api/user/signup', obj);
  }

  resetPassword(object: any) {
    return this.http.post<any>(
      environment.baseUrl + '/api/user/reset/password/request',
      object
    );
  }

  resendEmail(email: any) {
    return this.http.post<any>(
      environment.baseUrl + '/api/user/resend/email',
      email
    );
  }

  emailVerification(token: any) {
    return this.http.post<any>(environment.baseUrl + '/api/user/verify', token);
  }

  testHealth() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/test-health`,
      { headers }
    );
  }
  fetchMetadata() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/usergroup/name`,
      { headers }
    );
  }

  fetchSupplierFinanceTreddata( year: any, period: any,distributorId:any,supplierId:any ) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/distributor/finance/rebate/trend?year=${year}&distributorId=${distributorId}&period=${period}&supplierId=${supplierId}`,
      { headers }
    );
  }

  fetchRBACConfiguration() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/rbac/config`,
      { headers }
    );
  }

  fetchUserTypesRoles() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/user/roles-types`,
      { headers }
    );
  }

  userMgmtDetails(pageNo: any, pageSize: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/user-mgmt/users?page=${pageNo}&pageSize=${pageSize}`,
      { headers }
    );
  }

  lineChartPre() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/bgdashboard/finance/trend/prerequisite`,
      { headers }
    );
  }

  lineChartData(year: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/bgdashboard/finance/trend/data?year=${year}`,
      { headers }
    );
  }

  verifyToken(object: any) {
    return this.http.post<any>(
      environment.baseUrl + '/api/user/verify/token',
      object
    );
  }

  transactionMapping(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/transaction/mapping', body, {
      headers,
    });
  }

  bgDashboardFinanicalSummary(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/bgdashboard/finance/summary', body, {
      headers,
    });
  }

  bulkUserSignup(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/user/signup', body, {
      headers,
    });
  }

  seenNotification = (obj:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/notification/seen`, obj, {
      headers,
    });
  }
  

  downloadFile(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(
      environment.baseUrl + '/api/history/file/download',
      body,
      { headers, responseType: 'blob' as 'json' }
    );
  }


  downloadPivotFile(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(
      environment.baseUrl + '/api/pivotdata/file/download',
      body,
      { headers, responseType: 'blob' as 'json' }
    );
  }

  downloadSampleFile(type: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl + `/api/associate/file/download?type=${type}`,
      { headers, responseType: 'blob' as 'json' }
    );
  }

  getMasterData = (mappingType: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/column-mapping/masterData?mappingType=PC`,
      { headers }
    );
  }
  faqData() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/faqData`,
      { headers }
    );
  }

  updatePassword = (body: any) => {
    return this.http.post<any>(
      environment.baseUrl + '/api/user/reset/password',
      body
    );
  }

  updateOldPassword = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/user/update-password', body, {
      headers,
    });
  }

  createUser = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/user-mgmt/user', body, {
      headers,
    });
  }

  inGroupPurchase = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/group/purchase/summary', body, {
      headers,
    });
  }

  rebateSummary = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/dashboard/rebate/summary', body, {
      headers,
    });
  };

  rebateSummaryTable = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/dashboard/rebate/summary/table', body, {
      headers,
    });
  }

  rebateSummaryTablePagination = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/dashboard/rebate/summary/table/pagination', body, {
      headers,
    });
  }

  deleteUser = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/user-mgmt/delete-user', body, {
      headers,
    });
  }

  saveUsers = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/user-mgmt/update-user', body, {
      headers,
    });
  }

  saveMappingData = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/transaction/mapping', body, {
      headers,
    });
  }

  getUploadHistory = ( body: any ) => {
    console.log("sorting history",body);

    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken,

    );
    return this.http.post<any>(environment.baseUrl + '/api/history', body,{
      headers,
    });
  }

  getUploadHistorypivot = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );

    return this.http.post<any>(environment.baseUrl + '/api/pivotdata', body, {

      headers,

    });


  }

  getUploadHistorypivotstatus = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );

    return this.http.post<any>(environment.baseUrl + '/api/pivotdata', body, {

      headers,

    });


  }

  filterStatus = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + '/api/status', body, {
      headers,
    });
  }

  fetchSupplierPrerequisites = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/supplier/classification/prerequisite', body, {
      headers,
    });
  }

  updateSupplierClassification = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/supplier/classification/update', body, {
      headers,
    });
  }

  fetchProductCategoryPrequests = (payload: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/member/product/category/prerequisite', payload, {
      headers,
    });
  }
  getMemberProductData = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/member/product/category/search', body, {
      headers,
    });
  }

  getMasterCategories = () => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + '/api/category/master/dropdown', {
      headers,
    });
  }

  updateProductCategory = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/member/product/category/update', body, {
      headers,
    });
  }

  public getTranscationColumnMapping = (mappingType: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + `/api/transaction/column-mapping?mappingType=PC`, {
      headers,
    });
  }

  public getRebatePrograms = (pageSize: any, pageNo: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + `/api/member/rebate?pageSize=${pageNo}&page=${pageSize}`, {
      headers,
    });
  }

  public getRebateProgramDetails = (supplierId: any, year: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/member/rebateProgramDetails?supplierId=${supplierId}&year=${year}`,
      { headers }
    );
  }

  public getDashboardSummary = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/rebate/summary', body, {
      headers,
    });
  }

  public updateFirstLogin = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/user/detail/update', body, {
      headers,
    });
  }

  public getIngroupSummaryCategory = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/group/category/summary', body, {
      headers,
    });
  }

  public getSummaryDetailsPreRequeste = (queryType: any) => {
    this.validToken = localStorage.getItem('token');

    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + `/api/group/purchase/order/detail/prerequisite?contributor=${queryType}`, {
      headers,
    });
  }

  public getPurchaseOrderDetails = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/group/purchase/order/detail', body, {
      headers,
    });
  }

  public getInvoiceDetails = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/group/invoice/detail', body, {
      headers,
    });
  }

  public getRebateProgramCategories = () => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + `/api/member/rebateProductFilters`, {
      headers,
    });
  }

  public programCategoryDetails = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/member/getRebateProducts', body, {
      headers,
    });
  }

  public getMissedOppurtunityDetails = (year: any, month: any, pageNo: number, limit: number) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/group/missedOpportunity?year=${year}&month=${month}&pageNo=${pageNo}&limit=${limit}`,
      { headers }
    );
  }

  saveFeedBackData = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/feedback', body, {
      headers,
    });
  }
  public getHelpAndSupport = () => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + `/api/help/support`, {
      headers,
    });
  }

  public getYearsData = () => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + `/api/years`, {
      headers,
    });
  }

  public getLastUpdatedDate = () => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + `/api/usergroup/record/processing`, {
      headers,
    });
  }

  public getIngroupSummaryCategoryBySearch = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/group/category/search', body, {
      headers,
    });
  }
  public inGroupPurchaseSearch = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/group/purchase/search', body, {
      headers,
    });
  }

  userMgmtDetailsSearch(pageNo: any, pageSize: any, searchValue: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/user-mgmt/users/search?page=${pageNo}&pageSize=${pageSize}&email=${searchValue}`,
      { headers }
    );
  }

  getfilterUploadHistory = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/history', body, {
      headers,
    });
  }

  getSearchUploadHistory = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/history', body, {
      headers,
    });
  }

  getSearchUploadpivotHistory= (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/pivotdata', body, {
      headers,
    });
  }
  getFilterStatusHistory= (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/piovotdata/searchstatus', body, {
      headers,
    });
  }
  getAssociateLibraryData = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/associate', body, {
      headers,
    });
  }

  getAssociateHierarchicalData = (type: any, hierarchical: any) => {
    // this.validToken = localStorage.getItem('token');
    // const headers = new HttpHeaders().set(
    //   'Authorization',
    //   'Bearer ' + this.validToken
    // );
    // return this.http.post<any>(environment.baseUrl + '/api/associate/parent', body, {
    //   headers,
    // });
  }

  getFilterAssociateIds = (type: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/associate/dropdown?type=${type}`,
      { headers }
    );
  }

  getFilterEmailIds = (type: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/user/dropdown?type=${type}`,
      { headers }
    );
  }
  effectiveDateChanges = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + '/api/associate', body, {
      headers,
    });
  }



  userPermissionPrerequisite = (type: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/user/prerequisite?type=${type}`,
      { headers }
    );
  }

  associateFormPrerequisite = (type: any) => {

    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/associate/form/prerequisite?type=${type}`,
      { headers }
    );
  }


  fetchAssociateParent = (hierarchy: string, type: string, body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    console.log('body...', body);
    return this.http.post<any>(environment.baseUrl +`/api/associate/parent?hierarchy=${hierarchy}&type=${type}`, body,
      { headers }
    );
  }

  createAssociateData = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    console.log('body..',body);
    return this.http.post<any>(environment.baseUrl + '/api/associate/save', body, {
      headers,
    });
  }

  fetchTenantSegmentData = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    // return this.http.post<any>(environment.baseUrl + '/api/tenant/segments', body, {
    //   headers,
    // });
  }

  getUserManagementData = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/users/management', body, {
      headers,
    });
  }

  fetchAssociateDetail = (associateId: string) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/associate/detail/${associateId}`,

      { headers }
    );
  }
  getHierarchicalView = (userGroupId: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +

      `/api/associate/child?parent_id=${userGroupId}`,
      { headers }
    );
  }

  getOrgViewData = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/associate/preview', body, {
      headers,
    });
  }

  createManagementUser = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/users/management/createuser', body, {
      headers,
    });
  }

  getManagementUserDetails = (id: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/users/management/userdetails?user_id=${id}`,
      { headers }
    );
  }

  saveEditUserManagementDetails = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/users/management/updateuser', body, {
      headers,
    });
  }

  deleteActivateUserManagement = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/users/management/updateuser', body, {
      headers,
    });
  }

  uploadAssociatedFile = (body: any, type: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/associate/bulk?associateType=${type}`, body, {
      headers,
    });
  }

  uploadUserManagementFile = (body: any, type: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/associate/users/bulk?associateType=${type}`, body, {
      headers,
    });
  }

  editAssociateData = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    console.log("checking edit body",body);
    return this.http.patch<any>(environment.baseUrl + '/api/associate/edit', body, {
      headers,
    });

  }

  getTopographyData(): Observable<any> {
    const topoDataURL =
      'https://cdn.jsdelivr.net/npm/us-atlas@3/counties-albers-10m.json';

    return this.http.get(topoDataURL);
  }

  getAllFileTypes = (type: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/data-management/prerequisite?userType=${type}`,
      { headers }
    );
  }

  getBgDashboardTransactions = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/finance/totaltransactions`, body, {
      headers,
    });
  }

  getTopTransactions = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/finance/regionwisetoptransactions`, body, {
      headers,
    });
  }

  getSupplierWithNoData = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/finance/supplier/nodata`, body, {
      headers,
    });
  }
  getTopRebatePayers = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/finance/rebatepayingsuppliers`, body, {
      headers,
    });
  }

  getSupplierSales = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/finance/suppliersalessummary`, body, {
      headers,
    });
  }
  getDistributorPurchaseData(distributorObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/finance/distributorpurchasessummary`, distributorObj, {
      headers,
    });
  }

  sendEmailToSupplier(emailObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/send/email`, emailObj, {
      headers,
    });
  }

  getRebateTopOppertunities(distributorObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateOptimization/topOpportunities`, distributorObj, {
      headers,
    });
  }

  getWeeklyReports(reportObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/weeklyreport/summary`, reportObj, {
      headers,
    });
  }

  getNonRebatablePurchase(distributorObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateoptimization/distributor/nonRebatablePurchase`, distributorObj, {
      headers
    });
  }

  getRebateOptOverview = (overviewObj: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateoptimization/overview`, overviewObj, {
      headers,
    });
  }

  getRebateOptDistributor = (distributorObj: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateoptimization/distributor/quartile/summary`, distributorObj, {
      headers,
    });
  }

  getDistributorPerformance = (distributorObj: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateoptimization/distributor/performance`, distributorObj, {
      headers,
    });
  }

  getDistributorOptiNeed(distributorObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateOptimization/optimization/need`, distributorObj, {
      headers,
    });
  }

  getDistputeResolutionTickets(disputeObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/dispute/tickets`, disputeObject, {
      headers,
    });
  }

  getBgAdminTicketInfo(disputeObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/dispute/tickets`, disputeObject, {
      headers,
    });
  }

  getUserDataForTickets(payLoad: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/user/list/payload/basis`, payLoad, {
      headers,
    });
  }
  getBgAdminTicketDetails = (ticketPayload: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/dispute/ticket/detail`, ticketPayload, {
      headers,
    });
  }
  editTicketDetails = (ticketPayload: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/bgdashboard/dispute/ticket`, ticketPayload, {
      headers,
    });
  }

  getActivitiesComment(commentObj: any, pageLimit: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/dispute/ticket/comments?page=` + pageLimit.page + '&pageSize=' + pageLimit.pageSize, commentObj, {
      headers,
    });
  }

  getTicketAttachments(ticketObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/dispute/ticket/attachments`, ticketObj, {
      headers,
    });
  }

  downloadTicketAttachment(payLoad: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/dispute/ticket/attachment/download`, payLoad, {
      headers, responseType: 'blob' as 'json'
    });
  }
  sendActivitiesComment(ticketObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/dispute/ticket/comment`, ticketObj, {
      headers,
    });
  }

  uploadFile(fileObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/dispute/ticket/attachment`, fileObj, {
      headers,
    });
  }
  uploadFileManualBaseLine(obj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program_creation/special_conditions/manualbaseline/uploadCsv`, obj, {
      headers,
    });
  }

  getBgAdminPieChartData(year:any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(
      environment.baseUrl +
      `/api/bgdashboard/dispute/tickets/summary`,{year},
      { headers }
    );
  }

  getRebateGovernanceUnlockDetails(governanceObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateGovernance/request`, governanceObject, {
      headers,
    });
  }

  getRebateGovernanceDefaultCounts(type: any,year:any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/rebateGovernance/count/summary?requestStatus=${type}&year=${year}`,
      { headers }
    );
  }

  rebateGovernanceRequestDetails(requestDetailObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateGovernance/programs`, requestDetailObj, {
      headers,
    });
  }

  rebateGovernceActivateDeActivate(requestDetailObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateGovernance`, requestDetailObj, {
      headers,
    });
  }

  requestBgAprroveReject(reqObj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateGovernance/requests/approve_reject`, reqObj, {
      headers,
    });
  }

  requestApproveReject(requestApproveRejectObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateGovernance/requests/approve_reject`, requestApproveRejectObj, {
      headers,
    });
  }

  getSupplierRebateGovernanceAggrements(selectedYear: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate/programs/summary`, selectedYear, {
      headers,
    });
  }

  raiseRequest(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateGovernance/raise/request`, body, {
      headers,
    });
  }

  approveRejectActiveDeactive(requestApproveRejectObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebateGovernance/all/requests/approve_reject`, requestApproveRejectObj, {
      headers,
    });
  }

  getRebateProgramPrecis(body: { year: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate/programs/precis`, body, {
      headers,
    });
  }

  getRebateManagementDistributorSummary(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate_library/distributor/summary`, body, {
      headers,
    });
  }

  getSupplierRebateLibraryPrograms(aggrementObj: any) {
    console.log("program body service",aggrementObj)
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate/programs`, aggrementObj, {
      headers,
    });
  }
  // getVendorName(vendor_id?:any) {
  //   this.validToken = localStorage.getItem('token');
  //   const headers = new HttpHeaders().set(
  //     'Authorization',
  //     'Bearer ' + this.validToken
  //   );
  //   return this.http.post<any>(environment.baseUrl + `/api/rebate/programs`,vendor_id,  {
  //     headers,
  //   });
  // }
  getVendorRebateLibraryPrograms(obj: any, vendor_id?:any) {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
      );
      return this.http.post<any>(environment.baseUrl + `/api/rebate/vendorprograms/${vendor_id}`, obj, {
      headers,
      });
  }

  getSupplierGroupPrograms(bgUserSupplierPrograms: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate/programs/suppliers/grouping`, bgUserSupplierPrograms, {
      headers,
    });
  }

  getSupplierPrograms(bgUserSupplierPrograms: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate_library/distributor/supplier/programs`, bgUserSupplierPrograms, {
      headers,
    });
  }

  getIndividualBasePrograms(baseObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate_library/dealer/individual_base_programs`, baseObject, {
      headers,
    });
  }

  // getStatusAndAgreement(statusObject: any,vendor_id?:any) {
    getStatusAndAgreement(obj: any,vendor_id?:any) {
    console.log("program body");

    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    // return this.http.post<any>(environment.baseUrl + `/api/rebate/agreement/fetch`, statusObject, {
    // if(vendor_id){

    // }
    return this.http.post<any>(environment.baseUrl + `/api/rebate/vendorprograms/${vendor_id}`, obj, {
    // `/api/associate/detail/${vendor_id}`,
    // http.post(`${this.environment.baseUrl}` + `/create`, {selectedTable,documents,empList})}
    // return this.http.get<any>(`${this.environment.baseUrl}` + `/api/rebate/vendorprograms/`+vendor_id, statusObject, {
    headers,
    });
  }

  updatedAgreementStatus(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/rebate/agreement`, body, {
      headers,
    });
  }

  checkIsRejectedData(statusObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate/agreement/approval/validation`, statusObject, {
      headers,
    });
  }

  rebateLibFileDownload(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(
      environment.baseUrl + '/api/rebate-library/file/download',
      body,
      { headers, responseType: 'blob' as 'json' }
    );
  }


  rebateAgreementList() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/rebate_library/supplier/rebate_agreement/list`,
      { headers }
    );
  }

  saveRebateAgreement(baseObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate_library/supplier/rebate_agreement/select`, baseObject, {
      headers,
    });
  }


  uploaRebatedAgreement(fileObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate_library/supplier/rebate_agreement/upload`, fileObj, {
      headers,
    });
  }

  reUploaRebatedAgreement(fileObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate_library/supplier/rebate_agreement/upload`, fileObj, {
      headers,
    });
  }

  chooseDistributors(distributorObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/basicinfo/distributor`, distributorObj, {
      headers,
    });
  }

  getCreateProgramsList() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/Creation/prerequisite`, {}, {
      headers,
    });
  }

  getCreateVendorsList() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + `/api/program/creation/vendorlist`, {
      headers,
    });
  }

  getAllDependentDropDownOfCreateProgram(obj: { userGroupType: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/form/dds`, obj, {
      headers,
    });
  }
  filterDropdownData(distributorObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    // return this.http.post<any>(environment.baseUrl + `/api/tenant/segments`, {group_type:'distributor'}, {
    //   headers,
    // })
  }
  saveBasicInfoForm(formValues: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program_creation/save`, formValues, {
      headers,
    });
  }

  getCreateProgramSegments() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    // return this.http.post<any>(environment.baseUrl + `/api/tenant/segments`, {group_type:'distributor'}, {
    //   headers,
    // });
  }

  getEditDataForProgram(body: { program_id: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/basicinfo/data`, body, {
      headers,
    });
  }

  getAlternateFlags(body: { program_id: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate/program/alternateflags`, body, {
      headers,
    });
  }

  saveChooseDistributorList(requestObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    // return this.http.post<any>(environment.baseUrl + `/api/tenant/segments`, {group_type:'distributor'}, {
    //   headers,
    // });
  }

  getMethod = (apiUrl: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + apiUrl, {
      headers,
    });
  }

  postMethod(apiUrl: any, requestObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + apiUrl, requestObj, {
      headers,
    });
  }

  patchMethod(apiUrl: any, requestObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + apiUrl, requestObj, {
      headers,
    });
  }

  fileDownload(apiUrl: any, requestObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(
      environment.baseUrl + apiUrl,
      requestObj,
      { headers, responseType: 'blob' as 'json' }
    );
  }

  saveDistributorBasicInfo(requestObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + '/api/program_creation/save', requestObj, {
      headers,
    });
  }

  deleteIndividualSegmentDistributor(body: { program_id: any; segments: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/basicInfo/remove/segments`, body, {
      headers,
    });
  }

  deleteAllSegmentsDistributors(body: { program_id: any; remove: string }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/basicInfo/remove/segment_distributor/all`, body, {
      headers,
    });
  }

  updateSegmentData(object: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/program/basicInfo/segments`, object, {
      headers,
    });
  }

  saveCalculationComplexComments(object: { program_id: any; complexityDiscription: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/program/calculation`, object, {
      headers,
    });
  }

  getBasicDetailCalculations(object: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate/program/data`, object, {
      headers,
    });
  }

  saveCalculationSegmentObj(object: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/program/calculation/update`, object, {
      headers,
    });
  }

  deleteAllCalculationSegmentsDistributors(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/calculation/payment_segment/delete`, body, {
      headers,
    });
  }

  getCatelogBrands(obj: { supplierId: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/supplier/product/catalog/brand`, obj, {
      headers,
    });
  }

  getCatelogCategories(brandReqObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/supplier/product/catalog/category`, brandReqObject, {
      headers,
    });
  }
  saveCatelogBrands(brandsObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/rebate/program/catalog_selection`, brandsObj, {
      headers,
    });
  }

  getAllCalculationCriteiraDropdown() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/calculation/nondirectpay/criteria`, {}, {
      headers,
    });
  }
  updateCriteriaData(finalObject : { criteria_mapping: any; flag_id: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/calculation/updateCriteriaData`, finalObject, {
      headers,
    });
  }

  saveCriteriaData(finalObject: { criteria_mapping: any; payment_criteria: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/program/calculation/nondirectpay/criteria`, finalObject, {
      headers,
    });
  }

  deleteCriteriaTier(obj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/program/calculation/nondirectpay/remove`, obj, {
      headers,
    });
  }

  getCategoriesForConditions(body: { program_id: number; deduction_type: string }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/special/deduction/value`, body, {
      headers,
    });
  }

  saveDeductionSegment(object: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/special/deduction/segment`, object, {
      headers,
    });
  }

  getDeductionTypeDropdownValues(body: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/special/deduction/type/dropdown`, body, {
      headers,
    });
  }
  deleteAllSpecialSegments = (body: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/special/deduction/segment/remove`, body, {
      headers,
    });
  }

  getBasicInfoDistributors(manualBaseLineObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/basicinfo/distributors`, manualBaseLineObject, {
      headers,
    });
  }

  saveBaseLineValues(saveBaseLineObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/special/deduction/segment`, saveBaseLineObject, {
      headers,
    });
  }

  getBaseLineDetails(viewBaseLineDataObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/special/manual/baseline/edit/prerequisite`, viewBaseLineDataObj, {
      headers,
    });
  }

  getDependancyList(payload: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program_creation/special_conditions/dependency/programlist`, payload, {
      headers,
    });
  }

  saveRebateDependancy(payload: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/program_creation/special_conditions/dependency`, payload, {
      headers,
    });
  }

  saveRebateConfigSegment(saveSegmentObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/program_creation/update/rebate_config`, saveSegmentObject, {
      headers,
    });
  }

  deleteRebateConfigSegments(deleteObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program_creation/rebate_config/delete`, deleteObj, {
      headers,
    });
  }

  getViewProgramDetails(object: any) {
    console.log("basic service",object)
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/view/data`, object, {
      headers,
    });
  }

  getProgramDetailsOverview(obj: { program_id: number }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate_library/program/details`, obj, {
      headers,
    });
  }

  editRebateProgram(obj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program_creation/edit`, obj, {
      headers,
    });
  }

  finishRebateProgram(obj: { programId: number }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program_creation/completion`, obj, {
      headers,
    });
  }

  cloneRebateProgram(obj: { programId: number }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/clone`, obj, {
      headers,
    });
  }

  activeRebateProgram(obj: { programId: number }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/program/activation`, obj, {
      headers,
    });
  }
  deActiveRebateProgram(Deactivation: { programId: number }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.patch<any>(environment.baseUrl + `/api/program/deactivation`, Deactivation, {
      headers,
    });
  }
  getChildValues(object: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/view/child/data`, object, {
      headers,
    });
  }

  checkNavigationEnabled(param: { programId: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate/program/catalog/continue`, param, {
      headers,
    });
  }

  saveIsDeductionOrNot(dedcutionType: string, programId: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/program/creation/special/deduction?deductiontype=${dedcutionType}&program_id=${programId}`,
      { headers }
    );
  }

  checkManualBaseLineAddedOrNot(param: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program_creation/special_conditions/manualbaseline/check`, param, {
      headers,
    });
  }

  completeProgram(programId: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/program/complete?program_id=${programId}`,
      { headers }
    );
  }

  getSupplierDashboardData(year: any,supplierId:any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/supplier/dashboard/summary?year=${year}&supplierId=${supplierId}`,
      { headers }
    );
  }

    getSupplierDistributors() {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.get<any>(
          environment.baseUrl +
          `/api/associate/dropdown?type=distributor`,
          { headers }
      );
    }

  getFinancialHealthGrpData(reqObject: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/supplier/finance/summary/grouping`, reqObject, {
      headers,
    });
  }

  getFinancialHealthGrpDistributorData = (reqObject: any) => {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.post<any>(environment.baseUrl + `/api/distributor/finance/summary/grouping`, reqObject, {
      headers,
    });
  }

  seenAllNotifactions() {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/email/notification/markAll`, {}, {
      headers,
    });
  }

    getSupplierGrowthOpportunitySummary(globalYears: any,supplierId:any) {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.get<any>(
          environment.baseUrl +
          `/api/supplier/growth/opportunity/summary?year=${globalYears}&supplierId=${supplierId}`,
          { headers }
      );
    }

    getDataOfGrowthGrpDetails(obj: any) {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.post<any>(environment.baseUrl + `/api/supplier/growth/opportunity`, obj, {
        headers,
      });
    }

  getSupplierHierarchy(loggedInSupplierId: any, selctedGlobalYear: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.get<any>(
        environment.baseUrl +
        `/api/supplier/dashboard/hierarchy?supplierId=${loggedInSupplierId}&year=${selctedGlobalYear}`,
        { headers }
    );
  }

    getUnseenNotifaction(obj: { userGroupId: any }) {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.post<any>(environment.baseUrl + `/api/notification/unseen`, obj, {
        headers,
      });
    }

  getTopRebateSpendingReduced(object: any,dataUserType:any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/finance/distributer/topspendingtopreduced`, object, {
      headers,
    });
  }

    getReportHistory(param: any) {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.post<any>(environment.baseUrl + `/api/report/export/history/fetch`, param, {
        headers,
      });
    }

    downloadReportFile(obj: { export_type: any; file_date: any }) {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.post<any>(environment.baseUrl + `/api/export`, obj, {
        headers,
      });
    }

  saveReportHistory(saveHistoryObj: { file_date: any; file_type: string; status: string; row_count: any }) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/report/export/history`, saveHistoryObj, {
      headers,
    });
  }

    getBgDashboardDetails(yearObj: { year: any }) {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.post<any>(environment.baseUrl + `/api/bgadmin/overview`, yearObj, {
        headers,
      });
    }

  getTopSellingRebatePaid(object: { rebateType: any; year: any; limit: number }, valueSelectedType: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/finance/supplier/topsellingrebatepaid`, object, {
      headers,
    });
  }

    getCalculationEditDistributors(calObj: any) {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.post<any>(environment.baseUrl + `/api/program/basicinfo/directpaydistributors`, calObj, {
        headers,
      });
    }

  getSpecialConditionsEditDistributors(specialConditionObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/basicinfo/specialconditiondistributors`, specialConditionObj, {
      headers,
    });
  }

    saveProductData(saveProductObj: any) {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.post<any>(environment.baseUrl + `/api/supplier/product/catalog/products/save`, saveProductObj, {
        headers,
      });
    }

  deleteProgram(programObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/delete`, programObj, {
      headers,
    });
  }

  getRebateOptimizationRebateTypes(obj:any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/form/dds`, obj, {
      headers,
    });
  }

  checkActiveProductCatlogByYear(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/validatenewprogramrequirements`, obj, {
      headers,
    });
  }

  checkActiveProductCatlogByDate(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/validatecatalogrequirements`, obj, {
      headers,
    });
  }


  flushCache = (id:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.get<any>(
      environment.baseUrl +
      `/api/program/creation/distributor/cache/flush?programId=${id}`,
      { headers }
    );
  }

  saveEditDistributorsSearch(calObj: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program/creation/distributor/search/cache`, calObj, {
      headers,
    });
  }

  getLatestPayout(obj:any){
      this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/payoutmanagement/overview`, obj, {
      headers,
    });
  }

  fetchPayoutDetails(payoutTicketNo:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/payoutmanagement/payoutticket`, {payoutTicketNo}, {
      headers,
    });
  }

  fetchPayoutLibrary(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/payout/library`, obj, {
      headers,
    });
  }

  fetchPayoutTicketDetails(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/payoutmanagement/payoutticketdetails`, obj, {
      headers,
    });
  }

  fetchDistributorPayoutTicketDetails(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/payout/eventdetail`, obj, {
      headers,
    });
  }

  fetchDistributorPayoutEventSummary(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/payout/eventsummary`, obj, {
      headers,
    });
  }

  createPayout(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/payoutmanagement/createpayoutevent`, obj, {
      headers,
    });
  }

  fetchProgramType(){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.get<any>(environment.baseUrl + `/api/common/programtypes`, { headers } );
  }

  fetchAssessment(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/payoutmanagement/assessment`, obj, {
      headers,
    });
  }

  fetchAssessmentHistory(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/payoutmanagement/assessment/history`, obj, {
      headers,
    });
  }

  uploadPayoutFile(body: any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/payoutmanagement/uploadpayout`, body, {
      headers,
    });
  }

  uploadAssessentFile(body: any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/payoutmanagement/uploadassessment`, body, {
      headers,
    });
  }

  getDistributorHierarchy(loggedInSupplierId: any, selctedGlobalYear: any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
      return this.http.get<any>(environment.baseUrl +
        `/api/distributor/dashboard/hierarchy?year=${selctedGlobalYear}&distributorId=${loggedInSupplierId}`,
        { headers }
    );
  }

  fetchDistributorFinanceTrendData( year: any, period: any,distributorId:any,supplierId:any ) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.get<any>(
        environment.baseUrl +
        `/api/distributor/finance/rebate/trend?year=${year}&distributorId=${distributorId}&period=${period}&supplierId=${supplierId}`,
        { headers }
    );
  }

  getFinancialDistributorSummary = (year: any,distributorId:any,supplierId:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.get<any>(
        environment.baseUrl +
        `/api/distributor/finance/summary?year=${year}&distributorId=${distributorId}&supplierId=${supplierId}`,
        { headers }
    );
  }

  getDistributorFinacialHealthDashboard = (obj:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/financial/health/overview`, obj, {
      headers,
    });
  }

  saveDistributorDisputeTicket = (obj:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/dispute/tickets/raise`, obj, {
      headers,
    });
  }

  getDistributorDisputeSummary = (obj:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set('Authorization', 'Bearer ' + this.validToken);
    return this.http.post(environment.baseUrl +
        `/api/bgdashboard/dispute/tickets/summary`, obj,{ headers });
  }

  fetchDistributorRoiOpportunityProgramDetails(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/rebateoptimization/roi/growthprograms/detail`, obj, {
      headers,
    });
  }

  fetchSupplierTransactionData(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/finance/supplier/transaction/detail`, obj, {
      headers,
    });
  }
  getVendorROIExportData(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/bgdashboard/finance/vendorROI`, obj, {
      headers,
    });
  }

  getDistributorRebateOptiSummary(obj: any) {
      this.validToken = localStorage.getItem('token');
      const headers = new HttpHeaders().set(
          'Authorization',
          'Bearer ' + this.validToken
      );
      return this.http.post<any>(environment.baseUrl + `/api/distributor/rebateoptimization/summary`, obj, {
        headers,
      });
    }

  getRebateOptimizationROISummary = (obj:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/rebateoptimization/roi/summary`, obj, {
      headers,
    });
  }

  getRebateROIPrograms = (obj:any)=>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/rebateoptimization/roi/growthsummary`, obj, {
      headers,
    });
  }

  getROIAttainmentData = (obj:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/rebateoptimization/attainment`, obj, {
      headers,
    });
  }

  getAttainmentDropdown = () =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/rebateoptimization/roi/attaiments`, {}, {
      headers,
    });
  }

  getDistributorRebateOptimizationDashboard = (obj:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/rebate/optimization/overview`, obj, {
      headers,
    });

  }

  getAttainmentData = (obj:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/rebateoptimization/roi/growthprograms`, obj, {
      headers,
    });
  }

  getTierAndCriteriaDataBasedOnAltFlag = (obj:any)=>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate/program/alternaterebateflag`, obj, {
      headers,
    });
  }

  getRebateProgramList = (payload:any) =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(
        environment.baseUrl +
        `/api/bgdashboard/finance/supplier/rebateProgramList`,payload,
        { headers }
    );
  }

  getRebateTypeList = () =>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.get<any>(
        environment.baseUrl +
        `/api/bgdashboard/finance/supplier/rebateTypeList`,
        { headers }
    );
  }

  getDeductionDataBasedOnAltFlag = (obj:any)=>{
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/program_creation/special_conditions/getAltFlagData`, obj, {
      headers,
    });
  }

  downloadSupplierAndDealerTransactionHistory(obj: { year: any ; export_type: any}) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/export/stream`, obj, {
      headers,
    });
  }

  getDealerPerfomance = (obj:any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/export/stream`, obj, {
      headers,
    });
  }

  deleteDraftProgram(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/rebate_library/program/delete`, obj, {
      headers,
    });
  }

  downloadDealersNeedOptimization(obj:any) {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/export/stream`, obj, {
      headers,
    });
  }

  getDealerExportData(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/rebateoptimization/roi/growthprograms/export`, obj, {
      headers,
    });
  }

  getParentPrograms(obj:any){
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
        'Authorization',
        'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/rebateoptimization/parentprograms`, obj, {
      headers,
    });
  }

  getDealerPerformance = (dealerObj: any) => {
    this.validToken = localStorage.getItem('token');
    const headers = new HttpHeaders().set(
      'Authorization',
      'Bearer ' + this.validToken
    );
    return this.http.post<any>(environment.baseUrl + `/api/distributor/rebateoptimization/performance`, dealerObj, {
      headers,
    });
  }
}


