import { TestBed } from '@angular/core/testing';

import { RebateNotifierService } from './rebate-notifier.service';

describe('RebateNotifierService', () => {
  let service: RebateNotifierService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RebateNotifierService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
