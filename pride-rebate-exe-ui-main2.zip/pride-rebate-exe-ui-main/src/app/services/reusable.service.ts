import { Injectable } from '@angular/core';
import { CONSTANTS, UserType } from '../helpers/constants';
import { get as _get, reduce as _reduce, isEqual as _isEqual, isEmpty as _isEmpty } from 'lodash';
import * as moment from 'moment';
@Injectable({
  providedIn: 'root'
})
export class ReusableService {
  private timer: any;
  globalDataList:any=[]
  globalUnSelected:any=[]
  globalSelected:any=[]
  globalUnSelectedDistributors:any=[]
  globalCategoriesSelected:any=[]
  constructor() { }


  /**
   * throttles the passed function
   * @param fn function to throttle
   */
  throttle(fn: any, delay: number = CONSTANTS.downloadThrottleDelay) {
    if(this.timer) {
      return;
    }

    this.timer = setTimeout(() => {
      fn();
      this.timer = undefined;
    }, delay);
  }

  /**
   * Converts number to show in currency format
   *
   * @param value to format
   * @returns formatted value
   */
  significantNumber(value: number): any {
    return new Intl.NumberFormat('en-US', {
      //@ts-ignore
      // notation: "compact",
      // compactDisplay: "short",
     maximumSignificantDigits: 10,
      style: "currency",currency: "USD",
    }).format(value);
  }

  fixedDecimalValue = (data:any) =>{
    if(data){
      if(!Number.isInteger(data)){
        return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed();
      }else{
        return data
      }
    }
  }

  /**
   * @param fileType
   * @param userType
   * @returns mappingType
   */
  /*
  fileTypes: Product_Catalog, Summary_Files, Transaction_Files
  mappingType:
    ST --> Supplier Transaction
    SS --> Supplier Summary
    PC --> Product Catalog
    DT --> Distributor Transaction
    TV --> Tenant Verified
    XR --> Rebate Cross Reference
  */
  findMappingType(fileType: string, userType: string) {
    let mappingType;
    if(_isEqual(userType, UserType.Supplier)) {
      // ST --> Supplier Transaction
      // SS --> Supplier Summary
      // PC --> Product Catalog
      switch (fileType) {
        case 'Product_Catalog':
          mappingType = 'PC';
          break;

        case 'Summary_Files':
          mappingType = 'SS';
          break;

        case 'Transaction_Files':
          mappingType = 'ST';
          break;

        default:
          break;
      }

    } else if(_isEqual(userType, UserType.Distributor)) {
      // DT --> Distributor Transaction
      switch (fileType) {
        case 'Transaction_Files':
          mappingType = 'DT';
          break;

        default:
          break;
      }
    }
    return mappingType;
  }
   globalDataListArray = (value:any) =>{
    if(Array.isArray(value) && value.length==0){
      this.globalDataList = []
    }else{
      this.globalDataList.push(value)
    }
  }
  getGlobalDataList = () =>{
    return this.globalDataList
  }

  globalAddCategoriesList = (value:any) =>{
    if(Array.isArray(value) && value.length==0){
      this.globalCategoriesSelected = []
    }else{
      this.globalCategoriesSelected.push(value)
    }
  }
  getCategoryGlobalList = () =>{
    return this.globalCategoriesSelected
  }

  globalUnselectedList = (value:any)=>{
    if(Array.isArray(value) && value.length==0){
      this.globalUnSelected = []
    }else{
      this.globalUnSelected.push(value)
    }
  }
  getUnselectedList = () =>{
    return this.globalUnSelected
  }

  globalSelectedList = (value:any)=>{
    if(Array.isArray(value) && value.length==0){
      this.globalSelected = []
    }else{
      this.globalSelected.push(value)
    }
  }
  getSelectedList = () =>{
    return this.globalSelected
  }

  globalDistributorUnselected = (value:any) =>{
    if(Array.isArray(value) && value.length==0){
      this.globalUnSelectedDistributors = []
    }else{
      this.globalUnSelectedDistributors.push(value)
    }
  }
  globalDistributorUnselectedList = () =>{
    return this.globalUnSelectedDistributors
  }

  convertToCSV(objArray: any, headerList: any, isSerial=true) {
    let array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    let str = '';
    let row =isSerial ? 'S.No,':'';

    for (let index in headerList) {
      row += headerList[index] + ',';
    }
    row = row.slice(0, -1);
    str += row + '\r\n';
    for (let i = 0; i < array.length; i++) {
      let line;
      line = isSerial ? (i + 1) + '' :'';
      for (let index in headerList) {
        let head = headerList[index];

        line += isSerial ?',' + array[i][head]: array[i][head]+ ',';
      }
      if(!isSerial){
        line = line.slice(0, -1)
      };
      str += line + '\r\n';
    }
    return str;
  }

  formatDate = (date:any) => {
    return  moment.utc(date).local().format('YYYY-MM-DD')
  }

  formatDateToMTZ = (date:any) => {
    return moment(new Date(date)).format('MM/DD/YYYY');
  }

  roundOff(value:any){
    return Math.round(value)
  }

  significantNumber2(value: number): any {
    return new Intl.NumberFormat('en-US', {
      //@ts-ignore
      // notation: "compact",
      // compactDisplay: "short",
      // maximumSignificantDigits: 2,
      minimumFractionDigits: 0,
      //style: "currency",currency: "USD",
    }).format(value);
  }

  significantDecimalNumber2(value: number): any {
    return new Intl.NumberFormat('en-US', {
      //@ts-ignore
      // notation: "compact",
      // compactDisplay: "short",
      maximumSignificantDigits: 10,
      minimumFractionDigits: 0,
      //style: "currency",currency: "USD",
    }).format(value);
  }

}
