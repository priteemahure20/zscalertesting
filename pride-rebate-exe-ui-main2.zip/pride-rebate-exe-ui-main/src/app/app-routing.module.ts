import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserType } from './helpers/constants';
import { rbac } from './rbac/routes';
import { AuthGuardService as AuthGuard } from './services/auth-guard.service';
import { RoleGuardService as RoleGuard } from './services/role-guard.service';
import { LeaveGuardService as LeaveGuard } from './services/leave-guard.service';
import { AssociateCreateComponent } from './views/associate/associate-create/associate-create.component';
import { AssociateLibraryComponent } from './views/associate/associate-library/associate-library.component';
import { AssociateUserCreateComponent } from './views/associate/associate-user-create/associate-user-create.component';
import { AssociateUserManagementComponent } from './views/associate/associate-user-management/associate-user-management.component';
import { HomeComponent } from './views/home/home.component';
import { PageNotFoundComponent } from './views/page-not-found/page-not-found.component';
import { ResetPasswordComponent } from './views/reset-password/reset-password.component';
import { ResolverService as Resolver } from './services/resolver.service';
import {MyDashboardComponent} from './views/my-dashboard/my-dashboard.component';
import {FinancialHealthComponent} from './views/my-dashboard/supplier-dashboard/financial-health/financial-health.component';
import { RebateDetailsProgramComponent } from './views/rebate-management/financial-health/rebate-details-program/rebate-details-program.component';
import {GrowthOpportunityComponent} from './views/my-dashboard/supplier-dashboard/growth-opportunity/growth-opportunity.component';
import { OpportunityDetailsComponent } from './views/my-dashboard/supplier-dashboard/growth-opportunity/opportunity-details/opportunity-details.component';
import {PaymentsComponent} from './views/my-dashboard/supplier-dashboard/payments/payments.component';
import {RebateOptimizationComponent} from './views/rebate-management/rebate-optimization/rebate-optimization.component';
import {WeeklyLoginReportComponent} from './views/rebate-management/weekly-login-report/weekly-login-report.component';
import {BgFinancialHealthComponent} from './views/my-dashboard/bg-dashboard/bg-financial-health/bg-financial-health.component';
import { ReportGeneratorComponent } from './views/report-generator/report-generator.component';
import { DistributorFinancialHealthComponent } from './views/my-dashboard/distributor-dashboard/financial-health/distributor-financial-health.component';
import {
  TransactionDetailsComponent
} from './views/my-dashboard/distributor-dashboard/financial-health/transaction-details/transaction-details.component';
import {
  DistributorRebateOptimizationComponent
} from './views/my-dashboard/distributor-dashboard/distributor-rebate-optimization/distributor-rebate-optimization.component';
import {
  ROIOpportunitiesComponent
} from './views/my-dashboard/distributor-dashboard/distributor-rebate-optimization/roiopportunities/roiopportunities.component';
import { ProgramDetailsComponent } from './views/my-dashboard/distributor-dashboard/distributor-rebate-optimization/roiopportunities/program-details/program-details.component';
import { SupportComponent } from './views/support/support.component';


const routes: Routes = [
  { path: '', redirectTo: ':type/login', pathMatch: 'full' }, //remove once we get actual buying group name
  {
    path: ':type/login',
    loadChildren: () =>
      import('./views/login/login.module').then((m) => m.LoginModule),
  },
  { path: ':type/reset-password', component: ResetPasswordComponent },
  {
    path: ':type/home',
    component: HomeComponent,
    resolve: {
      data: Resolver
    },
    canActivate: [AuthGuard, RoleGuard],
    canDeactivate: [ LeaveGuard ],
    data: {
      roles: rbac.Home,
      userTypes: [UserType.Member, UserType.Supplier, UserType.Corporate],
    },
  },
  // {
  //   path: ':type/dashboard',
  //   loadChildren: () =>
  //     import('./views/dashboard/dashboard.module').then(
  //       (m) => m.DashboardModule
  //     ),
  //   canActivate: [AuthGuard, RoleGuard],
  //   data: {
  //     roles: [Role.Admin, Role.Dashboard],
  //     userTypes: [UserType.Member, UserType.Supplier],
  //   },
  // },
  // {
  //   path: ':type/patTool',
  //   loadChildren: () =>
  //     import('./views/pat-tool/pat-tool.module').then((m) => m.PatToolModule),
  //   canActivate: [AuthGuard, RoleGuard],
  //   data: {
  //     roles: [Role.Admin],
  //     userTypes: [UserType.Member, UserType.Supplier],
  //   },
  // },
  // {
  //   path: ':type/rebate-program',
  //   component: RebateProgramComponent,
  //   canActivate: [AuthGuard, RoleGuard],
  //   data: {
  //     roles: [Role.Admin],
  //     userTypes: [UserType.Member, UserType.Supplier],
  //   },
  // },
  // {
  //   path: ':type/supplier-classification',
  //   component: SupplierClassificationComponent,
  //   canActivate: [AuthGuard, RoleGuard],
  //   data: {
  //     roles: [Role.Admin],
  //     userTypes: [UserType.Member, UserType.Supplier],
  //   },
  // },
  // {
  //   path: ':type/product-categorization',
  //   loadChildren: () =>
  //     import(
  //       './views/member-product-categorization/member-product-categorization.module'
  //     ).then((m) => m.MemberProductCategorizationModule),
  //   canActivate: [AuthGuard, RoleGuard],
  //   data: {
  //     roles: [Role.Admin],
  //     userTypes: [UserType.Member, UserType.Supplier],
  //   },
  // },
  {
    path: ':type/file-management',
    loadChildren: () =>
      import('./views/file-management/file-management.module').then(
        (m) => m.FileManagementModule
      ),
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.FileManagement,
      userTypes: [ UserType.Corporate],
    },
  },
  // {
  //   path: ':type/user-mgmt',
  //   loadChildren: () =>
  //     import('./views/user-mgmt/user-mgmt.module').then(
  //       (m) => m.UserMgmtModule
  //     ),
  //   canActivate: [AuthGuard, RoleGuard],
  //   data: {
  //     roles: [Role.Admin],
  //     userTypes: [UserType.Member, UserType.Supplier],
  //   },
  // },
  {
    path: ':type/associate-library',
    component: AssociateLibraryComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.AssociateLibrary,
      userTypes: [UserType.Corporate],
    },
  },
  {
    path: ':type/report-generator',
    component: ReportGeneratorComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.ReportGenerator,
      userTypes: [UserType.Corporate],
    },
  },
  {
    path: ':type/associate/create',
    component: AssociateCreateComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.AssociateCreate,
      userTypes: [UserType.Corporate],
    },
  },
  {
    path: ':type/associate/edit/:associateId',
    component: AssociateCreateComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.AssociateEdit,
      userTypes: [UserType.Corporate],
    },
  },
  {
    path: ':type/associate-users',
    component: AssociateUserManagementComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.AssociateUserManagement,
      userTypes: [UserType.Member, UserType.Supplier, UserType.Corporate],
    },
  },
  {
    path: ':type/associate-createUser',
    component: AssociateUserCreateComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.AssociateUserCreate,
      userTypes: [UserType.Member, UserType.Supplier, UserType.Corporate],
    },
  },
  {
    path: ':type/faq-support',
    component: SupportComponent,
    // canActivate: [AuthGuard, RoleGuard],
    // data: {
    //   roles: [Role.Admin, Role.Dashboard],
    //   userTypes: [UserType.Member, UserType.Supplier],
    // },
  },
  {
    path: ':type/my-dashboard/supplier/financial-health',
    component: FinancialHealthComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.myDashboard,
      userTypes: [UserType.Supplier],
    },
  },
  {
    path: ':type/my-dashboard/distributor/financial-health',
    component: DistributorFinancialHealthComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.myDashboard,
      userTypes: [UserType.Distributor],
    },
  },
  {
    path: ':type/my-dashboard/supplier/growth-opportunity',
    component: GrowthOpportunityComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.myDashboard,
      userTypes: [UserType.Supplier],
    },
  },
  {
    path: ':type/my-dashboard/supplier/growth-opportunity/:programsType',
    component: OpportunityDetailsComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.myDashboard,
      userTypes: [UserType.Supplier],
    },
  },
  {
    path: ':type/my-dashboard/supplier/rebate-program-details',
    component: RebateDetailsProgramComponent,
    // canActivate: [AuthGuard, RoleGuard],
    // data: {
    //   roles: rbac.myDashboard,
    //   userTypes: [UserType.Corporate],
    // },
  },
  {
    path: ':type/my-dashboard/distributor/rebate-program-details',
    component: RebateDetailsProgramComponent,
    // canActivate: [AuthGuard, RoleGuard],
    // data: {
    //   roles: rbac.myDashboard,
    //   userTypes: [UserType.Corporate],
    // },
  },
  {
    path: ':type/my-dashboard/supplier/payments',
    component: PaymentsComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.myDashboard,
      userTypes: [UserType.Supplier],
    },
  },
  {
    path: ':type/my-dashboard/corporate/financial-health',
    component: BgFinancialHealthComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.FinancialHealth,
      userTypes: [UserType.Corporate],
    },
  },
  {
    path: ':type/my-dashboard/corporate/rebate-optimization',
    component: RebateOptimizationComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.RebateOptimization,
      userTypes: [UserType.Corporate],
    },
  },
  { path:':type/my-dashboard/corporate/weekly-login-report',
    component: WeeklyLoginReportComponent,
    canActivate: [AuthGuard, RoleGuard ],
    data: {
      roles: rbac.WeeklyLoginReport,
      userTypes: [ UserType.Corporate ],
    },
  },
  {
    path: ':type/my-dashboard/distributor/transaction-details',
    component: TransactionDetailsComponent,
    canActivate: [AuthGuard, RoleGuard],
    // data: {
    //   roles:'',
    //   userTypes: [],
    // },
  },
  {
    path: ':type/my-dashboard',
    component: MyDashboardComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.myDashboard,
      userTypes: [UserType.Member,UserType.Supplier, UserType.Corporate],
    },
  },
  {
    path: ':type/my-dashboard/distributor/rebate-optimization',
    component: DistributorRebateOptimizationComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.DistributorRebateOptimization,
      userTypes: [UserType.Distributor],
    },
  },
  {
    path: ':type/my-dashboard/distributor/rebate-optimization/ROIOpportunities',
    component: ROIOpportunitiesComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.DistributorRebateOptimization,
      userTypes: [UserType.Distributor],
    },
  },
  {
    path: ':type/my-dashboard/distributor/rebate-optimization/program-details',
    component: ProgramDetailsComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.DistributorRebateOptimization,
      userTypes: [UserType.Distributor],
    },
  },
  {
    path: ':type/rebateManagement',
    loadChildren: () =>
      import('./views/rebate-management/rebate-management.module').then(
        (m) => m.RebateManagementModule
      ),
  },
  {
    path: ':type/payoutManagement',
    loadChildren: () =>
      import('./views/payout-management/payout-management.module').then(
        (m) => m.PayoutManagementModule
      ),
      canActivate: [AuthGuard, RoleGuard],
      data: {
        roles: rbac.RebateOptimizationDealr,
        userTypes: [UserType.Corporate, UserType.Member],
      },
  },
  { path: ':type/payment', 
    loadChildren: () => import('./views/payment/payment-bg/payment-bg.module').then(m => m.PaymentBgModule),
    canActivate: [AuthGuard, RoleGuard],
    data: {
      roles: rbac.RebateOptimizationDealr,
      userTypes: [UserType.Corporate, UserType.Member],
    },
  },
  {
    path: '**',
    pathMatch: 'full',
    component: PageNotFoundComponent,
    canActivate: [AuthGuard],
  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, scrollPositionRestoration: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
