import { get as _get } from 'lodash';
import { cleanEntityData } from 'src/app/helpers/commonUtils';
import {FormControl, Validators} from '@angular/forms';
import * as moment from 'moment';

interface AssociateData{
    data: any,
    configureRebate: number,
    configurePayment: number,
    is_hq: number,
    type: string

}



const mapAssociateCreateData = (data: any, is_hq: boolean, configurePayment: number, configureRebate: number,  type: string) => cleanEntityData({
    group_name: _get(data, 'associateName'),
    gp_id: _get(data, 'associateId'),
    group_id: _get(data, 'associatePId'),
    active_flag:_get(data, 'active_flag'),
    user_group_id: _get(data, 'user_group_id'),
    group_type: type,
    associate_level: _get(data, 'hierarchyLevel'),
    hq_flag: is_hq,
    group_parent_id: _get(data, 'parentLink'),
    email: _get(data, 'emailId'),
    title: _get(data, 'title'),
    firstName: _get(data, 'firstName'),
    lastName: _get(data, 'lastName'),
    address: _get(data, 'address'),
    city: _get(data, 'city'),
    state: _get(data, 'state'),
    zip: _get(data, 'zip'),
    rebateType: _get(data, 'rebateType'),
    segments: _get(data, 'segments'),
    configurePayment,
    configureRebate
});

const mapDistributorAssociateCreateData = (data: any, is_hq: boolean,   type: string) => cleanEntityData({
    group_name: _get(data, 'associateName'),
    gp_id: _get(data, 'associateId'),
    group_id: _get(data, 'associatePId'),
    active_flag:_get(data, 'active_flag'),
    group_type: type,
    user_group_id: _get(data, 'user_group_id'),
   user_id: _get(data,'user_id'),
    associate_level: _get(data, 'hierarchyLevel'),
    hq_flag: is_hq,
    group_parent_id: _get(data, 'parentLink'),
    email: _get(data, 'emailId'),
    title: _get(data, 'title'),
    firstName: _get(data, 'firstName'),
    lastName: _get(data, 'lastName'),
    address: _get(data, 'address'),
    city: _get(data, 'city'),
    state: _get(data, 'state'),
    zip: _get(data, 'zip'),
    rebateType: _get(data, 'rebateType'),
    segments: _get(data, 'segments'),
    industry: _get(data, 'industry'),
    tier: _get(data, 'tier'),
    location: _get(data, 'location'),
    annualRevenue: _get(data, 'annualRevenue')


});
const mapCreateProgramData = (data:any)=>cleanEntityData({
  selectedvendor:_get(data, 'selectVendor[0][user_group_id]'),
   programFor:_get(data, 'programFor'),
   rebateType:_get(data, 'rebateType'),
   rebateCalculatedOn:_get(data, 'rebateCalculatedOn'),
   rebatePaidBack:_get(data, 'rebatePaidBack'),
    programStart:formatDate(_get(data, 'startDate')),
   programEnd:formatDate(_get(data, 'endDate')),
   autoRenewal:_get(data, 'autoRenewal')?"Y":"N",
   applicableFor:_get(data, 'applicableFor'),
   period:_get(data, 'period'),
   avgYear:_get(data,'avgYear'),
   manualBaseline:_get(data, 'mannualBaseLine')?"Y":"N",
   programName:_get(data, 'programName'),
   comments:_get(data, 'comments'),
  vendorsLevel:_get(data, 'selectVendorLevelFor'),
  alternateRebateFlag:_get(data, 'alternateRebateFlag')
})

const mapCreatePayout = (data:any)=>cleanEntityData({
    lastFileDate:formatDate(_get(data, 'lastFileDate')),
    programType:_get(data, 'programType').map((el:any)=>el['value']),
    exportTitle:_get(data, 'exportTitle')
 })

 const formatDate = (date:any) => {
    // return  moment.utc(date).local().format('YYYY-MM-DD')
    if(date){
        let dateValue =  moment(date,'YYYY-MM-DD')
        return  dateValue.toISOString(true).split("T")[0]
        
    }
}

export{
    mapAssociateCreateData,
    mapDistributorAssociateCreateData,
    mapCreateProgramData,
    mapCreatePayout
}
