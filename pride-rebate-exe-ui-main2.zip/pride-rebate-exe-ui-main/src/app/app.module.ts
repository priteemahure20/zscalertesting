import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './shared/shared.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginComponent } from './views/login/login.component';
import { ResetPasswordComponent } from './views/reset-password/reset-password.component';
import { PageNotFoundComponent } from './views/page-not-found/page-not-found.component';
import { NgxCsvParserModule } from 'ngx-csv-parser';
import { NgxNavbarModule } from 'ngx-bootstrap-navbar';
import { PasswordStrengthMeterComponent } from './common/password-strength-meter/password-strength-meter.component';
import { RebateProgramComponent } from './views/rebate-program/rebate-program.component';
import { SupplierClassificationComponent } from './views/supplier-classification/supplier-classification.component';
import { SupportComponent } from './views/support/support.component';
import { TermsConditionsComponent } from './common/terms-conditions/terms-conditions.component';
import { FaqComponent } from './views/support/faq/faq.component';
import { ContactUsComponent } from './views/support/contact-us/contact-us.component';
import { KBaseComponent } from './views/support/k-base/k-base.component';
import { CommonCompsModule } from './shared/common-comps.module';
import { AvatarModule } from 'ngx-avatar';
import { UpdatePasswordComponent } from './views/update-password/update-password.component';
import { InterceptorService } from './services/interceptor.service';
import { DashboardModule } from './views/dashboard/dashboard.module';
import { UpdateAllCategoariesComponent } from './common/update-all-categoaries/update-all-categoaries.component';
import { SpinnerService } from './services/spinner.service';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { NotificationsComponent } from './common/notifications/notifications.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { NgSelectModule } from '@ng-select/ng-select';
import { BnNgIdleService } from 'bn-ng-idle';
import { TitleCasePipe } from '@angular/common';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ToggleSwitchComponent } from './common/toggle-switch/toggle-switch.component';
import { InputFieldComponent } from './common/input-field/input-field.component';
import { ModelInputFieldComponent } from './common/model-input-field/model-input-field.component';
import { AssociateLibraryComponent } from './views/associate/associate-library/associate-library.component';
import { AssociateModule } from './views/associate/associate/associate.module';
import { AssociateCreateComponent } from './views/associate/associate-create/associate-create.component';
import { AssociateSupplierComponent } from './views/associate/associate-supplier/associate-supplier.component';
import { AssociateDistributorComponent } from './views/associate/associate-distributor/associate-distributor.component';
import { MessageModalComponent } from './common/message-modal/message-modal.component';
import { SuccessErrorModalComponent } from './common/success-error-modal/success-error-modal.component';
import { HomeComponent } from './views/home/home.component';
import { RebateNotifierComponent } from './common/rebate-notifier/rebate-notifier.component';
import { WarningModalComponent } from './common/warning-modal/warning-modal.component';
import { ReasonDialogComponent } from './common/reason-dialog/reason-dialog.component';
import {MultiSelectDropdownComponent} from './common/multi-select-dropdown/multi-select-dropdown.component';
import {NgMultiSelectDropDownModule} from 'ng-multiselect-dropdown';
import { MyDashboardComponent } from './views/my-dashboard/my-dashboard.component';
import { SupplierDashboardComponent } from './views/my-dashboard/supplier-dashboard/supplier-dashboard.component';
import {NgCircleProgressModule} from 'ng-circle-progress';
import { FinancialHealthComponent } from './views/my-dashboard/supplier-dashboard/financial-health/financial-health.component';
import { ChartComponent } from './views/my-dashboard/supplier-dashboard/financial-health/chart/chart.component';
import { ChartLeftControlsComponent } from './views/my-dashboard/supplier-dashboard/financial-health/chart/chart-left-controls/chart-left-controls.component';
import {MaterialModule} from './shared/material.module';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { DataListCardsComponent } from './common/data-list-cards/data-list-cards.component';
import { GrowthOpportunityComponent } from './views/my-dashboard/supplier-dashboard/growth-opportunity/growth-opportunity.component';
import { OpportunityDetailsComponent } from './views/my-dashboard/supplier-dashboard/growth-opportunity/opportunity-details/opportunity-details.component';
import {
  ProgramCompareComponent
} from './views/rebate-management/rebate-library/rebate-library-program-details/add-to-compare/program-compare/program-compare.component';
import { PaymentsComponent } from './views/my-dashboard/supplier-dashboard/payments/payments.component';
import { BgDashboardComponent } from './views/my-dashboard/bg-dashboard/bg-dashboard.component';
import { BgFinancialHealthComponent } from './views/my-dashboard/bg-dashboard/bg-financial-health/bg-financial-health.component';
import {OverviewComponent} from './views/rebate-management/financial-health/overview/overview.component';
import {GeomapComponent} from './common/geomap/geomap.component';
import {TopSummaryCardsComponent} from './views/rebate-management/financial-health/overview/top-summary-cards/top-summary-cards.component';
import {
  TopRebatePayingSuppliersComponent
} from './views/rebate-management/top-rebate-paying-suppliers/top-rebate-paying-suppliers.component';
import {RebateOptimizationComponent} from './views/rebate-management/rebate-optimization/rebate-optimization.component';
import {ProgramTypeComponent} from './views/rebate-management/rebate-optimization/top-opportunities/program-type.component';
import {WeeklyLoginReportComponent} from './views/rebate-management/weekly-login-report/weekly-login-report.component';
import {
  DistributorsOptimizationComponent
} from './views/rebate-management/rebate-optimization/distributors-optimization/distributors-optimization.component';
import {PurchaseSalesComponent} from './views/rebate-management/rebate-optimization/purchase-sales/purchase-sales.component';
import {SupplierWDataComponent} from './views/rebate-management/financial-health/overview/supplier-w-data/supplier-w-data.component';
import {SupplierWithoutDataComponent} from './views/rebate-management/supplier-without-data/supplier-without-data.component';
import {TopRebateComponent} from './views/rebate-management/financial-health/overview/top-rebate/top-rebate.component';
import { ReportGeneratorComponent } from './views/report-generator/report-generator.component';
import { ExportModalComponent } from './views/report-generator/export-modal/export-modal.component';
import { SwitchUserComponent } from './views/switch-user/switch-user.component';
import { SucessMessageModalComponent } from './common/sucess-message-modal/sucess-message-modal.component';
import { DistributorDashboardComponent } from './views/my-dashboard/distributor-dashboard/distributor-dashboard.component';
import { DistributorFinancialHealthComponent } from './views/my-dashboard/distributor-dashboard/financial-health/distributor-financial-health.component';
import { TransactionDetailsComponent } from './views/my-dashboard/distributor-dashboard/financial-health/transaction-details/transaction-details.component';
import { RaiseDisputeComponent } from './views/my-dashboard/distributor-dashboard/financial-health/transaction-details/raise-dispute/raise-dispute.component';
import { DistributorRebateOptimizationComponent } from './views/my-dashboard/distributor-dashboard/distributor-rebate-optimization/distributor-rebate-optimization.component';
import {NgxSliderModule} from '@angular-slider/ngx-slider';
import { ROIOpportunitiesComponent } from './views/my-dashboard/distributor-dashboard/distributor-rebate-optimization/roiopportunities/roiopportunities.component';
import { VerticalChordsComponent } from './common/vertical-chords/vertical-chords.component';
import { ProgramDetailsComponent } from './views/my-dashboard/distributor-dashboard/distributor-rebate-optimization/roiopportunities/program-details/program-details.component';
import {MatButtonToggleModule} from '@angular/material/button-toggle';

import {referrerCheckerProvider} from './referrer-checker'
import { ExcludeConfigurationModalComponent } from './views/rebate-management/supplier-rebate-mgmt/special-conditions/manual-base-line/exclude-configuration-modal/exclude-configuration-modal.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ResetPasswordComponent,
    PageNotFoundComponent,
    PasswordStrengthMeterComponent,
    RebateProgramComponent,
    SupplierClassificationComponent,
    SupportComponent,
    TermsConditionsComponent,
    FaqComponent,
    ContactUsComponent,
    KBaseComponent,
    UpdatePasswordComponent,
    UpdateAllCategoariesComponent,
    NotificationsComponent,
    MessageModalComponent,
    ExcludeConfigurationModalComponent,
    SuccessErrorModalComponent,
    HomeComponent,
    RebateNotifierComponent,
    WarningModalComponent,
    ReasonDialogComponent,
    MyDashboardComponent,
    SupplierDashboardComponent,
    FinancialHealthComponent,
    DataListCardsComponent,
    ChartComponent,
    ChartLeftControlsComponent,
    GrowthOpportunityComponent,
    OpportunityDetailsComponent,
    PaymentsComponent,
    BgDashboardComponent,
    BgFinancialHealthComponent,
    OverviewComponent,
    GeomapComponent,
    TopSummaryCardsComponent,
    TopRebatePayingSuppliersComponent,
    RebateOptimizationComponent,
    ProgramTypeComponent,
    WeeklyLoginReportComponent,
    DistributorsOptimizationComponent,
    PurchaseSalesComponent,
    SupplierWDataComponent,
    SupplierWithoutDataComponent,
    SupplierWDataComponent,
    TopRebateComponent,
    ReportGeneratorComponent,
    ExportModalComponent,
    SwitchUserComponent,
    SucessMessageModalComponent,
    DistributorDashboardComponent,
    DistributorFinancialHealthComponent,
    TransactionDetailsComponent,
    RaiseDisputeComponent,
    DistributorRebateOptimizationComponent,
    ROIOpportunitiesComponent,
    ProgramDetailsComponent,
   
    // ToggleSwitchComponent,
    // InputFieldComponent,
    // SubmitButtonComponent,
    // AssociateSupplierComponent,
    // AssociateDistributorComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedModule,
    BrowserAnimationsModule,
    HttpClientModule,
    NgxCsvParserModule,
    NgxNavbarModule,
    CommonCompsModule,
    AvatarModule,
    PdfViewerModule,
    ScrollingModule,
    NgSelectModule,
    AssociateModule,
    MatAutocompleteModule,
    MatButtonToggleModule,
    NgCircleProgressModule.forRoot({
      // set defaults here
      radius: 100,
      outerStrokeWidth: 16,
      outerStrokeColor: "#0BA0C1",
      animationDuration: 300,
    }),
    InfiniteScrollModule,
    NgxSliderModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
    // referrerCheckerProvider, 
    SpinnerService,
    BnNgIdleService,TitleCasePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
