import * as  moment from 'moment';
import { get as _get, reduce as _reduce } from 'lodash';
import cleanDeep from 'clean-deep';
import {ExportModalComponent} from '../views/report-generator/export-modal/export-modal.component';

const dateTimeConversion = ({ dateTime }: any ) => moment(dateTime).format('MM-DD-YYYY HH:mm:ss');

const enrichArrDataToObj = ({ data, field = '' }: any ) => _reduce(data, (acc, val) => ({ ...acc, [_get(val, field)]: val }), {});

const cleanEntityData = (data: any) => {
    let cleanData = {};
    try {
        cleanData = cleanDeep(data);
    } catch (e) {
        // log error
    }
    return cleanData;
};

// check if xls also to be allowed
const isCSVFile=(file:any)=>{
    return file && (file.name.endsWith('.csv') || file.name.endsWith('.CSV') || file.name.endsWith('.xls') || file.name.endsWith('.XLS') ||  file.name.endsWith('.xlsx') || file.name.endsWith('.XLSX'))
    // if(file && (file.name.endsWith('.csv') || file.name.endsWith('.CSV') || file.name.endsWith('.xls') || file.name.endsWith('.XLS') ||  file.name.endsWith('.xlsx') || file.name.endsWith('.XLSX'))){
    //     return true
    // }else{
    //    return false
    // }
}
const isPngJpeg=(file:any)=>{
    return file && (file.name.endsWith('.jpg') || file.name.endsWith('.JPG') || file.name.endsWith('.PNG') || file.name.endsWith('.png'))
}

const isValidSize = (file:any) =>{
   let size= file.size/1024/1024;
   if(size>0 && size<=4){
       return true;
   }else{
    return false;
   }
}

const isValidSizePayout = (file:any) =>{
    let size= file.size/1024/1024;
    if(size>0 && size<4){
        return true;
    }else{
     return false;
    }
 }


const getLastUpdatedDate = () =>{
    let modifedDate = localStorage.getItem('lastUpdatedDate');
    if(modifedDate){
      let lastUpdatedDate = moment(modifedDate,"YYYYMMDD")
        return lastUpdatedDate.format('MM/DD/YYYY')
    } else{
      return 'NA'
    }
}

const fixedDecimalValue = (data:any) =>{
    if(data){
        if(!Number.isInteger(data)){
            return (Math.floor(parseFloat(data) * Math.pow(10, 2)) / Math.pow(10, 2)).toFixed(2);
        }else{
            return data
        }
    }
}

// move this link from to config folder
const getPrivacyLink = () =>{
    return "https://www.tredence.com/privacy-policy"
}

const getTermsLink = () =>{
    return "https://www.rebate.ai/terms-conditions/"
}

const titlecase = (str: string | any[]) => {
    let upper = true;
    let newStr = "";
    for (let i = 0, l = str.length; i < l; i++) {
        if (str[i] == " ") {
        upper = true;
        newStr += " ";
        continue;
        }
        newStr += upper ? str[i].toUpperCase() : str[i].toLowerCase();
        upper = false;
    }
    return newStr;
}

const  checkNameLength = (name: any,length:number=10) => {
    if (name && name.length > length) {
      return name = name.substring(0, length) + "...";
    } else {
      return name
    }
}

const  checkSummaryLength = (name: any) => {
    if (name && name.length > 80) {
        return name = name.substring(0, 80) + "...";
    } else {
        return name
    }
}
const getEffectiveDate = (datumElement: any, datumElement2: any) => {
    let startDate:any = ''
    let endDate:any = ''
    if(datumElement){
        let formatDate =  moment(datumElement)
        startDate =formatDate.format('MM/DD/YYYY')+ ' - '
    }else{
        startDate = 'NA'+' - '
    }
    if(datumElement2){
        let formatDate =  moment(datumElement2)
        endDate = formatDate.format('MM/DD/YYYY')
    }else {
        endDate = 'NA'
    }
    return startDate + endDate
}
const downloadFile = (data: any, header: any, filename = 'data',csvData:any) => {
    let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {
        dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);

}
const criteriaBasedType = (name:any) =>{
  if(name && name.toLowerCase().includes('sales')){
    return '$'
  }else{
    return ''
  }
}



export {
    dateTimeConversion,
    enrichArrDataToObj,
    cleanEntityData,
    isCSVFile,
    isValidSize,
    isPngJpeg,
    getLastUpdatedDate,
    fixedDecimalValue,
    getPrivacyLink,
    getTermsLink,
    titlecase,
    checkNameLength,
    checkSummaryLength,
    getEffectiveDate,
    downloadFile,
  criteriaBasedType,
  isValidSizePayout
};
