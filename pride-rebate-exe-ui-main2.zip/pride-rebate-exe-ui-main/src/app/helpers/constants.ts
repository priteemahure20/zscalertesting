const CONSTANTS = Object.freeze({
    Frequency: {
        mth: 'mtd',
        qtr: 'qtd',
        ytd: 'ytd'
    },
    memberProductTableInternalLimit: 1500,
    tableLimit: 15,
    mpcNA: 'NA',
    mpcNone: 'None',
    error500: 'Something went wrong',
    sessionTimeoutLimit: 1800,
    excludeLoaderUrls: [], // implement in interceptor later
    downloadThrottleDelay: 2000
});

function generateArrayOfYears() {
    var max = new Date().getFullYear()
    var min = max - 9
    var years = []

    for (var i = min; i <= max; i++) {
      years.push(i)
    }
    return years;
}

const YEAR = generateArrayOfYears();

enum Role {
    Admin = 'ADMINISTRATION',
    Dashboard = 'DASHBOARD',
    SuperUser = 'SUPERUSER',
    SuperuserRebate = 'SUPERUSER_REBATE',
    SuperuserNonrebate = 'SUPERUSER_NONREBATE',
    ReportingLayerRebate = 'REPORTING_LAYER_REBATE',
    ReportingLayerNonrebate = 'REPORTING_LAYER_NONREBATE',
    DataLayerNonrebate = 'DATA_LAYER_NONREBATE',
    DataLayerRebate = 'DATA_LAYER_REBATE',
}

enum UserType {
    Supplier = 'SUPPLIER',
    Member = 'DEALER',
    Distributor = 'DEALER',
    Corporate = 'CORPORATE',
}
enum RebateGovernanceRequestStatus {
    ACTIVATE = 'activate',
    DEACTIVATE = 'deactivate',
    DRAFT = 'draft',
    PENDING = 'pending',
    INREVIEW ='in review',
    UNLOCK = 'unlock'
}

enum UserTypeId {
    Corporate = 1,
    Supplier = 2,
    Member = 3
}

// MT FOR MEMBER TRANSACTION,
// ST FOR SUPPLIER TRANSACTION,
// TV FOR TENANT VERIFIED, XR FOR CROSS REF,
//PC FOR PRODUCT CATALOG
enum MappingFileType {
    MemberTransaction = 'DT',
    SupplierTransaction = 'ST',
    SupplierSummary = 'SS',
    TenantVerified = 'TV',
    CrossRef = 'XR',
    ProductCatalog = 'PC'
}

enum DataProvider {
    supplierTransaction = 1,
    bgTransaction = 3
}

enum Frequency {
    mth = 'mtd',
    ytd = 'ytd',
    qtr = 'qtd'
}
enum INDICATION {
    up = "../../assets/pngs/up-icon.png",
    down = "../../assets/pngs/down-icon.png",
    nutral = "../../assets/pngs/nutral-icon.png"
}

enum SPINNERHIDE {
    assets = "assets",
    masterDataAPI = "api/column-mapping/masterData?mappingType",
    columnMappingAPI = "api/transaction/column-mapping",
    summaryAPI = "api/bgdashboard/dispute/tickets/summary"
}

enum APIMETHOD {
    GET = "GET"
}

enum STATUS_CODE{
    NOT_FOUND = 404,
    CREATED = 201,
    SUCCESS = 200,
    UNAUTHORIZE = 401,
    SERVER_ERROR = 500,
}

const FILE_TYPE={
    "SUPPLIER_SUMMARY":"Summary Transaction",
    "PRODUCT_CATALOG":"Product Catalog",
    "SUPPLIER_TRANSACTION":"Detailed Transaction",
    "SAMPLE_SUPPLIER_SUMMARY":"Summary Transaction",
    "SAMPLE_PRODUCT_CATALOG":"Product Catalog",
    "SAMPLE_SUPPLIER_TRANSACTION":"Detailed Transaction"
}
const DBVALUES ={
  DefaultRebate:"$#@nulL@#$"

}

export {
    CONSTANTS,
    Role,
    UserType,
    UserTypeId,
    DataProvider,
    Frequency,
    MappingFileType,
    INDICATION,
    SPINNERHIDE,
    APIMETHOD,
    RebateGovernanceRequestStatus,
    STATUS_CODE,
    YEAR,
    FILE_TYPE,
  DBVALUES
}

export const CIRCULAR_PROGRESS_DEFAULTS = Object.freeze({
    radius: 100,
    responsive: false,
    maxPercent: 100,
    startFromZero: true,
    animationDuration: 1000,

    showTitle: true,
    showSubtitle: true,
    showUnits: false,
    titleFontSize: '26',
    subtitleFontSize: '14',
    titleFontWeight: '500',

    outerStrokeWidth: 12,
    showZeroOuterStroke: true,
    space: -12,
    showInnerStroke: true,
    innerStrokeWidth: 12,
    innerStrokeColor: '#EEEEEE',

    showBackground: true,
    backgroundColor: '#ffffff',
    backgroundStrokeWidth: 10,
    backgroundStroke: '#F8F8F8'
});
export const getYears =() =>{
  var max = new Date().getFullYear() +1;
  var min = max - 10
  var years = []

  for (var i = max; i >= min; i--) {
    years.push(i)
  }
  return years
}
