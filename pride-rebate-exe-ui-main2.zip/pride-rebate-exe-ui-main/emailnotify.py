import smtplib
import ssl
import os
from datetime import date
smtp_server = 'smtp-mail.outlook.com'
smtp_port = 587
smtp_username = 'rebate.support@tredence.com'
smtp_password = 'Tredjun24**'
rname =os.environ['RELEASE_DEFINITIONNAME']
rid = os.environ['RELEASE_REQUESTEDFOR']
rqid = os.environ['RELEASE_RELEASEID']
pday = date.today()
pname = os.environ['SYSTEM_TEAMPROJECT']


release_definition_name = os.environ.get('RELEASE_DEFINITIONNAME', '')
if 'PROD' in release_definition_name:
    env = 'PROD'
elif 'QA' in release_definition_name:
    env = 'QA'
elif 'UAT' in release_definition_name:
    env = 'UAT'
else:
    env = ''

# Email configuration
sender_email = 'rebate.support@tredence.com'
receiver_email = 'Rebate.ai-Pride-Centric@tredence.com'
email_subject = 'Rebate.ai-PRIDE-Centric Deployment Notification'
email_body = f"""
 <html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">

      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width,initial-scale=1">
          <meta name="x-apple-disable-message-reformatting">
          <title></title>
      </head>

      <body style="margin:0;padding:0;">
          <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;background:#ffffff;">
            <tr>
              <td align="center" style="padding:0;">
                <table role="presentation"
                    style="width:602px;border-collapse:collapse;border:1px solid #cccccc;border-spacing:0;text-align:left;">
                    <tr>
                        <td align="center" style="padding:40px 0 30px 0;background:#087e0f;">
                            <h2 style="font-size:40px; color:#ffffff; margin:0 0 20px 0;font-family:Arial,sans-serif;">
                                PRIDE {env}-UI-App
                                Deployment
                                Notification</h2>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:36px 30px 42px 30px;">
                          <table style="color:#153643;">
                             
                                <tr>
                                    <td>
                                        <h6 style="font-size:15px;margin:0 0 10px 0;font-family:Arial,sans-serif;">
                                           Deployment Summary</h6>
                                    </td>
                                </tr>
								<tr>
								<td style="font-size:13px;padding:5px 0 0 20px;font-family:Arial,sans-serif;"><b>Project Name:</b></td>
								  <td style="font-size:13px;padding:5px 0 0 20px;font-family:Arial,sans-serif;">{pname}</td>
								</tr>
								<tr>
								 <td style="font-size:13px;padding:5px 0 0 20px;font-family:Arial,sans-serif;"><b>Pipeline Run Date:</b></td>
								  <td style="font-size:13px;padding:5px 0 0 20px;font-family:Arial,sans-serif;">{pday}</td>
								</tr>
                                <tr>
                                    <td style="font-size:13px;padding:5px 0 0 20px;font-family:Arial,sans-serif"><b>Release Name</b></td>
                                    <td style="font-size:13px;padding:5px 0 0 20px;font-family:Arial,sans-serif">{rname}</td>
                                </tr>
                                <tr>
                                    <td style="font-size:13px;padding:5px 0 0 20px;font-family:Arial,sans-serif"><b>Release Requested By</b></td>
                                    <td style="font-size:13px;padding:5px 0 0 20px;font-family:Arial,sans-serif">{rid}</td>
                                </tr>
                            </table>
                            <table role="presentation"
                                style="width:100%;border-collapse:collapse;border:0;border-spacing:0;font-family:Arial,sans-serif">
                                <tr>
                                    <td style="padding:55px 0 5px 0;color:#153643;">
                                        <h6 style="font-size:14px;margin:0 0 3px 0;font-family:Arial,sans-serif;">
                                            Please review the detailed release pipeline information below:</h6>
                                        <p
                                            style="margin:0 0 10px 0;font-size:11px;line-height:15px;font-family:Arial,sans-serif;">
                                            You can access the pipeline run link below to view step-by-step task details and deployment information.
                                            </p>
                                        <p
                                            style="margin:0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">
                                            <b style="font-size:14px;font-family:Arial,sans-serif">Pipeline URL: </b><a href="https://dev.azure.com/Industrials-Org/Rebate.ai-PRIDE-Centric/_releaseProgress?_a=release-pipeline-progress&releaseId={rqid}"
                                                style="color:#087e0f;text-decoration:underline;">UI Deployment</a></p>
                                    </td>
                                </tr>

                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:30px;background:#087e0f;">
                            <table role="presentation"
                                style="width:100%;border-collapse:collapse;border:0;border-spacing:0;font-size:9px;font-family:Arial,sans-serif;">
                                <tr>
                                    <td style="padding:0;width:50%;" align="left">
                                        <p
                                            style="margin:0;font-size:14px;line-height:16px;font-family:Arial,sans-serif;color:#ffffff;">
                                            Rebate.ai DevOps Team - Tredence<br />
                                        </p>
                                    </td>

                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
          </tr>
        </table>
      </body>

      </html> 
"""
if os.environ.get('AGENT_JOBSTATUS') == 'Succeeded':
    # Create SSL context for secure email transmission
    context = ssl.create_default_context()

    # Construct email message
    email_message = f"""\
From: {sender_email}
To: {receiver_email}
Subject: {email_subject}
MIME-Version: 1.0
Content-type: text/html

{email_body}
"""

    # Send email using SMTP
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls(context=context)
        server.login(smtp_username, smtp_password)
        server.sendmail(sender_email, receiver_email, email_message)

    print('Email sent successfully.')
else:
    print(' Tasks failed.')