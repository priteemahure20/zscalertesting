var express = require('express');
var app = express();
const path = require('path');
require('dotenv').config(); // env setup using dotenv
const bodyParser = require('body-parser');
app.use(bodyParser.json());
const cors = require('cors');
const config = require("config");

// app.use(bodyParser.urlencoded({ 'extended': true }));
// app.use(bodyParser.json);

//for handeling CORS
app.use((req, res, next) => {
    
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept"
    );
    res.setHeader(
        "Access-Control-Allow-Methods",
        "GET, POST, PATCH, DELETE, OPTIONS"
    );
    res.setHeader('X-Frame-Options', 'sameorigin');
    res.setHeader("Content-Security-Policy", "frame-ancestors 'self'; script-src 'self'");
    res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload');
    next();
});
app.use(express.static(__dirname + '/public'));

var corsOptions = {
    origin: '*',
    optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
    methods: 'GET, POST, PATCH, DELETE, OPTIONS',
    allowedHeaders: 'X-Requested-With,content-type,Authorization',
    credentials: false
};


// crome Access-Control-Allow-Headers

app.use(cors(corsOptions));
app.options('*', cors());



// process.env['PORT'] = 5002;

require('./backend/routes/demo/demoRoutes.js')(app);


var server = app.listen(config.get('appPort'), () => {
    var host = server.address().address
    var port = server.address().port
    console.log(`Angular app is listening on ${host} and ${port}`);

});

module.exports = {
    server,
}