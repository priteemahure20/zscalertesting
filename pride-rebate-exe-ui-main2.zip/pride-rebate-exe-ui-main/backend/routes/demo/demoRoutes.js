

const { get: _get, isEmpty: _isEmpty } = require('lodash');




module.exports = function(app) {
    app.get('/api/test-health', async(req, res, next) => {
        res.status(200).send({ data: 'test okay' });
       
    });

    
    
    
}
